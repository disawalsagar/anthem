package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class PCADX_SCL_NAIC2018_IexStgTransformation_PAEXPHMCY {

  // load lock key and current data

  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()

  import spark.implicits._

  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_IexStgTransformation_PAEXPHMCY])
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val tblReq = dbProperties.getProperty("requested_pa.tbl")
  val tblApp = dbProperties.getProperty("approved_pa.tbl")
  val tblDen = dbProperties.getProperty("denied_pa.tbl")
  val tblStg = dbProperties.getProperty("denied_pa.tbl")
  val uri: String = dbProperties.getProperty("uri")
  val case_type_cd_val = Seq("MEH", "SUA")

  def sparkInIt() {

    // val objPCADX_SCL_NAIC_DataExtraction = new PCADX_SCL_NAIC_DataExtraction()

    val naic2018_mcas_hlthex_paexphmcy_reqstd_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_paexphmcy_reqstd_wrk")
    val naic2018_mcas_hlthex_paexphmcy_apprvd_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_paexphmcy_apprvd_wrk")
    val naic2018_mcas_hlthex_paexphmcy_denied_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_paexphmcy_denied_wrk")
    val stageTblData = populateStageTbl(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk, naic2018_mcas_hlthex_paexphmcy_apprvd_wrk, naic2018_mcas_hlthex_paexphmcy_denied_wrk)
    writeDataToHive(dbsg + ".naic2018_mcas_hlthiex_paexphmcy_stg", stageTblData)
    spark.close()
  }

  def writeDataToHive(tblName: String, finalDf: DataFrame) {
    finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
    println("Data added in stage table")
  }

  def readDataFromHive(tble: String): DataFrame = {
    val queryOutputTable = """SELECT * FROM """ + tble
    val tbl_data_df = spark.sql(queryOutputTable) //.na.fill("")
    logger.info("Read data from hive" + tble)
    tbl_data_df
  }

  def populateStageTbl(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk: DataFrame, naic2018_mcas_hlthex_paexphmcy_apprvd_wrk: DataFrame,
                       naic2018_mcas_hlthex_paexphmcy_denied_wrk: DataFrame): DataFrame = {
    val final_df = null
    val reqFinalDf = getRequestedData(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk)
    val appFinalDf = getApprovededData(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk, naic2018_mcas_hlthex_paexphmcy_reqstd_wrk)

    val denFinalDf = getDeniedData(naic2018_mcas_hlthex_paexphmcy_denied_wrk, naic2018_mcas_hlthex_paexphmcy_reqstd_wrk)
    val stageTblData = getFinalData(reqFinalDf, appFinalDf, denFinalDf).toDF()

    println(current_timestamp())

    var load_log_key = ""

    if (!naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.take(1).isEmpty) {
      load_log_key = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.select($"load_log_key").first.getString(0)
    }
    val finalStageTblData = stageTblData.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());

    finalStageTblData.show()
    finalStageTblData
  }

  def getRequestedData(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk: DataFrame): DataFrame = {

    val nbrpa_rqstd_total_ip = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year".alias("health_year_r1"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r1"),
        $"state".alias("state_r1"), $"in_exchange".alias("in_exchange_r1")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_total_ip"))

    val nbrpa_rqstd_total_ip_pcols = nbrpa_rqstd_total_ip.select($"health_year_r1", $"cmpny_cf_cd_r1", $"state_r1", $"in_exchange_r1")

    val nbrpa_rqstd_total_sgp = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year".alias("health_year_r2"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r2"),
        $"state".alias("state_r2"), $"in_exchange".alias("in_exchange_r2")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_total_sgp"))

    val nbrpa_rqstd_total_sgp_pcols = nbrpa_rqstd_total_sgp.select($"health_year_r2", $"cmpny_cf_cd_r2", $"state_r2", $"in_exchange_r2")

    val nbrpa_rqstd_catastrophic = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_prod_desc").like("%CATASTROPHIC%") &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year".alias("health_year_r3"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r3"),
        $"state".alias("state_r3"), $"in_exchange".alias("in_exchange_r3")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_catastrophic"))

    val nbrpa_rqstd_catastrophic_pcols = nbrpa_rqstd_catastrophic.select($"health_year_r3", $"cmpny_cf_cd_r3", $"state_r3", $"in_exchange_r3")

    val nbrpa_rqstd_total_ms_ip = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").equalTo("M") 
        //naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").equalTo("IN") 
        )
      .groupBy($"health_year".alias("health_year_r4"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r4"),
        $"state".alias("state_r4"), $"in_exchange".alias("in_exchange_r4")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_total_ms_ip"))

    val nbrpa_rqstd_total_ms_ip_pcols = nbrpa_rqstd_total_ms_ip.select($"health_year_r4", $"cmpny_cf_cd_r4", $"state_r4", $"in_exchange_r4")

    val nbrpa_rqstd_total_ms_sgp = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").equalTo("M") 
       // naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").equalTo("IN") 
        )
      .groupBy($"health_year".alias("health_year_r5"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r5"),
        $"state".alias("state_r5"), $"in_exchange".alias("in_exchange_r5")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_total_ms_sgp"))

    val nbrpa_rqstd_total_ms_sgp_pcols = nbrpa_rqstd_total_ms_sgp.select($"health_year_r5", $"cmpny_cf_cd_r5", $"state_r5", $"in_exchange_r5")

    val nbrpa_rqstd_bh_total_ip = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r6"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r6"),
        $"state".alias("state_r6"), $"in_exchange".alias("in_exchange_r6")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_bh_total_ip"))

    val nbrpa_rqstd_bh_total_ip_pcols = nbrpa_rqstd_bh_total_ip.select($"health_year_r6", $"cmpny_cf_cd_r6", $"state_r6", $"in_exchange_r6")

    val nbrpa_rqstd_bh_total_sgp = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r7"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r7"),
        $"state".alias("state_r7"), $"in_exchange".alias("in_exchange_r7")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_bh_total_sgp"))

    val nbrpa_rqstd_bh_total_sgp_pcols = nbrpa_rqstd_bh_total_sgp.select($"health_year_r7", $"cmpny_cf_cd_r7", $"state_r7", $"in_exchange_r7")

    val nbrpa_rqstd_bh_catastrophic = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_prod_desc").like("%CATASTROPHIC%") &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r8"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r8"),
        $"state".alias("state_r8"), $"in_exchange".alias("in_exchange_r8")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_bh_catastrophic"))

    val nbrpa_rqstd_bh_catastrophic_pcols = nbrpa_rqstd_bh_catastrophic.select($"health_year_r8", $"cmpny_cf_cd_r8", $"state_r8", $"in_exchange_r8")

    val nbrpa_rqstd_bh_total_ms_ip = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r9"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r9"),
        $"state".alias("state_r9"), $"in_exchange".alias("in_exchange_r9")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_bh_total_ms_ip"))

    val nbrpa_rqstd_bh_total_ms_ip_pcols = nbrpa_rqstd_bh_total_ms_ip.select($"health_year_r9", $"cmpny_cf_cd_r9", $"state_r9", $"in_exchange_r9")

    val nbrpa_rqstd_bh_total_ms_sgp = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r10"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r10"),
        $"state".alias("state_r10"), $"in_exchange".alias("in_exchange_r10")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_bh_total_ms_sgp"))

    val nbrpa_rqstd_bh_total_ms_sgp_pcols = nbrpa_rqstd_bh_total_ms_sgp.select($"health_year_r10", $"cmpny_cf_cd_r10", $"state_r10", $"in_exchange_r10")

    logger.info("Executing reqmaster in getRequestedData  JOIN")

    val reqmaster = (nbrpa_rqstd_bh_total_ms_sgp_pcols.union(nbrpa_rqstd_bh_total_ms_ip_pcols.union(nbrpa_rqstd_bh_catastrophic_pcols.union(nbrpa_rqstd_bh_total_sgp_pcols
      .union(nbrpa_rqstd_bh_total_ip_pcols.union(nbrpa_rqstd_total_ms_sgp_pcols.union(nbrpa_rqstd_total_ms_ip_pcols.union(nbrpa_rqstd_catastrophic_pcols
        .union(nbrpa_rqstd_total_sgp_pcols.union(nbrpa_rqstd_total_ip_pcols)))))))))).select(
      $"health_year_r10".alias("health_year"), $"cmpny_cf_cd_r10".alias("cmpny_cf_cd"), $"state_r10".alias("state"), $"in_exchange_r10".alias("in_exchange")).distinct

    val reqjoin1 = reqmaster.join(nbrpa_rqstd_total_ip, reqmaster("health_year") === nbrpa_rqstd_total_ip("health_year_r1") &&
      reqmaster("cmpny_cf_cd") === nbrpa_rqstd_total_ip("cmpny_cf_cd_r1") && reqmaster("state") === nbrpa_rqstd_total_ip("state_r1") &&
      reqmaster("in_exchange") === nbrpa_rqstd_total_ip("in_exchange_r1"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_rqstd_total_ip")

    val reqjoin2 = reqjoin1.join(nbrpa_rqstd_total_sgp, reqjoin1("health_year") === nbrpa_rqstd_total_sgp("health_year_r2") &&
      reqjoin1("cmpny_cf_cd") === nbrpa_rqstd_total_sgp("cmpny_cf_cd_r2") && reqjoin1("state") === nbrpa_rqstd_total_sgp("state_r2") &&
      reqjoin1("in_exchange") === nbrpa_rqstd_total_sgp("in_exchange_r2"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp")

    val reqjoin3 = reqjoin2.join(nbrpa_rqstd_catastrophic, reqjoin2("health_year") === nbrpa_rqstd_catastrophic("health_year_r3") &&
      reqjoin2("cmpny_cf_cd") === nbrpa_rqstd_catastrophic("cmpny_cf_cd_r3") && reqjoin2("state") === nbrpa_rqstd_catastrophic("state_r3") &&
      reqjoin2("in_exchange") === nbrpa_rqstd_catastrophic("in_exchange_r3"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_catastrophic")

    val reqjoin4 = reqjoin3.join(nbrpa_rqstd_total_ms_ip, reqjoin3("health_year") === nbrpa_rqstd_total_ms_ip("health_year_r4") &&
      reqjoin3("cmpny_cf_cd") === nbrpa_rqstd_total_ms_ip("cmpny_cf_cd_r4") && reqjoin3("state") === nbrpa_rqstd_total_ms_ip("state_r4") &&
      reqjoin3("in_exchange") === nbrpa_rqstd_total_ms_ip("in_exchange_r4"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_total_ms_ip")

    val reqjoin5 = reqjoin4.join(nbrpa_rqstd_total_ms_sgp, reqjoin4("health_year") === nbrpa_rqstd_total_ms_sgp("health_year_r5") &&
      reqjoin4("cmpny_cf_cd") === nbrpa_rqstd_total_ms_sgp("cmpny_cf_cd_r5") && reqjoin4("state") === nbrpa_rqstd_total_ms_sgp("state_r5") &&
      reqjoin4("in_exchange") === nbrpa_rqstd_total_ms_sgp("in_exchange_r5"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_total_ms_ip", $"nbrpa_rqstd_total_ms_sgp")

    val reqjoin6 = reqjoin5.join(nbrpa_rqstd_bh_total_ip, reqjoin5("health_year") === nbrpa_rqstd_bh_total_ip("health_year_r6") &&
      reqjoin5("cmpny_cf_cd") === nbrpa_rqstd_bh_total_ip("cmpny_cf_cd_r6") && reqjoin5("state") === nbrpa_rqstd_bh_total_ip("state_r6") &&
      reqjoin5("in_exchange") === nbrpa_rqstd_bh_total_ip("in_exchange_r6"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_total_ms_ip", $"nbrpa_rqstd_total_ms_sgp", $"nbrpa_rqstd_bh_total_ip")

    val reqjoin7 = reqjoin6.join(nbrpa_rqstd_bh_total_sgp, reqjoin6("health_year") === nbrpa_rqstd_bh_total_sgp("health_year_r7") &&
      reqjoin6("cmpny_cf_cd") === nbrpa_rqstd_bh_total_sgp("cmpny_cf_cd_r7") && reqjoin6("state") === nbrpa_rqstd_bh_total_sgp("state_r7") &&
      reqjoin6("in_exchange") === nbrpa_rqstd_bh_total_sgp("in_exchange_r7"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_total_ms_ip", $"nbrpa_rqstd_total_ms_sgp", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp")

    val reqjoin8 = reqjoin7.join(nbrpa_rqstd_bh_catastrophic, reqjoin7("health_year") === nbrpa_rqstd_bh_catastrophic("health_year_r8") &&
      reqjoin7("cmpny_cf_cd") === nbrpa_rqstd_bh_catastrophic("cmpny_cf_cd_r8") && reqjoin7("state") === nbrpa_rqstd_bh_catastrophic("state_r8") &&
      reqjoin7("in_exchange") === nbrpa_rqstd_bh_catastrophic("in_exchange_r8"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_total_ms_ip", $"nbrpa_rqstd_total_ms_sgp", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_catastrophic")

    val reqjoin9 = reqjoin8.join(nbrpa_rqstd_bh_total_ms_ip, reqjoin8("health_year") === nbrpa_rqstd_bh_total_ms_ip("health_year_r9") &&
      reqjoin8("cmpny_cf_cd") === nbrpa_rqstd_bh_total_ms_ip("cmpny_cf_cd_r9") && reqjoin8("state") === nbrpa_rqstd_bh_total_ms_ip("state_r9") &&
      reqjoin8("in_exchange") === nbrpa_rqstd_bh_total_ms_ip("in_exchange_r9"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_total_ms_ip", $"nbrpa_rqstd_total_ms_sgp", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_catastrophic", $"nbrpa_rqstd_bh_total_ms_ip")

    val reqFinalDf = reqjoin9.join(nbrpa_rqstd_bh_total_ms_sgp, reqjoin9("health_year") === nbrpa_rqstd_bh_total_ms_sgp("health_year_r10") &&
      reqjoin9("cmpny_cf_cd") === nbrpa_rqstd_bh_total_ms_sgp("cmpny_cf_cd_r10") && reqjoin9("state") === nbrpa_rqstd_bh_total_ms_sgp("state_r10") &&
      reqjoin9("in_exchange") === nbrpa_rqstd_bh_total_ms_sgp("in_exchange_r10"), "left_outer")
      .select($"health_year".alias("health_year_requested"), $"cmpny_cf_cd".alias("cmpny_cf_cd_requested"), $"state".alias("state_requested"), $"in_exchange".alias("in_exchange_requested"), $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_total_ms_ip", $"nbrpa_rqstd_total_ms_sgp", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_catastrophic", $"nbrpa_rqstd_bh_total_ms_ip", $"nbrpa_rqstd_bh_total_ms_sgp")

    reqFinalDf

  }

  def getApprovededData(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk: DataFrame, naic2018_mcas_hlthex_paexphmcy_reqstd_wrk: DataFrame): DataFrame = {

    val nbrpa_aprvd_total_ip = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").equalTo("IN") )
      .groupBy($"health_year".alias("health_year_r1"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r1"),
        $"state".alias("state_r1"), $"in_exchange".alias("in_exchange_r1")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_total_ip"))

    val nbrpa_aprvd_total_ip_pcols = nbrpa_aprvd_total_ip.select($"health_year_r1", $"cmpny_cf_cd_r1", $"state_r1", $"in_exchange_r1")

    val nbrpa_aprvd_total_sgp = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year".alias("health_year_r2"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r2"),
        $"state".alias("state_r2"), $"in_exchange".alias("in_exchange_r2")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_total_sgp"))

    val nbrpa_aprvd_total_sgp_pcols = nbrpa_aprvd_total_sgp.select($"health_year_r2", $"cmpny_cf_cd_r2", $"state_r2", $"in_exchange_r2")

    val nbrpa_aprvd_catastrophic = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_prod_desc").like("%CATASTROPHIC%") &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").equalTo("IN") )
      .groupBy($"health_year".alias("health_year_r3"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r3"),
        $"state".alias("state_r3"), $"in_exchange".alias("in_exchange_r3")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_catastrophic"))

    val nbrpa_aprvd_catastrophic_pcols = nbrpa_aprvd_catastrophic.select($"health_year_r3", $"cmpny_cf_cd_r3", $"state_r3", $"in_exchange_r3")

    val nbrpa_aprvd_total_ms_ip = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year".alias("health_year_r4"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r4"),
        $"state".alias("state_r4"), $"in_exchange".alias("in_exchange_r4")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_total_ms_ip"))

    val nbrpa_aprvd_total_ms_ip_pcols = nbrpa_aprvd_total_ms_ip.select($"health_year_r4", $"cmpny_cf_cd_r4", $"state_r4", $"in_exchange_r4")

    val nbrpa_aprvd_total_ms_sgp = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year".alias("health_year_r5"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r5"),
        $"state".alias("state_r5"), $"in_exchange".alias("in_exchange_r5")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_total_ms_sgp"))

    val nbrpa_aprvd_total_ms_sgp_pcols = nbrpa_aprvd_total_ms_sgp.select($"health_year_r5", $"cmpny_cf_cd_r5", $"state_r5", $"in_exchange_r5")

    val nbrpa_aprvd_bh_total_ip = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r6"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r6"),
        $"state".alias("state_r6"), $"in_exchange".alias("in_exchange_r6")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_bh_total_ip"))

    val nbrpa_aprvd_bh_total_ip_pcols = nbrpa_aprvd_bh_total_ip.select($"health_year_r6", $"cmpny_cf_cd_r6", $"state_r6", $"in_exchange_r6")

    val nbrpa_aprvd_bh_total_sgp = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r7"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r7"),
        $"state".alias("state_r7"), $"in_exchange".alias("in_exchange_r7")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_bh_total_sgp"))

    val nbrpa_aprvd_bh_total_sgp_pcols = nbrpa_aprvd_bh_total_sgp.select($"health_year_r7", $"cmpny_cf_cd_r7", $"state_r7", $"in_exchange_r7")

    val nbrpa_aprvd_bh_catastrophic = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_prod_desc").like("%CATASTROPHIC%") &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r8"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r8"),
        $"state".alias("state_r8"), $"in_exchange".alias("in_exchange_r8")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_bh_catastrophic"))

    val nbrpa_aprvd_bh_catastrophic_pcols = nbrpa_aprvd_bh_catastrophic.select($"health_year_r8", $"cmpny_cf_cd_r8", $"state_r8", $"in_exchange_r8")

    val nbrpa_aprvd_bh_total_ms_ip = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r9"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r9"),
        $"state".alias("state_r9"), $"in_exchange".alias("in_exchange_r9")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_bh_total_ms_ip"))

    val nbrpa_aprvd_bh_total_ms_ip_pcols = nbrpa_aprvd_bh_total_ms_ip.select($"health_year_r9", $"cmpny_cf_cd_r9", $"state_r9", $"in_exchange_r9")

    val nbrpa_aprvd_bh_total_ms_sgp = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r10"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r10"), $"state".alias("state_r10"), $"in_exchange".alias("in_exchange_r10"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_bh_total_ms_sgp"))

    val nbrpa_aprvd_bh_total_ms_sgp_pcols = nbrpa_aprvd_bh_total_ms_sgp.select($"health_year_r10", $"cmpny_cf_cd_r10", $"state_r10", $"in_exchange_r10")

    val appmaster = (nbrpa_aprvd_bh_total_ms_sgp_pcols.union(nbrpa_aprvd_bh_total_ms_ip_pcols.union(nbrpa_aprvd_bh_catastrophic_pcols.union(nbrpa_aprvd_bh_total_sgp_pcols
      .union(nbrpa_aprvd_bh_total_ip_pcols.union(nbrpa_aprvd_total_ms_sgp_pcols.union(nbrpa_aprvd_total_ms_ip_pcols.union(nbrpa_aprvd_catastrophic_pcols
        .union(nbrpa_aprvd_total_sgp_pcols.union(nbrpa_aprvd_total_ip_pcols)))))))))).select(
      $"health_year_r10".alias("health_year"), $"cmpny_cf_cd_r10".alias("cmpny_cf_cd"), $"state_r10".alias("state"), $"in_exchange_r10".alias("in_exchange")).distinct

    val appjoin1 = appmaster.join(nbrpa_aprvd_total_ip, appmaster("health_year") === nbrpa_aprvd_total_ip("health_year_r1") &&
      appmaster("cmpny_cf_cd") === nbrpa_aprvd_total_ip("cmpny_cf_cd_r1") && appmaster("state") === nbrpa_aprvd_total_ip("state_r1") &&
      appmaster("in_exchange") === nbrpa_aprvd_total_ip("in_exchange_r1"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_aprvd_total_ip")

    val appjoin2 = appjoin1.join(nbrpa_aprvd_total_sgp, appjoin1("health_year") === nbrpa_aprvd_total_sgp("health_year_r2") &&
      appjoin1("cmpny_cf_cd") === nbrpa_aprvd_total_sgp("cmpny_cf_cd_r2") && appjoin1("state") === nbrpa_aprvd_total_sgp("state_r2") &&
      appjoin1("in_exchange") === nbrpa_aprvd_total_sgp("in_exchange_r2"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp")

    val appjoin3 = appjoin2.join(nbrpa_aprvd_catastrophic, appjoin2("health_year") === nbrpa_aprvd_catastrophic("health_year_r3") &&
      appjoin2("cmpny_cf_cd") === nbrpa_aprvd_catastrophic("cmpny_cf_cd_r3") && appjoin2("state") === nbrpa_aprvd_catastrophic("state_r3") &&
      appjoin2("in_exchange") === nbrpa_aprvd_catastrophic("in_exchange_r3"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_catastrophic")

    val appjoin4 = appjoin3.join(nbrpa_aprvd_total_ms_ip, appjoin3("health_year") === nbrpa_aprvd_total_ms_ip("health_year_r4") &&
      appjoin3("cmpny_cf_cd") === nbrpa_aprvd_total_ms_ip("cmpny_cf_cd_r4") && appjoin3("state") === nbrpa_aprvd_total_ms_ip("state_r4") &&
      appjoin3("in_exchange") === nbrpa_aprvd_total_ms_ip("in_exchange_r4"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_total_ms_ip")

    val appjoin5 = appjoin4.join(nbrpa_aprvd_total_ms_sgp, appjoin4("health_year") === nbrpa_aprvd_total_ms_sgp("health_year_r5") &&
      appjoin4("cmpny_cf_cd") === nbrpa_aprvd_total_ms_sgp("cmpny_cf_cd_r5") && appjoin4("state") === nbrpa_aprvd_total_ms_sgp("state_r5") &&
      appjoin4("in_exchange") === nbrpa_aprvd_total_ms_sgp("in_exchange_r5"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_total_ms_ip", $"nbrpa_aprvd_total_ms_sgp")

    val appjoin6 = appjoin5.join(nbrpa_aprvd_bh_total_ip, appjoin5("health_year") === nbrpa_aprvd_bh_total_ip("health_year_r6") &&
      appjoin5("cmpny_cf_cd") === nbrpa_aprvd_bh_total_ip("cmpny_cf_cd_r6") && appjoin5("state") === nbrpa_aprvd_bh_total_ip("state_r6") &&
      appjoin5("in_exchange") === nbrpa_aprvd_bh_total_ip("in_exchange_r6"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_total_ms_ip", $"nbrpa_aprvd_total_ms_sgp", $"nbrpa_aprvd_bh_total_ip")

    val appjoin7 = appjoin6.join(nbrpa_aprvd_bh_total_sgp, appjoin6("health_year") === nbrpa_aprvd_bh_total_sgp("health_year_r7") &&
      appjoin6("cmpny_cf_cd") === nbrpa_aprvd_bh_total_sgp("cmpny_cf_cd_r7") && appjoin6("state") === nbrpa_aprvd_bh_total_sgp("state_r7") &&
      appjoin6("in_exchange") === nbrpa_aprvd_bh_total_sgp("in_exchange_r7"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_total_ms_ip", $"nbrpa_aprvd_total_ms_sgp", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp")

    val appjoin8 = appjoin7.join(nbrpa_aprvd_bh_catastrophic, appjoin7("health_year") === nbrpa_aprvd_bh_catastrophic("health_year_r8") &&
      appjoin7("cmpny_cf_cd") === nbrpa_aprvd_bh_catastrophic("cmpny_cf_cd_r8") && appjoin7("state") === nbrpa_aprvd_bh_catastrophic("state_r8") &&
      appjoin7("in_exchange") === nbrpa_aprvd_bh_catastrophic("in_exchange_r8"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_total_ms_ip", $"nbrpa_aprvd_total_ms_sgp", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_catastrophic")

    val appjoin9 = appjoin8.join(nbrpa_aprvd_bh_total_ms_ip, appjoin8("health_year") === nbrpa_aprvd_bh_total_ms_ip("health_year_r9") &&
      appjoin8("cmpny_cf_cd") === nbrpa_aprvd_bh_total_ms_ip("cmpny_cf_cd_r9") && appjoin8("state") === nbrpa_aprvd_bh_total_ms_ip("state_r9") &&
      appjoin8("in_exchange") === nbrpa_aprvd_bh_total_ms_ip("in_exchange_r9"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_total_ms_ip", $"nbrpa_aprvd_total_ms_sgp", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_catastrophic",
        $"nbrpa_aprvd_bh_total_ms_ip")

    val appFinalDf = appjoin9.join(nbrpa_aprvd_bh_total_ms_sgp, appjoin9("health_year") === nbrpa_aprvd_bh_total_ms_sgp("health_year_r10") &&
      appjoin9("cmpny_cf_cd") === nbrpa_aprvd_bh_total_ms_sgp("cmpny_cf_cd_r10") && appjoin9("state") === nbrpa_aprvd_bh_total_ms_sgp("state_r10") &&
      appjoin9("in_exchange") === nbrpa_aprvd_bh_total_ms_sgp("in_exchange_r10"), "left_outer")
      .select($"health_year".alias("health_year_approved"), $"cmpny_cf_cd".alias("cmpny_cf_cd_approved"), $"state".alias("state_approved"),
        $"in_exchange".alias("in_exchange_approved"), $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_total_ms_ip", $"nbrpa_aprvd_total_ms_sgp", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_catastrophic",
        $"nbrpa_aprvd_bh_total_ms_ip", $"nbrpa_aprvd_bh_total_ms_sgp")

    appFinalDf
  }

  def getDeniedData(naic2018_mcas_hlthex_paexphmcy_denied_wrk: DataFrame, naic2018_mcas_hlthex_paexphmcy_reqstd_wrk: DataFrame): DataFrame = {

    val nbrpa_denied_total_ip = naic2018_mcas_hlthex_paexphmcy_denied_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year".alias("health_year_r1"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r1"),
        $"state".alias("state_r1"), $"in_exchange".alias("in_exchange_r1")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_total_ip"))

    val nbrpa_denied_total_ip_pcols = nbrpa_denied_total_ip.select($"health_year_r1", $"cmpny_cf_cd_r1", $"state_r1", $"in_exchange_r1")

    val nbrpa_denied_total_sgp = naic2018_mcas_hlthex_paexphmcy_denied_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year".alias("health_year_r2"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r2"),
        $"state".alias("state_r2"), $"in_exchange".alias("in_exchange_r2")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_total_sgp"))

    val nbrpa_denied_total_sgp_pcols = nbrpa_denied_total_sgp.select($"health_year_r2", $"cmpny_cf_cd_r2", $"state_r2", $"in_exchange_r2")

    val nbrpa_denied_catastrophic = naic2018_mcas_hlthex_paexphmcy_denied_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_prod_desc").like("%CATASTROPHIC%") &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year".alias("health_year_r3"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r3"),
        $"state".alias("state_r3"), $"in_exchange".alias("in_exchange_r3")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_catastrophic"))

    val nbrpa_denied_catastrophic_pcols = nbrpa_denied_catastrophic.select($"health_year_r3", $"cmpny_cf_cd_r3", $"state_r3", $"in_exchange_r3")

    val nbrpa_denied_total_ms_ip = naic2018_mcas_hlthex_paexphmcy_denied_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").equalTo("IN") &&
        (!naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r4"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r4"),
        $"state".alias("state_r4"), $"in_exchange".alias("in_exchange_r4")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_total_ms_ip"))

    val nbrpa_denied_total_ms_ip_pcols = nbrpa_denied_total_ms_ip.select($"health_year_r4", $"cmpny_cf_cd_r4", $"state_r4", $"in_exchange_r4")

    val nbrpa_denied_total_ms_sgp = naic2018_mcas_hlthex_paexphmcy_denied_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").equalTo("IN") &&
        (!naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r5"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r5"),
        $"state".alias("state_r5"), $"in_exchange".alias("in_exchange_r5")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_total_ms_sgp"))

    val nbrpa_denied_total_ms_sgp_pcols = nbrpa_denied_total_ms_sgp.select($"health_year_r5", $"cmpny_cf_cd_r5", $"state_r5", $"in_exchange_r5")

    val nbrpa_denied_bh_total_ip = naic2018_mcas_hlthex_paexphmcy_denied_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r6"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r6"),
        $"state".alias("state_r6"), $"in_exchange".alias("in_exchange_r6")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_bh_total_ip"))

        println("nbrpa_denied_bh_total_ip" +nbrpa_denied_bh_total_ip.show)
    val nbrpa_denied_bh_total_ip_pcols = nbrpa_denied_bh_total_ip.select($"health_year_r6", $"cmpny_cf_cd_r6", $"state_r6", $"in_exchange_r6")

    val nbrpa_denied_bh_total_sgp = naic2018_mcas_hlthex_paexphmcy_denied_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r7"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r7"),
        $"state".alias("state_r7"), $"in_exchange".alias("in_exchange_r7")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_bh_total_sgp"))

    val nbrpa_denied_bh_total_sgp_pcols = nbrpa_denied_bh_total_sgp.select($"health_year_r7", $"cmpny_cf_cd_r7", $"state_r7", $"in_exchange_r7")

    val nbrpa_denied_bh_catastrophic = naic2018_mcas_hlthex_paexphmcy_denied_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_prod_desc").like("%CATASTROPHIC%") &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r8"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r8"),
        $"state".alias("state_r8"), $"in_exchange".alias("in_exchange_r8")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_bh_catastrophic"))

    val nbrpa_rqstd_bh_catastrophic_pcols = nbrpa_denied_bh_catastrophic.select($"health_year_r8", $"cmpny_cf_cd_r8", $"state_r8", $"in_exchange_r8")

    val nbrpa_denied_bh_total_ms_ip = naic2018_mcas_hlthex_paexphmcy_denied_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r9"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r9"),
        $"state".alias("state_r9"), $"in_exchange".alias("in_exchange_r9")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_bh_total_ms_ip"))

    val nbrpa_rqstd_bh_total_ms_ip_pcols = nbrpa_denied_bh_total_ms_ip.select($"health_year_r9", $"cmpny_cf_cd_r9", $"state_r9", $"in_exchange_r9")

    val nbrpa_denied_bh_total_ms_sgp = naic2018_mcas_hlthex_paexphmcy_denied_wrk.
      filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").equalTo("IN") &&
        (naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r10"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r10"),
        $"state".alias("state_r10"), $"in_exchange".alias("in_exchange_r10")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_bh_total_ms_sgp"))

    val nbrpa_rqstd_bh_total_ms_sgp_pcols = nbrpa_denied_bh_total_ms_sgp.select($"health_year_r10", $"cmpny_cf_cd_r10", $"state_r10", $"in_exchange_r10")

    val denmaster = (nbrpa_rqstd_bh_total_ms_sgp_pcols.union(nbrpa_rqstd_bh_total_ms_ip_pcols.union(nbrpa_rqstd_bh_catastrophic_pcols.union(nbrpa_denied_bh_total_sgp_pcols
      .union(nbrpa_denied_bh_total_ip_pcols.union(nbrpa_denied_total_ms_sgp_pcols.union(nbrpa_denied_total_ms_ip_pcols.union(nbrpa_denied_catastrophic_pcols
        .union(nbrpa_denied_total_sgp_pcols.union(nbrpa_denied_total_ip_pcols))))))))))
      .select($"health_year_r10".alias("health_year"), $"cmpny_cf_cd_r10".alias("cmpny_cf_cd"), $"state_r10".alias("state"),
        $"in_exchange_r10".alias("in_exchange")).distinct

    val denjoin1 = denmaster.join(nbrpa_denied_total_ip, denmaster("health_year") === nbrpa_denied_total_ip("health_year_r1") &&
      denmaster("cmpny_cf_cd") === nbrpa_denied_total_ip("cmpny_cf_cd_r1") && denmaster("state") === nbrpa_denied_total_ip("state_r1") &&
      denmaster("in_exchange") === nbrpa_denied_total_ip("in_exchange_r1"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_denied_total_ip")

    val denjoin2 = denjoin1.join(nbrpa_denied_total_sgp, denjoin1("health_year") === nbrpa_denied_total_sgp("health_year_r2") &&
      denjoin1("cmpny_cf_cd") === nbrpa_denied_total_sgp("cmpny_cf_cd_r2") && denjoin1("state") === nbrpa_denied_total_sgp("state_r2") &&
      denjoin1("in_exchange") === nbrpa_denied_total_sgp("in_exchange_r2"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp")

    val denjoin3 = denjoin2.join(nbrpa_denied_catastrophic, denjoin2("health_year") === nbrpa_denied_catastrophic("health_year_r3") &&
      denjoin2("cmpny_cf_cd") === nbrpa_denied_catastrophic("cmpny_cf_cd_r3") && denjoin2("state") === nbrpa_denied_catastrophic("state_r3") &&
      denjoin2("in_exchange") === nbrpa_denied_catastrophic("in_exchange_r3"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_catastrophic")

    val denjoin4 = denjoin3.join(nbrpa_denied_total_ms_ip, denjoin3("health_year") === nbrpa_denied_total_ms_ip("health_year_r4") &&
      denjoin3("cmpny_cf_cd") === nbrpa_denied_total_ms_ip("cmpny_cf_cd_r4") && denjoin3("state") === nbrpa_denied_total_ms_ip("state_r4") &&
      denjoin3("in_exchange") === nbrpa_denied_total_ms_ip("in_exchange_r4"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_catastrophic", $"nbrpa_denied_total_ms_ip")

    val denjoin5 = denjoin4.join(nbrpa_denied_total_ms_sgp, denjoin4("health_year") === nbrpa_denied_total_ms_sgp("health_year_r5") &&
      denjoin4("cmpny_cf_cd") === nbrpa_denied_total_ms_sgp("cmpny_cf_cd_r5") && denjoin4("state") === nbrpa_denied_total_ms_sgp("state_r5") &&
      denjoin4("in_exchange") === nbrpa_denied_total_ms_sgp("in_exchange_r5"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_catastrophic", $"nbrpa_denied_total_ms_ip", $"nbrpa_denied_total_ms_sgp")

    val denjoin6 = denjoin5.join(nbrpa_denied_bh_total_ip, denjoin5("health_year") === nbrpa_denied_bh_total_ip("health_year_r6") &&
      denjoin5("cmpny_cf_cd") === nbrpa_denied_bh_total_ip("cmpny_cf_cd_r6") && denjoin5("state") === nbrpa_denied_bh_total_ip("state_r6") &&
      denjoin5("in_exchange") === nbrpa_denied_bh_total_ip("in_exchange_r6"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_catastrophic",
        $"nbrpa_denied_total_ms_ip", $"nbrpa_denied_total_ms_sgp", $"nbrpa_denied_bh_total_ip")

    val denjoin7 = denjoin6.join(nbrpa_denied_bh_total_sgp, denjoin6("health_year") === nbrpa_denied_bh_total_sgp("health_year_r7") &&
      denjoin6("cmpny_cf_cd") === nbrpa_denied_bh_total_sgp("cmpny_cf_cd_r7") && denjoin6("state") === nbrpa_denied_bh_total_sgp("state_r7") &&
      denjoin6("in_exchange") === nbrpa_denied_bh_total_sgp("in_exchange_r7"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_catastrophic",
        $"nbrpa_denied_total_ms_ip", $"nbrpa_denied_total_ms_sgp", $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp")

    val denjoin8 = denjoin7.join(nbrpa_denied_bh_catastrophic, denjoin7("health_year") === nbrpa_denied_bh_catastrophic("health_year_r8") &&
      denjoin7("cmpny_cf_cd") === nbrpa_denied_bh_catastrophic("cmpny_cf_cd_r8") && denjoin7("state") === nbrpa_denied_bh_catastrophic("state_r8") &&
      denjoin7("in_exchange") === nbrpa_denied_bh_catastrophic("in_exchange_r8"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_catastrophic",
        $"nbrpa_denied_total_ms_ip", $"nbrpa_denied_total_ms_sgp", $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp", $"nbrpa_denied_bh_catastrophic")

    val denjoin9 = denjoin8.join(nbrpa_denied_bh_total_ms_ip, denjoin8("health_year") === nbrpa_denied_bh_total_ms_ip("health_year_r9") &&
      denjoin8("cmpny_cf_cd") === nbrpa_denied_bh_total_ms_ip("cmpny_cf_cd_r9") && denjoin8("state") === nbrpa_denied_bh_total_ms_ip("state_r9") &&
      denjoin8("in_exchange") === nbrpa_denied_bh_total_ms_ip("in_exchange_r9"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_catastrophic",
        $"nbrpa_denied_total_ms_ip", $"nbrpa_denied_total_ms_sgp", $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp", $"nbrpa_denied_bh_catastrophic", $"nbrpa_denied_bh_total_ms_ip")

    val denFinalDf = denjoin9.join(nbrpa_denied_bh_total_ms_sgp, denjoin9("health_year") === nbrpa_denied_bh_total_ms_sgp("health_year_r10") &&
      denjoin9("cmpny_cf_cd") === nbrpa_denied_bh_total_ms_sgp("cmpny_cf_cd_r10") && denjoin9("state") === nbrpa_denied_bh_total_ms_sgp("state_r10") &&
      denjoin9("in_exchange") === nbrpa_denied_bh_total_ms_sgp("in_exchange_r10"), "left_outer")
      .select($"health_year".alias("health_year_denied"), $"cmpny_cf_cd".alias("cmpny_cf_cd_denied"), $"state".alias("state_denied"), $"in_exchange".alias("in_exchange_denied"),
        $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_catastrophic",
        $"nbrpa_denied_total_ms_ip", $"nbrpa_denied_total_ms_sgp", $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp", $"nbrpa_denied_bh_catastrophic",
        $"nbrpa_denied_bh_total_ms_ip", $"nbrpa_denied_bh_total_ms_sgp")

    denFinalDf

  }

  def getFinalData(reqDf: DataFrame, appDf: DataFrame, denDf: DataFrame): DataFrame = {

    val request = reqDf.select($"health_year_requested", $"cmpny_cf_cd_requested", $"state_requested", $"in_exchange_requested")
    val approve = appDf.select($"health_year_approved", $"cmpny_cf_cd_approved", $"state_approved", $"in_exchange_approved")
    val deny = denDf.select($"health_year_denied", $"cmpny_cf_cd_denied", $"state_denied", $"in_exchange_denied")

    val finalmaster = deny.union(request.union(approve)).select($"health_year_denied".alias("health_year"), $"cmpny_cf_cd_denied".alias("cmpny_cf_cd"),
      $"state_denied".alias("state"), $"in_exchange_denied".alias("in_exchange")).distinct

    val fjoin1 = finalmaster.join(reqDf, finalmaster("health_year") === reqDf("health_year_requested") &&
      finalmaster("cmpny_cf_cd") === reqDf("cmpny_cf_cd_requested") && finalmaster("state") === reqDf("state_requested") &&
      finalmaster("in_exchange") === reqDf("in_exchange_requested"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_catastrophic",
        $"nbrpa_rqstd_total_ms_ip", $"nbrpa_rqstd_total_ms_sgp", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_catastrophic",
        $"nbrpa_rqstd_bh_total_ms_ip", $"nbrpa_rqstd_bh_total_ms_sgp")

    val fjoin2 = fjoin1.join(appDf, fjoin1("health_year") === appDf("health_year_approved") &&
      fjoin1("cmpny_cf_cd") === appDf("cmpny_cf_cd_approved") && fjoin1("state") === appDf("state_approved") && fjoin1("in_exchange") === appDf("in_exchange_approved"),
      "left_outer").select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_catastrophic",
        $"nbrpa_rqstd_total_ms_ip", $"nbrpa_rqstd_total_ms_sgp", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_catastrophic",
        $"nbrpa_rqstd_bh_total_ms_ip", $"nbrpa_rqstd_bh_total_ms_sgp", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_catastrophic", $"nbrpa_aprvd_total_ms_ip",
        $"nbrpa_aprvd_total_ms_sgp", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_catastrophic", $"nbrpa_aprvd_bh_total_ms_ip", $"nbrpa_aprvd_bh_total_ms_sgp")

    val naicMcasHlthIexPa = fjoin2.join(denDf, fjoin2("health_year") === denDf("health_year_denied") &&
      fjoin2("cmpny_cf_cd") === denDf("cmpny_cf_cd_denied") && fjoin2("state") === denDf("state_denied") && fjoin2("in_exchange") === denDf("in_exchange_denied"), "left_outer")
      .select($"in_exchange".alias("market_exchange"), $"health_year", $"cmpny_cf_cd".alias("naic_cmpny_cd"), $"state",
        $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_total_ms_ip", $"nbrpa_rqstd_total_ms_sgp",
        $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_catastrophic", $"nbrpa_aprvd_total_ms_ip", $"nbrpa_aprvd_total_ms_sgp",
        $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_catastrophic", $"nbrpa_denied_total_ms_ip", $"nbrpa_denied_total_ms_sgp",
        $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_catastrophic", $"nbrpa_rqstd_bh_total_ms_ip", $"nbrpa_rqstd_bh_total_ms_sgp",
        $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp", $"nbrpa_denied_bh_catastrophic", $"nbrpa_denied_bh_total_ms_ip", $"nbrpa_denied_bh_total_ms_sgp",
        $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_catastrophic", $"nbrpa_aprvd_bh_total_ms_ip", $"nbrpa_aprvd_bh_total_ms_sgp")

    val finalMaicMcasHltIexPa = naicMcasHlthIexPa.na.fill(0)
    
    finalMaicMcasHltIexPa

  }

}

object PCADX_SCL_NAIC2018_IexStgTransformation_PAEXPHMCY {

  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    new PCADX_SCL_NAIC2018_IexStgTransformation_PAEXPHMCY().sparkInIt()
  }
}