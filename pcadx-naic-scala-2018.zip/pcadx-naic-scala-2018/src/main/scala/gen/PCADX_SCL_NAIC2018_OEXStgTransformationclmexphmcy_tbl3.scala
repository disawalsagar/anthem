package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl3(val spark: SparkSession) {

  /* val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()*/

  import spark.implicits._
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl3])

  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clmex")
  val end_year = dbProperties.getProperty("end_year_clmex")
  /* var naic_mcas_hlthex_clmexphmcy_paid_ip_wrk:DataFrame = null
  var naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk:DataFrame = null
  var naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk:DataFrame = null
  var naic_mcas_hlthex_clmexphmcy_paid_cat_wrk:DataFrame = null*/
  //val  mbu_cf_cdvals= dbProperties.getProperty("mbu_Cf_cdVals").split(",").toSeq
  def sparkInIt(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame, load_log_key: String) {
    val oexclmphrmcy = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy(spark)
    val oexclmphrmcy_1 = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_1(spark)
    
    // val obj_clmsExPhrmcy = new PCADX_SCL_NAIC_IEXStgTransformationclmexphmcy_part2()
    /*naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk")

     naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk")
     naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk")
      naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk")
     */
    val mbu_cf_cdvals = dbProperties.getProperty("mbu_Cf_cdVals").split(",").toSeq
    val objPaidInntwk = oexclmphrmcy_1.getPaidInntwk(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val objPaidInntwk0_30 = oexclmphrmcy_1.getPaidInntwkBetweenDays(0, 30, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val objPaidInntwk31_60 = oexclmphrmcy_1.getPaidInntwkBetweenDays(31, 60, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val objPaidInntwk61_90 = oexclmphrmcy_1.getPaidInntwkBetweenDays(61, 90, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val objPaidInntwk_90 = oexclmphrmcy_1.getPaidInntwk_90(end_year, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)

    val StgData_1 = getStageData(objPaidInntwk, objPaidInntwk0_30, objPaidInntwk31_60,
      objPaidInntwk61_90, objPaidInntwk_90)
    /* var load_log_key = ""
    if(!naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk.take(1).isEmpty){
     load_log_key = naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk.select($"load_log_key").first.getString(0)
    }*/
    val f_stgData = StgData_1.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
    oexclmphrmcy.writeDataToHive(dbwrk + ".naic2018_mcas_hlthoex_clmexphmcy_paidInColstemp", f_stgData)

  }

  def getStageData(objPaidInntwk: DataFrame, objPaidInntwk0_30: DataFrame, objPaidInntwk31_60: DataFrame,
                   objPaidInntwk61_90: DataFrame, objPaidInntwk_90: DataFrame): DataFrame = {

    val paidIn = objPaidInntwk.alias("parent").join(objPaidInntwk0_30.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"), col("nbrclm_paid_inntwk_stucvg"),
        col("nbrclm_paid_inntwk_0to30_bronze_ip"), col("nbrclm_paid_inntwk_0to30_silver_ip"), col("nbrclm_paid_inntwk_0to30_gold_ip"), col("nbrclm_paid_inntwk_0to30_platinum_ip"), col("nbrclm_paid_inntwk_0to30_total_ip"),
        col("nbrclm_paid_inntwk_0to30_bronze_sgp"), col("nbrclm_paid_inntwk_0to30_silver_sgp"), col("nbrclm_paid_inntwk_0to30_gold_sgp"), col("nbrclm_paid_inntwk_0to30_platinum_sgp"), col("nbrclm_paid_inntwk_0to30_total_sgp"), col("nbrclm_paid_inntwk_0to30_gtlgp"), col("nbrclm_paid_inntwk_0to30_gtsgp"), col("nbrclm_paid_inntwk_0to30_gtip"), col("nbrclm_paid_inntwk_0to30_total_gtip"), col("nbrclm_paid_inntwk_0to30_catastrophic"), col("nbrclm_paid_inntwk_0to30_lgp_mmcare"), col("nbrclm_paid_inntwk_0to30_stucvg"))

    val paidInData = paidIn.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp", "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",
        "nbrclm_paid_inntwk_0to30_bronze_ip", "nbrclm_paid_inntwk_0to30_silver_ip", "nbrclm_paid_inntwk_0to30_gold_ip", "nbrclm_paid_inntwk_0to30_platinum_ip", "nbrclm_paid_inntwk_0to30_total_ip",
        "nbrclm_paid_inntwk_0to30_bronze_sgp", "nbrclm_paid_inntwk_0to30_silver_sgp", "nbrclm_paid_inntwk_0to30_gold_sgp", "nbrclm_paid_inntwk_0to30_platinum_sgp", "nbrclm_paid_inntwk_0to30_total_sgp", "nbrclm_paid_inntwk_0to30_gtlgp", "nbrclm_paid_inntwk_0to30_gtsgp", "nbrclm_paid_inntwk_0to30_gtip", "nbrclm_paid_inntwk_0to30_total_gtip", "nbrclm_paid_inntwk_0to30_catastrophic", "nbrclm_paid_inntwk_0to30_lgp_mmcare", "nbrclm_paid_inntwk_0to30_stucvg")

    val paidIn31_60 = paidInData.alias("parent").join(objPaidInntwk31_60.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"), col("nbrclm_paid_inntwk_stucvg"),
        col("nbrclm_paid_inntwk_0to30_bronze_ip"), col("nbrclm_paid_inntwk_0to30_silver_ip"), col("nbrclm_paid_inntwk_0to30_gold_ip"), col("nbrclm_paid_inntwk_0to30_platinum_ip"), col("nbrclm_paid_inntwk_0to30_total_ip"),
        col("nbrclm_paid_inntwk_0to30_bronze_sgp"), col("nbrclm_paid_inntwk_0to30_silver_sgp"), col("nbrclm_paid_inntwk_0to30_gold_sgp"), col("nbrclm_paid_inntwk_0to30_platinum_sgp"), col("nbrclm_paid_inntwk_0to30_total_sgp"), col("nbrclm_paid_inntwk_0to30_gtlgp"), col("nbrclm_paid_inntwk_0to30_gtsgp"), col("nbrclm_paid_inntwk_0to30_gtip"), col("nbrclm_paid_inntwk_0to30_total_gtip"), col("nbrclm_paid_inntwk_0to30_catastrophic"), col("nbrclm_paid_inntwk_0to30_lgp_mmcare"), col("nbrclm_paid_inntwk_0to30_stucvg"),
        col("nbrclm_paid_inntwk_31to60_bronze_ip"), col("nbrclm_paid_inntwk_31to60_silver_ip"), col("nbrclm_paid_inntwk_31to60_gold_ip"), col("nbrclm_paid_inntwk_31to60_platinum_ip"), col("nbrclm_paid_inntwk_31to60_total_ip"),
        col("nbrclm_paid_inntwk_31to60_bronze_sgp"), col("nbrclm_paid_inntwk_31to60_silver_sgp"), col("nbrclm_paid_inntwk_31to60_gold_sgp"), col("nbrclm_paid_inntwk_31to60_platinum_sgp"), col("nbrclm_paid_inntwk_31to60_total_sgp"), col("nbrclm_paid_inntwk_31to60_gtlgp"), col("nbrclm_paid_inntwk_31to60_gtsgp"), col("nbrclm_paid_inntwk_31to60_gtip"), col("nbrclm_paid_inntwk_31to60_total_gtip"), col("nbrclm_paid_inntwk_31to60_catastrophic"), col("nbrclm_paid_inntwk_31to60_lgp_mmcare"), col("nbrclm_paid_inntwk_31to60_stucvg"))

    val paidIn31_60Data = paidIn31_60.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp", "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",
        "nbrclm_paid_inntwk_0to30_bronze_ip", "nbrclm_paid_inntwk_0to30_silver_ip", "nbrclm_paid_inntwk_0to30_gold_ip", "nbrclm_paid_inntwk_0to30_platinum_ip", "nbrclm_paid_inntwk_0to30_total_ip",
        "nbrclm_paid_inntwk_0to30_bronze_sgp", "nbrclm_paid_inntwk_0to30_silver_sgp", "nbrclm_paid_inntwk_0to30_gold_sgp", "nbrclm_paid_inntwk_0to30_platinum_sgp", "nbrclm_paid_inntwk_0to30_total_sgp", "nbrclm_paid_inntwk_0to30_gtlgp", "nbrclm_paid_inntwk_0to30_gtsgp", "nbrclm_paid_inntwk_0to30_gtip", "nbrclm_paid_inntwk_0to30_total_gtip", "nbrclm_paid_inntwk_0to30_catastrophic", "nbrclm_paid_inntwk_0to30_lgp_mmcare", "nbrclm_paid_inntwk_0to30_stucvg",
        "nbrclm_paid_inntwk_31to60_bronze_ip", "nbrclm_paid_inntwk_31to60_silver_ip", "nbrclm_paid_inntwk_31to60_gold_ip", "nbrclm_paid_inntwk_31to60_platinum_ip", "nbrclm_paid_inntwk_31to60_total_ip",
        "nbrclm_paid_inntwk_31to60_bronze_sgp", "nbrclm_paid_inntwk_31to60_silver_sgp", "nbrclm_paid_inntwk_31to60_gold_sgp", "nbrclm_paid_inntwk_31to60_platinum_sgp", "nbrclm_paid_inntwk_31to60_total_sgp", "nbrclm_paid_inntwk_31to60_gtlgp", "nbrclm_paid_inntwk_31to60_gtsgp", "nbrclm_paid_inntwk_31to60_gtip", "nbrclm_paid_inntwk_31to60_total_gtip", "nbrclm_paid_inntwk_31to60_catastrophic", "nbrclm_paid_inntwk_31to60_lgp_mmcare", "nbrclm_paid_inntwk_31to60_stucvg")

    val paidIn61_90 = paidIn31_60Data.alias("parent").join(objPaidInntwk61_90.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"), col("nbrclm_paid_inntwk_stucvg"),
        col("nbrclm_paid_inntwk_0to30_bronze_ip"), col("nbrclm_paid_inntwk_0to30_silver_ip"), col("nbrclm_paid_inntwk_0to30_gold_ip"), col("nbrclm_paid_inntwk_0to30_platinum_ip"), col("nbrclm_paid_inntwk_0to30_total_ip"),
        col("nbrclm_paid_inntwk_0to30_bronze_sgp"), col("nbrclm_paid_inntwk_0to30_silver_sgp"), col("nbrclm_paid_inntwk_0to30_gold_sgp"), col("nbrclm_paid_inntwk_0to30_platinum_sgp"), col("nbrclm_paid_inntwk_0to30_total_sgp"), col("nbrclm_paid_inntwk_0to30_gtlgp"), col("nbrclm_paid_inntwk_0to30_gtsgp"), col("nbrclm_paid_inntwk_0to30_gtip"), col("nbrclm_paid_inntwk_0to30_total_gtip"), col("nbrclm_paid_inntwk_0to30_catastrophic"), col("nbrclm_paid_inntwk_0to30_lgp_mmcare"), col("nbrclm_paid_inntwk_0to30_stucvg"),
        col("nbrclm_paid_inntwk_31to60_bronze_ip"), col("nbrclm_paid_inntwk_31to60_silver_ip"), col("nbrclm_paid_inntwk_31to60_gold_ip"), col("nbrclm_paid_inntwk_31to60_platinum_ip"), col("nbrclm_paid_inntwk_31to60_total_ip"),
        col("nbrclm_paid_inntwk_31to60_bronze_sgp"), col("nbrclm_paid_inntwk_31to60_silver_sgp"), col("nbrclm_paid_inntwk_31to60_gold_sgp"), col("nbrclm_paid_inntwk_31to60_platinum_sgp"), col("nbrclm_paid_inntwk_31to60_total_sgp"), col("nbrclm_paid_inntwk_31to60_gtlgp"), col("nbrclm_paid_inntwk_31to60_gtsgp"), col("nbrclm_paid_inntwk_31to60_gtip"), col("nbrclm_paid_inntwk_31to60_total_gtip"), col("nbrclm_paid_inntwk_31to60_catastrophic"), col("nbrclm_paid_inntwk_31to60_lgp_mmcare"), col("nbrclm_paid_inntwk_31to60_stucvg"),
        col("nbrclm_paid_inntwk_61to90_bronze_ip"), col("nbrclm_paid_inntwk_61to90_silver_ip"), col("nbrclm_paid_inntwk_61to90_gold_ip"), col("nbrclm_paid_inntwk_61to90_platinum_ip"), col("nbrclm_paid_inntwk_61to90_total_ip"),
        col("nbrclm_paid_inntwk_61to90_bronze_sgp"), col("nbrclm_paid_inntwk_61to90_silver_sgp"), col("nbrclm_paid_inntwk_61to90_gold_sgp"), col("nbrclm_paid_inntwk_61to90_platinum_sgp"), col("nbrclm_paid_inntwk_61to90_total_sgp"), col("nbrclm_paid_inntwk_61to90_gtlgp"), col("nbrclm_paid_inntwk_61to90_gtsgp"), col("nbrclm_paid_inntwk_61to90_gtip"), col("nbrclm_paid_inntwk_61to90_total_gtip"), col("nbrclm_paid_inntwk_61to90_catastrophic"), col("nbrclm_paid_inntwk_61to90_lgp_mmcare"), col("nbrclm_paid_inntwk_61to90_stucvg"))
    val paidIn61_90Data = paidIn61_90.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp", "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",
        "nbrclm_paid_inntwk_0to30_bronze_ip", "nbrclm_paid_inntwk_0to30_silver_ip", "nbrclm_paid_inntwk_0to30_gold_ip", "nbrclm_paid_inntwk_0to30_platinum_ip", "nbrclm_paid_inntwk_0to30_total_ip",
        "nbrclm_paid_inntwk_0to30_bronze_sgp", "nbrclm_paid_inntwk_0to30_silver_sgp", "nbrclm_paid_inntwk_0to30_gold_sgp", "nbrclm_paid_inntwk_0to30_platinum_sgp", "nbrclm_paid_inntwk_0to30_total_sgp", "nbrclm_paid_inntwk_0to30_gtlgp", "nbrclm_paid_inntwk_0to30_gtsgp", "nbrclm_paid_inntwk_0to30_gtip", "nbrclm_paid_inntwk_0to30_total_gtip", "nbrclm_paid_inntwk_0to30_catastrophic", "nbrclm_paid_inntwk_0to30_lgp_mmcare", "nbrclm_paid_inntwk_0to30_stucvg",
        "nbrclm_paid_inntwk_31to60_bronze_ip", "nbrclm_paid_inntwk_31to60_silver_ip", "nbrclm_paid_inntwk_31to60_gold_ip", "nbrclm_paid_inntwk_31to60_platinum_ip", "nbrclm_paid_inntwk_31to60_total_ip",
        "nbrclm_paid_inntwk_31to60_bronze_sgp", "nbrclm_paid_inntwk_31to60_silver_sgp", "nbrclm_paid_inntwk_31to60_gold_sgp", "nbrclm_paid_inntwk_31to60_platinum_sgp", "nbrclm_paid_inntwk_31to60_total_sgp", "nbrclm_paid_inntwk_31to60_gtlgp", "nbrclm_paid_inntwk_31to60_gtsgp", "nbrclm_paid_inntwk_31to60_gtip", "nbrclm_paid_inntwk_31to60_total_gtip", "nbrclm_paid_inntwk_31to60_catastrophic", "nbrclm_paid_inntwk_31to60_lgp_mmcare", "nbrclm_paid_inntwk_31to60_stucvg",
        "nbrclm_paid_inntwk_61to90_bronze_ip", "nbrclm_paid_inntwk_61to90_silver_ip", "nbrclm_paid_inntwk_61to90_gold_ip", "nbrclm_paid_inntwk_61to90_platinum_ip", "nbrclm_paid_inntwk_61to90_total_ip",
        "nbrclm_paid_inntwk_61to90_bronze_sgp", "nbrclm_paid_inntwk_61to90_silver_sgp", "nbrclm_paid_inntwk_61to90_gold_sgp", "nbrclm_paid_inntwk_61to90_platinum_sgp", "nbrclm_paid_inntwk_61to90_total_sgp", "nbrclm_paid_inntwk_61to90_gtlgp", "nbrclm_paid_inntwk_61to90_gtsgp", "nbrclm_paid_inntwk_61to90_gtip", "nbrclm_paid_inntwk_61to90_total_gtip", "nbrclm_paid_inntwk_61to90_catastrophic", "nbrclm_paid_inntwk_61to90_lgp_mmcare", "nbrclm_paid_inntwk_61to90_stucvg")

    val paidIn_90 = paidIn61_90Data.alias("parent").join(objPaidInntwk_90.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"), col("nbrclm_paid_inntwk_stucvg"),
        col("nbrclm_paid_inntwk_0to30_bronze_ip"), col("nbrclm_paid_inntwk_0to30_silver_ip"), col("nbrclm_paid_inntwk_0to30_gold_ip"), col("nbrclm_paid_inntwk_0to30_platinum_ip"), col("nbrclm_paid_inntwk_0to30_total_ip"),
        col("nbrclm_paid_inntwk_0to30_bronze_sgp"), col("nbrclm_paid_inntwk_0to30_silver_sgp"), col("nbrclm_paid_inntwk_0to30_gold_sgp"), col("nbrclm_paid_inntwk_0to30_platinum_sgp"), col("nbrclm_paid_inntwk_0to30_total_sgp"), col("nbrclm_paid_inntwk_0to30_gtlgp"), col("nbrclm_paid_inntwk_0to30_gtsgp"), col("nbrclm_paid_inntwk_0to30_gtip"), col("nbrclm_paid_inntwk_0to30_total_gtip"), col("nbrclm_paid_inntwk_0to30_catastrophic"), col("nbrclm_paid_inntwk_0to30_lgp_mmcare"), col("nbrclm_paid_inntwk_0to30_stucvg"),
        col("nbrclm_paid_inntwk_31to60_bronze_ip"), col("nbrclm_paid_inntwk_31to60_silver_ip"), col("nbrclm_paid_inntwk_31to60_gold_ip"), col("nbrclm_paid_inntwk_31to60_platinum_ip"), col("nbrclm_paid_inntwk_31to60_total_ip"),
        col("nbrclm_paid_inntwk_31to60_bronze_sgp"), col("nbrclm_paid_inntwk_31to60_silver_sgp"), col("nbrclm_paid_inntwk_31to60_gold_sgp"), col("nbrclm_paid_inntwk_31to60_platinum_sgp"), col("nbrclm_paid_inntwk_31to60_total_sgp"), col("nbrclm_paid_inntwk_31to60_gtlgp"), col("nbrclm_paid_inntwk_31to60_gtsgp"), col("nbrclm_paid_inntwk_31to60_gtip"), col("nbrclm_paid_inntwk_31to60_total_gtip"), col("nbrclm_paid_inntwk_31to60_catastrophic"), col("nbrclm_paid_inntwk_31to60_lgp_mmcare"), col("nbrclm_paid_inntwk_31to60_stucvg"),
        col("nbrclm_paid_inntwk_61to90_bronze_ip"), col("nbrclm_paid_inntwk_61to90_silver_ip"), col("nbrclm_paid_inntwk_61to90_gold_ip"), col("nbrclm_paid_inntwk_61to90_platinum_ip"), col("nbrclm_paid_inntwk_61to90_total_ip"),
        col("nbrclm_paid_inntwk_61to90_bronze_sgp"), col("nbrclm_paid_inntwk_61to90_silver_sgp"), col("nbrclm_paid_inntwk_61to90_gold_sgp"), col("nbrclm_paid_inntwk_61to90_platinum_sgp"), col("nbrclm_paid_inntwk_61to90_total_sgp"), col("nbrclm_paid_inntwk_61to90_gtlgp"), col("nbrclm_paid_inntwk_61to90_gtsgp"), col("nbrclm_paid_inntwk_61to90_gtip"), col("nbrclm_paid_inntwk_61to90_total_gtip"), col("nbrclm_paid_inntwk_61to90_catastrophic"), col("nbrclm_paid_inntwk_61to90_lgp_mmcare"), col("nbrclm_paid_inntwk_61to90_stucvg"),
        col("nbrclm_paid_inntwk_90_bronze_ip"), col("nbrclm_paid_inntwk_90_silver_ip"), col("nbrclm_paid_inntwk_90_gold_ip"), col("nbrclm_paid_inntwk_90_platinum_ip"), col("nbrclm_paid_inntwk_90_total_ip"),
        col("nbrclm_paid_inntwk_90_bronze_sgp"), col("nbrclm_paid_inntwk_90_silver_sgp"), col("nbrclm_paid_inntwk_90_gold_sgp"), col("nbrclm_paid_inntwk_90_platinum_sgp"), col("nbrclm_paid_inntwk_90_total_sgp"), col("nbrclm_paid_inntwk_90_gtlgp"), col("nbrclm_paid_inntwk_90_gtsgp"), col("nbrclm_paid_inntwk_90_gtip"), col("nbrclm_paid_inntwk_90_total_gtip"), col("nbrclm_paid_inntwk_90_catastrophic"), col("nbrclm_paid_inntwk_90_lgp_mmcare"), col("nbrclm_paid_inntwk_90_stucvg"))

    val paidIn_90Data = paidIn_90.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("market_exchange", lit("OUTOFF"))
      .select("market_exchange", "health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp", "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",
        "nbrclm_paid_inntwk_0to30_bronze_ip", "nbrclm_paid_inntwk_0to30_silver_ip", "nbrclm_paid_inntwk_0to30_gold_ip", "nbrclm_paid_inntwk_0to30_platinum_ip", "nbrclm_paid_inntwk_0to30_total_ip",
        "nbrclm_paid_inntwk_0to30_bronze_sgp", "nbrclm_paid_inntwk_0to30_silver_sgp", "nbrclm_paid_inntwk_0to30_gold_sgp", "nbrclm_paid_inntwk_0to30_platinum_sgp", "nbrclm_paid_inntwk_0to30_total_sgp", "nbrclm_paid_inntwk_0to30_gtlgp", "nbrclm_paid_inntwk_0to30_gtsgp", "nbrclm_paid_inntwk_0to30_gtip", "nbrclm_paid_inntwk_0to30_total_gtip", "nbrclm_paid_inntwk_0to30_catastrophic", "nbrclm_paid_inntwk_0to30_lgp_mmcare", "nbrclm_paid_inntwk_0to30_stucvg",
        "nbrclm_paid_inntwk_31to60_bronze_ip", "nbrclm_paid_inntwk_31to60_silver_ip", "nbrclm_paid_inntwk_31to60_gold_ip", "nbrclm_paid_inntwk_31to60_platinum_ip", "nbrclm_paid_inntwk_31to60_total_ip",
        "nbrclm_paid_inntwk_31to60_bronze_sgp", "nbrclm_paid_inntwk_31to60_silver_sgp", "nbrclm_paid_inntwk_31to60_gold_sgp", "nbrclm_paid_inntwk_31to60_platinum_sgp", "nbrclm_paid_inntwk_31to60_total_sgp", "nbrclm_paid_inntwk_31to60_gtlgp", "nbrclm_paid_inntwk_31to60_gtsgp", "nbrclm_paid_inntwk_31to60_gtip", "nbrclm_paid_inntwk_31to60_total_gtip", "nbrclm_paid_inntwk_31to60_catastrophic", "nbrclm_paid_inntwk_31to60_lgp_mmcare", "nbrclm_paid_inntwk_31to60_stucvg",
        "nbrclm_paid_inntwk_61to90_bronze_ip", "nbrclm_paid_inntwk_61to90_silver_ip", "nbrclm_paid_inntwk_61to90_gold_ip", "nbrclm_paid_inntwk_61to90_platinum_ip", "nbrclm_paid_inntwk_61to90_total_ip",
        "nbrclm_paid_inntwk_61to90_bronze_sgp", "nbrclm_paid_inntwk_61to90_silver_sgp", "nbrclm_paid_inntwk_61to90_gold_sgp", "nbrclm_paid_inntwk_61to90_platinum_sgp", "nbrclm_paid_inntwk_61to90_total_sgp", "nbrclm_paid_inntwk_61to90_gtlgp", "nbrclm_paid_inntwk_61to90_gtsgp", "nbrclm_paid_inntwk_61to90_gtip", "nbrclm_paid_inntwk_61to90_total_gtip", "nbrclm_paid_inntwk_61to90_catastrophic", "nbrclm_paid_inntwk_61to90_lgp_mmcare", "nbrclm_paid_inntwk_61to90_stucvg",
        "nbrclm_paid_inntwk_90_bronze_ip", "nbrclm_paid_inntwk_90_silver_ip", "nbrclm_paid_inntwk_90_gold_ip", "nbrclm_paid_inntwk_90_platinum_ip", "nbrclm_paid_inntwk_90_total_ip",
        "nbrclm_paid_inntwk_90_bronze_sgp", "nbrclm_paid_inntwk_90_silver_sgp", "nbrclm_paid_inntwk_90_gold_sgp", "nbrclm_paid_inntwk_90_platinum_sgp", "nbrclm_paid_inntwk_90_total_sgp", "nbrclm_paid_inntwk_90_gtlgp", "nbrclm_paid_inntwk_90_gtsgp", "nbrclm_paid_inntwk_90_gtip", "nbrclm_paid_inntwk_90_total_gtip", "nbrclm_paid_inntwk_90_catastrophic", "nbrclm_paid_inntwk_90_lgp_mmcare", "nbrclm_paid_inntwk_90_stucvg")

    paidIn_90Data
  }
}

object PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl3 {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    //new PCADX_SCL_NAIC_OEXStgTransformationclmexphmcy_tbl3().sparkInIt()
  }
}