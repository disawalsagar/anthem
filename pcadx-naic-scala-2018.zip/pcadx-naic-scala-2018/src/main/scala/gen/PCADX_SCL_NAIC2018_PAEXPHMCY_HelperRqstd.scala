package gen

class PCADX_SCL_NAIC2018_PAEXPHMCY_HelperRqstd() {

  def rqstdTrnctTbl(tbl: String) = {
    """Truncate table """ + tbl
  }

  def rqstdTrnctWrk1Tbl(tblwrk1: String) = {
    """Truncate table """ + tblwrk1
  }


  def reqstdWrk1(dbWrk: String, tblwrk1: String, load_log_key: String, strtDt: String, endDt: String) = """ Insert into table """ + tblwrk1 + """

  select 
    wrk.RFRNC_NBR as RFRNC_NBR , 
    wrk.MBR_KEY as MBR_KEY, 
    wrk.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
    wrk.UM_RQST_INITD_DT as UM_RQST_INITD_DT , 
    wrk.CASE_TYPE_CD as CASE_TYPE_CD,
   """ + load_log_key + """ as load_log_key,
    current_timestamp as load_dt
  from 
    """+ dbWrk +""".naic2018_mcas_hlthex_paexphmcy_wrk1 wrk
  where  
    wrk.UM_RQST_INITD_DT BETWEEN  """ + strtDt + """  AND  """ + endDt + """ 
  group by
    wrk.MBR_KEY, 
    wrk.RFRNC_NBR , 
    wrk.SRVC_LINE_NBR , 
    wrk.UM_RQST_INITD_DT, 
    wrk.CASE_TYPE_CD

  """

  def apprvdWrk1(dbwrk: String, tblwrk1: String, load_log_key: String, strtDt: String, endDt: String) = """Insert into table """ + tblwrk1 + """
  select  
    wrk.MBR_KEY as MBR_KEY, 
    wrk.RFRNC_NBR AS RFRNC_NBR , 
    wrk.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
    wrk.UM_RQST_INITD_DT as UM_RQST_INITD_DT ,
   case when STTS_DT > """ + endDt + """ 
    and ( ussh_STTS_DT is null or uis_STTS_DT <= """ + endDt + """ ) then uis_STTS_DT
    when STTS_DT > """ + endDt + """ 
    and ( uis_STTS_DT is null or ussh_STTS_DT <= """ + endDt + """ ) then ussh_STTS_DT
	else  STTS_DT end as STTS_DT, 
    wrk.uis_STTS_DT as uis_STTS_DT ,
    wrk.ussh_STTS_DT as ussh_STTS_DT ,  
    wrk.CASE_TYPE_CD as CASE_TYPE_CD ,
   """ + load_log_key + """ as load_log_key,
    current_timestamp as load_dt
  from 
    """+ dbwrk +""".naic2018_mcas_hlthex_paexphmcy_wrk2 wrk
  where 
    wrk.UM_SRVC_STTS_CD not in ( 'NA' , 'UNK' , 'P' , 'N' , 'C' , 'O' , 'X' , 'R'  ) 
  group by  
    wrk.MBR_KEY, 
    wrk.RFRNC_NBR, 
    wrk.SRVC_LINE_NBR, 
    wrk.UM_RQST_INITD_DT, 
    wrk.STTS_DT, 
    wrk.uis_STTS_DT, 
    wrk.ussh_STTS_DT, 
    wrk.CASE_TYPE_CD 
 """

  def deniedWrk1(dbWrk: String, tblwrk1: String, load_log_key: String, strtDt: String, endDt: String) = """Insert into table """ + tblwrk1 + """
  select  
    wrk.MBR_KEY as MBR_KEY, 
    wrk.RFRNC_NBR AS RFRNC_NBR, 
    wrk.SRVC_LINE_NBR as  SRVC_LINE_NBR, 
    wrk.UM_RQST_INITD_DT as UM_RQST_INITD_DT ,
    case when STTS_DT > """ + endDt + """ 
    and ( ussh_STTS_DT is null or uis_STTS_DT <= """ + endDt + """ ) then uis_STTS_DT
    when STTS_DT > """ + endDt + """ 
    and ( uis_STTS_DT is null or ussh_STTS_DT <= """ + endDt + """ ) then ussh_STTS_DT
	  else  STTS_DT end as STTS_DT,
    wrk.uis_STTS_DT as uis_STTS_DT, 
    wrk.ussh_STTS_DT as ussh_STTS_DT,  
    wrk.CASE_TYPE_CD as CASE_TYPE_CD ,
    """ + load_log_key + """ as load_log_key,
    current_timestamp as load_dt
  from 
    """+ dbWrk +""".naic2018_mcas_hlthex_paexphmcy_wrk2 wrk
  where  
    wrk.UM_SRVC_STTS_CD not in ( 'NA' , 'UNK' , 'P' , 'V' , 'A' , 'C' , 'O', 'X' , 'J'  )
  group by  
    wrk.MBR_KEY, 
    wrk.RFRNC_NBR, 
    wrk.SRVC_LINE_NBR, 
    wrk.UM_RQST_INITD_DT, 
    wrk.STTS_DT, 
    wrk.uis_STTS_DT,  
    wrk.ussh_STTS_DT, 
    wrk.CASE_TYPE_CD 
"""

  //k6
  def rqstdTtlIndvdl(dbwrk:String, dbInbnd: String, tbl: String, tblwrk1: String, reportYear: String, load_log_key: String, tempCol: String, prcp_cd: String) = """
Insert into table """ + tbl + """
select * from (select """ + reportYear + """ as health_year,
PA1.RFRNC_NBR AS RFRNC_NBR,
PA1.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
pa_temp.MBR_KEY AS MBR_KEY,
pa_temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
pa_temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD,
pa_temp.MBU_CF_CD AS MBU_CF_CD,
pa_temp.PROD_CF_CD AS PROD_CF_CD,
pa_temp.CMPNY_CF_CD AS CMPNY_CF_CD,
pa_temp.FUNDG_CF_CD AS FUNDG_CF_CD,
pa_temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
pa_temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
pa_temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD,
pa_temp.hcr_cmplynt_cd AS HCR_CMPLYNT_CD,
pa_temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
pa_temp.HIX_CD AS HIX_CD,
BRD.State AS  State,
CASE WHEN substring (pa_temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')
and pa_temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN'
WHEN pa_temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN'
WHEN SUBSTR(pa_temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( pa_temp.EXCHNG_IND_CD IS NULL OR pa_temp.EXCHNG_IND_CD ='UNK' ) AND pa_temp.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
END AS in_exchange ,
CASE WHEN substr (pa_temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and pa_temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF'
WHEN pa_temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
WHEN SUBSTR(pa_temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( pa_temp.EXCHNG_IND_CD IS NULL OR pa_temp.EXCHNG_IND_CD ='UNK' ) AND pa_temp.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
END AS outoff_exchange,
CB.GL_LVL_DESC AS naic_lob,
MED.GL_CF_DESC  as  naic_prod_desc,
pa_temp.PRCP_TYPE_CD as prcp_type_cd,
PA1.case_type_cd as case_type_cd,
pa_temp.SRC_GRP_NBR as src_grp_nbr ,
pa_temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
""" + load_log_key + """ as load_log_key,
current_timestamp as load_dt
from """+ tblwrk1 +""" PA1
  
INNER JOIN """+ dbwrk +""".clm_inter pa_temp
ON PA1.MBR_KEY = pa_temp.MBR_KEY
  
INNER JOIN (
select CF_CD, GL_LVL_DESC
from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
WHERE GL_CF_TYPE_DESC = 'CBE'
AND GL_LVL_DESC in ('TOTAL INDIVIDUAL CBE')
group by 1,2
) as CB
on CB.CF_CD = pa_temp.MBU_CF_CD

INNER JOIN (
select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'PRODUCT'
AND GL_CF_DESC NOT LIKE '%CATASTROPHIC%'
group by 1,2
) as MED
on MED.CF_CD = pa_temp.PROD_CF_CD

inner join
(
select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY gl
where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  group by 1,2
) BRD
on BRD.CF_CD= pa_temp.MBU_CF_CD
and BRD.state <> 'LT'

inner join
(
select DISTINCT CF_CD
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where  GL_CF_TYPE_DESC = 'FUND_CODE'
and CF_CD NOT IN ( select DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'FUND_CODE' AND
( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
)
) FC
ON FC.CF_CD = pa_temp.FUNDG_CF_CD
WHERE PA1.""" +tempCol+ """  between pa_temp.MBR_PROD_ENRLMNT_EFCTV_DT and pa_temp.MBR_PROD_ENRLMNT_TRMNTN_DT
AND BRD.STATE NOT IN ('IL', 'DC', 'MA')


GROUP BY
PA1.RFRNC_NBR,
PA1.SRVC_LINE_NBR,
pa_temp.MBR_KEY,
PA1.SRVC_LINE_NBR,
pa_temp.MBRSHP_SOR_CD,
pa_temp.GRNDFTHR_IND_CD,
pa_temp.HIX_CD,
pa_temp.GRNDFTHRG_STTS_CD,
pa_temp.hcr_cmplynt_cd,
pa_temp.EXCHNG_IND_CD,
pa_temp.EXCHNG_METL_TYPE_CD,
pa_temp.SRC_EXCHNG_CERTFN_CD,
pa_temp.MBU_CF_CD,
pa_temp.PROD_CF_CD,
pa_temp.CMPNY_CF_CD,
pa_temp.FUNDG_CF_CD,
BRD.State,
CB.GL_LVL_DESC,
MED.GL_CF_DESC,
pa_temp.PRCP_TYPE_CD,
PA1.case_type_cd,
pa_temp.SRC_GRP_NBR,
pa_temp.SRC_SUBGRP_NBR
) x
-- where x.IN_Exchange = 'IN' OR x.OUTOFF_Exchange = 'OUTOFF'
"""

  //k7
def rqstdSmllGrp(dbwrk:String, dbInbnd: String, tbl: String, tblwrk1: String, reportYear: String, load_log_key: String, tempCol: String, prcp_cd: String) = """
Insert into table """ + tbl + """
select * from (select """ + reportYear + """ as health_year,
PA1.RFRNC_NBR AS RFRNC_NBR ,
PA1.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
pa_temp.MBR_KEY AS MBR_KEY,
pa_temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
pa_temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
pa_temp.MBU_CF_CD AS MBU_CF_CD ,
pa_temp.PROD_CF_CD AS PROD_CF_CD,
pa_temp.CMPNY_CF_CD AS CMPNY_CF_CD,
pa_temp.FUNDG_CF_CD AS FUNDG_CF_CD,
pa_temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
pa_temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
pa_temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
pa_temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
pa_temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
pa_temp.HIX_CD AS HIX_CD,
BRD.State AS  State,
CASE WHEN substring (pa_temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')
and pa_temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN'
WHEN pa_temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN'
WHEN SUBSTR(pa_temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( pa_temp.EXCHNG_IND_CD IS NULL OR pa_temp.EXCHNG_IND_CD ='UNK' ) AND pa_temp.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
END AS IN_Exchange,
CASE WHEN substr (pa_temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and pa_temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF'
WHEN pa_temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
WHEN SUBSTR(pa_temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( pa_temp.EXCHNG_IND_CD IS NULL OR pa_temp.EXCHNG_IND_CD ='UNK' ) AND pa_temp.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
END AS OUTOFF_Exchange,
CB.GL_LVL_DESC AS naic_lob,
MED.GL_CF_DESC  as  naic_prod_desc,
pa_temp.PRCP_TYPE_CD as prcp_type_cd,
PA1.case_type_cd as case_type_cd,
pa_temp.SRC_GRP_NBR as src_grp_nbr ,
pa_temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
""" + load_log_key + """ as load_log_key,
current_timestamp as load_dt
from

(select * from """ + tblwrk1 + """ )  PA1

INNER JOIN """+ dbwrk +""".clm_inter pa_temp
ON PA1.MBR_KEY = pa_temp.MBR_KEY 

inner join (
select CF_CD, GL_LVL_DESC
from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
WHERE GL_CF_TYPE_DESC = 'CBE'
AND GL_LVL_DESC in ('TOTAL SMALL GROUP CBE')
group by 1,2
) as CB
on CB.CF_CD =pa_temp.MBU_CF_CD

inner join (
select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'PRODUCT'
group by 1,2
) as MED
on MED.CF_CD = pa_temp.PROD_CF_CD

inner join
(
select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State
from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  group by 1,2
) BRD
on BRD.CF_CD= pa_temp.MBU_CF_CD
and BRD.state <> 'LT'

inner join
(
select DISTINCT CF_CD
from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
where  GL_CF_TYPE_DESC = 'FUND_CODE'
and CF_CD NOT IN ( select  CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'FUND_CODE' AND
( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
)
) FC
ON FC.CF_CD = pa_temp.FUNDG_CF_CD

WHERE PA1.""" + tempCol + """  between pa_temp.mbr_prod_enrlmnt_efctv_dt and pa_temp.mbr_prod_enrlmnt_trmntn_dt
AND BRD.STATE NOT IN ('IL', 'DC', 'MA')

GROUP BY
PA1.RFRNC_NBR  ,
PA1.SRVC_LINE_NBR,
pa_temp.MBR_KEY ,
pa_temp.MBRSHP_SOR_CD ,
pa_temp.GRNDFTHR_IND_CD  ,
pa_temp.HIX_CD ,
pa_temp.GRNDFTHRG_STTS_CD ,
pa_temp.hcr_cmplynt_cd,
pa_temp.EXCHNG_IND_CD ,
pa_temp.EXCHNG_METL_TYPE_CD ,
pa_temp.SRC_EXCHNG_CERTFN_CD ,
pa_temp.MBU_CF_CD  ,
pa_temp.PROD_CF_CD ,
pa_temp.CMPNY_CF_CD ,
pa_temp.FUNDG_CF_CD ,
BRD.State ,
CB.GL_LVL_DESC,
MED.GL_CF_DESC,
pa_temp.PRCP_TYPE_CD ,
PA1.case_type_cd ,
pa_temp.SRC_GRP_NBR,
pa_temp.SRC_SUBGRP_NBR
) x
"""

  //k8
def rqstdAll(dbwrk:String, dbInbnd: String, tbl: String, tblwrk1: String, reportYear: String, load_log_key: String, tempCol: String, prcp_cd: String) = """
Insert into table """ + tbl + """
select * from (select """ + reportYear + """ as health_year,
PA1.RFRNC_NBR AS RFRNC_NBR ,
PA1.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
pa_temp.MBR_KEY AS MBR_KEY,
pa_temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
pa_temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
pa_temp.MBU_CF_CD AS MBU_CF_CD ,
pa_temp.PROD_CF_CD AS PROD_CF_CD,
pa_temp.CMPNY_CF_CD AS CMPNY_CF_CD,
pa_temp.FUNDG_CF_CD AS FUNDG_CF_CD,
pa_temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
pa_temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
pa_temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,   
pa_temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
pa_temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
pa_temp.HIX_CD AS HIX_CD,
BRD.State AS  State,
CASE WHEN substring (pa_temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')
and pa_temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN'
WHEN pa_temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN'
WHEN SUBSTR(pa_temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( pa_temp.EXCHNG_IND_CD IS NULL OR pa_temp.EXCHNG_IND_CD ='UNK' ) AND pa_temp.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
END AS IN_Exchange ,
CASE WHEN substr (pa_temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and pa_temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF'
WHEN pa_temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
WHEN SUBSTR(pa_temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( pa_temp.EXCHNG_IND_CD IS NULL OR pa_temp.EXCHNG_IND_CD ='UNK' ) AND pa_temp.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
END AS OUTOFF_Exchange,
MED.GL_CF_DESC AS naic_lob,
MED.GL_CF_DESC  as  naic_prod_desc,
pa_temp.PRCP_TYPE_CD as prcp_type_cd ,
PA1.case_type_cd as case_type_cd,
pa_temp.SRC_GRP_NBR as src_grp_nbr ,
pa_temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
""" + load_log_key + """ as load_log_key,
current_timestamp as load_dt
from """+ tblwrk1 +"""  PA1
  
INNER JOIN """+ dbwrk +""".clm_inter pa_temp
ON PA1.MBR_KEY = pa_temp.MBR_KEY

inner join (
select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'PRODUCT'
AND GL_CF_DESC LIKE '%CATASTROPHIC%'
group by 1,2
) as MED
on MED.CF_CD = pa_temp.PROD_CF_CD

inner join
(
select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State
from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  group by 1,2
) BRD
on BRD.CF_CD= pa_temp.MBU_CF_CD
and BRD.state <> 'LT'

inner join
(
select DISTINCT CF_CD
from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
where  GL_CF_TYPE_DESC = 'FUND_CODE'
and CF_CD NOT IN ( select  CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'FUND_CODE' AND
( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
)
) FC
ON FC.CF_CD = pa_temp.FUNDG_CF_CD

WHERE PA1.""" + tempCol + """  between pa_temp.mbr_prod_enrlmnt_efctv_dt and pa_temp.mbr_prod_enrlmnt_trmntn_dt
AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
GROUP BY
PA1.RFRNC_NBR,
PA1.SRVC_LINE_NBR,
pa_temp.MBR_KEY ,
pa_temp.MBRSHP_SOR_CD ,
pa_temp.GRNDFTHR_IND_CD  ,
pa_temp.HIX_CD ,
pa_temp.GRNDFTHRG_STTS_CD ,
pa_temp.hcr_cmplynt_cd,
pa_temp.EXCHNG_IND_CD ,
pa_temp.EXCHNG_METL_TYPE_CD ,
pa_temp.SRC_EXCHNG_CERTFN_CD ,
pa_temp.MBU_CF_CD  ,
pa_temp.PROD_CF_CD ,
pa_temp.CMPNY_CF_CD ,
pa_temp.FUNDG_CF_CD ,
BRD.State ,
MED.GL_CF_DESC,
MED.GL_CF_DESC,
pa_temp.PRCP_TYPE_CD ,
PA1.case_type_cd ,
pa_temp.SRC_GRP_NBR,
pa_temp.SRC_SUBGRP_NBR
) x
--where x.IN_Exchange = 'IN' OR x.OUTOFF_Exchange = 'OUTOFF'
"""

def rqstdAllEx(dbwrk: String, dbInbnd: String, tbl: String, tblwrk1: String, reportYear: String, load_log_key: String, tempCol: String, prcp_cd: String) = """
Insert into table """ + tbl + """
select * from (select """ + reportYear + """ as health_year,
PA1.RFRNC_NBR AS RFRNC_NBR ,
PA1.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
pa_temp.MBR_KEY AS MBR_KEY,
pa_temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
pa_temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
pa_temp.MBU_CF_CD AS MBU_CF_CD ,
pa_temp.PROD_CF_CD AS PROD_CF_CD,
pa_temp.CMPNY_CF_CD AS CMPNY_CF_CD,
pa_temp.FUNDG_CF_CD AS FUNDG_CF_CD,
pa_temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
pa_temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
pa_temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,  
pa_temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
pa_temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
pa_temp.HIX_CD AS HIX_CD,
BRD.State AS  State,
CASE WHEN substring (pa_temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')
and pa_temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN'
WHEN pa_temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN'
WHEN SUBSTR(pa_temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( pa_temp.EXCHNG_IND_CD IS NULL OR pa_temp.EXCHNG_IND_CD ='UNK') AND pa_temp.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
END AS IN_Exchange ,
CASE WHEN substr (pa_temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and pa_temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF'
WHEN pa_temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
WHEN SUBSTR(pa_temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( pa_temp.EXCHNG_IND_CD IS NULL OR pa_temp.EXCHNG_IND_CD ='UNK') AND pa_temp.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
END AS OUTOFF_Exchange,
CB.GL_LVL_DESC AS naic_lob,
MED.GL_CF_DESC  as  naic_prod_desc,
pa_temp.PRCP_TYPE_CD as prcp_type_cd ,
PA1.case_type_cd as case_type_cd,
pa_temp.SRC_GRP_NBR as src_grp_nbr ,
pa_temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
""" + load_log_key + """ as load_log_key,
current_timestamp as load_dt
from """+ tblwrk1 +"""  PA1
  
INNER JOIN """+ dbwrk +""".clm_inter pa_temp
ON PA1.MBR_KEY = pa_temp.MBR_KEY
  
inner join (
select CF_CD, GL_LVL_DESC
from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
WHERE GL_CF_TYPE_DESC = 'CBE'
AND  GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' )
group by 1,2
) as CB
on CB.CF_CD = pa_temp.MBU_CF_CD

inner join (
select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'PRODUCT'
group by 1,2
) as MED
on MED.CF_CD = pa_temp.PROD_CF_CD

inner join
(
select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State
from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  group by 1,2
) BRD
on BRD.CF_CD= pa_temp.MBU_CF_CD
and BRD.state <> 'LT'


inner join
(
select DISTINCT CF_CD
from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
where  GL_CF_TYPE_DESC = 'FUND_CODE'
and CF_CD NOT IN ( select  CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'FUND_CODE' AND
( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
)
) FC
ON FC.CF_CD = pa_temp.FUNDG_CF_CD

WHERE PA1."""+tempCol+"""  between pa_temp.mbr_prod_enrlmnt_efctv_dt and pa_temp.mbr_prod_enrlmnt_trmntn_dt
AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
AND  pa_temp.MBU_CF_CD NOT IN ('EDCASH', 'SPGAZZ', 'EDCOSH', 'EDINSH')

GROUP BY
PA1.RFRNC_NBR,
PA1.SRVC_LINE_NBR,
pa_temp.MBR_KEY,
pa_temp.MBRSHP_SOR_CD,
pa_temp.GRNDFTHR_IND_CD,
pa_temp.HIX_CD,
pa_temp.GRNDFTHRG_STTS_CD,
pa_temp.hcr_cmplynt_cd,
pa_temp.EXCHNG_IND_CD,
pa_temp.EXCHNG_METL_TYPE_CD,
pa_temp.SRC_EXCHNG_CERTFN_CD,
pa_temp.MBU_CF_CD,
pa_temp.PROD_CF_CD,
pa_temp.CMPNY_CF_CD,
pa_temp.FUNDG_CF_CD,
BRD.State,
CB.GL_LVL_DESC,
MED.GL_CF_DESC,
pa_temp.PRCP_TYPE_CD,
PA1.case_type_cd,
pa_temp.SRC_GRP_NBR,
pa_temp.SRC_SUBGRP_NBR 
) x
--where x.IN_Exchange = 'IN' OR x.OUTOFF_Exchange = 'OUTOFF'
"""

  def rqstdAllLgp(dbwrk:String, dbInbnd: String, tbl: String, tblwrk1: String, reportYear: String, load_log_key: String, tempCol: String, prcp_cd: String) = """
Insert into table """ + tbl + """
select * from (select """ + reportYear + """ as health_year,
PA1.RFRNC_NBR AS RFRNC_NBR ,
PA1.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
pa_temp.MBR_KEY AS MBR_KEY,
pa_temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
pa_temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD,
pa_temp.MBU_CF_CD AS MBU_CF_CD,
pa_temp.PROD_CF_CD AS PROD_CF_CD,
pa_temp.CMPNY_CF_CD AS CMPNY_CF_CD,
pa_temp.FUNDG_CF_CD AS FUNDG_CF_CD,
pa_temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
pa_temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
pa_temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD,
pa_temp.hcr_cmplynt_cd AS hcr_cmplynt_cd,
pa_temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
pa_temp.HIX_CD AS HIX_CD,
BRD.State AS  State,
CASE WHEN substring (pa_temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')
and pa_temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN'
WHEN pa_temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN'
WHEN SUBSTR(pa_temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( pa_temp.EXCHNG_IND_CD IS NULL OR pa_temp.EXCHNG_IND_CD ='UNK' ) AND pa_temp.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' ) THEN 'IN'
END AS IN_Exchange ,
CASE WHEN substr (pa_temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and pa_temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF'
WHEN pa_temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
WHEN SUBSTR(pa_temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( pa_temp.EXCHNG_IND_CD IS NULL OR pa_temp.EXCHNG_IND_CD ='UNK' ) AND pa_temp.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' ) THEN 'OUTOFF'
END AS OUTOFF_Exchange,
CB.GL_LVL_DESC AS naic_lob,
MED.GL_CF_DESC  as  naic_prod_desc,
pa_temp.PRCP_TYPE_CD as prcp_type_cd,
PA1.case_type_cd as case_type_cd,
pa_temp.SRC_GRP_NBR as src_grp_nbr ,
pa_temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
""" + load_log_key + """ as load_log_key,
current_timestamp as load_dt
from """ + tblwrk1 + """  PA1
INNER JOIN """+ dbwrk +""".clm_inter pa_temp
ON PA1.MBR_KEY = pa_temp.MBR_KEY

INNER JOIN (
select CF_CD, GL_LVL_DESC
from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
WHERE GL_CF_TYPE_DESC = 'CBE'
AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE', 'TOTAL NATIONAL CBE' )
group by 1,2
) as CB
on CB.CF_CD = pa_temp.MBU_CF_CD

INNER JOIN (
select CF_CD, GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'PRODUCT'
group by 1,2
) as MED
on MED.CF_CD = pa_temp.PROD_CF_CD

INNER JOIN (
select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1 ) ) State
from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  group by 1,2
) BRD
on BRD.CF_CD= pa_temp.MBU_CF_CD
and BRD.state <> 'LT'

inner join
(
select DISTINCT CF_CD
from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
where  GL_CF_TYPE_DESC = 'FUND_CODE'
and CF_CD NOT IN ( select  CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'FUND_CODE' AND
( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
)
) FC
ON FC.CF_CD = pa_temp.FUNDG_CF_CD

WHERE PA1.""" + tempCol + """  between pa_temp.mbr_prod_enrlmnt_efctv_dt and pa_temp.mbr_prod_enrlmnt_trmntn_dt

--added on 0108
AND ( ( pa_temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN pa_temp.PRCHSR_ORG_EFCTV_DT AND pa_temp.PRCHSR_ORG_TRMNTN_DT) OR pa_temp.PRCHSR_ORG_TRMNTN_DT IS NULL)
AND ( pa_temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN pa_temp.MBR_COA_EFCTV_DT AND pa_temp.MBR_COA_TRMNTN_DT)

AND  pa_temp.MBU_CF_CD IN ('EDCASH', 'SPGAZZ', 'EDCOSH', 'EDINSH')
AND (pa_temp.SRC_GRP_NBR IN  ( '278777', '175089', '175147', '276470', '276500', '277956', '277960', '278547', '280438', '280531', '281249', '281285','281297', 'GA7649',  '175093', '281729', '196519', '196614', 'IN2008')
       OR pa_temp.ORG_GRP_SRC_GRP_NBR IN  ( '278777', '175089', '175147', '276470','276500', '277956', '277960', '278547', '280438', '280531', '281249', '281285' ,'281297', 'GA7649',  '175093', '281729', '196519', '196614', 'IN2008')
    )

GROUP BY
PA1.RFRNC_NBR,
PA1.SRVC_LINE_NBR ,
pa_temp.MBR_KEY,
pa_temp.MBRSHP_SOR_CD,
pa_temp.GRNDFTHR_IND_CD,
pa_temp.HIX_CD,
pa_temp.GRNDFTHRG_STTS_CD,
pa_temp.hcr_cmplynt_cd,
pa_temp.EXCHNG_IND_CD,
pa_temp.EXCHNG_METL_TYPE_CD,
pa_temp.SRC_EXCHNG_CERTFN_CD,
pa_temp.MBU_CF_CD,
pa_temp.PROD_CF_CD,
pa_temp.CMPNY_CF_CD,
pa_temp.FUNDG_CF_CD,
BRD.State,
CB.GL_LVL_DESC,
MED.GL_CF_DESC,
pa_temp.PRCP_TYPE_CD,
PA1.case_type_cd,
pa_temp.SRC_GRP_NBR,
pa_temp.SRC_SUBGRP_NBR 
) x
--where x.IN_Exchange = 'IN' OR x.OUTOFF_Exchange = 'OUTOFF'
"""
}
