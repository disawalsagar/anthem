package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.functions.{ row_number, current_timestamp, when, lit }
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.apache.spark.sql.functions.unix_timestamp

class PCADX_SCL_NAIC2018_DQ_v1(val spark: SparkSession) {

  /**
   *
   * Initialize Spark session and define class variables
   */
  /*val spark = SparkSession.builder().config("hive.exec.dynamic.partition","true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash","true").
    config("spark.sql.parquet.writeLegacyFormat","true").
    enableHiveSupport().getOrCreate()  */

  import spark.implicits._
  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_DQ_v1])
  val dbOu = dbProperties.getProperty("outbound.db")
  val dbWh = dbProperties.getProperty("warehouse.db")
  val audit_log_df = spark.sql("select * from " + dbWh + ".audt_load_log")
  val load_log_key = audit_log_df.filter($"subj_area_nm" === "NAIC2018_MCAS" && $"prcs_nm" === "NAIC2018_MCAS_RPT" && $"load_stts_cd" === "S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString()
  val tblOu = "naic2018_mcas_report_outbnd"

  //val time_stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-mm-dd hh:mm:ss"));
  val time_stamp = unix_timestamp()

  def sparkInIt() {

    //spark.sql("truncate table "+dbOu+".naic_mcas_report_qlty_outbnd")
    println("########")
    val outDf = readDataFromHive(tblOu).persist(StorageLevel.MEMORY_ONLY) //.withColumn("RuleNo", 0)
    val qltyTble = dbOu + ".naic2018_mcas_report_qlty_outbnd"
    val qty = "naic2018_mcas_report_qlty_outbnd"
    //val writeDf= processDataQuality(outDf)
    //var writeDf = readDataFromHive(qty)
    val vert_df = vertical_Rules_1(outDf)
    //val final_dq = writeDf.union(vert_df)
    writeDataToHive(qltyTble, vert_df)
    spark.close()
  }

  def vertical_Rules_1(outDf: DataFrame): DataFrame = {
//changed 2018
    var schedule_data = Seq("HLTHIEXINDIV", "HLTHIEXCAT", "HLTHIEXMSIND")
    var first_df = outDf.filter($"line_nbr".equalTo("20") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_1")).withColumn("Rule_Description", lit("nbrpoa_issued_cnt_check"))
    var second_df = outDf.filter($"line_nbr".equalTo("22") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_1")).withColumn("Rule_Description", lit("nbrpoa_issued_cnt_check"))
    //var merged_df = get_vertical_ruleset_1(first_df,second_df)

    schedule_data = Seq("HLTHIEXINDIV", "HLTHIEXSMGRP", "HLTHIEXMSIND", "HLTHIEXMSSGRP")
    var line_nbr = Seq("36", "37", "38", "39", "40")

    //changed 2018 36 --> 42
    first_df = outDf.filter($"line_nbr".equalTo("42") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_7")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("43") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_7")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    var third_df = outDf.filter($"line_nbr".equalTo("44") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_7")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    var fourth_df = outDf.filter($"line_nbr".equalTo("45") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_7")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    var fifth_df = outDf.filter($"line_nbr".equalTo("46") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_7")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    var merged_df = get_vertical_ruleset_8(first_df, second_df, third_df, fourth_df, fifth_df)

    //changed 2018 41 --> 52
    first_df = outDf.filter($"line_nbr".equalTo("52") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_8")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("53") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_8")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("54") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_8")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("55") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_8")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("56") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_8")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_8(first_df, second_df, third_df, fourth_df, fifth_df))

    //changed 2018 46 --> 62
    schedule_data = Seq("HLTHIEXINDIV", "HLTHIEXSMGRP", "HLTHIEXMSIND")
    
    first_df = outDf.filter($"line_nbr".equalTo("62") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_9")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("63") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_9")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("64") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_9")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("65") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_9")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("66") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_9")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_8(first_df, second_df, third_df, fourth_df, fifth_df))

     //changed 2018 51 --> 67
    
    schedule_data = Seq("HLTHIEXINDIV", "HLTHIEXSMGRP", "HLTHIEXMSIND", "HLTHIEXMSSGRP")
    
    first_df = outDf.filter($"line_nbr".equalTo("67") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_10")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("68") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_10")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("69") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_10")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("70") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_10")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("71") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_10")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_8(first_df, second_df, third_df, fourth_df, fifth_df))

   
   
   
   
    //changed 2018  (93 --> 125)
    first_df = outDf.filter($"line_nbr".equalTo("115") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_23")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("116") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_23")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("117") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_23")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("118") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_23")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("119") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_23")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_8(first_df, second_df, third_df, fourth_df, fifth_df))

    //changed 2018  (98 --> 125)
    first_df = outDf.filter($"line_nbr".equalTo("125") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_24")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("126") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_24")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("127") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_24")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("128") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_24")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("129") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_24")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_8(first_df, second_df, third_df, fourth_df, fifth_df))

    //changed 2018  (103 --> 135)
    first_df = outDf.filter($"line_nbr".equalTo("135") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_25")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("136") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_25")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("137") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_25")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("138") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_25")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("139") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_25")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_8(first_df, second_df, third_df, fourth_df, fifth_df))

    //New code added 2018
     first_df = outDf.filter($"line_nbr".equalTo("140") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_26")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("141") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_26")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("142") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_26")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("143") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_26")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("144") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_26")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_8(first_df, second_df, third_df, fourth_df, fifth_df))

    
    schedule_data = Seq("HLTHOEXGRFTHD")
    
    //changed 2018  (108 --> 140) 
    first_df = outDf.filter($"line_nbr".equalTo("140") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_35")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("141") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_35")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("142") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_35")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("143") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_35")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("144") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_35")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_10(first_df, second_df, third_df, fourth_df, fifth_df))

    
    //changed 2018  (103 --> 135) 
    first_df = outDf.filter($"line_nbr".equalTo("135") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_34")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("136") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_34")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("137") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_34")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("138") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_34")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("139") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_34")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_10(first_df, second_df, third_df, fourth_df, fifth_df))
    
    
     //changed 2018  (98 --> 125) 
    first_df = outDf.filter($"line_nbr".equalTo("125") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_33")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("126") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_33")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("127") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_33")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("128") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_33")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("129") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_33")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_10(first_df, second_df, third_df, fourth_df, fifth_df))
    
     //changed 2018  (93 --> 115) 
    first_df = outDf.filter($"line_nbr".equalTo("115") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_32")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("116") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_32")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("117") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_32")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("118") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_32")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("119") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_32")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_10(first_df, second_df, third_df, fourth_df, fifth_df))
    
    //new coded added 2018
    schedule_data = Seq("HLTHIEXCAT")
    
    first_df = outDf.filter($"line_nbr".equalTo("67") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_15")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("68") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_15")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("69") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_15")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("70") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_15")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("71") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_15")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_9(first_df, second_df, third_df, fourth_df, fifth_df))

    //new coded added 2018 
    first_df = outDf.filter($"line_nbr".equalTo("62") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_14")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("63") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_14")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("64") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_14")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("65") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_14")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("66") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_14")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_9(first_df, second_df, third_df, fourth_df, fifth_df))

     //new coded added 2018 
    first_df = outDf.filter($"line_nbr".equalTo("52") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_13")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("53") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_13")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("54") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_13")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("55") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_13")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("56") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_13")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_9(first_df, second_df, third_df, fourth_df, fifth_df))

      //new coded added 2018 
    first_df = outDf.filter($"line_nbr".equalTo("42") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_12")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("43") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_12")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("44") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_12")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("45") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_12")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("46") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_12")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_9(first_df, second_df, third_df, fourth_df, fifth_df))

    
    schedule_data = Seq("HLTHOEXCAT", "HLTHOEXLGGRP", "HLTHOEXSTDNT")
    
    
    
    
     //changed 2018  (103 --> 135)
    
    first_df = outDf.filter($"line_nbr".equalTo("135") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_43")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("136") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_43")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("137") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_43")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("138") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_43")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("139") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_43")).withColumn("Rule_Description", lit("nbrclm_paid_inntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_9(first_df, second_df, third_df, fourth_df, fifth_df))
   

    
    //changed 2018  (93 --> 115)
    first_df = outDf.filter($"line_nbr".equalTo("115") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_41")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("116") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_41")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("117") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_41")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("118") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_41")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("119") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_41")).withColumn("Rule_Description", lit("nbrclm_denied_inntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_9(first_df, second_df, third_df, fourth_df, fifth_df))

    //changed 2018  (98 --> 125)
    first_df = outDf.filter($"line_nbr".equalTo("125") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_42")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("126") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_42")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("127") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_42")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("128") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_42")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("129") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_42")).withColumn("Rule_Description", lit("nbrclm_denied_outntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_9(first_df, second_df, third_df, fourth_df, fifth_df))
    //changed 2018  (108 --> 140)
    first_df = outDf.filter($"line_nbr".equalTo("140") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_44")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    second_df = outDf.filter($"line_nbr".equalTo("141") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_44")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    third_df = outDf.filter($"line_nbr".equalTo("142") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_44")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    fourth_df = outDf.filter($"line_nbr".equalTo("143") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_44")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    fifth_df = outDf.filter($"line_nbr".equalTo("144") && $"schedule".isin(schedule_data: _*)).withColumn("RuleNo", lit("v_44")).withColumn("Rule_Description", lit("nbrclm_paid_outntwk_cnt_blnc_check"))
    merged_df = merged_df.union(get_vertical_ruleset_9(first_df, second_df, third_df, fourth_df, fifth_df))

    merged_df = merged_df.withColumn(
      "QualityIndicator",
      when(($"report_val_6".isNull && $"report_val_7".isNull && $"report_val_8".isNull && $"report_val_9".isNull && $"report_val_10".isNull), "NA").otherwise($"QualityIndicator"))

    //  merged_df.show()
    merged_df = merged_df.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", lit(time_stamp)).select("health_year", "naic_cmpny_cd", "state", "schedule", "line_nbr", "report_val_6", "report_val_7", "report_val_8", "report_val_9", "report_val_10", "format_nbr", "format_field_nbr", "sel_priority", "RuleNo", "Rule_Description", "QualityIndicator", "load_log_key", "load_dt")
    merged_df

  }

  def get_vertical_ruleset_8(first_df: DataFrame, second_df: DataFrame, third_df: DataFrame, fourth_df: DataFrame, fifth_df: DataFrame): DataFrame = {
    var flag = false;

    //outer join
    //select statement
    //make sure that rule are not overwritten
    val merged_Df = first_df.alias("parent").join(second_df.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.naic_cmpny_cd" === $"child.naic_cmpny_cd" && $"parent.state" === $"child.state" && $"parent.schedule" === $"child.schedule", "outer").
      join(third_df.alias("t_child"), $"parent.health_year" === $"t_child.health_year"
        && $"parent.naic_cmpny_cd" === $"t_child.naic_cmpny_cd" && $"parent.state" === $"t_child.state" && $"parent.schedule" === $"t_child.schedule", "outer").
      join(fourth_df.alias("f_child"), $"parent.health_year" === $"f_child.health_year"
        && $"parent.naic_cmpny_cd" === $"f_child.naic_cmpny_cd" && $"parent.state" === $"f_child.state" && $"parent.schedule" === $"f_child.schedule", "outer").
      join(fifth_df.alias("ff_child"), $"parent.health_year" === $"ff_child.health_year"
        && $"parent.naic_cmpny_cd" === $"ff_child.naic_cmpny_cd" && $"parent.state" === $"ff_child.state" && $"parent.schedule" === $"ff_child.schedule", "outer").
      withColumn(
        "QualityIndicator",
        /*when($"child.report_val_6" + $"t_child.report_val_6" + $"f_child.report_val_6" + $"ff_child.report_val_6" === $"parent.report_val_6" &&
                 $"child.report_val_7" + $"t_child.report_val_7" + $"f_child.report_val_7" + $"ff_child.report_val_7" === $"parent.report_val_7" &&
                 $"child.report_val_8" + $"t_child.report_val_8" + $"f_child.report_val_8" + $"ff_child.report_val_8" === $"parent.report_val_8" &&
                 $"child.report_val_9" + $"t_child.report_val_9" + $"f_child.report_val_9" + $"ff_child.report_val_9" === $"parent.report_val_9" &&
                 $"child.report_val_10" + $"t_child.report_val_10" + $"f_child.report_val_10" + $"ff_child.report_val_10" === $"parent.report_val_10" , "Y").otherwise("N"))*/
        when(($"child.report_val_6" + $"t_child.report_val_6" + $"f_child.report_val_6" + $"ff_child.report_val_6" === $"parent.report_val_6" || ($"child.report_val_6".isNull && $"t_child.report_val_6".isNull && $"f_child.report_val_6".isNull && $"ff_child.report_val_6".isNull && $"parent.report_val_6".isNull)) &&
          ($"child.report_val_7" + $"t_child.report_val_7" + $"f_child.report_val_7" + $"ff_child.report_val_7" === $"parent.report_val_7" || ($"child.report_val_7".isNull && $"t_child.report_val_7".isNull && $"f_child.report_val_7".isNull && $"ff_child.report_val_7".isNull && $"parent.report_val_7".isNull)) &&
          ($"child.report_val_8" + $"t_child.report_val_8" + $"f_child.report_val_8" + $"ff_child.report_val_8" === $"parent.report_val_8" || ($"child.report_val_8".isNull && $"t_child.report_val_8".isNull && $"f_child.report_val_8".isNull && $"ff_child.report_val_8".isNull && $"parent.report_val_8".isNull)) &&
          ($"child.report_val_9" + $"t_child.report_val_9" + $"f_child.report_val_9" + $"ff_child.report_val_9" === $"parent.report_val_9" || ($"child.report_val_9".isNull && $"t_child.report_val_9".isNull && $"f_child.report_val_9".isNull && $"ff_child.report_val_9".isNull && $"parent.report_val_9".isNull)) &&
          ($"child.report_val_10" + $"t_child.report_val_10" + $"f_child.report_val_10" + $"ff_child.report_val_10" === $"parent.report_val_10" || ($"child.report_val_10".isNull && $"t_child.report_val_10".isNull && $"f_child.report_val_10".isNull && $"ff_child.report_val_10".isNull && $"parent.report_val_10".isNull)), "Y").otherwise("N"))
    val Components = List("parent", "child", "t_child", "f_child", "ff_child")

    val final_df = getUnionDf(merged_Df, Components.toSeq)
    final_df

  }

  def get_vertical_ruleset_9(first_df: DataFrame, second_df: DataFrame, third_df: DataFrame, fourth_df: DataFrame, fifth_df: DataFrame): DataFrame = {
    var flag = false;

    //outer join
    //select statement
    //make sure that rule are not overwritten
    val merged_Df = first_df.alias("parent").join(second_df.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.naic_cmpny_cd" === $"child.naic_cmpny_cd" && $"parent.state" === $"child.state" && $"parent.schedule" === $"child.schedule", "outer").
      join(third_df.alias("t_child"), $"parent.health_year" === $"t_child.health_year"
        && $"parent.naic_cmpny_cd" === $"t_child.naic_cmpny_cd" && $"parent.state" === $"t_child.state" && $"parent.schedule" === $"t_child.schedule", "outer").
      join(fourth_df.alias("f_child"), $"parent.health_year" === $"f_child.health_year"
        && $"parent.naic_cmpny_cd" === $"f_child.naic_cmpny_cd" && $"parent.state" === $"f_child.state" && $"parent.schedule" === $"f_child.schedule", "outer").
      join(fifth_df.alias("ff_child"), $"parent.health_year" === $"ff_child.health_year"
        && $"parent.naic_cmpny_cd" === $"ff_child.naic_cmpny_cd" && $"parent.state" === $"ff_child.state" && $"parent.schedule" === $"ff_child.schedule", "outer").
      withColumn(
        "QualityIndicator",
        when(
          ($"child.report_val_6" + $"t_child.report_val_6" + $"f_child.report_val_6" + $"ff_child.report_val_6" === $"parent.report_val_6" || ($"child.report_val_6".isNull && $"t_child.report_val_6".isNull && $"f_child.report_val_6".isNull && $"ff_child.report_val_6".isNull && $"parent.report_val_6".isNull)),
          "Y").otherwise("N"))

    val Components = List("parent", "child", "t_child", "f_child", "ff_child")

    val final_df = getUnionDf(merged_Df, Components.toSeq)
    final_df

  }

  def get_vertical_ruleset_10(first_df: DataFrame, second_df: DataFrame, third_df: DataFrame, fourth_df: DataFrame, fifth_df: DataFrame): DataFrame = {
    var flag = false;

    //outer join
    //select statement
    //make sure that rule are not overwritten
    val merged_Df = first_df.alias("parent").join(second_df.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.naic_cmpny_cd" === $"child.naic_cmpny_cd" && $"parent.state" === $"child.state" && $"parent.schedule" === $"child.schedule", "outer").
      join(third_df.alias("t_child"), $"parent.health_year" === $"t_child.health_year"
        && $"parent.naic_cmpny_cd" === $"t_child.naic_cmpny_cd" && $"parent.state" === $"t_child.state" && $"parent.schedule" === $"t_child.schedule", "outer").
      join(fourth_df.alias("f_child"), $"parent.health_year" === $"f_child.health_year"
        && $"parent.naic_cmpny_cd" === $"f_child.naic_cmpny_cd" && $"parent.state" === $"f_child.state" && $"parent.schedule" === $"f_child.schedule", "outer").
      join(fifth_df.alias("ff_child"), $"parent.health_year" === $"ff_child.health_year"
        && $"parent.naic_cmpny_cd" === $"ff_child.naic_cmpny_cd" && $"parent.state" === $"ff_child.state" && $"parent.schedule" === $"ff_child.schedule", "outer").
      withColumn(
        "QualityIndicator",
        /*when($"child.report_val_6" + $"t_child.report_val_6" + $"f_child.report_val_6" + $"ff_child.report_val_6" === $"parent.report_val_6" &&
                 $"child.report_val_7" + $"t_child.report_val_7" + $"f_child.report_val_7" + $"ff_child.report_val_7" === $"parent.report_val_7" &&
                 $"child.report_val_8" + $"t_child.report_val_8" + $"f_child.report_val_8" + $"ff_child.report_val_8" === $"parent.report_val_8" &&
                 $"child.report_val_9" + $"t_child.report_val_9" + $"f_child.report_val_9" + $"ff_child.report_val_9" === $"parent.report_val_9"   , "Y").otherwise("N"))*/
        when(($"child.report_val_6" + $"t_child.report_val_6" + $"f_child.report_val_6" + $"ff_child.report_val_6" === $"parent.report_val_6" || ($"child.report_val_6".isNull && $"t_child.report_val_6".isNull && $"f_child.report_val_6".isNull && $"ff_child.report_val_6".isNull && $"parent.report_val_6".isNull)) &&
          ($"child.report_val_7" + $"t_child.report_val_7" + $"f_child.report_val_7" + $"ff_child.report_val_7" === $"parent.report_val_7" || ($"child.report_val_7".isNull && $"t_child.report_val_7".isNull && $"f_child.report_val_7".isNull && $"ff_child.report_val_7".isNull && $"parent.report_val_7".isNull)) &&
          ($"child.report_val_8" + $"t_child.report_val_8" + $"f_child.report_val_8" + $"ff_child.report_val_8" === $"parent.report_val_8" || ($"child.report_val_8".isNull && $"t_child.report_val_8".isNull && $"f_child.report_val_8".isNull && $"ff_child.report_val_8".isNull && $"parent.report_val_8".isNull)) &&
          ($"child.report_val_9" + $"t_child.report_val_9" + $"f_child.report_val_9" + $"ff_child.report_val_9" === $"parent.report_val_9" || ($"child.report_val_9".isNull && $"t_child.report_val_9".isNull && $"f_child.report_val_9".isNull && $"ff_child.report_val_9".isNull && $"parent.report_val_9".isNull)), "Y").otherwise("N"))
    val Components = List("parent", "child", "t_child", "f_child", "ff_child")

    val final_df = getUnionDf(merged_Df, Components.toSeq)
    final_df

  }

  def getUnionDf(df: DataFrame, sSeq: Seq[String]): DataFrame = {
    var unionDf: DataFrame = null
    var first_df: Boolean = true
    for (x <- sSeq) {
      val df1 = df.select(x + ".health_year", x + ".naic_cmpny_cd", x + ".state", x + ".schedule", x + ".line_nbr", x + ".report_val_6", x + ".report_val_7", x + ".report_val_8", x + ".report_val_9", x + ".report_val_10", x + ".format_nbr", x + ".format_field_nbr", x + ".sel_priority", x + ".RuleNo", x + ".Rule_Description", "QualityIndicator")
      if (first_df) {
        println("First df true")
        unionDf = df1
        first_df = false
      } else {
        println("Union true")
        unionDf = unionDf.union(df1)
      }
    }
    unionDf
  }

  /**
   * Reads output table data from hive into Dataframe
   * @param : Table name
   * @return: output table dataframe
   *
   */
  def readDataFromHive(tble: String): DataFrame = {
    val queryOutputTable = """SELECT * FROM """ + dbOu + """.""" + tble

    val tbl_data_df = spark.sql(queryOutputTable) //.na.fill(0)
    logger.info("Read data from hive")
    tbl_data_df
  }

  /**
   * This method writes the dataframe to the hive table
   * @param :  table Name and datfarme to be written to the table
   */
  def writeDataToHive(tblName: String, finalDf: DataFrame) {
    //finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
    finalDf.write.mode(SaveMode.Append).insertInto(tblName)
    println("Data added in stage table")
  }

}

object PCADX_SCL_NAIC2018_DQ_v1 {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    //new PCADX_SCL_NAIC_DQ_v1().sparkInIt()
  }
}