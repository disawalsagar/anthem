package gen

import java.util.Properties
import org.apache.spark.sql.SparkSession

object PCADX_SCL_NAIC2018_EnvironValues {

  var fileName = ""
  private var refreshNumber = ""
  var claimServiceStartDate = ""
  var claimServiceEndDate = ""
  var warehouseDB = ""
  var load_log_key = ""
  def setFileName(str: String) = {
    if (str.equalsIgnoreCase("TS")) {
      fileName = "/ts_application.properties"
    } else if (str.equalsIgnoreCase("DV")) {
      fileName = "/dv_application.properties"
    } else if (str.equalsIgnoreCase("PR")) {
      fileName = "/pr_application.properties"
    } else {
      println("Please make sure you pass the correct Environment value(PR or TS or DV). \"" + str + "\" is passed. ")
      throw new IllegalArgumentException
    }
    println("===========================================")
    println("      Taking values from " + fileName)
    println("===========================================")
  }

  def setllk(dbWrh: String) = {
    val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
      config("hive.exec.dynamic.partition.mode", "nonstrict").
      config("spark.sql.parquet.compression.codec", "snappy").
      config("hive.warehouse.data.skipTrash", "true").
      config("spark.sql.parquet.writeLegacyFormat", "true").
      enableHiveSupport().getOrCreate()

    import spark.implicits._

    val audit_log_df = spark.sql("select * from  " + dbWrh + ".audt_load_log")

    if (!audit_log_df.take(1).isEmpty) {
      load_log_key = audit_log_df.filter($"subj_area_nm" === "NAIC2018_MCAS" && $"prcs_nm" === "NAIC2018_MCAS_RPT" && $"load_stts_cd" === "S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString()
    }

    println("load_log_key : " + load_log_key)

  }

}