package gen

import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.DataFrame
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit

import org.apache.hadoop.fs._;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

class PCADX_SCL_NAIC2018_InputFileProcessor {

  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()

  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_InputFileProcessor])
  val inbndPath = dbProperties.getProperty("inbound.path")
  val inbndDb = dbProperties.getProperty("inbound.db")
  val stgDb = dbProperties.getProperty("stage.db")
  val wrhDb = dbProperties.getProperty("warehouse.db")
  val time_stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

  import spark.implicits._

  def sparkInit(tbl: String, delimit: String) {
    processInputFile(inbndDb, stgDb, tbl.toLowerCase(), inbndPath, delimit)
    spark.close()
  }
  /**
   * The method takes the input the as the file name and delimiter add timestamp and put it to stage
   * @param input,stage db, table, input path and delimiters
   * @result Clean data in stage.
   */

  def processInputFile(inbndDb: String, stgDb: String, tbl: String, inbndPath: String, delimit: String) {
    println("Inbnd path :" +inbndPath + "/" + tbl + "_inbnd")
    var inputDf:DataFrame = null
    //val inputDf = spark.read.option("delimiter", delimit).option("quote", "\"").option("multiline", true).csv(inbndPath + "/" + tbl + "_inbnd")
     if (tbl.equalsIgnoreCase("naic2018_mcas_hlthiex_gl") || tbl.equalsIgnoreCase("naic2018_mcas_hlthoex_bh")){
     inputDf = spark.read.option("delimiter", delimit).option("multiline", true).csv(inbndPath + "/" + tbl + "_inbnd")
     }else{
       inputDf = spark.read.option("delimiter", delimit).csv(inbndPath + "/" + tbl + "_inbnd")
     }
    val header = inputDf.first()
   // inputDf.show()
    val audit_log_df = spark.sql("select * from "+wrhDb+".audt_load_log")
    var load_log_key:Long = 0
    //load_log_key=10
   
    if(!audit_log_df.take(1).isEmpty){
      load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0)
    }
    println("load_log_key : "+load_log_key)
    
    //val load_log_k = load_log_key(0)(0)
    if (tbl.equalsIgnoreCase("naic2018_mcas_codes_legal")) {
      inputDf.filter(x => x != header).withColumn("load_log_key",lit(load_log_key)).withColumn("load_dt", lit(time_stamp)).createOrReplaceTempView("inputTable")
      
    } else {
      inputDf.filter(x => x != header ).withColumn("load_log_key",lit(load_log_key)).withColumn("load_dt", lit(time_stamp)).createOrReplaceTempView("inputTable")
      //inputDf.filter(x => x != header ).createOrReplaceTempView("inputTable")
    }
    
    spark.sql("INSERT OVERWRITE TABLE " + stgDb + "." + tbl + "_stg select * from inputTable")
  }

}

object PCADX_SCL_NAIC2018_InputFileProcessor {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    new PCADX_SCL_NAIC2018_InputFileProcessor().sparkInit(args(1), args(2))

  }

}