package gen
import java.util.Properties
import org.apache.spark.sql.SparkSession
import org.apache.log4j.PropertyConfigurator
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException
import org.apache.spark.sql.functions.lit
import org.apache.hadoop.fs._
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter

class PCADX_SCL_NAIC2018_POAG_UN_TermdLives{

	val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
			config("hive.exec.dynamic.partition.mode", "nonstrict").
			config("spark.sql.parquet.compression.codec", "snappy").
			config("hive.warehouse.data.skipTrash", "true").
			config("spark.sql.parquet.writeLegacyFormat", "true").
			enableHiveSupport().getOrCreate()
			
			import spark.implicits._
			
			var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_DataExtraction])
			
			val dbProperties = new Properties
			dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
			val dbWrk = dbProperties.getProperty("work.db")
			val dbInbnd = dbProperties.getProperty("inbound.db")
      val reportYear =dbProperties.getProperty("report.year")
			val mbrEffBetFrmDt=dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_BET_FROM")
			val mbrEffBetToDt=dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_BET_TO")
			val mbrEffNotBetFrmDt=dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_NOT_BET_FROM")
			val mbrEffNotBetToDt=dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_NOT_BET_TO")
			val mbrTrmntBetFrmDt=dbProperties.getProperty("MBR_PROD_ENRLMNT_TRMNTN_DT_BET_FROM")
			val mbrTrmntBetToDt=dbProperties.getProperty("MBR_PROD_ENRLMNT_TRMNTN_DT_BET_TO")  
			val mbrTrmntGrtr = dbProperties.getProperty("MBR_PROD_ENRLMNT_TRMNTN_DT_GREATER")
			val wrhDb = dbProperties.getProperty("warehouse.db")
			val PRCHSRENotBetToDt = dbProperties.getProperty("PRCHSR_ORG_EFCTV_DT_NOT_BET_TO")

			val audit_log_df = spark.sql("select * from "+wrhDb+".audt_load_log") 
			val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0) 
			println("load_log_key : "+load_log_key) 	   

			println(" DB INBND : "+ dbInbnd)
			println(" DB wrk : "+ dbWrk)
			
			def poa_unicare_termed_lives_Trunc() = """Truncate table """+dbWrk+""".naic2018_mcas_hlthex_poag_unicare_termed_lives_wrk"""

			def poa_unicare_termed_lives_ma() ="""Insert into table """+dbWrk+""".naic2018_mcas_hlthex_poag_unicare_termed_lives_wrk"""+
					"""
					select x.health_year,
					x.sbscrbr_id ,
					x.mbr_rltnshp_cd , 
					x.mbr_prod_enrlmnt_efctv_dt ,
					x.mbr_prod_enrlmnt_trmntn_dt ,
					x.mbr_key ,
					x.mbrshp_sor_cd ,   
					x.grndfthr_ind_cd  ,
					x.mbu_cf_cd  ,
					x.prod_cf_cd,
					x.cmpny_cf_cd ,
					x.fundg_cf_cd,
					x.exchng_ind_cd ,
					x.exchng_metl_type_cd ,
					x.grndfthrg_stts_cd  ,   
					x.hcr_cmplynt_cd  ,
					x.src_exchng_certfn_cd ,
					x.state,
					x.in_exchange ,
					x.outoff_exchange, 
					x.naic_lob,
					x.naic_prod_desc,
					x.src_grp_nbr  ,
					x.src_subgrp_nbr,
					x.pos_mbrshp_sor_cd ,
          x.prchsr_org_type_cd ,
          x.prchsr_org_efctv_dt ,
          x.prchsr_org_trmntn_dt,
          x.prchsr_org_trmntn_rsncd ,
          x.bnft_pkg_nm ,
          x.bnft_pkg_id ,
					x.load_log_key,
					x.load_dt 
					from( 
					select 
					"""+reportYear+"""   as health_year,
					temp.SBSCRBR_ID as SBSCRBR_ID,
					temp.MBR_RLTNSHP_CD as MBR_RLTNSHP_CD, 
					temp.MBR_PROD_ENRLMNT_EFCTV_DT as MBR_PROD_ENRLMNT_EFCTV_DT,
					temp.MBR_PROD_ENRLMNT_TRMNTN_DT as MBR_PROD_ENRLMNT_TRMNTN_DT,
					temp.MBR_KEY AS MBR_KEY,
					temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,   
					temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
					temp.MBU_CF_CD AS MBU_CF_CD ,
					temp.PROD_CF_CD AS PROD_CF_CD,
					temp.CMPNY_CF_CD AS CMPNY_CF_CD,
					temp.FUNDG_CF_CD AS FUNDG_CF_CD,
					temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
					temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
					temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,   
					temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
					temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
					'MA'  AS  State,
					NULL   AS IN_Exchange ,
					'OUTOFF'  AS OUTOFF_Exchange, 
					'LARGE GROUP CBE'  AS naic_lob,
					MED.GL_CF_DESC  as  naic_prod_desc,
					temp.SRC_GRP_NBR as src_grp_nbr ,
					temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
					temp.pos_mbrshp_sor_cd as  pos_mbrshp_sor_cd ,
          temp.prchsr_org_type_cd as prchsr_org_type_cd ,
          temp.pos_prchsr_org_efctv_dt  as prchsr_org_efctv_dt ,
          temp.pos_prchsr_org_trmntn_dt as prchsr_org_trmntn_dt,
          temp.prchsr_org_trmntn_rsncd  as  prchsr_org_trmntn_rsncd ,
          temp.bnft_pkg_nm as bnft_pkg_nm,
          temp.bnft_pkg_id as bnft_pkg_id,
					$1  as load_log_key,
					current_timestamp as load_dt

					FROM  """+dbWrk+""".naic2018_mcas_hlthex_poa_wrk temp
					inner join (
					select CF_CD,  GL_CF_DESC  
					from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
					where GL_CF_TYPE_DESC = 'PRODUCT' 
					group by 1,2
					) as MED
					on MED.CF_CD = temp.PROD_CF_CD
					inner join
					(
					select DISTINCT CF_CD
					from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
					where  GL_CF_TYPE_DESC = 'FUND_CODE'
					and CF_CD NOT IN ( select  DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY  

					where     GL_CF_TYPE_DESC = 'FUND_CODE' 
					AND    ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
					)
					) FC
					ON FC.CF_CD = temp.FUNDG_CF_CD

					INNER JOIN """+dbInbnd+""".naic2018_mcas_gphm_trmntn_rsncd_inbnd  inbnd
					ON temp.MBR_ENRLMNT_TRMNTN_RSN_CD = inbnd.mbr_enrlmnt_trmntn_rsncd					
					AND temp.SRC_MBR_ENRLMNT_TRMNTN_RSN_CD = inbnd.src_mbr_enrlmnt_trmntn_rsncd
					AND temp.mbrshp_sor_cd = inbnd.mbrshp_sor_cd
					
				  LEFT OUTER JOIN  """+dbWrk+""".termed_prchsrcgrpnotin srcgrpim
			    on temp.pos_mbrshp_sor_cd = srcgrpim.mbrshp_sor_cd
			    AND temp.src_grp_nbr = srcgrpim.src_grp_nbr
      
 					where 					
          (srcgrpim.mbrshp_sor_cd is  null  AND srcgrpim.mbrshp_sor_cd is null )
					--temp.MBR_PROD_ENRLMNT_EFCTV_DT BETWEEN """+mbrEffBetFrmDt+""" AND """+mbrEffBetToDt+"""
					--AND temp.MBR_PROD_ENRLMNT_EFCTV_DT NOT BETWEEN """+mbrEffNotBetFrmDt+""" AND """+mbrEffNotBetToDt+"""
					   AND ( temp.pos_prchsr_org_trmntn_dt BETWEEN """ + mbrTrmntBetFrmDt + """ AND """ + mbrTrmntBetToDt + """
			      OR temp.pos_prchsr_org_trmntn_dt =   """ + PRCHSRENotBetToDt + """ )
			    AND temp.pos_prchsr_org_trmntn_dt <  """ + mbrTrmntGrtr + """
					  
					and (temp.SRC_GRP_NBR = '131192' or temp.ORG_GRP_SRC_GRP_NBR = '131192')

					AND ( ( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN temp.pos_prchsr_org_efctv_dt AND temp.pos_prchsr_org_trmntn_dt) OR temp.pos_prchsr_org_trmntn_dt IS NULL)
					AND ( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN temp.MBR_COA_EFCTV_DT AND temp.MBR_COA_TRMNTN_DT) 
					AND temp.DUP_DATA_CD = '00'

					GROUP BY
					temp.SBSCRBR_ID ,
					temp.MBR_RLTNSHP_CD ,
					temp.MBR_PROD_ENRLMNT_EFCTV_DT ,
					temp.MBR_PROD_ENRLMNT_TRMNTN_DT ,
					temp.MBR_KEY ,
					temp.SRC_MBR_ENRLMNT_TRMNTN_RSN_CD ,
					temp.MBRSHP_SOR_CD ,
					temp.GRNDFTHR_IND_CD  ,
					temp.GRNDFTHRG_STTS_CD  ,
					temp.HCR_CMPLYNT_CD  ,
					temp.EXCHNG_IND_CD ,
					temp.EXCHNG_METL_TYPE_CD ,
					temp.SRC_EXCHNG_CERTFN_CD ,
					temp.MBU_CF_CD  ,
					temp.PROD_CF_CD ,
					temp.CMPNY_CF_CD ,
					temp.FUNDG_CF_CD ,
					temp.SRC_GRP_NBR ,
					temp.SRC_SUBGRP_NBR,
					MED.GL_CF_DESC,
					temp.pos_mbrshp_sor_cd ,
          temp.prchsr_org_type_cd ,
          temp.pos_prchsr_org_efctv_dt ,
          temp.pos_prchsr_org_trmntn_dt,
          temp.prchsr_org_trmntn_rsncd ,
          temp.bnft_pkg_nm ,
          temp.bnft_pkg_id 
					)x 

					--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'"""
	
		def poa_unicare_termed_lives_ma_step2() ="""Insert into table """+dbWrk+""".naic2018_mcas_hlthex_poag_unicare_termed_lives_wrk"""+
					"""
					select x.health_year,
					x.SBSCRBR_ID ,
					x.MBR_RLTNSHP_CD , 
					x.MBR_PROD_ENRLMNT_EFCTV_DT ,
					x.MBR_PROD_ENRLMNT_TRMNTN_DT ,
					x.MBR_KEY ,
					x.MBRSHP_SOR_CD ,   
					x.GRNDFTHR_IND_CD  ,
					x.MBU_CF_CD  ,
					x.PROD_CF_CD ,
					x.CMPNY_CF_CD ,
					x.FUNDG_CF_CD ,
					x.EXCHNG_IND_CD ,
					x.EXCHNG_METL_TYPE_CD ,
					x.GRNDFTHRG_STTS_CD  ,   
					x.hcr_cmplynt_cd  ,
					x.SRC_EXCHNG_CERTFN_CD ,
					x.State,
					x.IN_Exchange ,
					x.OUTOFF_Exchange, 
					x.naic_lob,
					x.naic_prod_desc,
					x.SRC_GRP_NBR  ,
					x.SRC_SUBGRP_NBR,
					x.pos_mbrshp_sor_cd ,
          x.prchsr_org_type_cd ,
          x.prchsr_org_efctv_dt ,
          x.prchsr_org_trmntn_dt,
          x.prchsr_org_trmntn_rsncd ,
          x.bnft_pkg_nm ,
          x.bnft_pkg_id ,
					x.load_log_key,
					x.load_dt 
					from( 
					select 
					"""+reportYear+"""   as health_year,
					temp.SBSCRBR_ID as SBSCRBR_ID,
					temp.MBR_RLTNSHP_CD as MBR_RLTNSHP_CD, 
					temp.MBR_PROD_ENRLMNT_EFCTV_DT as MBR_PROD_ENRLMNT_EFCTV_DT,
					temp.MBR_PROD_ENRLMNT_TRMNTN_DT as MBR_PROD_ENRLMNT_TRMNTN_DT,
					temp.MBR_KEY AS MBR_KEY,
					temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,   
					temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
					temp.MBU_CF_CD AS MBU_CF_CD ,
					temp.PROD_CF_CD AS PROD_CF_CD,
					temp.CMPNY_CF_CD AS CMPNY_CF_CD,
					temp.FUNDG_CF_CD AS FUNDG_CF_CD,
					temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
					temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
					temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,   
					temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
					temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
					'MA'  AS  State,
					NULL   AS IN_Exchange ,
					'OUTOFF'  AS OUTOFF_Exchange, 
					'LARGE GROUP CBE'  AS naic_lob,
					MED.GL_CF_DESC  as  naic_prod_desc,
					temp.SRC_GRP_NBR as src_grp_nbr ,
					temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
					temp.pos_mbrshp_sor_cd as  pos_mbrshp_sor_cd ,
          temp.prchsr_org_type_cd as prchsr_org_type_cd ,
          temp.pos_prchsr_org_efctv_dt  as prchsr_org_efctv_dt ,
          temp.pos_prchsr_org_trmntn_dt as prchsr_org_trmntn_dt,
          temp.prchsr_org_trmntn_rsncd  as  prchsr_org_trmntn_rsncd ,
          temp.bnft_pkg_nm as bnft_pkg_nm ,
          temp.bnft_pkg_id as bnft_pkg_id ,
					$1  as load_log_key,
					current_timestamp as load_dt

					FROM  """+dbWrk+""".naic2018_mcas_hlthex_poa_wrk temp
					inner join (
					select CF_CD,  GL_CF_DESC  
					from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
					where GL_CF_TYPE_DESC = 'PRODUCT' 
					group by 1,2
					) as MED
					on MED.CF_CD = temp.PROD_CF_CD
					inner join
					(
					select DISTINCT CF_CD
					from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
					where  GL_CF_TYPE_DESC = 'FUND_CODE'
					and CF_CD NOT IN ( select  DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY  

					where     GL_CF_TYPE_DESC = 'FUND_CODE' 
					AND    ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
					)
					) FC
					ON FC.CF_CD = temp.FUNDG_CF_CD

					INNER JOIN """+dbInbnd+""".naic2018_mcas_gphg_trmntn_rsncd_inbnd  inbnd
					ON temp.prchsr_org_trmntn_rsncd = inbnd.prchsr_org_trmntn_rsncd
					AND temp.mbrshp_sor_cd = inbnd.mbrshp_sor_cd
					
				  LEFT OUTER JOIN  """+dbWrk+""".termed_prchsrcgrpnotin srcgrpim
			    on temp.pos_mbrshp_sor_cd = srcgrpim.mbrshp_sor_cd
			    AND temp.src_grp_nbr = srcgrpim.src_grp_nbr
      
 					where 					
          (srcgrpim.mbrshp_sor_cd is  null AND srcgrpim.mbrshp_sor_cd is null )
					--temp.MBR_PROD_ENRLMNT_EFCTV_DT BETWEEN """+mbrEffBetFrmDt+""" AND """+mbrEffBetToDt+"""
					--AND temp.MBR_PROD_ENRLMNT_EFCTV_DT NOT BETWEEN """+mbrEffNotBetFrmDt+""" AND """+mbrEffNotBetToDt+"""
					   AND ( temp.pos_prchsr_org_trmntn_dt BETWEEN """ + mbrTrmntBetFrmDt + """ AND """ + mbrTrmntBetToDt + """
			      OR temp.pos_prchsr_org_trmntn_dt =   """ + PRCHSRENotBetToDt + """ )
			    AND temp.pos_prchsr_org_trmntn_dt <  """ + mbrTrmntGrtr + """
					  
					and (temp.SRC_GRP_NBR = '131192' or temp.ORG_GRP_SRC_GRP_NBR = '131192')
					
					AND ( ( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN temp.pos_prchsr_org_efctv_dt AND temp.pos_prchsr_org_trmntn_dt) OR temp.pos_prchsr_org_trmntn_dt IS NULL)
					AND ( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN temp.MBR_COA_EFCTV_DT AND temp.MBR_COA_TRMNTN_DT) 
					AND temp.DUP_DATA_CD = '00'

					GROUP BY
					temp.SBSCRBR_ID ,
					temp.MBR_RLTNSHP_CD ,
					temp.MBR_PROD_ENRLMNT_EFCTV_DT ,
					temp.MBR_PROD_ENRLMNT_TRMNTN_DT ,
					temp.MBR_KEY ,
					temp.SRC_MBR_ENRLMNT_TRMNTN_RSN_CD ,
					temp.MBRSHP_SOR_CD ,
					temp.GRNDFTHR_IND_CD  ,
					temp.GRNDFTHRG_STTS_CD  ,
					temp.HCR_CMPLYNT_CD  ,
					temp.EXCHNG_IND_CD ,
					temp.EXCHNG_METL_TYPE_CD ,
					temp.SRC_EXCHNG_CERTFN_CD ,
					temp.MBU_CF_CD  ,
					temp.PROD_CF_CD ,
					temp.CMPNY_CF_CD ,
					temp.FUNDG_CF_CD ,
					temp.SRC_GRP_NBR ,
					temp.SRC_SUBGRP_NBR,
					MED.GL_CF_DESC,
					temp.pos_mbrshp_sor_cd ,
          temp.prchsr_org_type_cd ,
          temp.pos_prchsr_org_efctv_dt ,
          temp.pos_prchsr_org_trmntn_dt,
          temp.prchsr_org_trmntn_rsncd ,
          temp.bnft_pkg_nm ,
          temp.bnft_pkg_id 
					)x 

					--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'"""
					
//					def poa_unicare_termed_lives_dc() ="""Insert into table """+dbWrk+""".naic2018_mcas_hlthex_poa_unicare_termed_lives_wrk"""+"""
//							select x.health_year,
//							x.SBSCRBR_ID ,
//							x.MBR_RLTNSHP_CD , 
//							x.MBR_PROD_ENRLMNT_EFCTV_DT ,
//							x.MBR_PROD_ENRLMNT_TRMNTN_DT ,
//							x.MBR_KEY AS MBR_KEY,
//							x.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,   
//							x.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
//							x.MBU_CF_CD AS MBU_CF_CD ,
//							x.PROD_CF_CD AS PROD_CF_CD,
//							x.CMPNY_CF_CD AS CMPNY_CF_CD,
//							x.FUNDG_CF_CD AS FUNDG_CF_CD,
//							x.EXCHNG_IND_CD AS EXCHNG_IND_CD,
//							x.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
//							x.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,   
//							x.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
//							x.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
//							x.State,
//							x.IN_Exchange ,
//							x.OUTOFF_Exchange, 
//							x.naic_lob,
//							x.naic_prod_desc,
//							x.SRC_GRP_NBR  ,
//							x.SRC_SUBGRP_NBR,
//							x.load_log_key,
//							x.load_dt from(  
//							select 
//							"""+reportYear+"""   as health_year,
//							temp.SBSCRBR_ID ,
//							temp.MBR_RLTNSHP_CD , 
//							temp.MBR_PROD_ENRLMNT_EFCTV_DT ,
//							temp.MBR_PROD_ENRLMNT_TRMNTN_DT ,
//							temp.MBR_KEY AS MBR_KEY,
//							temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,   
//							temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
//							temp.MBU_CF_CD AS MBU_CF_CD ,
//							temp.PROD_CF_CD AS PROD_CF_CD,
//							temp.CMPNY_CF_CD AS CMPNY_CF_CD,
//							temp.FUNDG_CF_CD AS FUNDG_CF_CD,
//							temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
//							temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
//							temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,   
//							temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
//							temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
//							'DC'  AS  State,
//							NULL   AS IN_Exchange ,
//							'OUTOFF'  AS OUTOFF_Exchange, 
//							'INDIVIDUAL GRAND'  AS naic_lob,
//							MED.GL_CF_DESC  as  naic_prod_desc,
//              temp.SRC_GRP_NBR as src_grp_nbr ,
//              temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
//							$1  as load_log_key,
//							current_timestamp as load_dt
//
//							FROM  """+dbWrk+""".naic2018_mcas_poa_unicare_tmp_wrk temp
//							inner join (
//							select CF_CD,  GL_CF_DESC  
//							from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
//							where GL_CF_TYPE_DESC = 'PRODUCT' 
//							group by 1,2
//							) as MED
//							on MED.CF_CD = temp.PROD_CF_CD
//							inner join
//							(
//							select DISTINCT CF_CD
//							from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
//							where  GL_CF_TYPE_DESC = 'FUND_CODE'
//							and CF_CD NOT IN ( select  DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY  
//
//							where     GL_CF_TYPE_DESC = 'FUND_CODE' 
//							AND    ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
//							)
//							) FC
//							ON FC.CF_CD = temp.FUNDG_CF_CD
//
//							INNER JOIN """+dbInbnd+""".naic2018_mcas_ci_trmntn_rsncd_inbnd inbnd
//							ON temp.MBR_ENRLMNT_TRMNTN_RSN_CD = inbnd.mbr_enrlmnt_trmntn_rsncd
//							AND temp.mbrshp_sor_cd = inbnd.mbrshp_sor_cd
//							AND temp.SRC_MBR_ENRLMNT_TRMNTN_RSN_CD = inbnd.src_mbr_enrlmnt_trmntn_rsncd
//							where 
//							--temp.MBR_PROD_ENRLMNT_EFCTV_DT BETWEEN """+mbrEffBetFrmDt+""" AND """+mbrEffBetToDt+"""
//							--AND temp.MBR_PROD_ENRLMNT_EFCTV_DT NOT BETWEEN """+mbrEffNotBetFrmDt+""" AND """+mbrEffNotBetToDt+"""
//							temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN """+mbrTrmntBetFrmDt+""" AND """+mbrTrmntBetToDt+"""
//							AND temp.MBR_PROD_ENRLMNT_TRMNTN_DT <=  """+mbrTrmntGrtr+"""
//
//							and (temp.SRC_SUBGRP_NBR in ( 'G97600' ) or temp.ORG_GRP_SRC_SUBGRP_NBR in ( 'G97600' ) )
//
//							GROUP BY
//							temp.SBSCRBR_ID ,
//							temp.MBR_RLTNSHP_CD ,
//							temp.MBR_PROD_ENRLMNT_EFCTV_DT ,
//							temp.MBR_PROD_ENRLMNT_TRMNTN_DT ,
//							temp.MBR_KEY ,
//							temp.SRC_MBR_ENRLMNT_TRMNTN_RSN_CD ,
//							temp.MBRSHP_SOR_CD ,
//							temp.GRNDFTHR_IND_CD  ,
//							temp.GRNDFTHRG_STTS_CD  ,
//							temp.HCR_CMPLYNT_CD  ,
//							temp.EXCHNG_IND_CD ,
//							temp.EXCHNG_METL_TYPE_CD ,
//							temp.SRC_EXCHNG_CERTFN_CD ,
//							temp.MBU_CF_CD  ,
//							temp.PROD_CF_CD ,
//							temp.CMPNY_CF_CD ,
//							temp.FUNDG_CF_CD ,
//							temp.SRC_GRP_NBR ,
//							temp.SRC_SUBGRP_NBR,
//							MED.GL_CF_DESC
//							)x 
//							left outer join  sbscrbridtemp y
//							on x.SBSCRBR_ID = y.SBSCRBR_ID
//							where y.SBSCRBR_ID is null
//							--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'"""

   	def poa_unicare_termed_lives_il() ="""Insert into table """+dbWrk+""".naic2018_mcas_hlthex_poag_unicare_termed_lives_wrk"""+
									"""
									select 
									x.health_year,
									x.SBSCRBR_ID ,
									x.MBR_RLTNSHP_CD , 
									x.MBR_PROD_ENRLMNT_EFCTV_DT ,
									x.MBR_PROD_ENRLMNT_TRMNTN_DT ,
									x.MBR_KEY ,
									x.MBRSHP_SOR_CD ,   
									x.GRNDFTHR_IND_CD  ,
									x.MBU_CF_CD  ,
									x.PROD_CF_CD,
									x.CMPNY_CF_CD ,
									x.FUNDG_CF_CD ,
									x.EXCHNG_IND_CD ,
									x.EXCHNG_METL_TYPE_CD ,
									x.GRNDFTHRG_STTS_CD  ,   
									x.hcr_cmplynt_cd  ,
									x.SRC_EXCHNG_CERTFN_CD,
									x.State,
									x.IN_Exchange ,
									x.OUTOFF_Exchange, 
									x.naic_lob,
									x.naic_prod_desc,
									x.SRC_GRP_NBR  ,
									x.SRC_SUBGRP_NBR,
								 	x.pos_mbrshp_sor_cd,
									x.prchsr_org_type_cd,
									x.prchsr_org_efctv_dt,
									x.prchsr_org_trmntn_dt,
									x.prchsr_org_trmntn_rsncd,
									x.bnft_pkg_nm ,
									x.bnft_pkg_id ,
									x.load_log_key,
									x.load_dt 
									from
									( 
									select 
									"""+reportYear+"""   as health_year,
									temp.SBSCRBR_ID as SBSCRBR_ID,
									temp.MBR_RLTNSHP_CD as MBR_RLTNSHP_CD, 
									temp.MBR_PROD_ENRLMNT_EFCTV_DT as MBR_PROD_ENRLMNT_EFCTV_DT,
									temp.MBR_PROD_ENRLMNT_TRMNTN_DT as MBR_PROD_ENRLMNT_TRMNTN_DT,
									temp.MBR_KEY AS MBR_KEY,
									temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,   
									temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
									temp.MBU_CF_CD AS MBU_CF_CD ,
									temp.PROD_CF_CD AS PROD_CF_CD,
									temp.CMPNY_CF_CD AS CMPNY_CF_CD,
									temp.FUNDG_CF_CD AS FUNDG_CF_CD,
									temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
									temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
									temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,   
									temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
									temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
									'IL'  AS  State,
									NULL   AS IN_Exchange ,
									'OUTOFF'  AS OUTOFF_Exchange, 
									'LARGE GROUP GRAND'  AS naic_lob,
									MED.GL_CF_DESC  as  naic_prod_desc,
                  temp.SRC_GRP_NBR as src_grp_nbr ,
                  temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
                  temp.pos_mbrshp_sor_cd as  pos_mbrshp_sor_cd ,
                  temp.prchsr_org_type_cd as prchsr_org_type_cd ,
                  temp.pos_prchsr_org_efctv_dt  as prchsr_org_efctv_dt ,
                  temp.pos_prchsr_org_trmntn_dt as prchsr_org_trmntn_dt,
                  temp.prchsr_org_trmntn_rsncd  as  prchsr_org_trmntn_rsncd ,
                  temp.bnft_pkg_nm as bnft_pkg_nm ,
                  temp.bnft_pkg_id as bnft_pkg_id ,
									$1  as load_log_key,
									current_timestamp as load_dt

									FROM  """+dbWrk+""".naic2018_mcas_hlthex_poa_wrk temp
									inner join (
									select CF_CD,  GL_CF_DESC  
									from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
									where GL_CF_TYPE_DESC = 'PRODUCT' 
									group by 1,2
									) as MED
									on MED.CF_CD = temp.PROD_CF_CD
									inner join
									(
									select DISTINCT CF_CD
									from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
									where  GL_CF_TYPE_DESC = 'FUND_CODE'
									and CF_CD NOT IN ( select  DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY  

									where     GL_CF_TYPE_DESC = 'FUND_CODE' 
									AND    ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
									)
									) FC
									ON FC.CF_CD = temp.FUNDG_CF_CD

									INNER JOIN """+dbInbnd+""".naic2018_mcas_gphm_trmntn_rsncd_inbnd  inbnd
									ON temp.MBR_ENRLMNT_TRMNTN_RSN_CD = inbnd.mbr_enrlmnt_trmntn_rsncd
									AND temp.mbrshp_sor_cd = inbnd.mbrshp_sor_cd
									AND temp.SRC_MBR_ENRLMNT_TRMNTN_RSN_CD = inbnd.src_mbr_enrlmnt_trmntn_rsncd
									
									LEFT OUTER JOIN  """+dbWrk+""".termed_prchsrcgrpnotin srcgrpim
			            on temp.pos_mbrshp_sor_cd = srcgrpim.mbrshp_sor_cd
			            AND temp.src_grp_nbr = srcgrpim.src_grp_nbr
      
 					        where 					
                  (srcgrpim.mbrshp_sor_cd is  null  AND srcgrpim.mbrshp_sor_cd is null) 
									--temp.MBR_PROD_ENRLMNT_EFCTV_DT BETWEEN """+mbrEffBetFrmDt+""" AND """+mbrEffBetToDt+"""
									--AND temp.MBR_PROD_ENRLMNT_EFCTV_DT NOT BETWEEN """+mbrEffNotBetFrmDt+""" AND """+mbrEffNotBetToDt+"""
									   AND ( temp.pos_prchsr_org_trmntn_dt BETWEEN """ + mbrTrmntBetFrmDt + """ AND """ + mbrTrmntBetToDt + """
			      OR temp.pos_prchsr_org_trmntn_dt =   """ + PRCHSRENotBetToDt + """ )
			    AND temp.pos_prchsr_org_trmntn_dt <  """ + mbrTrmntGrtr + """
									and (temp.SRC_SUBGRP_NBR in (       
									'131195M001',       
									'131196M001',       
									'141333M001',       
									'145447M001'       
									) or
									temp.ORG_GRP_SRC_SUBGRP_NBR in (       
									'131195M001',       
									'131196M001',       
									'141333M001',       
									'145447M001'       
									)  
									)
									
									AND ( ( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN temp.pos_prchsr_org_efctv_dt AND temp.pos_prchsr_org_trmntn_dt) OR temp.pos_prchsr_org_trmntn_dt IS NULL)
									AND ( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN temp.MBR_COA_EFCTV_DT AND temp.MBR_COA_TRMNTN_DT) 
									AND temp.DUP_DATA_CD = '00'

									GROUP BY
									temp.SBSCRBR_ID ,
									temp.MBR_RLTNSHP_CD ,
									temp.MBR_PROD_ENRLMNT_EFCTV_DT ,
									temp.MBR_PROD_ENRLMNT_TRMNTN_DT ,
									temp.MBR_KEY ,
									temp.SRC_MBR_ENRLMNT_TRMNTN_RSN_CD ,
									temp.MBRSHP_SOR_CD ,
									temp.GRNDFTHR_IND_CD  ,
									temp.GRNDFTHRG_STTS_CD  ,
									temp.HCR_CMPLYNT_CD  ,
									temp.EXCHNG_IND_CD ,
									temp.EXCHNG_METL_TYPE_CD ,
									temp.SRC_EXCHNG_CERTFN_CD ,
									temp.MBU_CF_CD  ,
									temp.PROD_CF_CD ,
									temp.CMPNY_CF_CD ,
									temp.FUNDG_CF_CD ,
									temp.SRC_GRP_NBR ,
									temp.SRC_SUBGRP_NBR,
									MED.GL_CF_DESC,
									temp.pos_mbrshp_sor_cd ,
                  temp.prchsr_org_type_cd ,
                  temp.pos_prchsr_org_efctv_dt ,
                  temp.pos_prchsr_org_trmntn_dt,
                  temp.prchsr_org_trmntn_rsncd ,
                  temp.bnft_pkg_nm ,
                  temp.bnft_pkg_id
									)x 

									--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'"""

   	def poa_unicare_termed_lives_il_step2() ="""Insert into table """+dbWrk+""".naic2018_mcas_hlthex_poag_unicare_termed_lives_wrk"""+
									"""
									select x.health_year,
									x.sbscrbr_id ,
									x.mbr_rltnshp_cd , 
									x.mbr_prod_enrlmnt_efctv_dt ,
									x.mbr_prod_enrlmnt_trmntn_dt ,
									x.mbr_key ,
									x.mbrshp_sor_cd,   
									x.grndfthr_ind_cd  ,
									x.mbu_cf_cd  ,
									x.prod_cf_cd ,
									x.cmpny_cf_cd ,
									x.fundg_cf_cd ,
									x.exchng_ind_cd ,
									x.exchng_metl_type_cd ,
									x.grndfthrg_stts_cd  ,   
									x.hcr_cmplynt_cd  ,
									x.src_exchng_certfn_cd,
									x.state,
									x.in_exchange ,
									x.outoff_exchange, 
									x.naic_lob,
									x.naic_prod_desc,
									x.src_grp_nbr  ,
									x.src_subgrp_nbr,
									x.pos_mbrshp_sor_cd ,
									x.prchsr_org_type_cd ,
									x.prchsr_org_efctv_dt ,
									x.prchsr_org_trmntn_dt,
									x.prchsr_org_trmntn_rsncd ,
									x.bnft_pkg_nm ,
									x.bnft_pkg_id ,
									x.load_log_key,
									x.load_dt from( 
									select 
									"""+reportYear+"""   as health_year,
									temp.SBSCRBR_ID as SBSCRBR_ID,
									temp.MBR_RLTNSHP_CD as MBR_RLTNSHP_CD, 
									temp.MBR_PROD_ENRLMNT_EFCTV_DT as MBR_PROD_ENRLMNT_EFCTV_DT,
									temp.MBR_PROD_ENRLMNT_TRMNTN_DT as MBR_PROD_ENRLMNT_TRMNTN_DT,
									temp.MBR_KEY AS MBR_KEY,
									temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,   
									temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
									temp.MBU_CF_CD AS MBU_CF_CD ,
									temp.PROD_CF_CD AS PROD_CF_CD,
									temp.CMPNY_CF_CD AS CMPNY_CF_CD,
									temp.FUNDG_CF_CD AS FUNDG_CF_CD,
									temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
									temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
									temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,   
									temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
									temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
									'IL'  AS  State,
									NULL   AS IN_Exchange ,
									'OUTOFF'  AS OUTOFF_Exchange, 
									'LARGE GROUP GRAND'  AS naic_lob,
									MED.GL_CF_DESC  as  naic_prod_desc,
                  temp.SRC_GRP_NBR as src_grp_nbr ,
                  temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
                  temp.pos_mbrshp_sor_cd as  pos_mbrshp_sor_cd ,
                  temp.prchsr_org_type_cd as prchsr_org_type_cd ,
                  temp.pos_prchsr_org_efctv_dt  as prchsr_org_efctv_dt ,
                  temp.pos_prchsr_org_trmntn_dt as prchsr_org_trmntn_dt,
                  temp.prchsr_org_trmntn_rsncd  as  prchsr_org_trmntn_rsncd ,
                  temp.bnft_pkg_nm as bnft_pkg_nm ,
                  temp.bnft_pkg_id as bnft_pkg_id ,
									$1  as load_log_key,
									current_timestamp as load_dt

									FROM  """+dbWrk+""".naic2018_mcas_hlthex_poa_wrk temp
									inner join (
									select CF_CD,  GL_CF_DESC  
									from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
									where GL_CF_TYPE_DESC = 'PRODUCT' 
									group by 1,2
									) as MED
									on MED.CF_CD = temp.PROD_CF_CD
									inner join
									(
									select DISTINCT CF_CD
									from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
									where  GL_CF_TYPE_DESC = 'FUND_CODE'
									and CF_CD NOT IN ( select  DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY  

									where     GL_CF_TYPE_DESC = 'FUND_CODE' 
									AND    ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
									)
									) FC
									ON FC.CF_CD = temp.FUNDG_CF_CD

									INNER JOIN """+dbInbnd+""".naic2018_mcas_gphg_trmntn_rsncd_inbnd  inbnd
									ON temp.prchsr_org_trmntn_rsncd = inbnd.prchsr_org_trmntn_rsncd
									AND temp.mbrshp_sor_cd = inbnd.mbrshp_sor_cd
						
									LEFT OUTER JOIN  """+dbWrk+""".termed_prchsrcgrpnotin srcgrpim
			            on temp.pos_mbrshp_sor_cd = srcgrpim.mbrshp_sor_cd
			            AND temp.src_grp_nbr = srcgrpim.src_grp_nbr
      
 					        where 					
                  (srcgrpim.mbrshp_sor_cd is  null AND srcgrpim.mbrshp_sor_cd is null) 
									--temp.MBR_PROD_ENRLMNT_EFCTV_DT BETWEEN """+mbrEffBetFrmDt+""" AND """+mbrEffBetToDt+"""
									--AND temp.MBR_PROD_ENRLMNT_EFCTV_DT NOT BETWEEN """+mbrEffNotBetFrmDt+""" AND """+mbrEffNotBetToDt+"""
									   AND ( temp.pos_prchsr_org_trmntn_dt BETWEEN """ + mbrTrmntBetFrmDt + """ AND """ + mbrTrmntBetToDt + """
			      OR temp.pos_prchsr_org_trmntn_dt =   """ + PRCHSRENotBetToDt + """ )
			    AND temp.pos_prchsr_org_trmntn_dt <  """ + mbrTrmntGrtr + """
									and (temp.SRC_SUBGRP_NBR in (       
									'131195M001',       
									'131196M001',       
									'141333M001',       
									'145447M001'       
									) or
									temp.ORG_GRP_SRC_SUBGRP_NBR in (       
									'131195M001',       
									'131196M001',       
									'141333M001',       
									'145447M001'       
									)  
									)

									GROUP BY
									temp.SBSCRBR_ID ,
									temp.MBR_RLTNSHP_CD ,
									temp.MBR_PROD_ENRLMNT_EFCTV_DT ,
									temp.MBR_PROD_ENRLMNT_TRMNTN_DT ,
									temp.MBR_KEY ,
									temp.SRC_MBR_ENRLMNT_TRMNTN_RSN_CD ,
									temp.MBRSHP_SOR_CD ,
									temp.GRNDFTHR_IND_CD  ,
									temp.GRNDFTHRG_STTS_CD  ,
									temp.HCR_CMPLYNT_CD  ,
									temp.EXCHNG_IND_CD ,
									temp.EXCHNG_METL_TYPE_CD ,
									temp.SRC_EXCHNG_CERTFN_CD ,
									temp.MBU_CF_CD  ,
									temp.PROD_CF_CD ,
									temp.CMPNY_CF_CD ,
									temp.FUNDG_CF_CD ,
									temp.SRC_GRP_NBR ,
									temp.SRC_SUBGRP_NBR,
									MED.GL_CF_DESC,
									temp.pos_mbrshp_sor_cd ,
                  temp.prchsr_org_type_cd ,
                  temp.pos_prchsr_org_efctv_dt ,
                  temp.pos_prchsr_org_trmntn_dt,
                  temp.prchsr_org_trmntn_rsncd ,
                  temp.bnft_pkg_nm ,
                  temp.bnft_pkg_id
									)x 

									--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'"""

				def sparkInIt(){
				spark.sql(poa_unicare_termed_lives_Trunc())
				
				var   obj_poa_unicare_termed_lives_ma=poa_unicare_termed_lives_ma()
				obj_poa_unicare_termed_lives_ma=obj_poa_unicare_termed_lives_ma.replace("$1",String.valueOf(load_log_key))
				spark.sql(obj_poa_unicare_termed_lives_ma)
				
				var   obj_poa_unicare_termed_lives_ma_step2=poa_unicare_termed_lives_ma_step2()
				obj_poa_unicare_termed_lives_ma_step2=obj_poa_unicare_termed_lives_ma_step2.replace("$1",String.valueOf(load_log_key))
				spark.sql(obj_poa_unicare_termed_lives_ma_step2)	

				var   obj_poa_unicare_termed_lives_il=poa_unicare_termed_lives_il()
				obj_poa_unicare_termed_lives_il=obj_poa_unicare_termed_lives_il.replace("$1",String.valueOf(load_log_key))
				spark.sql(obj_poa_unicare_termed_lives_il)
				
				var   obj_poa_unicare_termed_lives_il_step2=poa_unicare_termed_lives_il_step2()
				obj_poa_unicare_termed_lives_il_step2=obj_poa_unicare_termed_lives_il_step2.replace("$1",String.valueOf(load_log_key))
				spark.sql(obj_poa_unicare_termed_lives_il_step2)

				spark.close()
			}

}

object PCADX_SCL_NAIC2018_POAG_UN_TermdLives{
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val termedLives =  new PCADX_SCL_NAIC2018_POAG_UN_TermdLives()
		termedLives.sparkInIt()
	}
}