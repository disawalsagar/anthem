package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_part2(val spark: SparkSession) {

  val clmexphmcy = new PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy(spark)
  /* val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()*/
  import spark.implicits._
  def getPaidInntwk(
    naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk:  DataFrame,
    naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
    naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame): DataFrame = {
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    var lob_type = "TOTAL INDIVIDUAL CBE"

    val ip_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val nbrclm_paid_inntwk_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_bronze_ip"))

    val nbrclm_paid_inntwk_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_silver_ip"))

    val brSil = nbrclm_paid_inntwk_bronze_ip.alias("parent").join(nbrclm_paid_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip")

    val nbrclm_paid_inntwk_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gold_ip"))

    val gldMaster = brSilData.alias("parent").join(nbrclm_paid_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip")

    val nbrclm_paid_inntwk_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip")

    val tot_ip = nbrclm_paid_inntwk_bronze_ip.union(nbrclm_paid_inntwk_silver_ip.union(nbrclm_paid_inntwk_gold_ip.union(nbrclm_paid_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_inntwk_bronze_ip"))

    val nbrclm_paid_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_inntwk_bronze_ip").alias("nbrclm_paid_inntwk_total_ip"))

    val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"))

    val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"

    val sgp_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val nbrclm_paid_inntwk_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_bronze_sgp"))

    val BrzsgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_inntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"))

    val BrzsgpMasterData = BrzsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp")

    val nbrclm_paid_inntwk_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_silver_sgp"))

    val silsgpMaster = BrzsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"))

    val silsgpMasterData = silsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp")

    val nbrclm_paid_inntwk_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gold_sgp"))

    val gldsgpMaster = silsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"))

    val gldsgpMasterData = gldsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp")

    val nbrclm_paid_inntwk_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_platinum_sgp"))

    val pltsgpMaster = gldsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"))

    val pltsgpMasterData = pltsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp")
    val tot_sgp = nbrclm_paid_inntwk_bronze_sgp.union(nbrclm_paid_inntwk_silver_sgp.union(nbrclm_paid_inntwk_gold_sgp.union(nbrclm_paid_inntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_inntwk_bronze_sgp"))

    val nbrclm_paid_inntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_inntwk_bronze_sgp").alias("nbrclm_paid_inntwk_total_sgp"))

    val sgpMaster = pltsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"))

    val sgpMasterData = sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp")
    val nbrclm_paid_inntwk_catastrophic = naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_exchange".equalTo("IN") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_catastrophic"))

    val catMaster = sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = clmexphmcy.getMSPlan(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val nbrclm_paid_inntwk_bronze_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_bronze_ms_ip"))

    val msBrzMaster = catMasterData.alias("parent").join(nbrclm_paid_inntwk_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"),
        col("nbrclm_paid_inntwk_bronze_ms_ip"))

    val msBrzMasterData = msBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic",
        "nbrclm_paid_inntwk_bronze_ms_ip")
    val nbrclm_paid_inntwk_silver_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_silver_ms_ip"))

    val msSilMaster = msBrzMasterData.alias("parent").join(nbrclm_paid_inntwk_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"),
        col("nbrclm_paid_inntwk_bronze_ms_ip"), col("nbrclm_paid_inntwk_silver_ms_ip")) //nbrclm_paid_inntwk_bronze_ms_ip

    val msSilMasterData = msSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic",
        "nbrclm_paid_inntwk_bronze_ms_ip", "nbrclm_paid_inntwk_silver_ms_ip")

    val nbrclm_paid_inntwk_gold_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gold_ms_ip"))

    val msGldMaster = msSilMasterData.alias("parent").join(nbrclm_paid_inntwk_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"),
        col("nbrclm_paid_inntwk_bronze_ms_ip"), col("nbrclm_paid_inntwk_silver_ms_ip"), col("nbrclm_paid_inntwk_gold_ms_ip"))

    val msGldMasterData = msGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic",
        "nbrclm_paid_inntwk_bronze_ms_ip", "nbrclm_paid_inntwk_silver_ms_ip", "nbrclm_paid_inntwk_gold_ms_ip")
    val nbrclm_paid_inntwk_platinum_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_platinum_ms_ip"))

    val msPltMaster = msGldMasterData.alias("parent").join(nbrclm_paid_inntwk_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"),
        col("nbrclm_paid_inntwk_bronze_ms_ip"), col("nbrclm_paid_inntwk_silver_ms_ip"), col("nbrclm_paid_inntwk_gold_ms_ip"), col("nbrclm_paid_inntwk_platinum_ms_ip"))

    val msPltMasterData = msPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic",
        "nbrclm_paid_inntwk_bronze_ms_ip", "nbrclm_paid_inntwk_silver_ms_ip", "nbrclm_paid_inntwk_gold_ms_ip", "nbrclm_paid_inntwk_platinum_ms_ip")
    val tot_ms_ip = nbrclm_paid_inntwk_bronze_ms_ip.union(nbrclm_paid_inntwk_silver_ms_ip.union(nbrclm_paid_inntwk_gold_ms_ip.union(nbrclm_paid_inntwk_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_inntwk_bronze_ms_ip"))

    val nbrclm_paid_inntwk_total_ms_ip = tot_ms_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_inntwk_bronze_ms_ip").alias("nbrclm_paid_inntwk_total_ms_ip"))

    val msipMaster = msPltMasterData.alias("parent").join(nbrclm_paid_inntwk_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"),
        col("nbrclm_paid_inntwk_bronze_ms_ip"), col("nbrclm_paid_inntwk_silver_ms_ip"), col("nbrclm_paid_inntwk_gold_ms_ip"), col("nbrclm_paid_inntwk_platinum_ms_ip"), col("nbrclm_paid_inntwk_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic",
        "nbrclm_paid_inntwk_bronze_ms_ip", "nbrclm_paid_inntwk_silver_ms_ip", "nbrclm_paid_inntwk_gold_ms_ip", "nbrclm_paid_inntwk_platinum_ms_ip", "nbrclm_paid_inntwk_total_ms_ip")
    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = clmexphmcy.getMSPlan(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val nbrclm_paid_inntwk_bronze_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_paid_inntwk_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"),
        col("nbrclm_paid_inntwk_bronze_ms_ip"), col("nbrclm_paid_inntwk_silver_ms_ip"), col("nbrclm_paid_inntwk_gold_ms_ip"), col("nbrclm_paid_inntwk_platinum_ms_ip"), col("nbrclm_paid_inntwk_total_ms_ip"),
        col("nbrclm_paid_inntwk_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic",
        "nbrclm_paid_inntwk_bronze_ms_ip", "nbrclm_paid_inntwk_silver_ms_ip", "nbrclm_paid_inntwk_gold_ms_ip", "nbrclm_paid_inntwk_platinum_ms_ip", "nbrclm_paid_inntwk_total_ms_ip",
        "nbrclm_paid_inntwk_bronze_ms_sgp")

    val nbrclm_paid_inntwk_silver_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_paid_inntwk_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"),
        col("nbrclm_paid_inntwk_bronze_ms_ip"), col("nbrclm_paid_inntwk_silver_ms_ip"), col("nbrclm_paid_inntwk_gold_ms_ip"), col("nbrclm_paid_inntwk_platinum_ms_ip"), col("nbrclm_paid_inntwk_total_ms_ip"),
        col("nbrclm_paid_inntwk_bronze_ms_sgp"), col("nbrclm_paid_inntwk_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic",
        "nbrclm_paid_inntwk_bronze_ms_ip", "nbrclm_paid_inntwk_silver_ms_ip", "nbrclm_paid_inntwk_gold_ms_ip", "nbrclm_paid_inntwk_platinum_ms_ip", "nbrclm_paid_inntwk_total_ms_ip",
        "nbrclm_paid_inntwk_bronze_ms_sgp", "nbrclm_paid_inntwk_silver_ms_sgp")
    val nbrclm_paid_inntwk_gold_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_paid_inntwk_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"),
        col("nbrclm_paid_inntwk_bronze_ms_ip"), col("nbrclm_paid_inntwk_silver_ms_ip"), col("nbrclm_paid_inntwk_gold_ms_ip"), col("nbrclm_paid_inntwk_platinum_ms_ip"), col("nbrclm_paid_inntwk_total_ms_ip"),
        col("nbrclm_paid_inntwk_bronze_ms_sgp"), col("nbrclm_paid_inntwk_silver_ms_sgp"), col("nbrclm_paid_inntwk_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic",
        "nbrclm_paid_inntwk_bronze_ms_ip", "nbrclm_paid_inntwk_silver_ms_ip", "nbrclm_paid_inntwk_gold_ms_ip", "nbrclm_paid_inntwk_platinum_ms_ip", "nbrclm_paid_inntwk_total_ms_ip",
        "nbrclm_paid_inntwk_bronze_ms_sgp", "nbrclm_paid_inntwk_silver_ms_sgp", "nbrclm_paid_inntwk_gold_ms_sgp")

    val nbrclm_paid_inntwk_platinum_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_paid_inntwk_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"),
        col("nbrclm_paid_inntwk_bronze_ms_ip"), col("nbrclm_paid_inntwk_silver_ms_ip"), col("nbrclm_paid_inntwk_gold_ms_ip"), col("nbrclm_paid_inntwk_platinum_ms_ip"), col("nbrclm_paid_inntwk_total_ms_ip"),
        col("nbrclm_paid_inntwk_bronze_ms_sgp"), col("nbrclm_paid_inntwk_silver_ms_sgp"), col("nbrclm_paid_inntwk_gold_ms_sgp"), col("nbrclm_paid_inntwk_platinum_ms_sgp"))

    val mmssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic",
        "nbrclm_paid_inntwk_bronze_ms_ip", "nbrclm_paid_inntwk_silver_ms_ip", "nbrclm_paid_inntwk_gold_ms_ip", "nbrclm_paid_inntwk_platinum_ms_ip", "nbrclm_paid_inntwk_total_ms_ip",
        "nbrclm_paid_inntwk_bronze_ms_sgp", "nbrclm_paid_inntwk_silver_ms_sgp", "nbrclm_paid_inntwk_gold_ms_sgp", "nbrclm_paid_inntwk_platinum_ms_sgp")

    val tot_ms_sgp = nbrclm_paid_inntwk_bronze_ms_sgp.union(nbrclm_paid_inntwk_silver_ms_sgp.union(nbrclm_paid_inntwk_gold_ms_sgp.union(nbrclm_paid_inntwk_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_inntwk_bronze_ms_sgp"))

    val nbrclm_paid_inntwk_total_ms_sgp = tot_ms_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_inntwk_bronze_ms_sgp").alias("nbrclm_paid_inntwk_total_ms_sgp"))

    val mssgpMaster = mmssgpPltMasterData.alias("parent").join(nbrclm_paid_inntwk_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"),
        col("nbrclm_paid_inntwk_bronze_ms_ip"), col("nbrclm_paid_inntwk_silver_ms_ip"), col("nbrclm_paid_inntwk_gold_ms_ip"), col("nbrclm_paid_inntwk_platinum_ms_ip"), col("nbrclm_paid_inntwk_total_ms_ip"),
        col("nbrclm_paid_inntwk_bronze_ms_sgp"), col("nbrclm_paid_inntwk_silver_ms_sgp"), col("nbrclm_paid_inntwk_gold_ms_sgp"), col("nbrclm_paid_inntwk_platinum_ms_sgp"), col("nbrclm_paid_inntwk_total_ms_sgp"))

    val paidInntwkdata = mssgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic",
        "nbrclm_paid_inntwk_bronze_ms_ip", "nbrclm_paid_inntwk_silver_ms_ip", "nbrclm_paid_inntwk_gold_ms_ip", "nbrclm_paid_inntwk_platinum_ms_ip", "nbrclm_paid_inntwk_total_ms_ip",
        "nbrclm_paid_inntwk_bronze_ms_sgp", "nbrclm_paid_inntwk_silver_ms_sgp", "nbrclm_paid_inntwk_gold_ms_sgp", "nbrclm_paid_inntwk_platinum_ms_sgp", "nbrclm_paid_inntwk_total_ms_sgp")

    paidInntwkdata

  }
  def getpaidInntwkBetweenDates(start_day: Int, end_day: Int, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
                                naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = start_day.toString + "to" + end_day
    val fend_day = end_day + 1
    val ip_df = clmexphmcy.getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val nbrclm_paid_inntwk_colVal_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_inntwk_colVal_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_paid_inntwk_colVal_bronze_ip.alias("parent").join(nbrclm_paid_inntwk_colVal_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip")
    val nbrclm_paid_inntwk_colVal_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip")

    val nbrclm_paid_inntwk_colVal_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_paid_inntwk_colVal_bronze_ip.union(nbrclm_paid_inntwk_colVal_silver_ip.union(nbrclm_paid_inntwk_colVal_gold_ip.union(nbrclm_paid_inntwk_colVal_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_inntwk_colVal_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_ip").alias("nbrclm_paid_inntwk_" + colVal + "_total_ip"))
    //********************
    val totipMaster = pltMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = clmexphmcy.getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val nbrclm_paid_inntwk_colVal_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp")

    val nbrclm_paid_inntwk_colVal_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp")

    val nbrclm_paid_inntwk_colVal_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp")

    val nbrclm_paid_inntwk_colVal_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp")

    val tot_sgp = nbrclm_paid_inntwk_colVal_bronze_sgp.union(nbrclm_paid_inntwk_colVal_silver_sgp.union(nbrclm_paid_inntwk_colVal_gold_sgp.union(nbrclm_paid_inntwk_colVal_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_paid_inntwk_colVal_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp").alias("nbrclm_paid_inntwk_" + colVal + "_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp")

    val nbrclm_paid_inntwk_colVal_catastrophic = naic_mcas_hlthex_clmexphmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = clmexphmcy.getMSPlan(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val nbrclm_paid_inntwk_colVal_bronze_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip")

    val nbrclm_paid_inntwk_colVal_silver_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip")

    val nbrclm_paid_inntwk_colVal_gold_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip")

    val nbrclm_paid_inntwk_colVal_platinum_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip")
    val tot_msip = nbrclm_paid_inntwk_colVal_bronze_ms_ip.union(nbrclm_paid_inntwk_colVal_silver_ms_ip.union(nbrclm_paid_inntwk_colVal_gold_ms_ip.union(nbrclm_paid_inntwk_colVal_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"))

    val nbrclm_paid_inntwk_colVal_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip").alias("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = clmexphmcy.getMSPlan(naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val nbrclm_paid_inntwk_colVal_bronze_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp")

    val nbrclm_paid_inntwk_colVal_silver_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp")
    val nbrclm_paid_inntwk_colVal_gold_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp")

    val nbrclm_paid_inntwk_colVal_platinum_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_sgp")

    val tot_mssgp = nbrclm_paid_inntwk_colVal_bronze_ms_sgp.union(nbrclm_paid_inntwk_colVal_silver_ms_sgp.union(nbrclm_paid_inntwk_colVal_gold_ms_sgp.union(nbrclm_paid_inntwk_colVal_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"))

    val nbrclm_paid_inntwk_colVal_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp").alias("nbrclm_paid_inntwk_" + colVal + "_total_ms_sgp"))

    val paid_inntwk = mssgpPltMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_sgp"))

    val paid_inntwkData = paid_inntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_ms_sgp")
    paid_inntwkData
  }
  def getpaidInntwk_90(end_year: String, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
                       naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = "90"
    val strt_day: Int = 91
    val ip_df = clmexphmcy.getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_inntwk_colVal_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_inntwk_colVal_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_paid_inntwk_colVal_bronze_ip.alias("parent").join(nbrclm_paid_inntwk_colVal_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip")
    val nbrclm_paid_inntwk_colVal_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip")

    val nbrclm_paid_inntwk_colVal_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_paid_inntwk_colVal_bronze_ip.union(nbrclm_paid_inntwk_colVal_silver_ip.union(nbrclm_paid_inntwk_colVal_gold_ip.union(nbrclm_paid_inntwk_colVal_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_inntwk_colVal_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_ip").alias("nbrclm_paid_inntwk_" + colVal + "_total_ip"))
    //********************
    val totipMaster = pltMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = clmexphmcy.getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_inntwk_colVal_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp")

    val nbrclm_paid_inntwk_colVal_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp")

    val nbrclm_paid_inntwk_colVal_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp")

    val nbrclm_paid_inntwk_colVal_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp")

    val tot_sgp = nbrclm_paid_inntwk_colVal_bronze_sgp.union(nbrclm_paid_inntwk_colVal_silver_sgp.union(nbrclm_paid_inntwk_colVal_gold_sgp.union(nbrclm_paid_inntwk_colVal_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_paid_inntwk_colVal_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp").alias("nbrclm_paid_inntwk_" + colVal + "_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp")

    val nbrclm_paid_inntwk_colVal_catastrophic = naic_mcas_hlthex_clmexphmcy_paid_cat_wrk.withColumn("constant_date", lit(end_year))
      .filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
        $"in_Exchange".equalTo("IN") &&
        $"inn_cd".isin(clminn_cd: _*) &&
        $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = clmexphmcy.getMSPlan(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_inntwk_colVal_bronze_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip")

    val nbrclm_paid_inntwk_colVal_silver_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip")

    val nbrclm_paid_inntwk_colVal_gold_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip")

    val nbrclm_paid_inntwk_colVal_platinum_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip")
    val tot_msip = nbrclm_paid_inntwk_colVal_bronze_ms_ip.union(nbrclm_paid_inntwk_colVal_silver_ms_ip.union(nbrclm_paid_inntwk_colVal_gold_ms_ip.union(nbrclm_paid_inntwk_colVal_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"))

    val nbrclm_paid_inntwk_colVal_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip").alias("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = clmexphmcy.getMSPlan(naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_inntwk_colVal_bronze_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp")

    val nbrclm_paid_inntwk_colVal_silver_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp")
    val nbrclm_paid_inntwk_colVal_gold_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp")

    val nbrclm_paid_inntwk_colVal_platinum_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_sgp")

    val tot_mssgp = nbrclm_paid_inntwk_colVal_bronze_ms_sgp.union(nbrclm_paid_inntwk_colVal_silver_ms_sgp.union(nbrclm_paid_inntwk_colVal_gold_ms_sgp.union(nbrclm_paid_inntwk_colVal_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"))

    val nbrclm_paid_inntwk_colVal_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp").alias("nbrclm_paid_inntwk_" + colVal + "_total_ms_sgp"))

    val paid_inntwk = mssgpPltMasterData.alias("parent").join(nbrclm_paid_inntwk_colVal_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ms_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_ms_sgp"))

    val paid_inntwkData = paid_inntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_ms_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_ms_sgp")
    paid_inntwkData
  }
  def getPaidOutntwk(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
                     naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame): DataFrame = {
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    var lob_type = "TOTAL INDIVIDUAL CBE"

    val ip_df = clmexphmcy.getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val nbrclm_paid_outntwk_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_bronze_ip"))

    val nbrclm_paid_outntwk_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_silver_ip"))

    val brSil = nbrclm_paid_outntwk_bronze_ip.alias("parent").join(nbrclm_paid_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip")

    val nbrclm_paid_outntwk_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gold_ip"))

    val gldMaster = brSilData.alias("parent").join(nbrclm_paid_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip")

    val nbrclm_paid_outntwk_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip")

    val tot_ip = nbrclm_paid_outntwk_bronze_ip.union(nbrclm_paid_outntwk_silver_ip.union(nbrclm_paid_outntwk_gold_ip.union(nbrclm_paid_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_outntwk_bronze_ip"))

    val nbrclm_paid_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_outntwk_bronze_ip").alias("nbrclm_paid_outntwk_total_ip"))

    val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"))

    val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"

    val sgp_df = clmexphmcy.getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val nbrclm_paid_outntwk_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_bronze_sgp"))

    val BrzsgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_outntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"))

    val BrzsgpMasterData = BrzsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp")

    val nbrclm_paid_outntwk_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_silver_sgp"))

    val silsgpMaster = BrzsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"))

    val silsgpMasterData = silsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp")

    val nbrclm_paid_outntwk_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gold_sgp"))

    val gldsgpMaster = silsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"))

    val gldsgpMasterData = gldsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp")

    val nbrclm_paid_outntwk_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_platinum_sgp"))

    val pltsgpMaster = gldsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"))

    val pltsgpMasterData = pltsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp")
    val tot_sgp = nbrclm_paid_outntwk_bronze_sgp.union(nbrclm_paid_outntwk_silver_sgp.union(nbrclm_paid_outntwk_gold_sgp.union(nbrclm_paid_outntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_outntwk_bronze_sgp"))

    val nbrclm_paid_outntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_outntwk_bronze_sgp").alias("nbrclm_paid_outntwk_total_sgp"))

    val sgpMaster = pltsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"))

    val sgpMasterData = sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp")
    val nbrclm_paid_outntwk_catastrophic = naic_mcas_hlthex_clmexphmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_exchange".equalTo("IN") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_catastrophic"))

    val catMaster = sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = clmexphmcy.getMSPlan(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val nbrclm_paid_outntwk_bronze_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_bronze_ms_ip"))

    val msBrzMaster = catMasterData.alias("parent").join(nbrclm_paid_outntwk_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"),
        col("nbrclm_paid_outntwk_bronze_ms_ip"))

    val msBrzMasterData = msBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic",
        "nbrclm_paid_outntwk_bronze_ms_ip")
    val nbrclm_paid_outntwk_silver_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_silver_ms_ip"))

    val msSilMaster = msBrzMasterData.alias("parent").join(nbrclm_paid_outntwk_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"),
        col("nbrclm_paid_outntwk_bronze_ms_ip"), col("nbrclm_paid_outntwk_silver_ms_ip")) //nbrclm_paid_outntwk_bronze_ms_ip

    val msSilMasterData = msSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic",
        "nbrclm_paid_outntwk_bronze_ms_ip", "nbrclm_paid_outntwk_silver_ms_ip")

    val nbrclm_paid_outntwk_gold_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gold_ms_ip"))

    val msGldMaster = msSilMasterData.alias("parent").join(nbrclm_paid_outntwk_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"),
        col("nbrclm_paid_outntwk_bronze_ms_ip"), col("nbrclm_paid_outntwk_silver_ms_ip"), col("nbrclm_paid_outntwk_gold_ms_ip"))

    val msGldMasterData = msGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic",
        "nbrclm_paid_outntwk_bronze_ms_ip", "nbrclm_paid_outntwk_silver_ms_ip", "nbrclm_paid_outntwk_gold_ms_ip")
    val nbrclm_paid_outntwk_platinum_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_platinum_ms_ip"))

    val msPltMaster = msGldMasterData.alias("parent").join(nbrclm_paid_outntwk_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"),
        col("nbrclm_paid_outntwk_bronze_ms_ip"), col("nbrclm_paid_outntwk_silver_ms_ip"), col("nbrclm_paid_outntwk_gold_ms_ip"), col("nbrclm_paid_outntwk_platinum_ms_ip"))

    val msPltMasterData = msPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic",
        "nbrclm_paid_outntwk_bronze_ms_ip", "nbrclm_paid_outntwk_silver_ms_ip", "nbrclm_paid_outntwk_gold_ms_ip", "nbrclm_paid_outntwk_platinum_ms_ip")
    val tot_ms_ip = nbrclm_paid_outntwk_bronze_ms_ip.union(nbrclm_paid_outntwk_silver_ms_ip.union(nbrclm_paid_outntwk_gold_ms_ip.union(nbrclm_paid_outntwk_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_outntwk_bronze_ms_ip"))

    val nbrclm_paid_outntwk_total_ms_ip = tot_ms_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_outntwk_bronze_ms_ip").alias("nbrclm_paid_outntwk_total_ms_ip"))

    val msipMaster = msPltMasterData.alias("parent").join(nbrclm_paid_outntwk_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"),
        col("nbrclm_paid_outntwk_bronze_ms_ip"), col("nbrclm_paid_outntwk_silver_ms_ip"), col("nbrclm_paid_outntwk_gold_ms_ip"), col("nbrclm_paid_outntwk_platinum_ms_ip"), col("nbrclm_paid_outntwk_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic",
        "nbrclm_paid_outntwk_bronze_ms_ip", "nbrclm_paid_outntwk_silver_ms_ip", "nbrclm_paid_outntwk_gold_ms_ip", "nbrclm_paid_outntwk_platinum_ms_ip", "nbrclm_paid_outntwk_total_ms_ip")
    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = clmexphmcy.getMSPlan(naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val nbrclm_paid_outntwk_bronze_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_paid_outntwk_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"),
        col("nbrclm_paid_outntwk_bronze_ms_ip"), col("nbrclm_paid_outntwk_silver_ms_ip"), col("nbrclm_paid_outntwk_gold_ms_ip"), col("nbrclm_paid_outntwk_platinum_ms_ip"), col("nbrclm_paid_outntwk_total_ms_ip"),
        col("nbrclm_paid_outntwk_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic",
        "nbrclm_paid_outntwk_bronze_ms_ip", "nbrclm_paid_outntwk_silver_ms_ip", "nbrclm_paid_outntwk_gold_ms_ip", "nbrclm_paid_outntwk_platinum_ms_ip", "nbrclm_paid_outntwk_total_ms_ip",
        "nbrclm_paid_outntwk_bronze_ms_sgp")

    val nbrclm_paid_outntwk_silver_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_paid_outntwk_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"),
        col("nbrclm_paid_outntwk_bronze_ms_ip"), col("nbrclm_paid_outntwk_silver_ms_ip"), col("nbrclm_paid_outntwk_gold_ms_ip"), col("nbrclm_paid_outntwk_platinum_ms_ip"), col("nbrclm_paid_outntwk_total_ms_ip"),
        col("nbrclm_paid_outntwk_bronze_ms_sgp"), col("nbrclm_paid_outntwk_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic",
        "nbrclm_paid_outntwk_bronze_ms_ip", "nbrclm_paid_outntwk_silver_ms_ip", "nbrclm_paid_outntwk_gold_ms_ip", "nbrclm_paid_outntwk_platinum_ms_ip", "nbrclm_paid_outntwk_total_ms_ip",
        "nbrclm_paid_outntwk_bronze_ms_sgp", "nbrclm_paid_outntwk_silver_ms_sgp")
    val nbrclm_paid_outntwk_gold_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_paid_outntwk_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"),
        col("nbrclm_paid_outntwk_bronze_ms_ip"), col("nbrclm_paid_outntwk_silver_ms_ip"), col("nbrclm_paid_outntwk_gold_ms_ip"), col("nbrclm_paid_outntwk_platinum_ms_ip"), col("nbrclm_paid_outntwk_total_ms_ip"),
        col("nbrclm_paid_outntwk_bronze_ms_sgp"), col("nbrclm_paid_outntwk_silver_ms_sgp"), col("nbrclm_paid_outntwk_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic",
        "nbrclm_paid_outntwk_bronze_ms_ip", "nbrclm_paid_outntwk_silver_ms_ip", "nbrclm_paid_outntwk_gold_ms_ip", "nbrclm_paid_outntwk_platinum_ms_ip", "nbrclm_paid_outntwk_total_ms_ip",
        "nbrclm_paid_outntwk_bronze_ms_sgp", "nbrclm_paid_outntwk_silver_ms_sgp", "nbrclm_paid_outntwk_gold_ms_sgp")

    val nbrclm_paid_outntwk_platinum_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_paid_outntwk_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"),
        col("nbrclm_paid_outntwk_bronze_ms_ip"), col("nbrclm_paid_outntwk_silver_ms_ip"), col("nbrclm_paid_outntwk_gold_ms_ip"), col("nbrclm_paid_outntwk_platinum_ms_ip"), col("nbrclm_paid_outntwk_total_ms_ip"),
        col("nbrclm_paid_outntwk_bronze_ms_sgp"), col("nbrclm_paid_outntwk_silver_ms_sgp"), col("nbrclm_paid_outntwk_gold_ms_sgp"), col("nbrclm_paid_outntwk_platinum_ms_sgp"))

    val mmssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic",
        "nbrclm_paid_outntwk_bronze_ms_ip", "nbrclm_paid_outntwk_silver_ms_ip", "nbrclm_paid_outntwk_gold_ms_ip", "nbrclm_paid_outntwk_platinum_ms_ip", "nbrclm_paid_outntwk_total_ms_ip",
        "nbrclm_paid_outntwk_bronze_ms_sgp", "nbrclm_paid_outntwk_silver_ms_sgp", "nbrclm_paid_outntwk_gold_ms_sgp", "nbrclm_paid_outntwk_platinum_ms_sgp")

    val tot_ms_sgp = nbrclm_paid_outntwk_bronze_ms_sgp.union(nbrclm_paid_outntwk_silver_ms_sgp.union(nbrclm_paid_outntwk_gold_ms_sgp.union(nbrclm_paid_outntwk_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_outntwk_bronze_ms_sgp"))

    val nbrclm_paid_outntwk_total_ms_sgp = tot_ms_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_outntwk_bronze_ms_sgp").alias("nbrclm_paid_outntwk_total_ms_sgp"))

    val mssgpMaster = mmssgpPltMasterData.alias("parent").join(nbrclm_paid_outntwk_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"),
        col("nbrclm_paid_outntwk_bronze_ms_ip"), col("nbrclm_paid_outntwk_silver_ms_ip"), col("nbrclm_paid_outntwk_gold_ms_ip"), col("nbrclm_paid_outntwk_platinum_ms_ip"), col("nbrclm_paid_outntwk_total_ms_ip"),
        col("nbrclm_paid_outntwk_bronze_ms_sgp"), col("nbrclm_paid_outntwk_silver_ms_sgp"), col("nbrclm_paid_outntwk_gold_ms_sgp"), col("nbrclm_paid_outntwk_platinum_ms_sgp"), col("nbrclm_paid_outntwk_total_ms_sgp"))

    val paidInntwkdata = mssgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic",
        "nbrclm_paid_outntwk_bronze_ms_ip", "nbrclm_paid_outntwk_silver_ms_ip", "nbrclm_paid_outntwk_gold_ms_ip", "nbrclm_paid_outntwk_platinum_ms_ip", "nbrclm_paid_outntwk_total_ms_ip",
        "nbrclm_paid_outntwk_bronze_ms_sgp", "nbrclm_paid_outntwk_silver_ms_sgp", "nbrclm_paid_outntwk_gold_ms_sgp", "nbrclm_paid_outntwk_platinum_ms_sgp", "nbrclm_paid_outntwk_total_ms_sgp")

    paidInntwkdata

  }
  def getpaidOutntwkBetweenDates(start_day: Int, end_day: Int, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
                                 naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = start_day.toString + "to" + end_day
    val fend_day = end_day + 1
    val ip_df = clmexphmcy.getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val nbrclm_paid_outntwk_colVal_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_outntwk_colVal_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_paid_outntwk_colVal_bronze_ip.alias("parent").join(nbrclm_paid_outntwk_colVal_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip")
    val nbrclm_paid_outntwk_colVal_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip")

    val nbrclm_paid_outntwk_colVal_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_paid_outntwk_colVal_bronze_ip.union(nbrclm_paid_outntwk_colVal_silver_ip.union(nbrclm_paid_outntwk_colVal_gold_ip.union(nbrclm_paid_outntwk_colVal_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_outntwk_colVal_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_ip").alias("nbrclm_paid_outntwk_" + colVal + "_total_ip"))
    //********************
    val totipMaster = pltMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = clmexphmcy.getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val nbrclm_paid_outntwk_colVal_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp")

    val nbrclm_paid_outntwk_colVal_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp")

    val nbrclm_paid_outntwk_colVal_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp")

    val nbrclm_paid_outntwk_colVal_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp")

    val tot_sgp = nbrclm_paid_outntwk_colVal_bronze_sgp.union(nbrclm_paid_outntwk_colVal_silver_sgp.union(nbrclm_paid_outntwk_colVal_gold_sgp.union(nbrclm_paid_outntwk_colVal_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_paid_outntwk_colVal_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp").alias("nbrclm_paid_outntwk_" + colVal + "_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp")

    val nbrclm_paid_outntwk_colVal_catastrophic = naic_mcas_hlthex_clmexphmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = clmexphmcy.getMSPlan(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val nbrclm_paid_outntwk_colVal_bronze_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip")

    val nbrclm_paid_outntwk_colVal_silver_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip")

    val nbrclm_paid_outntwk_colVal_gold_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip")

    val nbrclm_paid_outntwk_colVal_platinum_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip")
    val tot_msip = nbrclm_paid_outntwk_colVal_bronze_ms_ip.union(nbrclm_paid_outntwk_colVal_silver_ms_ip.union(nbrclm_paid_outntwk_colVal_gold_ms_ip.union(nbrclm_paid_outntwk_colVal_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"))

    val nbrclm_paid_outntwk_colVal_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip").alias("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = clmexphmcy.getMSPlan(naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val nbrclm_paid_outntwk_colVal_bronze_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp")

    val nbrclm_paid_outntwk_colVal_silver_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp")
    val nbrclm_paid_outntwk_colVal_gold_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp")

    val nbrclm_paid_outntwk_colVal_platinum_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_sgp")

    val tot_mssgp = nbrclm_paid_outntwk_colVal_bronze_ms_sgp.union(nbrclm_paid_outntwk_colVal_silver_ms_sgp.union(nbrclm_paid_outntwk_colVal_gold_ms_sgp.union(nbrclm_paid_outntwk_colVal_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"))

    val nbrclm_paid_outntwk_colVal_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp").alias("nbrclm_paid_outntwk_" + colVal + "_total_ms_sgp"))

    val paid_outntwk = mssgpPltMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_sgp"))

    val paid_outntwkData = paid_outntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_ms_sgp")
    paid_outntwkData
  }
  def getpaidOutntwk_90(end_year: String, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
                        naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = "90"
    val strt_day = 91
    val ip_df = clmexphmcy.getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_outntwk_colVal_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_outntwk_colVal_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_paid_outntwk_colVal_bronze_ip.alias("parent").join(nbrclm_paid_outntwk_colVal_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip")
    val nbrclm_paid_outntwk_colVal_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip")

    val nbrclm_paid_outntwk_colVal_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_paid_outntwk_colVal_bronze_ip.union(nbrclm_paid_outntwk_colVal_silver_ip.union(nbrclm_paid_outntwk_colVal_gold_ip.union(nbrclm_paid_outntwk_colVal_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_outntwk_colVal_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_ip").alias("nbrclm_paid_outntwk_" + colVal + "_total_ip"))
    //********************
    val totipMaster = pltMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = clmexphmcy.getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_outntwk_colVal_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp")

    val nbrclm_paid_outntwk_colVal_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp")

    val nbrclm_paid_outntwk_colVal_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp")

    val nbrclm_paid_outntwk_colVal_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp")

    val tot_sgp = nbrclm_paid_outntwk_colVal_bronze_sgp.union(nbrclm_paid_outntwk_colVal_silver_sgp.union(nbrclm_paid_outntwk_colVal_gold_sgp.union(nbrclm_paid_outntwk_colVal_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_paid_outntwk_colVal_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp").alias("nbrclm_paid_outntwk_" + colVal + "_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp")

    val nbrclm_paid_outntwk_colVal_catastrophic = naic_mcas_hlthex_clmexphmcy_paid_cat_wrk.withColumn("constant_date", lit(end_year))
      .filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
        $"in_Exchange".equalTo("IN") &&
        (!$"inn_cd".isin(clminn_cd: _*)) &&
        $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = clmexphmcy.getMSPlan(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_outntwk_colVal_bronze_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip")

    val nbrclm_paid_outntwk_colVal_silver_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip")

    val nbrclm_paid_outntwk_colVal_gold_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip")

    val nbrclm_paid_outntwk_colVal_platinum_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip")
    val tot_msip = nbrclm_paid_outntwk_colVal_bronze_ms_ip.union(nbrclm_paid_outntwk_colVal_silver_ms_ip.union(nbrclm_paid_outntwk_colVal_gold_ms_ip.union(nbrclm_paid_outntwk_colVal_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"))

    val nbrclm_paid_outntwk_colVal_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip").alias("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = clmexphmcy.getMSPlan(naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_outntwk_colVal_bronze_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp")

    val nbrclm_paid_outntwk_colVal_silver_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp")
    val nbrclm_paid_outntwk_colVal_gold_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp")

    val nbrclm_paid_outntwk_colVal_platinum_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_sgp")

    val tot_mssgp = nbrclm_paid_outntwk_colVal_bronze_ms_sgp.union(nbrclm_paid_outntwk_colVal_silver_ms_sgp.union(nbrclm_paid_outntwk_colVal_gold_ms_sgp.union(nbrclm_paid_outntwk_colVal_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"))

    val nbrclm_paid_outntwk_colVal_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp").alias("nbrclm_paid_outntwk_" + colVal + "_total_ms_sgp"))

    val paid_outntwk = mssgpPltMasterData.alias("parent").join(nbrclm_paid_outntwk_colVal_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ms_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_ms_sgp"))

    val paid_outntwkData = paid_outntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_catastrophic",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_ms_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_ms_sgp")
    paid_outntwkData
  }

  def getamtData(paid_col: String, typeOfPay: String, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
                 naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"

    val ip_df = clmexphmcy.getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val clm_total_amt_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_bronze_ip")).withColumn("clm_total_" + typeOfPay + "_amt_bronze_ip", col("clm_total_" + typeOfPay + "_amt_bronze_ip").cast(IntegerType))

    val clm_total_amt_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_silver_ip")).withColumn("clm_total_" + typeOfPay + "_amt_silver_ip", col("clm_total_" + typeOfPay + "_amt_silver_ip").cast(IntegerType))

    val brSil = clm_total_amt_bronze_ip.alias("parent").join(clm_total_amt_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip")

    val clm_total_amt_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_gold_ip")).withColumn("clm_total_" + typeOfPay + "_amt_gold_ip", col("clm_total_" + typeOfPay + "_amt_gold_ip").cast(IntegerType))

    val gldMaster = brSilData.alias("parent").join(clm_total_amt_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip")

    val clm_total_amt_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_platinum_ip")).withColumn("clm_total_" + typeOfPay + "_amt_platinum_ip", col("clm_total_" + typeOfPay + "_amt_platinum_ip").cast(IntegerType))

    val pltMaster = gldMasterData.alias("parent").join(clm_total_amt_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip")

    val tot_ip = clm_total_amt_bronze_ip.union(clm_total_amt_silver_ip.union(clm_total_amt_gold_ip.union(clm_total_amt_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("clm_total_" + typeOfPay + "_amt_bronze_ip"))

    val clm_total_amt_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("clm_total_" + typeOfPay + "_amt_bronze_ip").alias("clm_total_" + typeOfPay + "_amt_total_ip"))

    val ipMaster = pltMasterData.alias("parent").join(clm_total_amt_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"))

    val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"

    val sgp_df = clmexphmcy.getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val clm_total_amt_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_bronze_sgp")).withColumn("clm_total_" + typeOfPay + "_amt_bronze_sgp", col("clm_total_" + typeOfPay + "_amt_bronze_sgp").cast(IntegerType))

    val BrzsgpMaster = ipMasterData.alias("parent").join(clm_total_amt_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"))

    val BrzsgpMasterData = BrzsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp")

    val clm_total_amt_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_silver_sgp")).withColumn("clm_total_" + typeOfPay + "_amt_silver_sgp", col("clm_total_" + typeOfPay + "_amt_silver_sgp").cast(IntegerType))

    val silsgpMaster = BrzsgpMasterData.alias("parent").join(clm_total_amt_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"))

    val silsgpMasterData = silsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp")

    val clm_total_amt_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_gold_sgp")).withColumn("clm_total_" + typeOfPay + "_amt_gold_sgp", col("clm_total_" + typeOfPay + "_amt_gold_sgp").cast(IntegerType))

    val gldsgpMaster = silsgpMasterData.alias("parent").join(clm_total_amt_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"))

    val gldsgpMasterData = gldsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp")
    val clm_total_amt_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_platinum_sgp")).withColumn("clm_total_" + typeOfPay + "_amt_platinum_sgp", col("clm_total_" + typeOfPay + "_amt_platinum_sgp").cast(IntegerType))

    val pltsgpMaster = gldsgpMasterData.alias("parent").join(clm_total_amt_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"))

    val pltsgpMasterData = pltsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp")

    val tot_sgp = clm_total_amt_bronze_sgp.union(clm_total_amt_silver_sgp.union(clm_total_amt_gold_sgp.union(clm_total_amt_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("clm_total_" + typeOfPay + "_amt_bronze_sgp"))

    val clm_total_amt_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("clm_total_" + typeOfPay + "_amt_bronze_sgp").alias("clm_total_" + typeOfPay + "_amt_total_sgp"))

    val sgpMaster = pltsgpMasterData.alias("parent").join(clm_total_amt_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"))

    val sgpMasterData = sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = clmexphmcy.getMSPlan(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val clm_total_amt_bronze_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("04"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_bronze_ms_ip")).withColumn("clm_total_" + typeOfPay + "_amt_bronze_ms_ip", col("clm_total_" + typeOfPay + "_amt_bronze_ms_ip").cast(IntegerType))

    val brzmsipMaster = sgpMasterData.alias("parent").join(clm_total_amt_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_ip"))

    val brzmsipMasterData = brzmsipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_ip")
    val clm_total_amt_silver_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("03"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_silver_ms_ip")).withColumn("clm_total_" + typeOfPay + "_amt_silver_ms_ip", col("clm_total_" + typeOfPay + "_amt_silver_ms_ip").cast(IntegerType))

    val silmsipMaster = brzmsipMasterData.alias("parent").join(clm_total_amt_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ms_ip"))

    val silmsipMasterData = silmsipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_ip", "clm_total_" + typeOfPay + "_amt_silver_ms_ip")
    val clm_total_amt_gold_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("02"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_gold_ms_ip")).withColumn("clm_total_" + typeOfPay + "_amt_gold_ms_ip", col("clm_total_" + typeOfPay + "_amt_gold_ms_ip").cast(IntegerType))

    val gldmsipMaster = silmsipMasterData.alias("parent").join(clm_total_amt_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ms_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ms_ip"))

    val gldmsipMasterData = gldmsipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_ip", "clm_total_" + typeOfPay + "_amt_silver_ms_ip", "clm_total_" + typeOfPay + "_amt_gold_ms_ip")
    val clm_total_amt_platinum_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("01"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_platinum_ms_ip")).withColumn("clm_total_" + typeOfPay + "_amt_platinum_ms_ip", col("clm_total_" + typeOfPay + "_amt_platinum_ms_ip").cast(IntegerType))

    val pltmsipMaster = gldmsipMasterData.alias("parent").join(clm_total_amt_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ms_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ms_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ms_ip"))

    val pltmsipMasterData = pltmsipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_ip", "clm_total_" + typeOfPay + "_amt_silver_ms_ip", "clm_total_" + typeOfPay + "_amt_gold_ms_ip", "clm_total_" + typeOfPay + "_amt_platinum_ms_ip")

    val tot_ms_ip = clm_total_amt_bronze_ms_ip.union(clm_total_amt_silver_ms_ip.union(clm_total_amt_gold_ms_ip.union(clm_total_amt_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("clm_total_" + typeOfPay + "_amt_bronze_ms_ip"))

    val clm_total_amt_total_ms_ip = tot_ms_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("clm_total_" + typeOfPay + "_amt_bronze_ms_ip").alias("clm_total_" + typeOfPay + "_amt_total_ms_ip"))

    val msipMaster = pltmsipMasterData.alias("parent").join(clm_total_amt_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ms_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ms_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ms_ip"), col("clm_total_" + typeOfPay + "_amt_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_ip", "clm_total_" + typeOfPay + "_amt_silver_ms_ip", "clm_total_" + typeOfPay + "_amt_gold_ms_ip", "clm_total_" + typeOfPay + "_amt_platinum_ms_ip", "clm_total_" + typeOfPay + "_amt_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = clmexphmcy.getMSPlan(naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val clm_total_amt_bronze_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_bronze_ms_sgp")).withColumn("clm_total_" + typeOfPay + "_amt_bronze_ms_sgp", col("clm_total_" + typeOfPay + "_amt_bronze_ms_sgp").cast(IntegerType))
    val brzmssgpMaster = msipMasterData.alias("parent").join(clm_total_amt_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ms_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ms_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ms_ip"), col("clm_total_" + typeOfPay + "_amt_total_ms_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_sgp"))

    val brzmssgpMasterData = brzmssgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_ip", "clm_total_" + typeOfPay + "_amt_silver_ms_ip", "clm_total_" + typeOfPay + "_amt_gold_ms_ip", "clm_total_" + typeOfPay + "_amt_platinum_ms_ip", "clm_total_" + typeOfPay + "_amt_total_ms_ip", "clm_total_" + typeOfPay + "_amt_bronze_ms_sgp")

    val clm_total_amt_silver_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_silver_ms_sgp")).withColumn("clm_total_" + typeOfPay + "_amt_silver_ms_sgp", col("clm_total_" + typeOfPay + "_amt_silver_ms_sgp").cast(IntegerType))
    val silmssgpMaster = brzmssgpMasterData.alias("parent").join(clm_total_amt_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ms_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ms_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ms_ip"), col("clm_total_" + typeOfPay + "_amt_total_ms_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_ms_sgp"))

    val silmssgpMasterData = silmssgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_ip", "clm_total_" + typeOfPay + "_amt_silver_ms_ip", "clm_total_" + typeOfPay + "_amt_gold_ms_ip", "clm_total_" + typeOfPay + "_amt_platinum_ms_ip", "clm_total_" + typeOfPay + "_amt_total_ms_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_sgp", "clm_total_" + typeOfPay + "_amt_silver_ms_sgp")

    val clm_total_amt_gold_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_gold_ms_sgp")).withColumn("clm_total_" + typeOfPay + "_amt_gold_ms_sgp", col("clm_total_" + typeOfPay + "_amt_gold_ms_sgp").cast(IntegerType))
    val gldmssgpMaster = silmssgpMasterData.alias("parent").join(clm_total_amt_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ms_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ms_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ms_ip"), col("clm_total_" + typeOfPay + "_amt_total_ms_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_ms_sgp"))

    val gldmssgpMasterData = gldmssgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_ip", "clm_total_" + typeOfPay + "_amt_silver_ms_ip", "clm_total_" + typeOfPay + "_amt_gold_ms_ip", "clm_total_" + typeOfPay + "_amt_platinum_ms_ip", "clm_total_" + typeOfPay + "_amt_total_ms_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_sgp", "clm_total_" + typeOfPay + "_amt_silver_ms_sgp", "clm_total_" + typeOfPay + "_amt_gold_ms_sgp")

    val clm_total_amt_platinum_ms_sgp = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_platinum_ms_sgp")).withColumn("clm_total_" + typeOfPay + "_amt_platinum_ms_sgp", col("clm_total_" + typeOfPay + "_amt_platinum_ms_sgp").cast(IntegerType))
    val pltmssgpMaster = gldmssgpMasterData.alias("parent").join(clm_total_amt_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ms_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ms_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ms_ip"), col("clm_total_" + typeOfPay + "_amt_total_ms_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_ms_sgp"))

    val pltmssgpMasterData = pltmssgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_ip", "clm_total_" + typeOfPay + "_amt_silver_ms_ip", "clm_total_" + typeOfPay + "_amt_gold_ms_ip", "clm_total_" + typeOfPay + "_amt_platinum_ms_ip", "clm_total_" + typeOfPay + "_amt_total_ms_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_sgp", "clm_total_" + typeOfPay + "_amt_silver_ms_sgp", "clm_total_" + typeOfPay + "_amt_gold_ms_sgp", "clm_total_" + typeOfPay + "_amt_platinum_ms_sgp")
    val tot_ms_sgp = clm_total_amt_bronze_ms_sgp.union(clm_total_amt_silver_ms_sgp.union(clm_total_amt_gold_ms_sgp.union(clm_total_amt_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("clm_total_" + typeOfPay + "_amt_bronze_ms_sgp"))

    val clm_total_amt_total_ms_sgp = tot_ms_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("clm_total_" + typeOfPay + "_amt_bronze_ms_sgp").alias("clm_total_" + typeOfPay + "_amt_total_ms_sgp"))

    val clmPaid = pltmssgpMasterData.alias("parent").join(clm_total_amt_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ms_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ms_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ms_ip"), col("clm_total_" + typeOfPay + "_amt_total_ms_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_total_ms_sgp"))

    val clmPaidData = clmPaid.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_ip", "clm_total_" + typeOfPay + "_amt_silver_ms_ip", "clm_total_" + typeOfPay + "_amt_gold_ms_ip", "clm_total_" + typeOfPay + "_amt_platinum_ms_ip", "clm_total_" + typeOfPay + "_amt_total_ms_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_sgp", "clm_total_" + typeOfPay + "_amt_silver_ms_sgp", "clm_total_" + typeOfPay + "_amt_gold_ms_sgp", "clm_total_" + typeOfPay + "_amt_platinum_ms_sgp", "clm_total_" + typeOfPay + "_amt_total_ms_sgp")

    val clm_total_amt_catastrophic = naic_mcas_hlthex_clmexphmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_exchange".equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_catastrophic")).withColumn("clm_total_" + typeOfPay + "_amt_catastrophic", col("clm_total_" + typeOfPay + "_amt_catastrophic").cast(IntegerType))

    val finalMaster = clmPaidData.alias("parent").join(clm_total_amt_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ms_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ms_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ms_ip"), col("clm_total_" + typeOfPay + "_amt_total_ms_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_total_ms_sgp"), col("clm_total_" + typeOfPay + "_amt_catastrophic"))

    val finalMasterData = finalMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp", "clm_total_" + typeOfPay + "_amt_catastrophic",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_ip", "clm_total_" + typeOfPay + "_amt_silver_ms_ip", "clm_total_" + typeOfPay + "_amt_gold_ms_ip", "clm_total_" + typeOfPay + "_amt_platinum_ms_ip", "clm_total_" + typeOfPay + "_amt_total_ms_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_ms_sgp", "clm_total_" + typeOfPay + "_amt_silver_ms_sgp", "clm_total_" + typeOfPay + "_amt_gold_ms_sgp", "clm_total_" + typeOfPay + "_amt_platinum_ms_sgp", "clm_total_" + typeOfPay + "_amt_total_ms_sgp")

    finalMasterData

  }
}