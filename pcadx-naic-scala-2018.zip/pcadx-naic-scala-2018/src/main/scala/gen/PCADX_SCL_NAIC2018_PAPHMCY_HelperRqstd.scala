package gen

class PCADX_SCL_NAIC2018_PAPHMCY_HelperRqstd {

def rqstdTrnctTbl(table: String) = """Truncate table """ + table

def reqstdwrk1(dbInbnd: String, tb2: String,load_log_key:String, strtDt: String, endDt: String) =  """Insert into table """+tb2+"""
select * from (select ur.RFRNC_NBR AS RFRNC_NBR , ur.MBR_KEY as MBR_KEY, ur.um_rqst_initd_dt ,ur.case_type_cd,"""+ load_log_key +""" as load_log_key,
current_timestamp as load_dt
from  """+dbInbnd+""".UM_RQST ur
Left join  """+dbInbnd+""".UM_SRVC_STTS us
on us.RFRNC_NBR = ur.RFRNC_NBR
Left join  """+dbInbnd+""".UM_SRVC ux
on ux.RFRNC_NBR = ur.RFRNC_NBR
where ur.clncl_sor_cd in ('873', '872','870','1103','1035','948')
and ur.AUTHRZN_STTS_CD in ('A', 'C', 'N', 'NA', 'O', 'P', 'UNK', 'V')
and ur.UM_RQST_INITD_DT BETWEEN  """+strtDt+"""  AND  """+endDt+"""
and ur.case_type_cd  IN ( 'PHARMACY' )
and ux.SRVC_RVW_TYPE_CD in ('P','PU','PNU')
and ur.RCRD_STTS_CD not in ( 'DEL', 'DUP' )
group by  ur.MBR_KEY, ur.RFRNC_NBR ,ur.UM_RQST_INITD_DT,ur.case_type_cd)"""

def aprvdwrk1(dbInbnd: String, tb2: String,load_log_key:String, strtDt: String, endDt: String) =  """Insert into table """+tb2+"""
select * from (select ur.RFRNC_NBR AS RFRNC_NBR, ur.MBR_KEY  as MBR_KEY, us.STTS_DT,ur.case_type_cd,"""+ load_log_key +""" as load_log_key,
current_timestamp as load_dt
from  """+dbInbnd+""".UM_RQST ur
Left join  """+dbInbnd+""".UM_SRVC_STTS us
on us.RFRNC_NBR = ur.RFRNC_NBR
Left join  """+dbInbnd+""".UM_SRVC ux
on ux.RFRNC_NBR = ur.RFRNC_NBR
where ur.clncl_sor_cd in ('873', '872','870','1103','1035','948')
and ur.AUTHRZN_STTS_CD  IN ('A','V')
and us.STTS_DT BETWEEN  """+strtDt+"""  AND  """+endDt+"""
and ur.case_type_cd  IN ( 'PHARMACY' )
and ux.SRVC_RVW_TYPE_CD in ('P','PU','PNU')
and ur.RCRD_STTS_CD not in ( 'DEL', 'DUP' )
group by  ur.MBR_KEY,ur.RFRNC_NBR,us.STTS_DT,ur.case_type_cd)"""

def deniedwrk1(dbInbnd: String, tb2: String,load_log_key:String, strtDt: String, endDt: String) =  """Insert into table """+tb2+"""
select * from (select ur.RFRNC_NBR AS RFRNC_NBR , ur.MBR_KEY as MBR_KEY, us.STTS_DT,ur.case_type_cd,"""+ load_log_key +""" as load_log_key,
current_timestamp as load_dt
from  """+dbInbnd+""".UM_RQST ur
Left join  """+dbInbnd+""".UM_SRVC_STTS us
on us.RFRNC_NBR = ur.RFRNC_NBR
Left join  """+dbInbnd+""".UM_SRVC ux
on ux.RFRNC_NBR = ur.RFRNC_NBR
where ur.clncl_sor_cd in ('873', '872','870','1103','1035','948') 
and ur.AUTHRZN_STTS_CD in ('N')
and us.STTS_DT BETWEEN  """+strtDt+"""  AND  """+endDt+""" 
and ur.case_type_cd  IN ( 'PHARMACY' )
and ux.SRVC_RVW_TYPE_CD in ('P','PU','PNU')
and ur.RCRD_STTS_CD not in ( 'DEL', 'DUP' )
group by ur.MBR_KEY,ur.RFRNC_NBR ,us.STTS_DT,ur.case_type_cd)"""

def rqstdTtlIndvdl (dbwrk:String,dbInbnd:String,tbl:String,tb2:String,reportYear:String,load_log_key:String,tempCol:String,prcp_cd:String)="""
Insert into table """+tbl+"""
select * from (select """+reportYear+""" as health_year,
PA1.RFRNC_NBR AS RFRNC_NBR ,
temp.MBR_KEY AS MBR_KEY,
temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
temp.MBU_CF_CD AS MBU_CF_CD ,
temp.PROD_CF_CD AS PROD_CF_CD,
temp.CMPNY_CF_CD AS CMPNY_CF_CD,
temp.FUNDG_CF_CD AS FUNDG_CF_CD,
temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
temp.HIX_CD AS HIX_CD,
BRD.State AS  State,
CASE WHEN substring (temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')
and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN'
WHEN temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN'
WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK' )AND temp.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
END AS IN_Exchange ,
CASE WHEN substr (temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF'
WHEN temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK' )AND temp.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
END AS OUTOFF_Exchange,
CB.GL_LVL_DESC AS naic_lob,
MED.GL_CF_DESC  as  naic_prod_desc,
temp.PRCP_TYPE_CD as prcp_type_cd ,
PA1.case_type_cd as case_type_cd,
temp.SRC_GRP_NBR as src_grp_nbr,
temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
"""+ load_log_key +""" as load_log_key,
current_timestamp as load_dt
from  """+tb2+""" PA1
INNER JOIN """+dbwrk+""".clm_inter temp
ON PA1.MBR_KEY = temp.MBR_KEY
inner join (
select CF_CD, GL_LVL_DESC
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
WHERE GL_CF_TYPE_DESC = 'CBE'
AND GL_LVL_DESC in ('TOTAL INDIVIDUAL CBE')
group by 1,2
) as CB
on CB.CF_CD =temp.MBU_CF_CD
inner join (
select CF_CD,  GL_CF_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'PRODUCT'
AND GL_CF_DESC NOT LIKE '%CATASTROPHIC%'
group by 1,2
) as MED
on MED.CF_CD = temp.PROD_CF_CD

inner join
(
select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY gl
where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  group by 1,2
) BRD
on BRD.CF_CD= temp.MBU_CF_CD
and BRD.state <> 'LT'

inner join
(
select DISTINCT CF_CD
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where  GL_CF_TYPE_DESC = 'FUND_CODE'
and CF_CD NOT IN ( select DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'FUND_CODE' AND
( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
)
) FC
ON FC.CF_CD = temp.FUNDG_CF_CD

WHERE
PA1."""+tempCol+"""  between temp.mbr_prod_enrlmnt_efctv_dt and temp.mbr_prod_enrlmnt_trmntn_dt
AND BRD.STATE NOT IN ('IL', 'DC', 'MA')

GROUP BY
PA1.RFRNC_NBR  ,
temp.MBR_KEY ,
temp.MBRSHP_SOR_CD ,
temp.GRNDFTHR_IND_CD  ,
temp.HIX_CD ,
temp.GRNDFTHRG_STTS_CD ,
temp.hcr_cmplynt_cd,
temp.EXCHNG_IND_CD ,
temp.EXCHNG_METL_TYPE_CD ,
temp.SRC_EXCHNG_CERTFN_CD ,
temp.MBU_CF_CD  ,
temp.PROD_CF_CD ,
temp.CMPNY_CF_CD ,
temp.FUNDG_CF_CD ,
BRD.State ,
CB.GL_LVL_DESC,
MED.GL_CF_DESC ,
temp.PRCP_TYPE_CD,
PA1.case_type_cd,
temp.SRC_GRP_NBR  ,
temp.SRC_SUBGRP_NBR
)
"""

def rqstdSmllGrp(dbwrk:String,dbInbnd:String,tbl:String,tb2:String,reportYear:String,load_log_key:String, tempCol:String,temp_cd:String)="""
Insert into table """+tbl+"""
select * from (select """+
reportYear+""" as health_year,
PA1.RFRNC_NBR AS RFRNC_NBR ,
temp.MBR_KEY AS MBR_KEY,
temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
temp.MBU_CF_CD AS MBU_CF_CD ,
temp.PROD_CF_CD AS PROD_CF_CD,
temp.CMPNY_CF_CD AS CMPNY_CF_CD,
temp.FUNDG_CF_CD AS FUNDG_CF_CD,
temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
temp.HIX_CD AS HIX_CD,
BRD.State AS  State,
CASE WHEN substring (temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')
and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN'
WHEN temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN'
WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK' )AND temp.HIX_CD IN
('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
END AS IN_Exchange ,
CASE WHEN substr (temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF'
WHEN temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK' )AND temp.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
END AS OUTOFF_Exchange,
CB.GL_LVL_DESC AS naic_lob,
MED.GL_CF_DESC  as  naic_prod_desc,
temp.PRCP_TYPE_CD as PRCP_type_cd,
PA1.case_type_cd as case_type_cd,
temp.SRC_GRP_NBR as src_grp_nbr ,
temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
"""+load_log_key +""" as load_log_key,
current_timestamp as load_dt
from (select * from """+tb2+""")  PA1
INNER JOIN """+dbwrk+""".clm_inter temp
ON PA1.MBR_KEY = temp.MBR_KEY
inner join (
select CF_CD, GL_LVL_DESC
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
WHERE GL_CF_TYPE_DESC = 'CBE'
AND GL_LVL_DESC in ('TOTAL SMALL GROUP CBE')
group by 1,2
) as CB
on CB.CF_CD =temp.MBU_CF_CD
inner join (
select CF_CD,GL_CF_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'PRODUCT'
group by 1,2
) as MED
on MED.CF_CD = temp.PROD_CF_CD
inner join
(
select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY gl
where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  group by 1,2
) BRD
on BRD.CF_CD= temp.MBU_CF_CD
and BRD.state <> 'LT'
inner join
(
select DISTINCT CF_CD
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where  GL_CF_TYPE_DESC = 'FUND_CODE'
and CF_CD NOT IN ( select  CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'FUND_CODE' AND
( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
)
) FC
ON FC.CF_CD = temp.FUNDG_CF_CD
WHERE
PA1."""+tempCol+"""  between temp.mbr_prod_enrlmnt_efctv_dt and temp.mbr_prod_enrlmnt_trmntn_dt
AND BRD.STATE NOT IN ('IL', 'DC', 'MA')

GROUP BY
PA1.RFRNC_NBR  ,
temp.MBR_KEY ,
temp.MBRSHP_SOR_CD ,
temp.GRNDFTHR_IND_CD  ,
temp.HIX_CD ,
temp.GRNDFTHRG_STTS_CD ,
temp.hcr_cmplynt_cd,
temp.EXCHNG_IND_CD ,
temp.EXCHNG_METL_TYPE_CD ,
temp.SRC_EXCHNG_CERTFN_CD ,
temp.MBU_CF_CD  ,
temp.PROD_CF_CD ,
temp.CMPNY_CF_CD ,
temp.FUNDG_CF_CD ,
BRD.State ,
CB.GL_LVL_DESC,
MED.GL_CF_DESC,
temp.PRCP_TYPE_CD ,
PA1.case_type_cd ,
temp.SRC_GRP_NBR  ,
temp.SRC_SUBGRP_NBR
)
"""

def rqstdAll(dbwrk:String,dbInbnd:String,tbl:String,tb2:String,reportYear:String,load_log_key:String,tempCol:String,prcp_cd:String)="""
Insert into table """+tbl+"""
select * from (select """+
reportYear+""" as health_year,
PA1.RFRNC_NBR AS RFRNC_NBR ,
temp.MBR_KEY AS MBR_KEY,
temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
temp.MBU_CF_CD AS MBU_CF_CD ,
temp.PROD_CF_CD AS PROD_CF_CD,
temp.CMPNY_CF_CD AS CMPNY_CF_CD,
temp.FUNDG_CF_CD AS FUNDG_CF_CD,
temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
temp.HIX_CD AS HIX_CD,
BRD.State AS  State,
CASE WHEN substring (temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')
and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN'
WHEN temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN'
WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK' )AND temp.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
END AS IN_Exchange ,
CASE WHEN substr (temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF'
WHEN temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK' )AND temp.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
END AS OUTOFF_Exchange,
MED.GL_CF_DESC AS naic_lob,
MED.GL_CF_DESC  as  naic_prod_desc,
temp.PRCP_TYPE_CD as prcp_type_cd ,
PA1.case_type_cd as case_type_cd,
temp.SRC_GRP_NBR as src_grp_nbr ,
temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
"""+load_log_key+""" as load_log_key,
current_timestamp as load_dt
from """+tb2+"""  PA1
INNER JOIN """+dbwrk+""".clm_inter temp
ON PA1.MBR_KEY = temp.MBR_KEY
inner join (
select CF_CD,  GL_CF_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'PRODUCT'
AND GL_CF_DESC LIKE '%CATASTROPHIC%'
group by 1,2
) as MED
on MED.CF_CD = temp.PROD_CF_CD

inner join
(
select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY gl
where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  group by 1,2
) BRD
on BRD.CF_CD= temp.MBU_CF_CD
and BRD.state <> 'LT'
inner join
(
select DISTINCT CF_CD
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where  GL_CF_TYPE_DESC = 'FUND_CODE'
and CF_CD NOT IN ( select  CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'FUND_CODE' AND
( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
)
) FC
ON FC.CF_CD = temp.FUNDG_CF_CD

WHERE
PA1."""+tempCol+"""  between temp.mbr_prod_enrlmnt_efctv_dt and temp.mbr_prod_enrlmnt_trmntn_dt
AND BRD.STATE NOT IN ('IL', 'DC', 'MA')

GROUP BY
PA1.RFRNC_NBR  ,
temp.MBR_KEY ,
temp.MBRSHP_SOR_CD ,
temp.GRNDFTHR_IND_CD  ,
temp.HIX_CD ,
temp.GRNDFTHRG_STTS_CD ,
temp.hcr_cmplynt_cd,
temp.EXCHNG_IND_CD ,
temp.EXCHNG_METL_TYPE_CD ,
temp.SRC_EXCHNG_CERTFN_CD ,
temp.MBU_CF_CD  ,
temp.PROD_CF_CD ,
temp.CMPNY_CF_CD ,
temp.FUNDG_CF_CD ,
BRD.State ,
MED.GL_CF_DESC ,
MED.GL_CF_DESC,
temp.PRCP_TYPE_CD ,
PA1.case_type_cd,
temp.SRC_GRP_NBR  ,
temp.SRC_SUBGRP_NBR

)

"""
def rqstdAllEx(dbwrk:String,dbInbnd:String,tbl:String,tb2:String, reportYear:String,load_log_key:String,tempCol:String,prcp_cd:String)="""
Insert into table """+tbl+"""
select * from (select """+reportYear+""" as health_year,
PA1.RFRNC_NBR AS RFRNC_NBR ,
temp.MBR_KEY AS MBR_KEY,
temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
temp.MBU_CF_CD AS MBU_CF_CD ,
temp.PROD_CF_CD AS PROD_CF_CD,
temp.CMPNY_CF_CD AS CMPNY_CF_CD,
temp.FUNDG_CF_CD AS FUNDG_CF_CD,
temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
temp.HIX_CD AS HIX_CD,
BRD.State AS  State,
CASE WHEN substring (temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')
and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN'
WHEN temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN'
WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK' )AND temp.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
END AS IN_Exchange ,
CASE WHEN substr (temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF'
WHEN temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK' )AND temp.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
END AS OUTOFF_Exchange,
CB.GL_LVL_DESC AS naic_lob,
MED.GL_CF_DESC  as  naic_prod_desc,
temp.PRCP_TYPE_CD as prcp_type_cd ,
PA1.case_type_cd as case_type_cd ,
temp.SRC_GRP_NBR as src_grp_nbr ,
temp.SRC_SUBGRP_NBR as src_subgrp_nbr,

"""+load_log_key+""" as load_log_key,
current_timestamp as load_dt
from  """+tb2+""" PA1
INNER JOIN """+dbwrk+""".clm_inter temp
ON PA1.MBR_KEY = temp.MBR_KEY
inner join (
select CF_CD, GL_LVL_DESC
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
WHERE GL_CF_TYPE_DESC = 'CBE'
AND  GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' )
group by 1,2
) as CB
on CB.CF_CD =temp.MBU_CF_CD
inner join (
select CF_CD,  GL_CF_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'PRODUCT'
group by 1,2
) as MED
on MED.CF_CD = temp.PROD_CF_CD

inner join
(
select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY gl
where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  group by 1,2
) BRD
on BRD.CF_CD= temp.MBU_CF_CD
and BRD.state <> 'LT'

inner join
(
select DISTINCT CF_CD
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where  GL_CF_TYPE_DESC = 'FUND_CODE'
and CF_CD NOT IN ( select  CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'FUND_CODE' AND
( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
)
) FC
ON FC.CF_CD = temp.FUNDG_CF_CD

WHERE PA1."""+tempCol+"""  between temp.mbr_prod_enrlmnt_efctv_dt and temp.mbr_prod_enrlmnt_trmntn_dt
AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
AND  temp.MBU_CF_CD NOT IN ('EDCASH','SPGAZZ','EDCOSH','EDINSH')

GROUP BY
PA1.RFRNC_NBR  ,
temp.MBR_KEY ,
temp.MBRSHP_SOR_CD ,
temp.GRNDFTHR_IND_CD  ,
temp.HIX_CD ,
temp.GRNDFTHRG_STTS_CD ,
temp.hcr_cmplynt_cd,
temp.EXCHNG_IND_CD ,
temp.EXCHNG_METL_TYPE_CD ,
temp.SRC_EXCHNG_CERTFN_CD ,
temp.MBU_CF_CD  ,
temp.PROD_CF_CD ,
temp.CMPNY_CF_CD ,
temp.FUNDG_CF_CD ,
BRD.State ,
CB.GL_LVL_DESC,
MED.GL_CF_DESC,
temp.PRCP_TYPE_CD,
PA1.case_type_cd,
temp.SRC_GRP_NBR  ,
temp.SRC_SUBGRP_NBR
)

"""
def rqstdAllLgp(dbwrk:String,dbInbnd:String,tbl:String, tb2:String,reportYear:String,load_log_key:String,tempCol:String,prcp_cd:String)="""
Insert into table """+tbl+"""
select * from (select """+reportYear+""" as health_year,
PA1.RFRNC_NBR AS RFRNC_NBR ,
temp.MBR_KEY AS MBR_KEY,
temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
temp.MBU_CF_CD AS MBU_CF_CD ,
temp.PROD_CF_CD AS PROD_CF_CD,
temp.CMPNY_CF_CD AS CMPNY_CF_CD,
temp.FUNDG_CF_CD AS FUNDG_CF_CD,
temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
temp.HIX_CD AS HIX_CD,
BRD.State AS  State,
CASE WHEN substring (temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')
and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN'
WHEN temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN'
WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK' )AND temp.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
END AS IN_Exchange ,
CASE WHEN substr (temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF'
WHEN temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK' )AND temp.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
END AS OUTOFF_Exchange,
CB.GL_LVL_DESC AS naic_lob,
MED.GL_CF_DESC  as  naic_prod_desc,
temp.PRCP_TYPE_CD as prcp_type_cd ,
PA1.case_type_cd as case_type_cd ,
temp.SRC_GRP_NBR as src_grp_nbr ,
temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
"""+load_log_key+""" as load_log_key,
current_timestamp as load_dt
from """+tb2+"""  PA1
INNER JOIN """+dbwrk+""".clm_inter temp
ON PA1.MBR_KEY = temp.MBR_KEY

inner join (
select CF_CD, GL_LVL_DESC
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
WHERE GL_CF_TYPE_DESC = 'CBE'
AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' )
group by 1,2
) as CB
on CB.CF_CD =temp.MBU_CF_CD
inner join (
select CF_CD,  GL_CF_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'PRODUCT'
group by 1,2
) as MED
on MED.CF_CD = temp.PROD_CF_CD

inner join
(
select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY gl
where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  group by 1,2
) BRD
on BRD.CF_CD= temp.MBU_CF_CD
and BRD.state <> 'LT'

inner join
(
select DISTINCT CF_CD
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where  GL_CF_TYPE_DESC = 'FUND_CODE'
and CF_CD NOT IN ( select  CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'FUND_CODE' AND
( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
)
) FC
ON FC.CF_CD = temp.FUNDG_CF_CD


WHERE PA1."""+tempCol+"""  between temp.mbr_prod_enrlmnt_efctv_dt and temp.mbr_prod_enrlmnt_trmntn_dt
AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
AND (( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN temp.PRCHSR_ORG_EFCTV_DT AND temp.PRCHSR_ORG_TRMNTN_DT) OR temp.PRCHSR_ORG_TRMNTN_DT IS NULL)
AND (temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN temp.MBR_COA_EFCTV_DT AND temp.MBR_COA_TRMNTN_DT)
AND  temp.MBU_CF_CD  IN ('EDCASH','SPGAZZ','EDCOSH','EDINSH')
AND (temp.SRC_GRP_NBR IN ('278777','175089','175147','276470','276500','277956','277960','278547','280438','280531','281249','281285' ,'281297','GA7649','175093','281729','196519','196614','IN2008')
or
temp.ORG_GRP_SRC_GRP_NBR IN  ('278777','175089','175147','276470','276500','277956','277960','278547','280438','280531','281249','281285','281297','GA7649','175093','281729','196519','196614','IN2008')
)
GROUP BY
PA1.RFRNC_NBR  ,
temp.MBR_KEY ,
temp.MBRSHP_SOR_CD ,
temp.GRNDFTHR_IND_CD  ,
temp.HIX_CD ,
temp.GRNDFTHRG_STTS_CD ,
temp.hcr_cmplynt_cd,
temp.EXCHNG_IND_CD ,
temp.EXCHNG_METL_TYPE_CD ,
temp.SRC_EXCHNG_CERTFN_CD ,
temp.MBU_CF_CD  ,
temp.PROD_CF_CD ,
temp.CMPNY_CF_CD ,
temp.FUNDG_CF_CD ,
BRD.State ,
CB.GL_LVL_DESC,
MED.GL_CF_DESC,
temp.PRCP_TYPE_CD,
PA1.case_type_cd,
temp.SRC_GRP_NBR  ,
temp.SRC_SUBGRP_NBR
)
"""

}

