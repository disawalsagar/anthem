package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate

class PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl1_1(val spark: SparkSession) {

  import spark.implicits._
  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy])
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clmex")
  val end_year = dbProperties.getProperty("end_year_clmex")
  
  def sparkInIt(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame, 
      naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, 
      naic2018_mcas_src_eob_cd_inbnd: DataFrame,naic2018_mcas_eob_cd_inbnd: DataFrame,naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame, 
      naic2018_mcas_ce_src_eob_cd_inbnd:DataFrame,naic2018_mcas_ce_eob_cd_inbnd :DataFrame,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd:DataFrame,
      naic2018_mcas_pa_src_eob_cd_inbnd:DataFrame,naic2018_mcas_pa_eob_cd_inbnd:DataFrame,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd:DataFrame,
      naic2018_mcas_ncb_src_eob_cd_inbnd:DataFrame,naic2018_mcas_ncb_eob_cd_inbnd:DataFrame,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd:DataFrame,
      naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame,naic2018_mcas_nmn_eob_cd_inbnd: DataFrame,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
			naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame,
      load_log_key: String) {
  val oexclmphrmcy_2018 = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_2018(spark)
  val oexclmphrmcy = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy(spark)
  
  val objDeniedInntwkce =oexclmphrmcy_2018.getDeniedInntwk_typeOfData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, 
                  naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk,
                  naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                  naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                  naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                  "ce")
                  
  val objDeniedInntwkpa =oexclmphrmcy_2018.getDeniedInntwk_typeOfData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, 
                  naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk,
                  naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                  naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                  naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                  "pa")
  val objDeniedInntwkncb =oexclmphrmcy_2018.getDeniedInntwk_typeOfData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, 
                  naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk,
                  naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                  naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                  naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                  "ncb")                
                  
   val objDeniedInntwknebh =oexclmphrmcy_2018.getdeniedbhebhInntwk("ebh",naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk,naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk,
			             naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk,
			             naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
					         naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
					
   val objDeniedInntwknbh =oexclmphrmcy_2018.getdeniedbhebhInntwk("bh",naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk,naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk,
			             naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk,
			             naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
					         naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
 
    
   val StgData_1 = getStageData(objDeniedInntwkce,objDeniedInntwkpa,objDeniedInntwkncb,objDeniedInntwknebh,objDeniedInntwknbh)
     		        
   val f_stgData = StgData_1.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
   oexclmphrmcy.writeDataToHive(dbwrk + ".naic2018_mcas_hlthoex_clmexphmcy_deniedInntwktemp", f_stgData)
  
  }
  
def getStageData(objDeniedInntwkce:DataFrame,objDeniedInntwkpa: DataFrame, objDeniedInntwkncb: DataFrame, objDeniedInntwknebh: DataFrame,
                 objDeniedInntwknbh: DataFrame): DataFrame = {
  
   val deniedIncepa = objDeniedInntwkce.alias("parent").join(objDeniedInntwkpa.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),$"child.state".alias("s_state"),
                    col("nbrclm_denied_inntwk_ce_bronze_ip"),col("nbrclm_denied_inntwk_ce_silver_ip"),col("nbrclm_denied_inntwk_ce_gold_ip"),col("nbrclm_denied_inntwk_ce_platinum_ip"),col("nbrclm_denied_inntwk_ce_total_ip"),
                    col("nbrclm_denied_inntwk_ce_bronze_sgp"),col("nbrclm_denied_inntwk_ce_silver_sgp"),col("nbrclm_denied_inntwk_ce_gold_sgp"),col("nbrclm_denied_inntwk_ce_platinum_sgp"),col("nbrclm_denied_inntwk_ce_total_sgp"),
                    col("nbrclm_denied_inntwk_ce_gtlgp"),col("nbrclm_denied_inntwk_ce_gtsgp"),col("nbrclm_denied_inntwk_ce_gtip"),col("nbrclm_denied_inntwk_ce_total_gtip"),  
                    col("nbrclm_denied_inntwk_ce_catastrophic"),col("nbrclm_denied_inntwk_ce_lgp_mmcare"),col("nbrclm_denied_inntwk_ce_stucvg"),
                    col("nbrclm_denied_inntwk_pa_bronze_ip"),col("nbrclm_denied_inntwk_pa_silver_ip"),col("nbrclm_denied_inntwk_pa_gold_ip"),col("nbrclm_denied_inntwk_pa_platinum_ip"),col("nbrclm_denied_inntwk_pa_total_ip"),
                    col("nbrclm_denied_inntwk_pa_bronze_sgp"),col("nbrclm_denied_inntwk_pa_silver_sgp"),col("nbrclm_denied_inntwk_pa_gold_sgp"),col("nbrclm_denied_inntwk_pa_platinum_sgp"),col("nbrclm_denied_inntwk_pa_total_sgp"),
                    col("nbrclm_denied_inntwk_pa_gtlgp"),col("nbrclm_denied_inntwk_pa_gtsgp"),col("nbrclm_denied_inntwk_pa_gtip"),col("nbrclm_denied_inntwk_pa_total_gtip"),
                    col("nbrclm_denied_inntwk_pa_catastrophic"),col("nbrclm_denied_inntwk_pa_lgp_mmcare"),col("nbrclm_denied_inntwk_pa_stucvg"))
    
  val deniedIncepaData = deniedIncepa.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                     .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                     .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                     .select("health_year", "cmpny_cf_cd", "state",
                                     ("nbrclm_denied_inntwk_ce_bronze_ip"),("nbrclm_denied_inntwk_ce_silver_ip"),("nbrclm_denied_inntwk_ce_gold_ip"),("nbrclm_denied_inntwk_ce_platinum_ip"),("nbrclm_denied_inntwk_ce_total_ip"),
                                     ("nbrclm_denied_inntwk_ce_bronze_sgp"),("nbrclm_denied_inntwk_ce_silver_sgp"),("nbrclm_denied_inntwk_ce_gold_sgp"),("nbrclm_denied_inntwk_ce_platinum_sgp"),("nbrclm_denied_inntwk_ce_total_sgp"),
                                     ("nbrclm_denied_inntwk_ce_gtlgp"),("nbrclm_denied_inntwk_ce_gtsgp"),("nbrclm_denied_inntwk_ce_gtip"),("nbrclm_denied_inntwk_ce_total_gtip"),
                                     ("nbrclm_denied_inntwk_ce_catastrophic"),("nbrclm_denied_inntwk_ce_lgp_mmcare"),("nbrclm_denied_inntwk_ce_stucvg"),
                                     ("nbrclm_denied_inntwk_pa_bronze_ip"),("nbrclm_denied_inntwk_pa_silver_ip"),("nbrclm_denied_inntwk_pa_gold_ip"),("nbrclm_denied_inntwk_pa_platinum_ip"),("nbrclm_denied_inntwk_pa_total_ip"),
                                     ("nbrclm_denied_inntwk_pa_bronze_sgp"),("nbrclm_denied_inntwk_pa_silver_sgp"),("nbrclm_denied_inntwk_pa_gold_sgp"),("nbrclm_denied_inntwk_pa_platinum_sgp"),("nbrclm_denied_inntwk_pa_total_sgp"),
                                     ("nbrclm_denied_inntwk_pa_gtlgp"),("nbrclm_denied_inntwk_pa_gtsgp"),("nbrclm_denied_inntwk_pa_gtip"),("nbrclm_denied_inntwk_pa_total_gtip"),
                                     ("nbrclm_denied_inntwk_pa_catastrophic"),("nbrclm_denied_inntwk_pa_lgp_mmcare"),("nbrclm_denied_inntwk_pa_stucvg"))
                    
 val deniedIncepancb = deniedIncepaData.alias("parent").join(objDeniedInntwkncb.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),$"child.state".alias("s_state"),  col("nbrclm_denied_inntwk_ce_bronze_ip"),col("nbrclm_denied_inntwk_ce_silver_ip"),col("nbrclm_denied_inntwk_ce_gold_ip"),col("nbrclm_denied_inntwk_ce_platinum_ip"),col("nbrclm_denied_inntwk_ce_total_ip"),
                    col("nbrclm_denied_inntwk_ce_bronze_sgp"),col("nbrclm_denied_inntwk_ce_silver_sgp"),col("nbrclm_denied_inntwk_ce_gold_sgp"),col("nbrclm_denied_inntwk_ce_platinum_sgp"),col("nbrclm_denied_inntwk_ce_total_sgp"),
                    col("nbrclm_denied_inntwk_ce_gtlgp"),col("nbrclm_denied_inntwk_ce_gtsgp"),col("nbrclm_denied_inntwk_ce_gtip"),col("nbrclm_denied_inntwk_ce_total_gtip"),  
                    col("nbrclm_denied_inntwk_ce_catastrophic"),col("nbrclm_denied_inntwk_ce_lgp_mmcare"),col("nbrclm_denied_inntwk_ce_stucvg"),
                    col("nbrclm_denied_inntwk_pa_bronze_ip"),col("nbrclm_denied_inntwk_pa_silver_ip"),col("nbrclm_denied_inntwk_pa_gold_ip"),col("nbrclm_denied_inntwk_pa_platinum_ip"),col("nbrclm_denied_inntwk_pa_total_ip"),
                    col("nbrclm_denied_inntwk_pa_bronze_sgp"),col("nbrclm_denied_inntwk_pa_silver_sgp"),col("nbrclm_denied_inntwk_pa_gold_sgp"),col("nbrclm_denied_inntwk_pa_platinum_sgp"),col("nbrclm_denied_inntwk_pa_total_sgp"),
                    col("nbrclm_denied_inntwk_pa_gtlgp"),col("nbrclm_denied_inntwk_pa_gtsgp"),col("nbrclm_denied_inntwk_pa_gtip"),col("nbrclm_denied_inntwk_pa_total_gtip"),
                    col("nbrclm_denied_inntwk_pa_catastrophic"),col("nbrclm_denied_inntwk_pa_lgp_mmcare"),col("nbrclm_denied_inntwk_pa_stucvg"),                    
                    col("nbrclm_denied_inntwk_ncb_bronze_ip"),col("nbrclm_denied_inntwk_ncb_silver_ip"),col("nbrclm_denied_inntwk_ncb_gold_ip"),col("nbrclm_denied_inntwk_ncb_platinum_ip"),col("nbrclm_denied_inntwk_ncb_total_ip"),
                    col("nbrclm_denied_inntwk_ncb_bronze_sgp"),col("nbrclm_denied_inntwk_ncb_silver_sgp"),col("nbrclm_denied_inntwk_ncb_gold_sgp"),col("nbrclm_denied_inntwk_ncb_platinum_sgp"),col("nbrclm_denied_inntwk_ncb_total_sgp"),
                    col("nbrclm_denied_inntwk_ncb_gtlgp"),col("nbrclm_denied_inntwk_ncb_gtsgp"),col("nbrclm_denied_inntwk_ncb_gtip"),col("nbrclm_denied_inntwk_ncb_total_gtip"),
                    col("nbrclm_denied_inntwk_ncb_catastrophic"),col("nbrclm_denied_inntwk_ncb_lgp_mmcare"),col("nbrclm_denied_inntwk_ncb_stucvg"))

  val deniedIncepancbData = deniedIncepancb.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                           .select("health_year", "cmpny_cf_cd", "state",
                                           ("nbrclm_denied_inntwk_ce_bronze_ip"),("nbrclm_denied_inntwk_ce_silver_ip"),("nbrclm_denied_inntwk_ce_gold_ip"),("nbrclm_denied_inntwk_ce_platinum_ip"),("nbrclm_denied_inntwk_ce_total_ip"),
                                           ("nbrclm_denied_inntwk_ce_bronze_sgp"),("nbrclm_denied_inntwk_ce_silver_sgp"),("nbrclm_denied_inntwk_ce_gold_sgp"),("nbrclm_denied_inntwk_ce_platinum_sgp"),("nbrclm_denied_inntwk_ce_total_sgp"),
                                           ("nbrclm_denied_inntwk_ce_gtlgp"),("nbrclm_denied_inntwk_ce_gtsgp"),("nbrclm_denied_inntwk_ce_gtip"),("nbrclm_denied_inntwk_ce_total_gtip"),
                                           ("nbrclm_denied_inntwk_ce_catastrophic"),("nbrclm_denied_inntwk_ce_lgp_mmcare"),("nbrclm_denied_inntwk_ce_stucvg"),
                                           ("nbrclm_denied_inntwk_pa_bronze_ip"),("nbrclm_denied_inntwk_pa_silver_ip"),("nbrclm_denied_inntwk_pa_gold_ip"),("nbrclm_denied_inntwk_pa_platinum_ip"),("nbrclm_denied_inntwk_pa_total_ip"),
                                           ("nbrclm_denied_inntwk_pa_bronze_sgp"),("nbrclm_denied_inntwk_pa_silver_sgp"),("nbrclm_denied_inntwk_pa_gold_sgp"),("nbrclm_denied_inntwk_pa_platinum_sgp"),("nbrclm_denied_inntwk_pa_total_sgp"),
                                           ("nbrclm_denied_inntwk_pa_gtlgp"),("nbrclm_denied_inntwk_pa_gtsgp"),("nbrclm_denied_inntwk_pa_gtip"),("nbrclm_denied_inntwk_pa_total_gtip"),
                                           ("nbrclm_denied_inntwk_pa_catastrophic"),("nbrclm_denied_inntwk_pa_lgp_mmcare"),("nbrclm_denied_inntwk_pa_stucvg"),
                                           ("nbrclm_denied_inntwk_ncb_bronze_ip"),("nbrclm_denied_inntwk_ncb_silver_ip"),("nbrclm_denied_inntwk_ncb_gold_ip"),("nbrclm_denied_inntwk_ncb_platinum_ip"),("nbrclm_denied_inntwk_ncb_total_ip"),
                                           ("nbrclm_denied_inntwk_ncb_bronze_sgp"),("nbrclm_denied_inntwk_ncb_silver_sgp"),("nbrclm_denied_inntwk_ncb_gold_sgp"),("nbrclm_denied_inntwk_ncb_platinum_sgp"),("nbrclm_denied_inntwk_ncb_total_sgp"),
                                           ("nbrclm_denied_inntwk_ncb_gtlgp"),("nbrclm_denied_inntwk_ncb_gtsgp"),("nbrclm_denied_inntwk_ncb_gtip"),("nbrclm_denied_inntwk_ncb_total_gtip"),
                                           ("nbrclm_denied_inntwk_ncb_catastrophic"),("nbrclm_denied_inntwk_ncb_lgp_mmcare"),("nbrclm_denied_inntwk_ncb_stucvg"))

 val deniedIncepancbebh = deniedIncepancbData.alias("parent").join(objDeniedInntwknebh.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),$"child.state".alias("s_state"),  col("nbrclm_denied_inntwk_ce_bronze_ip"),col("nbrclm_denied_inntwk_ce_silver_ip"),col("nbrclm_denied_inntwk_ce_gold_ip"),col("nbrclm_denied_inntwk_ce_platinum_ip"),col("nbrclm_denied_inntwk_ce_total_ip"),
                    col("nbrclm_denied_inntwk_ce_bronze_sgp"),col("nbrclm_denied_inntwk_ce_silver_sgp"),col("nbrclm_denied_inntwk_ce_gold_sgp"),col("nbrclm_denied_inntwk_ce_platinum_sgp"),col("nbrclm_denied_inntwk_ce_total_sgp"),
                    col("nbrclm_denied_inntwk_ce_gtlgp"),col("nbrclm_denied_inntwk_ce_gtsgp"),col("nbrclm_denied_inntwk_ce_gtip"),col("nbrclm_denied_inntwk_ce_total_gtip"),  
                    col("nbrclm_denied_inntwk_ce_catastrophic"),col("nbrclm_denied_inntwk_ce_lgp_mmcare"),col("nbrclm_denied_inntwk_ce_stucvg"),
                    col("nbrclm_denied_inntwk_pa_bronze_ip"),col("nbrclm_denied_inntwk_pa_silver_ip"),col("nbrclm_denied_inntwk_pa_gold_ip"),col("nbrclm_denied_inntwk_pa_platinum_ip"),col("nbrclm_denied_inntwk_pa_total_ip"),
                    col("nbrclm_denied_inntwk_pa_bronze_sgp"),col("nbrclm_denied_inntwk_pa_silver_sgp"),col("nbrclm_denied_inntwk_pa_gold_sgp"),col("nbrclm_denied_inntwk_pa_platinum_sgp"),col("nbrclm_denied_inntwk_pa_total_sgp"),
                    col("nbrclm_denied_inntwk_pa_gtlgp"),col("nbrclm_denied_inntwk_pa_gtsgp"),col("nbrclm_denied_inntwk_pa_gtip"),col("nbrclm_denied_inntwk_pa_total_gtip"),
                    col("nbrclm_denied_inntwk_pa_catastrophic"),col("nbrclm_denied_inntwk_pa_lgp_mmcare"),col("nbrclm_denied_inntwk_pa_stucvg"),                    
                    col("nbrclm_denied_inntwk_ncb_bronze_ip"),col("nbrclm_denied_inntwk_ncb_silver_ip"),col("nbrclm_denied_inntwk_ncb_gold_ip"),col("nbrclm_denied_inntwk_ncb_platinum_ip"),col("nbrclm_denied_inntwk_ncb_total_ip"),
                    col("nbrclm_denied_inntwk_ncb_bronze_sgp"),col("nbrclm_denied_inntwk_ncb_silver_sgp"),col("nbrclm_denied_inntwk_ncb_gold_sgp"),col("nbrclm_denied_inntwk_ncb_platinum_sgp"),col("nbrclm_denied_inntwk_ncb_total_sgp"),
                    col("nbrclm_denied_inntwk_ncb_gtlgp"),col("nbrclm_denied_inntwk_ncb_gtsgp"),col("nbrclm_denied_inntwk_ncb_gtip"),col("nbrclm_denied_inntwk_ncb_total_gtip"),
                    col("nbrclm_denied_inntwk_ncb_catastrophic"),col("nbrclm_denied_inntwk_ncb_lgp_mmcare"),col("nbrclm_denied_inntwk_ncb_stucvg"),
                    col("nbrclm_denied_inntwk_ebh_bronze_ip"),col("nbrclm_denied_inntwk_ebh_silver_ip"),col("nbrclm_denied_inntwk_ebh_gold_ip"),col("nbrclm_denied_inntwk_ebh_platinum_ip"),col("nbrclm_denied_inntwk_ebh_total_ip"),
                    col("nbrclm_denied_inntwk_ebh_bronze_sgp"),col("nbrclm_denied_inntwk_ebh_silver_sgp"),col("nbrclm_denied_inntwk_ebh_gold_sgp"),col("nbrclm_denied_inntwk_ebh_platinum_sgp"),col("nbrclm_denied_inntwk_ebh_total_sgp"),
                    col("nbrclm_denied_inntwk_ebh_gtlgp"),col("nbrclm_denied_inntwk_ebh_gtsgp"),col("nbrclm_denied_inntwk_ebh_gtip"),col("nbrclm_denied_inntwk_ebh_total_gtip"),
                    col("nbrclm_denied_inntwk_ebh_catastrophic"),col("nbrclm_denied_inntwk_ebh_lgp_mmcare"),col("nbrclm_denied_inntwk_ebh_stucvg"))                    

  val deniedIncepancbebhData = deniedIncepancbebh.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                           .select("health_year", "cmpny_cf_cd", "state",
                                           ("nbrclm_denied_inntwk_ce_bronze_ip"),("nbrclm_denied_inntwk_ce_silver_ip"),("nbrclm_denied_inntwk_ce_gold_ip"),("nbrclm_denied_inntwk_ce_platinum_ip"),("nbrclm_denied_inntwk_ce_total_ip"),
                                           ("nbrclm_denied_inntwk_ce_bronze_sgp"),("nbrclm_denied_inntwk_ce_silver_sgp"),("nbrclm_denied_inntwk_ce_gold_sgp"),("nbrclm_denied_inntwk_ce_platinum_sgp"),("nbrclm_denied_inntwk_ce_total_sgp"),
                                           ("nbrclm_denied_inntwk_ce_gtlgp"),("nbrclm_denied_inntwk_ce_gtsgp"),("nbrclm_denied_inntwk_ce_gtip"),("nbrclm_denied_inntwk_ce_total_gtip"),
                                           ("nbrclm_denied_inntwk_ce_catastrophic"),("nbrclm_denied_inntwk_ce_lgp_mmcare"),("nbrclm_denied_inntwk_ce_stucvg"),
                                           ("nbrclm_denied_inntwk_pa_bronze_ip"),("nbrclm_denied_inntwk_pa_silver_ip"),("nbrclm_denied_inntwk_pa_gold_ip"),("nbrclm_denied_inntwk_pa_platinum_ip"),("nbrclm_denied_inntwk_pa_total_ip"),
                                           ("nbrclm_denied_inntwk_pa_bronze_sgp"),("nbrclm_denied_inntwk_pa_silver_sgp"),("nbrclm_denied_inntwk_pa_gold_sgp"),("nbrclm_denied_inntwk_pa_platinum_sgp"),("nbrclm_denied_inntwk_pa_total_sgp"),
                                           ("nbrclm_denied_inntwk_pa_gtlgp"),("nbrclm_denied_inntwk_pa_gtsgp"),("nbrclm_denied_inntwk_pa_gtip"),("nbrclm_denied_inntwk_pa_total_gtip"),
                                           ("nbrclm_denied_inntwk_pa_catastrophic"),("nbrclm_denied_inntwk_pa_lgp_mmcare"),("nbrclm_denied_inntwk_pa_stucvg"),
                                           ("nbrclm_denied_inntwk_ncb_bronze_ip"),("nbrclm_denied_inntwk_ncb_silver_ip"),("nbrclm_denied_inntwk_ncb_gold_ip"),("nbrclm_denied_inntwk_ncb_platinum_ip"),("nbrclm_denied_inntwk_ncb_total_ip"),
                                           ("nbrclm_denied_inntwk_ncb_bronze_sgp"),("nbrclm_denied_inntwk_ncb_silver_sgp"),("nbrclm_denied_inntwk_ncb_gold_sgp"),("nbrclm_denied_inntwk_ncb_platinum_sgp"),("nbrclm_denied_inntwk_ncb_total_sgp"),
                                           ("nbrclm_denied_inntwk_ncb_gtlgp"),("nbrclm_denied_inntwk_ncb_gtsgp"),("nbrclm_denied_inntwk_ncb_gtip"),("nbrclm_denied_inntwk_ncb_total_gtip"),
                                           ("nbrclm_denied_inntwk_ncb_catastrophic"),("nbrclm_denied_inntwk_ncb_lgp_mmcare"),("nbrclm_denied_inntwk_ncb_stucvg"),                    
                                           ("nbrclm_denied_inntwk_ebh_bronze_ip"),("nbrclm_denied_inntwk_ebh_silver_ip"),("nbrclm_denied_inntwk_ebh_gold_ip"),("nbrclm_denied_inntwk_ebh_platinum_ip"),("nbrclm_denied_inntwk_ebh_total_ip"),
                                           ("nbrclm_denied_inntwk_ebh_bronze_sgp"),("nbrclm_denied_inntwk_ebh_silver_sgp"),("nbrclm_denied_inntwk_ebh_gold_sgp"),("nbrclm_denied_inntwk_ebh_platinum_sgp"),("nbrclm_denied_inntwk_ebh_total_sgp"),
                                           ("nbrclm_denied_inntwk_ebh_gtlgp"),("nbrclm_denied_inntwk_ebh_gtsgp"),("nbrclm_denied_inntwk_ebh_gtip"),("nbrclm_denied_inntwk_ebh_total_gtip"),
                                           ("nbrclm_denied_inntwk_ebh_catastrophic"),("nbrclm_denied_inntwk_ebh_lgp_mmcare"),("nbrclm_denied_inntwk_ebh_stucvg"))

 val deniedIncepancbebh_bh = deniedIncepancbebhData.alias("parent").join(objDeniedInntwknbh.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),$"child.state".alias("s_state"),  col("nbrclm_denied_inntwk_ce_bronze_ip"),col("nbrclm_denied_inntwk_ce_silver_ip"),col("nbrclm_denied_inntwk_ce_gold_ip"),col("nbrclm_denied_inntwk_ce_platinum_ip"),col("nbrclm_denied_inntwk_ce_total_ip"),
                    col("nbrclm_denied_inntwk_ce_bronze_sgp"),col("nbrclm_denied_inntwk_ce_silver_sgp"),col("nbrclm_denied_inntwk_ce_gold_sgp"),col("nbrclm_denied_inntwk_ce_platinum_sgp"),col("nbrclm_denied_inntwk_ce_total_sgp"),
                    col("nbrclm_denied_inntwk_ce_gtlgp"),col("nbrclm_denied_inntwk_ce_gtsgp"),col("nbrclm_denied_inntwk_ce_gtip"),col("nbrclm_denied_inntwk_ce_total_gtip"),  
                    col("nbrclm_denied_inntwk_ce_catastrophic"),col("nbrclm_denied_inntwk_ce_lgp_mmcare"),col("nbrclm_denied_inntwk_ce_stucvg"),
                    col("nbrclm_denied_inntwk_pa_bronze_ip"),col("nbrclm_denied_inntwk_pa_silver_ip"),col("nbrclm_denied_inntwk_pa_gold_ip"),col("nbrclm_denied_inntwk_pa_platinum_ip"),col("nbrclm_denied_inntwk_pa_total_ip"),
                    col("nbrclm_denied_inntwk_pa_bronze_sgp"),col("nbrclm_denied_inntwk_pa_silver_sgp"),col("nbrclm_denied_inntwk_pa_gold_sgp"),col("nbrclm_denied_inntwk_pa_platinum_sgp"),col("nbrclm_denied_inntwk_pa_total_sgp"),
                    col("nbrclm_denied_inntwk_pa_gtlgp"),col("nbrclm_denied_inntwk_pa_gtsgp"),col("nbrclm_denied_inntwk_pa_gtip"),col("nbrclm_denied_inntwk_pa_total_gtip"),
                    col("nbrclm_denied_inntwk_pa_catastrophic"),col("nbrclm_denied_inntwk_pa_lgp_mmcare"),col("nbrclm_denied_inntwk_pa_stucvg"),                    
                    col("nbrclm_denied_inntwk_ncb_bronze_ip"),col("nbrclm_denied_inntwk_ncb_silver_ip"),col("nbrclm_denied_inntwk_ncb_gold_ip"),col("nbrclm_denied_inntwk_ncb_platinum_ip"),col("nbrclm_denied_inntwk_ncb_total_ip"),
                    col("nbrclm_denied_inntwk_ncb_bronze_sgp"),col("nbrclm_denied_inntwk_ncb_silver_sgp"),col("nbrclm_denied_inntwk_ncb_gold_sgp"),col("nbrclm_denied_inntwk_ncb_platinum_sgp"),col("nbrclm_denied_inntwk_ncb_total_sgp"),
                    col("nbrclm_denied_inntwk_ncb_gtlgp"),col("nbrclm_denied_inntwk_ncb_gtsgp"),col("nbrclm_denied_inntwk_ncb_gtip"),col("nbrclm_denied_inntwk_ncb_total_gtip"),
                    col("nbrclm_denied_inntwk_ncb_catastrophic"),col("nbrclm_denied_inntwk_ncb_lgp_mmcare"),col("nbrclm_denied_inntwk_ncb_stucvg"),
                    col("nbrclm_denied_inntwk_ebh_bronze_ip"),col("nbrclm_denied_inntwk_ebh_silver_ip"),col("nbrclm_denied_inntwk_ebh_gold_ip"),col("nbrclm_denied_inntwk_ebh_platinum_ip"),col("nbrclm_denied_inntwk_ebh_total_ip"),
                    col("nbrclm_denied_inntwk_ebh_bronze_sgp"),col("nbrclm_denied_inntwk_ebh_silver_sgp"),col("nbrclm_denied_inntwk_ebh_gold_sgp"),col("nbrclm_denied_inntwk_ebh_platinum_sgp"),col("nbrclm_denied_inntwk_ebh_total_sgp"),
                    col("nbrclm_denied_inntwk_ebh_gtlgp"),col("nbrclm_denied_inntwk_ebh_gtsgp"),col("nbrclm_denied_inntwk_ebh_gtip"),col("nbrclm_denied_inntwk_ebh_total_gtip"),
                    col("nbrclm_denied_inntwk_ebh_catastrophic"),col("nbrclm_denied_inntwk_ebh_lgp_mmcare"),col("nbrclm_denied_inntwk_ebh_stucvg"),
                    col("nbrclm_denied_inntwk_bh_bronze_ip"),col("nbrclm_denied_inntwk_bh_silver_ip"),col("nbrclm_denied_inntwk_bh_gold_ip"),col("nbrclm_denied_inntwk_bh_platinum_ip"),col("nbrclm_denied_inntwk_bh_total_ip"),
                    col("nbrclm_denied_inntwk_bh_bronze_sgp"),col("nbrclm_denied_inntwk_bh_silver_sgp"),col("nbrclm_denied_inntwk_bh_gold_sgp"),col("nbrclm_denied_inntwk_bh_platinum_sgp"),col("nbrclm_denied_inntwk_bh_total_sgp"),
                    col("nbrclm_denied_inntwk_bh_gtlgp"),col("nbrclm_denied_inntwk_bh_gtsgp"),col("nbrclm_denied_inntwk_bh_gtip"),col("nbrclm_denied_inntwk_bh_total_gtip"),
                    col("nbrclm_denied_inntwk_bh_catastrophic"),col("nbrclm_denied_inntwk_bh_lgp_mmcare"),col("nbrclm_denied_inntwk_bh_stucvg"))                    
  
  val deniedIncepancbebh_bhData = deniedIncepancbebh_bh.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                           .withColumn("market_exchange", lit("OUTOFF"))
                                           .select("market_exchange","health_year", "cmpny_cf_cd", "state",
                                           ("nbrclm_denied_inntwk_ce_bronze_ip"),("nbrclm_denied_inntwk_ce_silver_ip"),("nbrclm_denied_inntwk_ce_gold_ip"),("nbrclm_denied_inntwk_ce_platinum_ip"),("nbrclm_denied_inntwk_ce_total_ip"),
                                           ("nbrclm_denied_inntwk_ce_bronze_sgp"),("nbrclm_denied_inntwk_ce_silver_sgp"),("nbrclm_denied_inntwk_ce_gold_sgp"),("nbrclm_denied_inntwk_ce_platinum_sgp"),("nbrclm_denied_inntwk_ce_total_sgp"),
                                           ("nbrclm_denied_inntwk_ce_gtlgp"),("nbrclm_denied_inntwk_ce_gtsgp"),("nbrclm_denied_inntwk_ce_gtip"),("nbrclm_denied_inntwk_ce_total_gtip"),
                                           ("nbrclm_denied_inntwk_ce_catastrophic"),("nbrclm_denied_inntwk_ce_lgp_mmcare"),("nbrclm_denied_inntwk_ce_stucvg"),
                                           ("nbrclm_denied_inntwk_pa_bronze_ip"),("nbrclm_denied_inntwk_pa_silver_ip"),("nbrclm_denied_inntwk_pa_gold_ip"),("nbrclm_denied_inntwk_pa_platinum_ip"),("nbrclm_denied_inntwk_pa_total_ip"),
                                           ("nbrclm_denied_inntwk_pa_bronze_sgp"),("nbrclm_denied_inntwk_pa_silver_sgp"),("nbrclm_denied_inntwk_pa_gold_sgp"),("nbrclm_denied_inntwk_pa_platinum_sgp"),("nbrclm_denied_inntwk_pa_total_sgp"),
                                           ("nbrclm_denied_inntwk_pa_gtlgp"),("nbrclm_denied_inntwk_pa_gtsgp"),("nbrclm_denied_inntwk_pa_gtip"),("nbrclm_denied_inntwk_pa_total_gtip"),
                                           ("nbrclm_denied_inntwk_pa_catastrophic"),("nbrclm_denied_inntwk_pa_lgp_mmcare"),("nbrclm_denied_inntwk_pa_stucvg"),
                                           ("nbrclm_denied_inntwk_ncb_bronze_ip"),("nbrclm_denied_inntwk_ncb_silver_ip"),("nbrclm_denied_inntwk_ncb_gold_ip"),("nbrclm_denied_inntwk_ncb_platinum_ip"),("nbrclm_denied_inntwk_ncb_total_ip"),
                                           ("nbrclm_denied_inntwk_ncb_bronze_sgp"),("nbrclm_denied_inntwk_ncb_silver_sgp"),("nbrclm_denied_inntwk_ncb_gold_sgp"),("nbrclm_denied_inntwk_ncb_platinum_sgp"),("nbrclm_denied_inntwk_ncb_total_sgp"),
                                           ("nbrclm_denied_inntwk_ncb_gtlgp"),("nbrclm_denied_inntwk_ncb_gtsgp"),("nbrclm_denied_inntwk_ncb_gtip"),("nbrclm_denied_inntwk_ncb_total_gtip"),
                                           ("nbrclm_denied_inntwk_ncb_catastrophic"),("nbrclm_denied_inntwk_ncb_lgp_mmcare"),("nbrclm_denied_inntwk_ncb_stucvg"),                    
                                           ("nbrclm_denied_inntwk_ebh_bronze_ip"),("nbrclm_denied_inntwk_ebh_silver_ip"),("nbrclm_denied_inntwk_ebh_gold_ip"),("nbrclm_denied_inntwk_ebh_platinum_ip"),("nbrclm_denied_inntwk_ebh_total_ip"),
                                           ("nbrclm_denied_inntwk_ebh_bronze_sgp"),("nbrclm_denied_inntwk_ebh_silver_sgp"),("nbrclm_denied_inntwk_ebh_gold_sgp"),("nbrclm_denied_inntwk_ebh_platinum_sgp"),("nbrclm_denied_inntwk_ebh_total_sgp"),
                                           ("nbrclm_denied_inntwk_ebh_gtlgp"),("nbrclm_denied_inntwk_ebh_gtsgp"),("nbrclm_denied_inntwk_ebh_gtip"),("nbrclm_denied_inntwk_ebh_total_gtip"),
                                           ("nbrclm_denied_inntwk_ebh_catastrophic"),("nbrclm_denied_inntwk_ebh_lgp_mmcare"),("nbrclm_denied_inntwk_ebh_stucvg"),
                                           ("nbrclm_denied_inntwk_bh_bronze_ip"),("nbrclm_denied_inntwk_bh_silver_ip"),("nbrclm_denied_inntwk_bh_gold_ip"),("nbrclm_denied_inntwk_bh_platinum_ip"),("nbrclm_denied_inntwk_bh_total_ip"),
                                           ("nbrclm_denied_inntwk_bh_bronze_sgp"),("nbrclm_denied_inntwk_bh_silver_sgp"),("nbrclm_denied_inntwk_bh_gold_sgp"),("nbrclm_denied_inntwk_bh_platinum_sgp"),("nbrclm_denied_inntwk_bh_total_sgp"),
                                           ("nbrclm_denied_inntwk_bh_gtlgp"),("nbrclm_denied_inntwk_bh_gtsgp"),("nbrclm_denied_inntwk_bh_gtip"),("nbrclm_denied_inntwk_bh_total_gtip"),
                                           ("nbrclm_denied_inntwk_bh_catastrophic"),("nbrclm_denied_inntwk_bh_lgp_mmcare"),("nbrclm_denied_inntwk_bh_stucvg"))

  deniedIncepancbebh_bhData                                           
}  
}


object PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl1_1 {

  def main(args: Array[String]) {

    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
   /* new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl1_1().sparkInIt()*/
  }
}