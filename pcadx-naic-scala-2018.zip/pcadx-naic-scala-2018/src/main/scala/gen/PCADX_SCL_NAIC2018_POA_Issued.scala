package gen

import java.util.Properties
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.sql.Timestamp
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.hadoop.fs._;
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source

class PCADX_SCL_NAIC2018_POA_Issued() {

  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()

  import spark.implicits._

  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_DataExtraction])

  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))

  val dbWrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val reportYear = dbProperties.getProperty("report.year")
  val mbrEffBetFrmDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_BET_FROM")
  val mbrEffBetToDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_BET_TO")
  val mbrEffNotBetFrmDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_NOT_BET_FROM")
  val mbrEffNotBetToDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_NOT_BET_TO")
  val mbrTrmntBetFrmDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_TRMNTN_DT_BET_FROM")
  val mbrTrmntBetToDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_TRMNTN_DT_BET_TO")
  val mbrTrmntGrtr = dbProperties.getProperty("MBR_PROD_ENRLMNT_TRMNTN_DT_GREATER")
  val wrhDb = dbProperties.getProperty("warehouse.db")

  val audit_log_df = spark.sql("select * from " + wrhDb + ".audt_load_log")
  val load_log_key = audit_log_df.filter($"subj_area_nm" === "NAIC2018_MCAS" && $"prcs_nm" === "NAIC2018_MCAS_RPT" && $"load_stts_cd" === "S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString()
  println("load_log_key : " + load_log_key)

  def issuedTrnctTbl() = """Truncate table """ + dbWrk + """.naic2018_mcas_hlthex_poa_issued_wrk"""
  
  

  def issuedNonCat() = """insert into table """ + dbWrk + """.naic2018_mcas_hlthex_poa_issued_wrk 
			select
			""" + reportYear + """  as health_year,
			temp.SBSCRBR_ID AS SBSCRBR_ID  ,
			temp.MBR_KEY AS MBR_KEY,
			temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
			temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
			temp.MBU_CF_CD AS MBU_CF_CD ,
			temp.PROD_CF_CD AS PROD_CF_CD,
			temp.CMPNY_CF_CD AS CMPNY_CF_CD,
			temp.FUNDG_CF_CD AS FUNDG_CF_CD,
			temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
			temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD AS HIX_CD,
			BRD.State AS  State,
			CASE WHEN substr ( temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')
			and  temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN'
			WHEN  temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN'
			WHEN SUBSTR( temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND (  temp.EXCHNG_IND_CD IS NULL OR  temp.EXCHNG_IND_CD ='UNK' )AND HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
			END AS IN_Exchange ,
			CASE WHEN substr ( temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and  temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF'
			WHEN  temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
			WHEN SUBSTR( temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND (  temp.EXCHNG_IND_CD IS NULL OR  temp.EXCHNG_IND_CD ='UNK' )AND HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
			END AS OUTOFF_Exchange,
			CB.GL_LVL_DESC AS naic_lob,
			MED.GL_CF_DESC  as  naic_prod_desc ,
			temp.SRC_GRP_NBR as src_grp_nbr,
			temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
			""" + load_log_key + """ as load_log_key,
			current_timestamp as load_dt
 
			FROM """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp
			inner join (
			select CF_CD, GL_LVL_DESC
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('TOTAL INDIVIDUAL CBE')
			group by CF_CD, GL_LVL_DESC
			) as CB
			on CB.CF_CD =  temp.MBU_CF_CD
			inner join (
			select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT'
			AND GL_CF_DESC NOT LIKE '%CATASTROPHIC%'
			group by CF_CD,  GL_CF_DESC
			) as MED
			on MED.CF_CD =  temp.PROD_CF_CD
			inner join
			(
			select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
			(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))
			group by gl.CF_CD,gl.GL_LVL_DESC
			) BRD
			on BRD.CF_CD=  temp.MBU_CF_CD
			and BRD.state <> 'LT'
			inner join
			(
			select DISTINCT gl.CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and gl.CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			WHERE  GL_CF_TYPE_DESC = 'FUND_CODE' AND
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC
			ON FC.CF_CD =  temp.FUNDG_CF_CD
      
      inner join """+dbWrk+""".sbscrbridCheckin2018 sub
			on temp.SBSCRBR_ID = sub.SBSCRBR_ID

      left outer join """+dbWrk+""".sbscrbridCheck  subid
			on temp.SBSCRBR_ID = subid.SBSCRBR_ID
			
      -- Added on 4/25
			left outer join """+dbWrk+""".sbscrbridcheck_Notin2018 subNotin
			on temp.SBSCRBR_ID = subNotin.SBSCRBR_ID
			
      WHERE
      subid.SBSCRBR_ID is null AND subNotin.SBSCRBR_ID is null
      AND temp.MBR_PROD_ENRLMNT_EFCTV_DT BETWEEN  """ + mbrEffBetFrmDt + """  AND  """ + mbrEffBetToDt + """ 
			AND  temp.MBR_PROD_ENRLMNT_EFCTV_DT NOT BETWEEN  """ + mbrEffNotBetFrmDt + """  AND  """ + mbrEffNotBetToDt + """
			AND ( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN  """ + mbrTrmntBetFrmDt + """  AND  """ + mbrTrmntBetToDt + """
			OR  temp.MBR_PROD_ENRLMNT_TRMNTN_DT >=  """ + mbrTrmntGrtr + """    )

			AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
			
			GROUP BY
			temp.SBSCRBR_ID  ,
			temp.MBR_KEY ,
			temp.MBRSHP_SOR_CD ,
			temp.GRNDFTHR_IND_CD ,
			temp.HIX_CD ,
			temp.GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd,
			temp.EXCHNG_IND_CD ,
			temp.EXCHNG_METL_TYPE_CD ,
			temp.SRC_EXCHNG_CERTFN_CD ,
			temp.MBU_CF_CD  ,
			temp.PROD_CF_CD ,
			temp.CMPNY_CF_CD ,
			temp.FUNDG_CF_CD ,
			BRD.State ,
			CB.GL_LVL_DESC,
			MED.GL_CF_DESC,
			temp.SRC_GRP_NBR,
			temp.SRC_SUBGRP_NBR
			--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'
			"""

  def issuedLG() = """ insert into table """ + dbWrk + """.naic2018_mcas_hlthex_poa_issued_wrk
			select 
			z.health_year,
			z.SBSCRBR_ID  ,
			z.MBR_KEY ,
			z.MBRSHP_SOR_CD,  
			z.GRNDFTHR_IND_CD  ,
			z.MBU_CF_CD  ,
			z.PROD_CF_CD ,
			z.CMPNY_CF_CD ,
			z.FUNDG_CF_CD ,
			z.EXCHNG_IND_CD,
			z.EXCHNG_METL_TYPE_CD ,
			z.GRNDFTHRG_STTS_CD  ,
			z.hcr_cmplynt_cd  ,
			z.SRC_EXCHNG_CERTFN_CD,
			z.HIX_CD ,
			z.State,
			z.IN_Exchange,
			z.OUTOFF_Exchange,
			z.naic_lob,
			z.naic_prod_desc,
			z.src_grp_nbr,
			z.src_subgrp_nbr,
			z.load_log_key,
			z.load_dt 
			from (
			select x.*
			from(select 
			""" + reportYear + """  as health_year,
			temp.SBSCRBR_ID AS SBSCRBR_ID  ,
			temp.MBR_KEY AS MBR_KEY,
			temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,  
			temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
			temp.MBU_CF_CD AS MBU_CF_CD ,
			temp.PROD_CF_CD AS PROD_CF_CD,
			temp.CMPNY_CF_CD AS CMPNY_CF_CD,
			temp.FUNDG_CF_CD AS FUNDG_CF_CD,
			temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
			temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD AS HIX_CD,
			BRD.State AS  State,
			CASE WHEN substr ( temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    
			and  temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
			WHEN  temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN' 
			WHEN SUBSTR( temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND (  temp.EXCHNG_IND_CD IS NULL OR  temp.EXCHNG_IND_CD ='UNK' )AND HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
			END AS IN_Exchange ,
			CASE WHEN substr ( temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and  temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
			WHEN  temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
			WHEN SUBSTR( temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND (  temp.EXCHNG_IND_CD IS NULL OR  temp.EXCHNG_IND_CD ='UNK' )AND HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
			END AS OUTOFF_Exchange, 
			CB.GL_LVL_DESC AS naic_lob,
			MED.GL_CF_DESC  as  naic_prod_desc ,
			temp.SRC_GRP_NBR as src_grp_nbr, 
			temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
			""" + load_log_key + """  as load_log_key,
			current_timestamp as load_dt
			FROM """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' ) 
			group by 1,2
			) as CB
			on CB.CF_CD =  temp.MBU_CF_CD
			inner join (
			select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			group by 1,2
			) as MED
			on MED.CF_CD =  temp.PROD_CF_CD
			inner join
			(
			select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl 
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
			(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  
			group by 1,2
			) BRD
			on BRD.CF_CD=  temp.MBU_CF_CD 
			and BRD.state <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE  GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC
			ON FC.CF_CD =  temp.FUNDG_CF_CD
			WHERE

			temp.MBR_PROD_ENRLMNT_EFCTV_DT BETWEEN  """ + mbrEffBetFrmDt + """  AND  """ + mbrEffBetToDt + """ 
			AND  temp.MBR_PROD_ENRLMNT_EFCTV_DT NOT BETWEEN  """ + mbrEffNotBetFrmDt + """  AND  """ + mbrEffNotBetToDt + """ 
			AND ( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN  """ + mbrTrmntBetFrmDt + """  AND  """ + mbrTrmntBetToDt + """  
			OR  temp.MBR_PROD_ENRLMNT_TRMNTN_DT >=  """ + mbrTrmntGrtr + """  )

			AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
			AND  temp.MBU_CF_CD NOT IN ( 'EDCASH' , 'SPGAZZ' ,'EDCOSH' , 'EDINSH' )

			GROUP BY 
			temp.SBSCRBR_ID  ,
			temp.MBR_KEY ,
			temp.MBRSHP_SOR_CD ,
			temp.GRNDFTHR_IND_CD ,
			temp.HIX_CD ,
			temp.GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd,
			temp.EXCHNG_IND_CD ,
			temp.EXCHNG_METL_TYPE_CD ,
			temp.SRC_EXCHNG_CERTFN_CD ,
			temp.MBU_CF_CD  ,
			temp.PROD_CF_CD ,
			temp.CMPNY_CF_CD ,
			temp.FUNDG_CF_CD ,
			BRD.State ,
			CB.GL_LVL_DESC,
			MED.GL_CF_DESC,
			temp.SRC_GRP_NBR,
			temp.SRC_SUBGRP_NBR
			) x  
			left outer join  sbscrbridtemp y
			on x.SBSCRBR_ID = y.SBSCRBR_ID
			where y.SBSCRBR_ID is null
			) z

			left outer join  sbscrbridtemp_2018 sub
			on z.SBSCRBR_ID = sub.SBSCRBR_ID
			where sub.SBSCRBR_ID is not null

			--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'
			"""

  def issuedCat() = """insert into table """ + dbWrk + """.naic2018_mcas_hlthex_poa_issued_wrk
		 select 
			""" + reportYear + """  as health_year,
			temp.SBSCRBR_ID AS SBSCRBR_ID  ,
			temp.MBR_KEY AS MBR_KEY,
			temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,  
			temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
			temp.MBU_CF_CD AS MBU_CF_CD ,
			temp.PROD_CF_CD AS PROD_CF_CD,
			temp.CMPNY_CF_CD AS CMPNY_CF_CD,
			temp.FUNDG_CF_CD AS FUNDG_CF_CD,
			temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
			temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD AS HIX_CD,
			BRD.State AS  State,
			CASE WHEN substr ( temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    
			and  temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
			WHEN  temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN' 
			WHEN SUBSTR( temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND (  temp.EXCHNG_IND_CD IS NULL OR  temp.EXCHNG_IND_CD ='UNK' )AND HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
			END AS IN_Exchange ,
			CASE WHEN substr ( temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and  temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
			WHEN  temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
			WHEN SUBSTR( temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND (  temp.EXCHNG_IND_CD IS NULL OR  temp.EXCHNG_IND_CD ='UNK' )AND HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
			END AS OUTOFF_Exchange, 
			MED.GL_LVL_DESC AS naic_lob,
			MED.GL_CF_DESC  as  naic_prod_desc ,
			temp.SRC_GRP_NBR as src_grp_nbr, 
			temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
			""" + load_log_key + """  as load_log_key,
			current_timestamp as load_dt
			FROM """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp
			inner join (
			select CF_CD,  GL_CF_DESC,GL_LVL_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			AND GL_CF_DESC  LIKE '%CATASTROPHIC%'
			group by 1,2,3
			) as MED
			on MED.CF_CD =  temp.PROD_CF_CD
			inner join
			(
			select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl 
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
			(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  
			group by 1,2
			) BRD
			on BRD.CF_CD=  temp.MBU_CF_CD 
			and BRD.state <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE  GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC
			ON FC.CF_CD =  temp.FUNDG_CF_CD
      
      inner join """+dbWrk+""".sbscrbridCheckin2018 sub
			on temp.SBSCRBR_ID = sub.SBSCRBR_ID
      
      left outer join """+dbWrk+""".sbscrbridCheck  subid
			on temp.SBSCRBR_ID = subid.SBSCRBR_ID
			
      -- Added on 4/25
      left outer join """+dbWrk+""".sbscrbridcheck_Notin2018 subNotin
      on temp.SBSCRBR_ID = subNotin.SBSCRBR_ID
      
			WHERE
      subid.SBSCRBR_ID is null AND subNotin.SBSCRBR_ID is null
      AND temp.MBR_PROD_ENRLMNT_EFCTV_DT BETWEEN  """ + mbrEffBetFrmDt + """  AND  """ + mbrEffBetToDt + """ 
			AND  temp.MBR_PROD_ENRLMNT_EFCTV_DT NOT BETWEEN  """ + mbrEffNotBetFrmDt + """  AND  """ + mbrEffNotBetToDt + """ 
			AND ( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN  """ + mbrTrmntBetFrmDt + """  AND  """ + mbrTrmntBetToDt + """  
			OR  temp.MBR_PROD_ENRLMNT_TRMNTN_DT >=  """ + mbrTrmntGrtr + """  )
			AND BRD.STATE NOT IN ('IL', 'DC', 'MA')

			GROUP BY 
			temp.SBSCRBR_ID  ,
			temp.MBR_KEY ,
			temp.MBRSHP_SOR_CD ,   
			temp.GRNDFTHR_IND_CD ,
			temp.HIX_CD ,
			temp.GRNDFTHRG_STTS_CD ,     
			temp.hcr_cmplynt_cd,
			temp.EXCHNG_IND_CD ,
			temp.EXCHNG_METL_TYPE_CD ,
			temp.SRC_EXCHNG_CERTFN_CD ,
			temp.MBU_CF_CD  ,
			temp.PROD_CF_CD ,
			temp.CMPNY_CF_CD ,
			temp.FUNDG_CF_CD ,
			BRD.State ,
			MED.GL_CF_DESC,
			MED.GL_LVL_DESC,
			temp.SRC_GRP_NBR,
			temp.SRC_SUBGRP_NBR
			--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'
			"""

  def issued_2017() = """insert into table """ + dbWrk + """.naic2018_mcas_hlthex_poa_issued_wrk
			select 
			x.health_year,
			x.SBSCRBR_ID  ,
			x.MBR_KEY ,
			x.MBRSHP_SOR_CD,  
			x.GRNDFTHR_IND_CD  ,
			x.MBU_CF_CD  ,
			x.PROD_CF_CD ,
			x.CMPNY_CF_CD ,
			x.FUNDG_CF_CD ,
			x.EXCHNG_IND_CD,
			x.EXCHNG_METL_TYPE_CD ,
			x.GRNDFTHRG_STTS_CD  ,
			x.hcr_cmplynt_cd  ,
			x.SRC_EXCHNG_CERTFN_CD,
			x.HIX_CD ,
			x.State,
			x.IN_Exchange,
			x.OUTOFF_Exchange,
			x.naic_lob,
			x.naic_prod_desc,
			x.src_grp_nbr,
			x.src_subgrp_nbr,
			x.load_log_key,
			x. load_dt 
			from (select 
			""" + reportYear + """  as health_year,
			temp.SBSCRBR_ID AS SBSCRBR_ID  ,
			temp.MBR_KEY AS MBR_KEY,
			temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,  
			temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
			temp.MBU_CF_CD AS MBU_CF_CD ,
			temp.PROD_CF_CD AS PROD_CF_CD,
			temp.CMPNY_CF_CD AS CMPNY_CF_CD,
			temp.FUNDG_CF_CD AS FUNDG_CF_CD,
			temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
			temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD AS HIX_CD,
			BRD.State AS  State,
			CASE WHEN substr ( temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    
			and  temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
			WHEN  temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN' 
			WHEN SUBSTR( temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND (  temp.EXCHNG_IND_CD IS NULL OR  temp.EXCHNG_IND_CD ='UNK' )AND HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
			END AS IN_Exchange ,
			CASE WHEN substr ( temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and  temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
			WHEN  temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
			WHEN SUBSTR( temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND (  temp.EXCHNG_IND_CD IS NULL OR  temp.EXCHNG_IND_CD ='UNK' )AND HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
			END AS OUTOFF_Exchange, 
			CB.GL_LVL_DESC AS naic_lob,
			MED.GL_CF_DESC  as  naic_prod_desc ,
			temp.SRC_GRP_NBR  as src_grp_nbr, 
			temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
			""" + load_log_key + """  as load_log_key,
			current_timestamp as load_dt
			FROM """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' )  
			group by 1,2
			) as CB
			on CB.CF_CD =  temp.MBU_CF_CD
			inner join (
			select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			group by 1,2
			) as MED
			on MED.CF_CD =  temp.PROD_CF_CD
			inner join
			(
			select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl 
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
			(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  
			group by 1,2
			) BRD
			on BRD.CF_CD=  temp.MBU_CF_CD 
			and BRD.state <> 'LT'

			WHERE

			temp.MBR_PROD_ENRLMNT_EFCTV_DT BETWEEN  """ + mbrEffBetFrmDt + """  AND  """ + mbrEffBetToDt + """ 
			AND  temp.MBR_PROD_ENRLMNT_EFCTV_DT NOT BETWEEN  """ + mbrEffNotBetFrmDt + """  AND  """ + mbrEffNotBetToDt + """ 
			AND ( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN  """ + mbrTrmntBetFrmDt + """  AND  """ + mbrTrmntBetToDt + """  
			OR  temp.MBR_PROD_ENRLMNT_TRMNTN_DT >=  """ + mbrTrmntGrtr + """  )

			AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
			AND  BRD.State IN ( 'GA', 'KY', 'NH', 'VA' )
			AND temp.FUNDG_CF_CD = '45'
			GROUP BY 
			temp.SBSCRBR_ID  ,
			temp.MBR_KEY ,
			temp.MBRSHP_SOR_CD ,   temp.GRNDFTHR_IND_CD ,
			temp.HIX_CD ,
			temp.GRNDFTHRG_STTS_CD ,     temp.hcr_cmplynt_cd,
			temp.EXCHNG_IND_CD ,
			temp.EXCHNG_METL_TYPE_CD ,
			temp.SRC_EXCHNG_CERTFN_CD ,
			temp.MBU_CF_CD  ,
			temp.PROD_CF_CD ,
			temp.CMPNY_CF_CD ,
			temp.FUNDG_CF_CD ,
			BRD.State ,
			CB.GL_LVL_DESC,
			MED.GL_CF_DESC, 
			temp.SRC_GRP_NBR, 
			temp.SRC_SUBGRP_NBR 
			) x  
			left outer join  sbscrbridtemp y
			on x.SBSCRBR_ID = y.SBSCRBR_ID
			where y.SBSCRBR_ID is null
			--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'
			"""

  def issuedLG_srcgrp() = """insert into table """ + dbWrk + """.naic2018_mcas_hlthex_poa_issued_wrk
			select 
			x.health_year,
			x.SBSCRBR_ID  ,
			x.MBR_KEY ,
			x.MBRSHP_SOR_CD,  
			x.GRNDFTHR_IND_CD  ,
			x.MBU_CF_CD  ,
			x.PROD_CF_CD ,
			x.CMPNY_CF_CD ,
			x.FUNDG_CF_CD ,
			x.EXCHNG_IND_CD,
			x.EXCHNG_METL_TYPE_CD ,
			x.GRNDFTHRG_STTS_CD  ,
			x.hcr_cmplynt_cd  ,
			x.SRC_EXCHNG_CERTFN_CD,
			x.HIX_CD ,
			x.State,
			x.IN_Exchange,
			x.OUTOFF_Exchange,
			x.naic_lob,
			x.naic_prod_desc,
			x.src_grp_nbr,
			x.src_subgrp_nbr, 
			x.load_log_key,
			x. load_dt 
			from (select 
			""" + reportYear + """  as health_year,
			temp.SBSCRBR_ID AS SBSCRBR_ID  ,
			temp.MBR_KEY AS MBR_KEY,
			temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,  
			temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
			temp.MBU_CF_CD AS MBU_CF_CD ,
			temp.PROD_CF_CD AS PROD_CF_CD,
			temp.CMPNY_CF_CD AS CMPNY_CF_CD,
			temp.FUNDG_CF_CD AS FUNDG_CF_CD,
			temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
			temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD AS HIX_CD,
			BRD.State AS  State,
			CASE WHEN substr ( temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    
			and  temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
			WHEN  temp.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN' 
			WHEN SUBSTR( temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND (  temp.EXCHNG_IND_CD IS NULL OR  temp.EXCHNG_IND_CD ='UNK' )AND HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
			END AS IN_Exchange ,
			CASE WHEN substr ( temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and  temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
			WHEN  temp.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
			WHEN SUBSTR( temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND (  temp.EXCHNG_IND_CD IS NULL OR  temp.EXCHNG_IND_CD ='UNK' )AND HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
			END AS OUTOFF_Exchange, 
			CB.GL_LVL_DESC AS naic_lob,
			MED.GL_CF_DESC  as  naic_prod_desc ,
			temp.SRC_GRP_NBR as src_grp_nbr, 
			temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
			""" + load_log_key + """  as load_log_key,
			current_timestamp as load_dt
			FROM """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' ) 
			group by 1,2
			) as CB
			on CB.CF_CD =  temp.MBU_CF_CD
			inner join (
			select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			group by 1,2
			) as MED
			on MED.CF_CD =  temp.PROD_CF_CD
			inner join
			(
			select gl.CF_CD ,trim(substring(gl.GL_LVL_DESC, length(gl.GL_LVL_DESC) - 1) ) State 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl 
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE' and
			(gl.GL_LVL_DESC LIKE ('NON BLUE%') or gl.GL_LVL_DESC LIKE ('BLUE%')  and gl.GL_LVL_DESC not like  ('%TOTAL'))  
			group by 1,2
			) BRD
			on BRD.CF_CD=  temp.MBU_CF_CD 
			and BRD.state <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE  GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC
			ON FC.CF_CD =  temp.FUNDG_CF_CD
			WHERE

			temp.MBR_PROD_ENRLMNT_EFCTV_DT BETWEEN  """ + mbrEffBetFrmDt + """  AND  """ + mbrEffBetToDt + """ 
			AND  temp.MBR_PROD_ENRLMNT_EFCTV_DT NOT BETWEEN  """ + mbrEffNotBetFrmDt + """  AND  """ + mbrEffNotBetToDt + """ 
			AND ( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN  """ + mbrTrmntBetFrmDt + """  AND  """ + mbrTrmntBetToDt + """  
			OR  temp.MBR_PROD_ENRLMNT_TRMNTN_DT >=  """ + mbrTrmntGrtr + """  )

			AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
			AND  temp.MBU_CF_CD  IN ( 'EDCASH' , 'SPGAZZ' ,'EDCOSH' , 'EDINSH' )

			AND temp.SRC_GRP_NBR IN  ( '278777'  , '175089' , '175147' , '276470' ,'276500' , '277956' , '277960' , '278547' , '280438' , '280531' , '281249' , '281285' ,'281297'  , 'GA7649')
			GROUP BY 
			temp.SBSCRBR_ID  ,
			temp.MBR_KEY ,
			temp.MBRSHP_SOR_CD ,   
			temp.GRNDFTHR_IND_CD ,
			temp.HIX_CD ,
			temp.GRNDFTHRG_STTS_CD ,     
			temp.hcr_cmplynt_cd,
			temp.EXCHNG_IND_CD ,
			temp.EXCHNG_METL_TYPE_CD ,
			temp.SRC_EXCHNG_CERTFN_CD ,
			temp.MBU_CF_CD  ,
			temp.PROD_CF_CD ,
			temp.CMPNY_CF_CD ,
			temp.FUNDG_CF_CD ,
			BRD.State ,
			CB.GL_LVL_DESC,
			MED.GL_CF_DESC, 
			temp.SRC_GRP_NBR,
			temp.SRC_SUBGRP_NBR 
			) x  
			left outer join  sbscrbridtemp y
			on x.SBSCRBR_ID = y.SBSCRBR_ID
			where y.SBSCRBR_ID is null
			--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'
			"""
  
 
  def sparkInIt() {

    println("Date" + mbrEffBetFrmDt)
    spark.sql(issuedTrnctTbl())
    spark.sql(issuedNonCat())
    spark.sql(issuedCat())
    
    // Commented on 5/2/2019 as part of 2018 requirement   
   /*    spark.sql(issuedLG())    
      (reportYear.toInt == 2017) {
      spark.sql(issued_2017())
    } 
    spark.sql(issuedLG_srcgrp())*/
    
    spark.close()
  }

}

object PCADX_SCL_NAIC2018_POA_Issued {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    val issued = new PCADX_SCL_NAIC2018_POA_Issued()
    issued.sparkInIt()
  }
}