package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl5(val spark: SparkSession) {
  

  /* val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()*/

  import spark.implicits._
  
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy])
  
  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))  
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clmex")
  val end_year = dbProperties.getProperty("end_year_clmex")
  
  var naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame = null

  def sparkInIt(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame, load_log_key: String) {
    val oexclmphrmcy = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy(spark)
    val oexclmphrmcy_1 = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_1(spark)
    val mbu_cf_cdvals = dbProperties.getProperty("mbu_Cf_cdVals").split(",").toSeq
    /*naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk")

     naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk")
     naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk")
      naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk")*/
    val clm_paidamt = oexclmphrmcy_1.getamtData("PAID_AMT", "paid", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val clm_cpayamt = oexclmphrmcy_1.getamtData("CPAY_AMT", "copay", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val clm_coinsrnamt = oexclmphrmcy_1.getamtData("COINSRN_AMT", "coinsrn", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val clm_ddctblamt = oexclmphrmcy_1.getamtData("DDCTBL_AMT", "ddctbl", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)

    println("Done ")
    val StgData_1 = getStageData(clm_paidamt, clm_cpayamt, clm_coinsrnamt, clm_ddctblamt)
    /*     var load_log_key = ""
    if(!naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk.take(1).isEmpty){
     load_log_key = naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk.select($"load_log_key").first.getString(0)
    }*/
    val f_stgData = StgData_1.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
    oexclmphrmcy.writeDataToHive(dbwrk + ".naic2018_mcas_hlthoex_clmexphmcy_amtColstemp", f_stgData)
  }
  
  def getStageData(clm_paidamt: DataFrame, clm_cpayamt: DataFrame, clm_coinsrnamt: DataFrame, clm_ddctblamt: DataFrame): DataFrame = {

    val clm_cpay = clm_paidamt.alias("parent").join(clm_cpayamt.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_paid_amt_bronze_ip"), col("clm_total_paid_amt_silver_ip"), col("clm_total_paid_amt_gold_ip"), col("clm_total_paid_amt_platinum_ip"), col("clm_total_paid_amt_total_ip"),
        col("clm_total_paid_amt_bronze_sgp"), col("clm_total_paid_amt_silver_sgp"), col("clm_total_paid_amt_gold_sgp"), col("clm_total_paid_amt_platinum_sgp"), col("clm_total_paid_amt_total_sgp"), col("clm_total_paid_amt_gtlgp"), col("clm_total_paid_amt_gtsgp"), col("clm_total_paid_amt_gtip"), col("clm_total_paid_amt_total_gtip"), col("clm_total_paid_amt_catastrophic"), col("clm_total_paid_amt_lgp_mmcare"), col("clm_total_paid_amt_stucvg"),
        col("clm_total_copay_amt_bronze_ip"), col("clm_total_copay_amt_silver_ip"), col("clm_total_copay_amt_gold_ip"), col("clm_total_copay_amt_platinum_ip"), col("clm_total_copay_amt_total_ip"),
        col("clm_total_copay_amt_bronze_sgp"), col("clm_total_copay_amt_silver_sgp"), col("clm_total_copay_amt_gold_sgp"), col("clm_total_copay_amt_platinum_sgp"), col("clm_total_copay_amt_total_sgp"), col("clm_total_copay_amt_gtlgp"), col("clm_total_copay_amt_gtsgp"), col("clm_total_copay_amt_gtip"), col("clm_total_copay_amt_total_gtip"), col("clm_total_copay_amt_catastrophic"), col("clm_total_copay_amt_lgp_mmcare"), col("clm_total_copay_amt_stucvg"))

   val clm_cpayData = clm_cpay.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_paid_amt_bronze_ip", "clm_total_paid_amt_silver_ip", "clm_total_paid_amt_gold_ip", "clm_total_paid_amt_platinum_ip", "clm_total_paid_amt_total_ip",
        "clm_total_paid_amt_bronze_sgp", "clm_total_paid_amt_silver_sgp", "clm_total_paid_amt_gold_sgp", "clm_total_paid_amt_platinum_sgp", "clm_total_paid_amt_total_sgp", "clm_total_paid_amt_gtlgp", "clm_total_paid_amt_gtsgp", "clm_total_paid_amt_gtip", "clm_total_paid_amt_total_gtip", "clm_total_paid_amt_catastrophic", "clm_total_paid_amt_lgp_mmcare", "clm_total_paid_amt_stucvg",
        "clm_total_copay_amt_bronze_ip", "clm_total_copay_amt_silver_ip", "clm_total_copay_amt_gold_ip", "clm_total_copay_amt_platinum_ip", "clm_total_copay_amt_total_ip",
        "clm_total_copay_amt_bronze_sgp", "clm_total_copay_amt_silver_sgp", "clm_total_copay_amt_gold_sgp", "clm_total_copay_amt_platinum_sgp", "clm_total_copay_amt_total_sgp", "clm_total_copay_amt_gtlgp", "clm_total_copay_amt_gtsgp", "clm_total_copay_amt_gtip", "clm_total_copay_amt_total_gtip", "clm_total_copay_amt_catastrophic", "clm_total_copay_amt_lgp_mmcare", "clm_total_copay_amt_stucvg")

    val coinsr = clm_cpayData.alias("parent").join(clm_coinsrnamt.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_paid_amt_bronze_ip"), col("clm_total_paid_amt_silver_ip"), col("clm_total_paid_amt_gold_ip"), col("clm_total_paid_amt_platinum_ip"), col("clm_total_paid_amt_total_ip"),
        col("clm_total_paid_amt_bronze_sgp"), col("clm_total_paid_amt_silver_sgp"), col("clm_total_paid_amt_gold_sgp"), col("clm_total_paid_amt_platinum_sgp"), col("clm_total_paid_amt_total_sgp"), col("clm_total_paid_amt_gtlgp"), col("clm_total_paid_amt_gtsgp"), col("clm_total_paid_amt_gtip"), col("clm_total_paid_amt_total_gtip"), col("clm_total_paid_amt_catastrophic"), col("clm_total_paid_amt_lgp_mmcare"), col("clm_total_paid_amt_stucvg"),
        col("clm_total_copay_amt_bronze_ip"), col("clm_total_copay_amt_silver_ip"), col("clm_total_copay_amt_gold_ip"), col("clm_total_copay_amt_platinum_ip"), col("clm_total_copay_amt_total_ip"),
        col("clm_total_copay_amt_bronze_sgp"), col("clm_total_copay_amt_silver_sgp"), col("clm_total_copay_amt_gold_sgp"), col("clm_total_copay_amt_platinum_sgp"), col("clm_total_copay_amt_total_sgp"), col("clm_total_copay_amt_gtlgp"), col("clm_total_copay_amt_gtsgp"), col("clm_total_copay_amt_gtip"), col("clm_total_copay_amt_total_gtip"), col("clm_total_copay_amt_catastrophic"), col("clm_total_copay_amt_lgp_mmcare"), col("clm_total_copay_amt_stucvg"),
        col("clm_total_coinsrn_amt_bronze_ip"), col("clm_total_coinsrn_amt_silver_ip"), col("clm_total_coinsrn_amt_gold_ip"), col("clm_total_coinsrn_amt_platinum_ip"), col("clm_total_coinsrn_amt_total_ip"),
        col("clm_total_coinsrn_amt_bronze_sgp"), col("clm_total_coinsrn_amt_silver_sgp"), col("clm_total_coinsrn_amt_gold_sgp"), col("clm_total_coinsrn_amt_platinum_sgp"), col("clm_total_coinsrn_amt_total_sgp"), col("clm_total_coinsrn_amt_gtlgp"), col("clm_total_coinsrn_amt_gtsgp"), col("clm_total_coinsrn_amt_gtip"), col("clm_total_coinsrn_amt_total_gtip"), col("clm_total_coinsrn_amt_catastrophic"), col("clm_total_coinsrn_amt_lgp_mmcare"), col("clm_total_coinsrn_amt_stucvg"))

    val coinsrData = coinsr.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_paid_amt_bronze_ip", "clm_total_paid_amt_silver_ip", "clm_total_paid_amt_gold_ip", "clm_total_paid_amt_platinum_ip", "clm_total_paid_amt_total_ip",
        "clm_total_paid_amt_bronze_sgp", "clm_total_paid_amt_silver_sgp", "clm_total_paid_amt_gold_sgp", "clm_total_paid_amt_platinum_sgp", "clm_total_paid_amt_total_sgp", "clm_total_paid_amt_gtlgp", "clm_total_paid_amt_gtsgp", "clm_total_paid_amt_gtip", "clm_total_paid_amt_total_gtip", "clm_total_paid_amt_catastrophic", "clm_total_paid_amt_lgp_mmcare", "clm_total_paid_amt_stucvg",
        "clm_total_copay_amt_bronze_ip", "clm_total_copay_amt_silver_ip", "clm_total_copay_amt_gold_ip", "clm_total_copay_amt_platinum_ip", "clm_total_copay_amt_total_ip",
        "clm_total_copay_amt_bronze_sgp", "clm_total_copay_amt_silver_sgp", "clm_total_copay_amt_gold_sgp", "clm_total_copay_amt_platinum_sgp", "clm_total_copay_amt_total_sgp", "clm_total_copay_amt_gtlgp", "clm_total_copay_amt_gtsgp", "clm_total_copay_amt_gtip", "clm_total_copay_amt_total_gtip", "clm_total_copay_amt_catastrophic", "clm_total_copay_amt_lgp_mmcare", "clm_total_copay_amt_stucvg",
        "clm_total_coinsrn_amt_bronze_ip", "clm_total_coinsrn_amt_silver_ip", "clm_total_coinsrn_amt_gold_ip", "clm_total_coinsrn_amt_platinum_ip", "clm_total_coinsrn_amt_total_ip",
        "clm_total_coinsrn_amt_bronze_sgp", "clm_total_coinsrn_amt_silver_sgp", "clm_total_coinsrn_amt_gold_sgp", "clm_total_coinsrn_amt_platinum_sgp", "clm_total_coinsrn_amt_total_sgp", "clm_total_coinsrn_amt_gtlgp", "clm_total_coinsrn_amt_gtsgp", "clm_total_coinsrn_amt_gtip", "clm_total_coinsrn_amt_total_gtip", "clm_total_coinsrn_amt_catastrophic", "clm_total_coinsrn_amt_lgp_mmcare", "clm_total_coinsrn_amt_stucvg")

    val ddctbl = coinsrData.alias("parent").join(clm_ddctblamt.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_paid_amt_bronze_ip"), col("clm_total_paid_amt_silver_ip"), col("clm_total_paid_amt_gold_ip"), col("clm_total_paid_amt_platinum_ip"), col("clm_total_paid_amt_total_ip"),
        col("clm_total_paid_amt_bronze_sgp"), col("clm_total_paid_amt_silver_sgp"), col("clm_total_paid_amt_gold_sgp"), col("clm_total_paid_amt_platinum_sgp"), col("clm_total_paid_amt_total_sgp"), col("clm_total_paid_amt_gtlgp"), col("clm_total_paid_amt_gtsgp"), col("clm_total_paid_amt_gtip"), col("clm_total_paid_amt_total_gtip"), col("clm_total_paid_amt_catastrophic"), col("clm_total_paid_amt_lgp_mmcare"), col("clm_total_paid_amt_stucvg"),
        col("clm_total_copay_amt_bronze_ip"), col("clm_total_copay_amt_silver_ip"), col("clm_total_copay_amt_gold_ip"), col("clm_total_copay_amt_platinum_ip"), col("clm_total_copay_amt_total_ip"),
        col("clm_total_copay_amt_bronze_sgp"), col("clm_total_copay_amt_silver_sgp"), col("clm_total_copay_amt_gold_sgp"), col("clm_total_copay_amt_platinum_sgp"), col("clm_total_copay_amt_total_sgp"), col("clm_total_copay_amt_gtlgp"), col("clm_total_copay_amt_gtsgp"), col("clm_total_copay_amt_gtip"), col("clm_total_copay_amt_total_gtip"), col("clm_total_copay_amt_catastrophic"), col("clm_total_copay_amt_lgp_mmcare"), col("clm_total_copay_amt_stucvg"),
        col("clm_total_coinsrn_amt_bronze_ip"), col("clm_total_coinsrn_amt_silver_ip"), col("clm_total_coinsrn_amt_gold_ip"), col("clm_total_coinsrn_amt_platinum_ip"), col("clm_total_coinsrn_amt_total_ip"),
        col("clm_total_coinsrn_amt_bronze_sgp"), col("clm_total_coinsrn_amt_silver_sgp"), col("clm_total_coinsrn_amt_gold_sgp"), col("clm_total_coinsrn_amt_platinum_sgp"), col("clm_total_coinsrn_amt_total_sgp"), col("clm_total_coinsrn_amt_gtlgp"), col("clm_total_coinsrn_amt_gtsgp"), col("clm_total_coinsrn_amt_gtip"), col("clm_total_coinsrn_amt_total_gtip"), col("clm_total_coinsrn_amt_catastrophic"), col("clm_total_coinsrn_amt_lgp_mmcare"), col("clm_total_coinsrn_amt_stucvg"),
        col("clm_total_ddctbl_amt_bronze_ip"), col("clm_total_ddctbl_amt_silver_ip"), col("clm_total_ddctbl_amt_gold_ip"), col("clm_total_ddctbl_amt_platinum_ip"), col("clm_total_ddctbl_amt_total_ip"),
        col("clm_total_ddctbl_amt_bronze_sgp"), col("clm_total_ddctbl_amt_silver_sgp"), col("clm_total_ddctbl_amt_gold_sgp"), col("clm_total_ddctbl_amt_platinum_sgp"), col("clm_total_ddctbl_amt_total_sgp"), col("clm_total_ddctbl_amt_gtlgp"), col("clm_total_ddctbl_amt_gtsgp"), col("clm_total_ddctbl_amt_gtip"), col("clm_total_ddctbl_amt_total_gtip"), col("clm_total_ddctbl_amt_catastrophic"), col("clm_total_ddctbl_amt_lgp_mmcare"), col("clm_total_ddctbl_amt_stucvg"))

    val ddctblData = ddctbl.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("market_exchange", lit("OUTOFF"))
      .select("market_exchange", "health_year", "cmpny_cf_cd", "state", "clm_total_paid_amt_bronze_ip", "clm_total_paid_amt_silver_ip", "clm_total_paid_amt_gold_ip", "clm_total_paid_amt_platinum_ip", "clm_total_paid_amt_total_ip",
        "clm_total_paid_amt_bronze_sgp", "clm_total_paid_amt_silver_sgp", "clm_total_paid_amt_gold_sgp", "clm_total_paid_amt_platinum_sgp", "clm_total_paid_amt_total_sgp", "clm_total_paid_amt_gtlgp", "clm_total_paid_amt_gtsgp", "clm_total_paid_amt_gtip", "clm_total_paid_amt_total_gtip", "clm_total_paid_amt_catastrophic", "clm_total_paid_amt_lgp_mmcare", "clm_total_paid_amt_stucvg",
        "clm_total_copay_amt_bronze_ip", "clm_total_copay_amt_silver_ip", "clm_total_copay_amt_gold_ip", "clm_total_copay_amt_platinum_ip", "clm_total_copay_amt_total_ip",
        "clm_total_copay_amt_bronze_sgp", "clm_total_copay_amt_silver_sgp", "clm_total_copay_amt_gold_sgp", "clm_total_copay_amt_platinum_sgp", "clm_total_copay_amt_total_sgp", "clm_total_copay_amt_gtlgp", "clm_total_copay_amt_gtsgp", "clm_total_copay_amt_gtip", "clm_total_copay_amt_total_gtip", "clm_total_copay_amt_catastrophic", "clm_total_copay_amt_lgp_mmcare", "clm_total_copay_amt_stucvg",
        "clm_total_coinsrn_amt_bronze_ip", "clm_total_coinsrn_amt_silver_ip", "clm_total_coinsrn_amt_gold_ip", "clm_total_coinsrn_amt_platinum_ip", "clm_total_coinsrn_amt_total_ip",
        "clm_total_coinsrn_amt_bronze_sgp", "clm_total_coinsrn_amt_silver_sgp", "clm_total_coinsrn_amt_gold_sgp", "clm_total_coinsrn_amt_platinum_sgp", "clm_total_coinsrn_amt_total_sgp", "clm_total_coinsrn_amt_gtlgp", "clm_total_coinsrn_amt_gtsgp", "clm_total_coinsrn_amt_gtip", "clm_total_coinsrn_amt_total_gtip", "clm_total_coinsrn_amt_catastrophic", "clm_total_coinsrn_amt_lgp_mmcare", "clm_total_coinsrn_amt_stucvg",
        "clm_total_ddctbl_amt_bronze_ip", "clm_total_ddctbl_amt_silver_ip", "clm_total_ddctbl_amt_gold_ip", "clm_total_ddctbl_amt_platinum_ip", "clm_total_ddctbl_amt_total_ip",
        "clm_total_ddctbl_amt_bronze_sgp", "clm_total_ddctbl_amt_silver_sgp", "clm_total_ddctbl_amt_gold_sgp", "clm_total_ddctbl_amt_platinum_sgp", "clm_total_ddctbl_amt_total_sgp", "clm_total_ddctbl_amt_gtlgp", "clm_total_ddctbl_amt_gtsgp", "clm_total_ddctbl_amt_gtip", "clm_total_ddctbl_amt_total_gtip", "clm_total_ddctbl_amt_catastrophic", "clm_total_ddctbl_amt_lgp_mmcare", "clm_total_ddctbl_amt_stucvg")

    ddctblData
  }

}
object PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl5 {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    //new PCADX_SCL_NAIC_OEXStgTransformationclmexphmcy_tbl5().sparkInIt()
  }
}