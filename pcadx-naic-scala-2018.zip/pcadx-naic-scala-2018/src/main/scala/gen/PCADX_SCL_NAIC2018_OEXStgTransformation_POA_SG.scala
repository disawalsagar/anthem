package gen

import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit


class PCADX_SCL_NAIC2018_OEXStgTransformation_POA_SG {

	val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
			config("hive.exec.dynamic.partition.mode", "nonstrict").
			config("spark.sql.parquet.compression.codec", "snappy").
			config("hive.warehouse.data.skipTrash", "true").
			config("spark.sql.parquet.writeLegacyFormat", "true").
			enableHiveSupport().getOrCreate()

			import org.apache.spark.sql.types._
			import spark.implicits._

			var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_OEXStgTransformation_POA_SG])

			val dbProperties = new Properties
			dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
			val dbsg = dbProperties.getProperty("stage.db")
			val dbwrk = dbProperties.getProperty("work.db")
			val tblIssued = dbProperties.getProperty("issued_poa")
			val tblRenewed = dbProperties.getProperty("renewed_poa")
			val tblMmissued = dbProperties.getProperty("mmissued_poa")
			val tblMmrenewed = dbProperties.getProperty("mmrenewed_poa")
			val tblTermed = dbProperties.getProperty("termed_poa")
			val tblTermed_nonpay = dbProperties.getProperty("termed_nonpay_poa")
			val tblTermed_lives = dbProperties.getProperty("termed_lives_poa")
			val tblTermed_nonpay_lives = dbProperties.getProperty("termed_nonpay_lives_poa")
			val uri: String = dbProperties.getProperty("uri")
			val mbu_cf_cdvals_sql = dbProperties.getProperty("mbu_Cf_cdVals_sql")
			val mbu_cf_cdvals = dbProperties.getProperty("mbu_Cf_cdVals").split(",").toSeq
			val strt_year = dbProperties.getProperty("strt_year_poa")
			val end_year = dbProperties.getProperty("end_year_poa")
			val date1 = LocalDate.parse(end_year)
			val date2 = LocalDate.parse(strt_year)
			val strt_year_sql = dbProperties.getProperty("strt_year_poa_sql")
			val end_year_sql = dbProperties.getProperty("end_year_poa_sql")
			val naic_lob_lgp = Seq("LARGE GROUP CBE EXCLUDING MEDICARE"  , "TOTAL NATIONAL CBE")
			val mmissue_const_date = dbProperties.getProperty("const_date_mmissued")

			def sparkInIt() {
				val naic2018_mcas_hlthex_poa_issued_wrk = readDataFromHive(dbwrk + "." + tblIssued)
						val naic2018_mcas_hlthex_poa_renewed_wrk = readDataFromHive(dbwrk + "." + tblRenewed)
						val naic2018_mcas_hlthex_poa_mmissued_wrk = readDataFromHive(dbwrk + "." + tblMmissued)
						val naic2018_mcas_hlthex_poa_mmrenewed_wrk = readDataFromHive(dbwrk + "." + tblMmrenewed)
						val naic2018_mcas_hlthex_poa_termed_wrk = readDataFromHive(dbwrk + "." + tblTermed)
						val naic2018_mcas_hlthex_poa_termed_nonpay_wrk = readDataFromHive(dbwrk + "." + tblTermed_nonpay)
						val naic2018_mcas_hlthex_poa_termed_lives_wrk = readDataFromHive(dbwrk + "." + tblTermed_lives)
						val naic2018_mcas_hlthex_poa_termed_nonpay_lives_wrk = readDataFromHive(dbwrk + "." + tblTermed_nonpay_lives)
						val naic2018_mcas_hlthex_poag_issued_wrk = readDataFromHive(dbwrk + ". naic2018_mcas_hlthex_poag_issued_wrk")
						val naic2018_mcas_hlthex_poag_renewed_wrk = readDataFromHive(dbwrk + ". naic2018_mcas_hlthex_poag_renewed_wrk")
						val naic2018_mcas_hlthex_poag_mmissued_wrk = readDataFromHive(dbwrk + ". naic2018_mcas_hlthex_poag_mmissued_wrk ")
						val naic2018_mcas_hlthex_poag_mmrenewed_wrk = readDataFromHive(dbwrk + ". naic2018_mcas_hlthex_poag_mmrenewed_wrk")
						val naic2018_mcas_hlthex_poag_termed_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_poag_termed_wrk")
						val naic2018_mcas_hlthex_poag_termed_nonpay_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_poag_termed_nonpay_wrk ")
						val naic2018_mcas_hlthex_poag_termed_lives_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_poag_termed_lives_wrk")
						val naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk ")
						val naic2018_mcas_hlthoex_poa_facets_stg = readDataFromHive(dbsg + ".naic2018_mcas_hlthoex_poa_facets_stg")

						//truncateTbl(dbsg+"."+"naic_mcas_hlthiex_poa_stg")
						val sg_stgData = populateStageTbl(naic2018_mcas_hlthex_poa_issued_wrk, naic2018_mcas_hlthex_poag_issued_wrk,naic2018_mcas_hlthex_poag_mmissued_wrk, 
								naic2018_mcas_hlthex_poa_renewed_wrk,naic2018_mcas_hlthex_poag_renewed_wrk,naic2018_mcas_hlthex_poag_mmrenewed_wrk, 
								naic2018_mcas_hlthex_poa_termed_wrk,naic2018_mcas_hlthex_poag_termed_wrk,naic2018_mcas_hlthoex_poa_facets_stg,naic2018_mcas_hlthex_poag_termed_lives_wrk,
								naic2018_mcas_hlthex_poa_termed_nonpay_wrk,naic2018_mcas_hlthex_poag_termed_nonpay_wrk,naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk )
						sg_stgData.repartition(50)
						writeDataToHive(dbsg + "." + "naic2018_mcas_hlthoex_poa_sg_stg", sg_stgData)
						spark.close()
			}

			def truncateTbl(tblName: String) {
				spark.sql("TRUNCATE TABLE " + tblName)
			}

			def writeDataToHive(tblName: String, finalDf: DataFrame) {
				finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
				println("Data added in POA Small Group Stage Table")
			}

			def readDataFromHive(tble: String): DataFrame = {
					val queryOutputTable = """SELECT * FROM """ + tble
							println(queryOutputTable)
							val tbl_data_df = spark.sql(queryOutputTable) //.na.fill("")
							logger.info("Read data from hive")
							tbl_data_df
			}

			def populateStageTbl(naic2018_mcas_hlthex_poa_issued_wrk:DataFrame, naic2018_mcas_hlthex_poag_issued_wrk: DataFrame,naic2018_mcas_hlthex_poag_mmissued_wrk: DataFrame, 
					naic2018_mcas_hlthex_poa_renewed_wrk: DataFrame,naic2018_mcas_hlthex_poag_renewed_wrk: DataFrame,naic2018_mcas_hlthex_poag_mmrenewed_wrk: DataFrame, 
					naic2018_mcas_hlthex_poa_termed_wrk: DataFrame,naic2018_mcas_hlthex_poag_termed_wrk: DataFrame,naic2018_mcas_hlthoex_poa_facets_stg:DataFrame,naic2018_mcas_hlthex_poag_termed_lives_wrk: DataFrame,
					naic_mcas_hlthex_poa_termed_nonpay_wrk: DataFrame,naic_mcas_hlthex_poag_termed_nonpay_wrk: DataFrame, naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk: DataFrame): DataFrame = {

							val final_df = null
									val issueFinalDf = getIssuedData(naic2018_mcas_hlthex_poa_issued_wrk,naic2018_mcas_hlthex_poag_issued_wrk,naic2018_mcas_hlthex_poag_mmissued_wrk, "issued")
									val rennewedFinalDf = getIssuedData(naic2018_mcas_hlthex_poa_renewed_wrk,naic2018_mcas_hlthex_poag_renewed_wrk,naic2018_mcas_hlthex_poag_mmrenewed_wrk, "renewed")
									val termedFinalDf =  getTermedLivesData(naic2018_mcas_hlthex_poa_termed_wrk,naic2018_mcas_hlthex_poag_termed_wrk,naic2018_mcas_hlthoex_poa_facets_stg,naic2018_mcas_hlthex_poag_termed_lives_wrk,"termed")
									val termed_nonpayFinalDf = getTermedLivesData(naic_mcas_hlthex_poa_termed_nonpay_wrk,naic_mcas_hlthex_poag_termed_nonpay_wrk,naic2018_mcas_hlthoex_poa_facets_stg,naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk, "termed_nonpay")						  
									val OexStgData = getStageData(issueFinalDf, rennewedFinalDf, termedFinalDf, termed_nonpayFinalDf)
									var load_log_key = ""

									if (!naic2018_mcas_hlthex_poag_mmissued_wrk.take(1).isEmpty) {
										load_log_key = naic2018_mcas_hlthex_poag_mmissued_wrk.select($"load_log_key").first.getString(0)
									}

							val finalStgdata = OexStgData.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
							//finalStgdata.filter($"state".equalTo("OH")).show()
							finalStgdata			  
			}

			def getIssuedData(naic2018_mcas_hlthex_poa_issued_wrk:DataFrame,naic2018_mcas_hlthex_poag_issued_wrk: DataFrame,naic2018_mcas_hlthex_poag_mmissued_wrk: DataFrame, typeOfData: String): DataFrame = {
					// val finalIssuedDataDf;

					val nbrpoa_bronze_sgp = "nbrpoa_" + typeOfData + "_bronze_sgp"
							val nbrpoa_issued_bronze_sgp = naic2018_mcas_hlthex_poag_mmissued_wrk.filter(naic2018_mcas_hlthex_poag_mmissued_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic2018_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").isNull) &&
									naic2018_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic2018_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").isNull) &&
									naic2018_mcas_hlthex_poag_mmissued_wrk("exchng_metl_type_cd").equalTo("04") &&
									naic2018_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias(nbrpoa_bronze_sgp))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(nbrpoa_bronze_sgp).alias(nbrpoa_bronze_sgp))

              // println (nbrpoa_issued_bronze_sgp.show)
							val nbrpoa_silver_sgp = "nbrpoa_" + typeOfData + "_silver_sgp"
							val nbrpoa_issued_silver_sgp = naic2018_mcas_hlthex_poag_mmissued_wrk.filter(naic2018_mcas_hlthex_poag_mmissued_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic2018_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").isNull) &&
									naic2018_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic2018_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").isNull) &&
									naic2018_mcas_hlthex_poag_mmissued_wrk("exchng_metl_type_cd").equalTo("03") &&
									naic2018_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias(nbrpoa_silver_sgp))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(nbrpoa_silver_sgp).alias(nbrpoa_silver_sgp))


							val brSil = nbrpoa_issued_bronze_sgp.alias("bronze").join(nbrpoa_issued_silver_sgp.alias("silver"), $"bronze.health_year" === $"silver.health_year"
							&& $"bronze.cmpny_cf_cd" === $"silver.cmpny_cf_cd" && $"bronze.state" === $"silver.state" , "outer")
							.select($"bronze.health_year".alias("b_year"), $"silver.health_year".alias("s_year"),
									$"bronze.cmpny_cf_cd".alias("b_cmpny"), $"silver.cmpny_cf_cd".alias("s_cmpny"), $"bronze.state".alias("b_state"),
									$"silver.state".alias("s_state"),col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp))

							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_sgp, nbrpoa_silver_sgp)

							val nbrpoa_gold_sgp = "nbrpoa_" + typeOfData + "_gold_sgp"
							val nbrpoa_issued_gold_sgp = naic2018_mcas_hlthex_poag_mmissued_wrk.filter(naic2018_mcas_hlthex_poag_mmissued_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic2018_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").isNull) &&
									naic2018_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic2018_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").isNull) &&
									naic2018_mcas_hlthex_poag_mmissued_wrk("exchng_metl_type_cd").equalTo("02") &&
									naic2018_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias(nbrpoa_gold_sgp))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(nbrpoa_gold_sgp).alias(nbrpoa_gold_sgp))


							val bsGold = brSilData.alias("brsil").join(nbrpoa_issued_gold_sgp.alias("gold"), $"brsil.health_year" === $"gold.health_year"
							&& $"brsil.cmpny_cf_cd" === $"gold.cmpny_cf_cd" && $"brsil.state" === $"gold.state" , "outer")
							.select($"brsil.health_year".alias("b_year"), $"gold.health_year".alias("s_year"),
									$"brsil.cmpny_cf_cd".alias("b_cmpny"), $"gold.cmpny_cf_cd".alias("s_cmpny"), $"brsil.state".alias("b_state"),
									$"gold.state".alias("s_state"), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp))

							val bsGoldData = bsGold.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.select("health_year", "cmpny_cf_cd", "state",  nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp)

							val nbrpoa_platinum_sgp = "nbrpoa_" + typeOfData + "_platinum_sgp"
							val nbrpoa_issued_platinum_sgp = naic2018_mcas_hlthex_poag_mmissued_wrk.filter(naic2018_mcas_hlthex_poag_mmissued_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic2018_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").isNull) &&
									naic2018_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic2018_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").isNull) &&
									naic2018_mcas_hlthex_poag_mmissued_wrk("exchng_metl_type_cd").equalTo("01") &&
									naic2018_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias(nbrpoa_platinum_sgp))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(nbrpoa_platinum_sgp).alias(nbrpoa_platinum_sgp))


							val bsgPlt = bsGoldData.alias("bsg").join(nbrpoa_issued_platinum_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" , "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp))

							val bsgPltinumData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp)

							val nbrpoa_total_sgp = "nbrpoa_" + typeOfData + "_total_sgp"
							val getTotal_ip = nbrpoa_issued_bronze_sgp.union(nbrpoa_issued_silver_sgp.union(nbrpoa_issued_gold_sgp.union(nbrpoa_issued_platinum_sgp)))
							.select($"health_year", $"cmpny_cf_cd", $"state",  col(nbrpoa_bronze_sgp)).withColumn(nbrpoa_bronze_sgp, col(nbrpoa_bronze_sgp).cast(IntegerType))

							val nbrpoa_issued_total_sgp = getTotal_ip.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col(nbrpoa_bronze_sgp)).alias(nbrpoa_total_sgp))

							val bsgpTot = bsgPltinumData.alias("bsg").join(nbrpoa_issued_total_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" , "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp),
									col(nbrpoa_total_sgp))

							val bsgPTotData = bsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.select("health_year", "cmpny_cf_cd", "state",nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,
									nbrpoa_total_sgp)

							val nbrpoa_gtlgp = "nbrpoa_" + typeOfData + "_gtlgp"

							val nbrpoa_issued_gtlgp = naic2018_mcas_hlthex_poag_issued_wrk.filter(naic2018_mcas_hlthex_poag_issued_wrk("naic_lob").isin(naic_lob_lgp:_*) &&
									naic2018_mcas_hlthex_poag_issued_wrk("grndfthr_ind_cd").equalTo("YES") &&
									naic2018_mcas_hlthex_poag_issued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state",$"mbrshp_sor_cd",$"src_grp_nbr").agg((lit(1)).alias("count_Val")).groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias(nbrpoa_gtlgp))

							val ipgtlgp = bsgPTotData.alias("bsg").join(nbrpoa_issued_gtlgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp),
									col(nbrpoa_total_sgp), col(nbrpoa_gtlgp))

							val ipgtlgpData = ipgtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state",  nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,
									nbrpoa_total_sgp, nbrpoa_gtlgp)

							val nbrpoa_gtsgp = "nbrpoa_" + typeOfData + "_gtsgp"

							val nbrpoa_issued_gtsgp = naic2018_mcas_hlthex_poag_mmissued_wrk.filter(naic2018_mcas_hlthex_poag_mmissued_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic2018_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").notEqual("Y")|| naic2018_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").isNull) &&
									naic2018_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state",$"mbrshp_sor_cd",$"src_grp_nbr").agg((lit(1)).alias("count_Val")).groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias(nbrpoa_gtsgp))

							val ipbsgtsgp = ipgtlgpData.alias("bsg").join(nbrpoa_issued_gtsgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state",
									"outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp),
									col(nbrpoa_total_sgp), col(nbrpoa_gtlgp),col(nbrpoa_gtsgp))

							val ipbsgtsgpData = ipbsgtsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,
									nbrpoa_total_sgp, nbrpoa_gtlgp, nbrpoa_gtsgp)

							val nbrpoa_gtip = "nbrpoa_" + typeOfData + "_gtip"
							val nbrpoa_issued_gtip = naic2018_mcas_hlthex_poa_issued_wrk.filter(naic2018_mcas_hlthex_poa_issued_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
									(naic2018_mcas_hlthex_poa_issued_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_poa_issued_wrk("hcr_cmplynt_cd").notEqual("Y")|| naic2018_mcas_hlthex_poa_issued_wrk("hcr_cmplynt_cd").isNull) &&
									naic2018_mcas_hlthex_poa_issued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_gtip))

							val ipgtlgpip = ipbsgtsgpData.alias("bsg").join(nbrpoa_issued_gtip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp),
									col(nbrpoa_total_sgp), col(nbrpoa_gtlgp),col(nbrpoa_gtsgp), col(nbrpoa_gtip))

							val ipgtlgpipData = ipgtlgpip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,
									nbrpoa_total_sgp, nbrpoa_gtlgp,nbrpoa_gtsgp, nbrpoa_gtip)

							val nbrpoa_total_gtip = "nbrpoa_" + typeOfData + "_total_gtip"
							val getTotal_gtip = nbrpoa_issued_gtlgp.union(nbrpoa_issued_gtsgp.union(nbrpoa_issued_gtip))
							.select($"health_year", $"cmpny_cf_cd", $"state", col(nbrpoa_gtlgp))

							val nbrpoa_issued_total_ip = getTotal_gtip.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(nbrpoa_gtlgp).alias(nbrpoa_total_gtip))


							val ipbsgpTotgtLgpgtsgpipTot = ipgtlgpipData.alias("bsg").join(nbrpoa_issued_total_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp),
									col(nbrpoa_total_sgp), col(nbrpoa_gtlgp),col(nbrpoa_gtsgp), col(nbrpoa_gtip), col(nbrpoa_total_gtip))

							val ipbsgpTotgtLgpgtsgpipTotData = ipbsgpTotgtLgpgtsgpipTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state",nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,
									nbrpoa_total_sgp, nbrpoa_gtlgp,nbrpoa_gtsgp, nbrpoa_gtip, nbrpoa_total_gtip)

							ipbsgpTotgtLgpgtsgpipTotData

			}

			def getTermedLivesData(naic2018_mcas_hlthex_poa_termed_wrk: DataFrame,naic2018_mcas_hlthex_poag_termed_wrk: DataFrame,naic2018_mcas_hlthoex_poa_facets_stg:DataFrame,naic_mcas_hlthex_poag_wrk:DataFrame,typeOfData: String): DataFrame = {

					naic2018_mcas_hlthex_poa_termed_wrk.createOrReplaceTempView("termedPOA_wrk")	
					naic2018_mcas_hlthex_poag_termed_wrk.createOrReplaceTempView("termedPOAG_wrk")
					naic2018_mcas_hlthoex_poa_facets_stg.createOrReplaceTempView("facets_stg")
					naic_mcas_hlthex_poag_wrk.createOrReplaceTempView("termedlivesPOAG_wrk")


					val nbrpoa_bronze_sgp = "nbrpoa_" + typeOfData + "_bronze_sgp"
					val nbrpoa_termed_nonpay_lives_bronze_sgp = naic_mcas_hlthex_poag_wrk
					.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
							(naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("04") &&
							naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_bronze_sgp))

					val nbrpoa_silver_sgp = "nbrpoa_" + typeOfData + "_silver_sgp"
					val nbrpoa_termed_nonpay_lives_silver_sgp = naic_mcas_hlthex_poag_wrk
					.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
							(naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("03") &&
							naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_silver_sgp))

					val ipbSil = nbrpoa_termed_nonpay_lives_bronze_sgp.alias("bsg").join(nbrpoa_termed_nonpay_lives_silver_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp))

					val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_sgp, nbrpoa_silver_sgp)

					val nbrpoa_gold_sgp = "nbrpoa_" + typeOfData + "_gold_sgp"
					val nbrpoa_termed_nonpay_lives_gold_sgp = naic_mcas_hlthex_poag_wrk
					.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
							(naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("02") &&
							naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_gold_sgp))

					val ipbsGld = ipbSilData.alias("bsg").join(nbrpoa_termed_nonpay_lives_gold_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp))

					val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state",  nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp)

					val nbrpoa_platinum_sgp = "nbrpoa_" + typeOfData + "_platinum_sgp"
					val nbrpoa_termed_nonpay_lives_platimun_sgp = naic_mcas_hlthex_poag_wrk
					.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
							(naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("01") &&
							naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_platinum_sgp))

					val ipbsgPlt = ipbsGldData.alias("bsg").join(nbrpoa_termed_nonpay_lives_platimun_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp))

					val ipbsgPltData = ipbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp)

					val nbrpoa_total_sgp = "nbrpoa_" + typeOfData + "_total_sgp"
					val getTotal_sgp = nbrpoa_termed_nonpay_lives_bronze_sgp.union(nbrpoa_termed_nonpay_lives_silver_sgp.union(nbrpoa_termed_nonpay_lives_gold_sgp.union(nbrpoa_termed_nonpay_lives_platimun_sgp)))
					.select($"health_year", $"cmpny_cf_cd", $"state", col(nbrpoa_bronze_sgp))

					val nbrpoa_termed_nonpay_lives_total_sgp = getTotal_sgp.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col(nbrpoa_bronze_sgp)).alias(nbrpoa_total_sgp))

					val ipbsgpTot = ipbsgPltData.alias("bsg").join(nbrpoa_termed_nonpay_lives_total_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp))

					val ipsgpData = ipbsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp)

					val nbrpoa_gtlgb = "nbrpoa_" + typeOfData + "_gtlgp"

					val nbrpoa_termed_lives_gtlgp = spark.sql(""" 
							select 
							case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.health_year
							when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.health_year
							when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
							and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.health_year
							end as  health_year ,      

							case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.anthem_cmpny_cd 
							when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.cmpny_cf_cd 
							when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
							and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.cmpny_cf_cd
							end as  cmpny_cf_cd ,

							case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.state
							when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.state 
							when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
							and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.state
							end as  state , 

							CASE WHEN stg.anthem_cmpny_cd is null and stg.state is null THEN 
							cast((count(distinct wrk1.mbrshp_sor_cd, wrk1.src_grp_nbr)) as  int)
							when stg.anthem_cmpny_cd is not null and stg.state is not null 
							and wrk1.cmpny_cf_cd is not null and wrk1.state is not null
							THEN cast((count(distinct wrk1.mbrshp_sor_cd, wrk1.src_grp_nbr) + stg."""+nbrpoa_gtlgb+""") as  int)
							WHEN wrk1.cmpny_cf_cd IS NULL AND wrk1.state IS NULL THEN stg."""+nbrpoa_gtlgb+"""
							end as """+nbrpoa_gtlgb+"""

							from 
							( select wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.mbrshp_sor_cd, wrk.src_grp_nbr
							from termedPOAG_wrk wrk
							where wrk.naic_lob in ('LARGE GROUP CBE EXCLUDING MEDICARE'  , 'TOTAL NATIONAL CBE' ) 
							and   wrk.grndfthr_ind_cd = 'YES' 
							and wrk.in_exchange is null
							group by wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.mbrshp_sor_cd, wrk.src_grp_nbr
							)wrk1
							full outer join facets_stg stg
							on wrk1.cmpny_cf_cd = stg.anthem_cmpny_cd
							and wrk1.state = stg.state

							group by  
							wrk1.health_year ,
							wrk1.cmpny_cf_cd ,
							wrk1.state,
							stg.anthem_cmpny_cd,
							stg.state,
							stg."""+nbrpoa_gtlgb+""",
							stg.health_year
							"""
							)



					val ipbsgpTotgtLgp = ipsgpData.alias("bsg").join(nbrpoa_termed_lives_gtlgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
							col(nbrpoa_gtlgb))

					val ipbsgpTotgtLgpData = ipbsgpTotgtLgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state",nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_gtlgb)

					
					val nbrpoa_gtsgp = "nbrpoa_" + typeOfData + "_gtsgp"
					
					val nbrpoa_termed_lives_gtsgp = naic_mcas_hlthex_poag_wrk
					.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
							(naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").equalTo("YES") || naic_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").notEqual("Y") || 
							     naic_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_gtsgp))  


					val ipbsgpTotgtLgpgtsgp = ipbsgpTotgtLgpData.alias("bsg").join(nbrpoa_termed_lives_gtsgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
							col(nbrpoa_gtlgb), col(nbrpoa_gtsgp))

					val ipbsgpTotgtLgpgtsgpData = ipbsgpTotgtLgpgtsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_gtlgb, nbrpoa_gtsgp)

					val nbrpoa_gtip = "nbrpoa_" + typeOfData + "_gtip"


					
val nbrpoa_issued_gtip = spark.sql("""
		
							select 
               case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.health_year
                    when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.health_year
                when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
                and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.health_year
            end as  health_year ,      
         
         case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.anthem_cmpny_cd 
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.cmpny_cf_cd 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.cmpny_cf_cd
        end as  cmpny_cf_cd ,
        
        case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.state
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.state 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.state
        end as  state , 
        
							CASE WHEN stg.anthem_cmpny_cd is null and stg.state is null THEN cast(count(distinct wrk1.sbscrbr_id) as int)
							when stg.anthem_cmpny_cd is not null and stg.state is not null and
							wrk1.cmpny_cf_cd is not null and wrk1.state is not null
							THEN cast((count(distinct wrk1.sbscrbr_id) + stg."""+nbrpoa_gtip+""") as int)
							WHEN wrk1.cmpny_cf_cd IS NULL  AND wrk1.state IS NULL THEN stg."""+nbrpoa_gtip+"""
							end as  """+nbrpoa_gtip+"""
							  
							from 
							( select wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.sbscrbr_id
							from termedPOA_wrk wrk
							where wrk.naic_lob = 'TOTAL INDIVIDUAL CBE'
							and ( wrk.grndfthr_ind_cd = 'YES'   or  wrk.hcr_cmplynt_cd <> 'Y'  or  wrk.hcr_cmplynt_cd is null  )
							and  wrk.in_exchange is null
							group by wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.sbscrbr_id
							)wrk1
							full outer join facets_stg stg
							on wrk1.cmpny_cf_cd = stg.anthem_cmpny_cd
							and wrk1.state = stg.state
							
							group by  
							wrk1.health_year ,
							wrk1.cmpny_cf_cd ,
							wrk1.state,
							stg.anthem_cmpny_cd,
							stg.state,
							stg."""+nbrpoa_gtip+""",
							stg.health_year 
"""
							)
					val ipbsgpTotgtLgpgtsgpip = ipbsgpTotgtLgpgtsgpData.alias("bsg").join( nbrpoa_issued_gtip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
							col(nbrpoa_gtlgb), col(nbrpoa_gtsgp), col(nbrpoa_gtip))

					val ipbsgpTotgtLgpgtsgpipData = ipbsgpTotgtLgpgtsgpip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state",  nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, 
					    nbrpoa_gtlgb, nbrpoa_gtsgp,	nbrpoa_gtip)
							
					val nbrpoa_total_gtip = "nbrpoa_" + typeOfData + "_total_gtip"
					val getTotal_gtip = nbrpoa_termed_lives_gtlgp.union(nbrpoa_termed_lives_gtsgp.union(nbrpoa_issued_gtip))
					.select($"health_year", $"cmpny_cf_cd", $"state", col(nbrpoa_gtlgb))

					val mbrmpoa_renewed_total_ip = getTotal_gtip.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(nbrpoa_gtlgb).alias(nbrpoa_total_gtip))

					val ipbsgpTotgtLgpgtsgpipTot = ipbsgpTotgtLgpgtsgpipData.alias("bsg").join(mbrmpoa_renewed_total_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
							col(nbrpoa_gtlgb), col(nbrpoa_gtsgp), col(nbrpoa_gtip), col(nbrpoa_total_gtip))

					val ipbsgpTotgtLgpgtsgpipTotData = ipbsgpTotgtLgpgtsgpipTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state",nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_gtlgb, nbrpoa_gtsgp,
							nbrpoa_gtip, nbrpoa_total_gtip)

					ipbsgpTotgtLgpgtsgpipTotData

			}


			def getStageData(issueFinalDf: DataFrame, rennewedFinalDf: DataFrame,termedFinalDf: DataFrame, termed_nonpayFinalDf: DataFrame ): DataFrame = {

					val issued_renewed = issueFinalDf.alias("parent").join(rennewedFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd"&& $"parent.state" === $"child.state", "outer")
							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
									$"child.state".alias("s_state"),  $"nbrpoa_issued_bronze_sgp", $"nbrpoa_issued_silver_sgp", $"nbrpoa_issued_gold_sgp", $"nbrpoa_issued_platinum_sgp",
									$"nbrpoa_issued_total_sgp", 
									$"nbrpoa_issued_gtlgp", $"nbrpoa_issued_gtsgp",$"nbrpoa_issued_gtip", $"nbrpoa_issued_total_gtip",
									$"nbrpoa_renewed_bronze_sgp", $"nbrpoa_renewed_silver_sgp", $"nbrpoa_renewed_gold_sgp", $"nbrpoa_renewed_platinum_sgp",
									$"nbrpoa_renewed_total_sgp",
									$"nbrpoa_renewed_gtlgp",$"nbrpoa_renewed_gtsgp",$"nbrpoa_renewed_gtip", $"nbrpoa_renewed_total_gtip")

							val issued_renewedData = issued_renewed.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.select("health_year", "cmpny_cf_cd", "state", 
									"nbrpoa_issued_bronze_sgp", "nbrpoa_issued_silver_sgp", "nbrpoa_issued_gold_sgp", "nbrpoa_issued_platinum_sgp", "nbrpoa_issued_total_sgp", 
									"nbrpoa_issued_gtlgp", "nbrpoa_issued_gtsgp", "nbrpoa_issued_gtip","nbrpoa_issued_total_gtip", 
									"nbrpoa_renewed_bronze_sgp", "nbrpoa_renewed_silver_sgp", "nbrpoa_renewed_gold_sgp", "nbrpoa_renewed_platinum_sgp", "nbrpoa_renewed_total_sgp", 
									"nbrpoa_renewed_gtlgp", "nbrpoa_renewed_gtsgp", "nbrpoa_renewed_gtip","nbrpoa_renewed_total_gtip") 


							val ir_termed = issued_renewedData.alias("parent").join(termedFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
									$"child.state".alias("s_state"),
									$"nbrpoa_issued_bronze_sgp", $"nbrpoa_issued_silver_sgp", $"nbrpoa_issued_gold_sgp", $"nbrpoa_issued_platinum_sgp",
									$"nbrpoa_issued_total_sgp", 
									$"nbrpoa_issued_gtlgp", $"nbrpoa_issued_gtsgp",$"nbrpoa_issued_gtip", $"nbrpoa_issued_total_gtip",
									$"nbrpoa_renewed_bronze_sgp", $"nbrpoa_renewed_silver_sgp", $"nbrpoa_renewed_gold_sgp", $"nbrpoa_renewed_platinum_sgp",
									$"nbrpoa_renewed_total_sgp",
									$"nbrpoa_renewed_gtlgp",$"nbrpoa_renewed_gtsgp",$"nbrpoa_renewed_gtip", $"nbrpoa_renewed_total_gtip",
									$"nbrpoa_termed_bronze_sgp", $"nbrpoa_termed_silver_sgp", $"nbrpoa_termed_gold_sgp", $"nbrpoa_termed_platinum_sgp", $"nbrpoa_termed_total_sgp",
									$"nbrpoa_termed_gtlgp", $"nbrpoa_termed_gtsgp", $"nbrpoa_termed_gtip", $"nbrpoa_termed_total_gtip")

							val ir_termedData = ir_termed.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.select("health_year", "cmpny_cf_cd", "state", 
									"nbrpoa_issued_bronze_sgp", "nbrpoa_issued_silver_sgp", "nbrpoa_issued_gold_sgp", "nbrpoa_issued_platinum_sgp", "nbrpoa_issued_total_sgp", 
									"nbrpoa_issued_gtlgp", "nbrpoa_issued_gtsgp", "nbrpoa_issued_gtip","nbrpoa_issued_total_gtip", 
									"nbrpoa_renewed_bronze_sgp", "nbrpoa_renewed_silver_sgp", "nbrpoa_renewed_gold_sgp", "nbrpoa_renewed_platinum_sgp", "nbrpoa_renewed_total_sgp", 
									"nbrpoa_renewed_gtlgp", "nbrpoa_renewed_gtsgp", "nbrpoa_renewed_gtip","nbrpoa_renewed_total_gtip",
									"nbrpoa_termed_bronze_sgp", "nbrpoa_termed_silver_sgp", "nbrpoa_termed_gold_sgp", "nbrpoa_termed_platinum_sgp", "nbrpoa_termed_total_sgp", 
									"nbrpoa_termed_gtlgp", "nbrpoa_termed_gtsgp", "nbrpoa_termed_gtip", "nbrpoa_termed_total_gtip") 		

							val irtermedNonPay = ir_termedData.alias("parent").join(termed_nonpayFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
									$"child.state".alias("s_state"), 
									$"nbrpoa_issued_bronze_sgp", $"nbrpoa_issued_silver_sgp", $"nbrpoa_issued_gold_sgp", $"nbrpoa_issued_platinum_sgp",
									$"nbrpoa_issued_total_sgp", 
									$"nbrpoa_issued_gtlgp", $"nbrpoa_issued_gtsgp",$"nbrpoa_issued_gtip", $"nbrpoa_issued_total_gtip",
									$"nbrpoa_renewed_bronze_sgp", $"nbrpoa_renewed_silver_sgp", $"nbrpoa_renewed_gold_sgp", $"nbrpoa_renewed_platinum_sgp",
									$"nbrpoa_renewed_total_sgp",
									$"nbrpoa_renewed_gtlgp",$"nbrpoa_renewed_gtsgp",$"nbrpoa_renewed_gtip", $"nbrpoa_renewed_total_gtip",
									$"nbrpoa_termed_bronze_sgp", $"nbrpoa_termed_silver_sgp", $"nbrpoa_termed_gold_sgp", $"nbrpoa_termed_platinum_sgp", $"nbrpoa_termed_total_sgp",
									$"nbrpoa_termed_gtlgp", $"nbrpoa_termed_gtsgp", $"nbrpoa_termed_gtip", $"nbrpoa_termed_total_gtip",
									$"nbrpoa_termed_nonpay_bronze_sgp", $"nbrpoa_termed_nonpay_silver_sgp", $"nbrpoa_termed_nonpay_gold_sgp", $"nbrpoa_termed_nonpay_platinum_sgp", $"nbrpoa_termed_nonpay_total_sgp",
									$"nbrpoa_termed_nonpay_gtlgp", $"nbrpoa_termed_nonpay_gtsgp", $"nbrpoa_termed_nonpay_gtip", $"nbrpoa_termed_nonpay_total_gtip")

							val finalData = irtermedNonPay.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", lit("OUTOFF"))
							.select("outoff_exchange", "health_year", "cmpny_cf_cd", "state", 
									"nbrpoa_issued_bronze_sgp", "nbrpoa_issued_silver_sgp", "nbrpoa_issued_gold_sgp", "nbrpoa_issued_platinum_sgp", "nbrpoa_issued_total_sgp", 
									"nbrpoa_issued_gtlgp", "nbrpoa_issued_gtsgp", "nbrpoa_issued_gtip","nbrpoa_issued_total_gtip", 
									"nbrpoa_renewed_bronze_sgp", "nbrpoa_renewed_silver_sgp", "nbrpoa_renewed_gold_sgp", "nbrpoa_renewed_platinum_sgp", "nbrpoa_renewed_total_sgp", 
									"nbrpoa_renewed_gtlgp", "nbrpoa_renewed_gtsgp", "nbrpoa_renewed_gtip","nbrpoa_renewed_total_gtip",
									"nbrpoa_termed_bronze_sgp", "nbrpoa_termed_silver_sgp", "nbrpoa_termed_gold_sgp", "nbrpoa_termed_platinum_sgp", "nbrpoa_termed_total_sgp", 
									"nbrpoa_termed_gtlgp", "nbrpoa_termed_gtsgp", "nbrpoa_termed_gtip", "nbrpoa_termed_total_gtip",
									"nbrpoa_termed_nonpay_bronze_sgp", "nbrpoa_termed_nonpay_silver_sgp", "nbrpoa_termed_nonpay_gold_sgp", "nbrpoa_termed_nonpay_platinum_sgp", "nbrpoa_termed_nonpay_total_sgp", 
									"nbrpoa_termed_nonpay_gtlgp", "nbrpoa_termed_nonpay_gtsgp", "nbrpoa_termed_nonpay_gtip", "nbrpoa_termed_nonpay_total_gtip") 	

							finalData

			}

}

object PCADX_SCL_NAIC2018_OEXStgTransformation_POA_SG {
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val oex = new PCADX_SCL_NAIC2018_OEXStgTransformation_POA_SG()
		oex.sparkInIt()
	}
}