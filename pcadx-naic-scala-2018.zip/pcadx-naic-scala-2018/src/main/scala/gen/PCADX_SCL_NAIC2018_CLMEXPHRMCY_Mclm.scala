package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator

import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit
class PCADX_SCL_NAIC2018_CLMEXPHRMCY_Mclm {
   val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()
    import spark.implicits._
  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_CLMEXPHRMCY_Mclm])
     val dbWrk = dbProperties.getProperty("work.db")
     val dbInbnd = dbProperties.getProperty("inbound.db")
	    val clmexRcvdStrtDt = dbProperties.getProperty("CLM_EX_RCVD_DT_STRT")
	    val clmexRcvdEndDt = dbProperties.getProperty("CLM_EX_RCVD_DT_END")
	    
     val reportYear =dbProperties.getProperty("report.year")
     
     val wrhDb = dbProperties.getProperty("warehouse.db")
	 val audit_log_df = spark.sql("select * from "+wrhDb+".audt_load_log") 
    val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString() 
    println("load_log_key : "+load_log_key)
     println(clmexRcvdEndDt)
     println(clmexRcvdStrtDt)
     
  def naic_mcas_mclm_wrk() = """INSERT OVERWRITE TABLE  """+dbWrk+""".naic2018_mcas_mclm_wrk         
 SELECT 
 x.health_year,
 x.CLM_ADJSTMNT_KEY  ,
x.CLM_LINE_NBR    ,
x.CLM_SOR_CD       ,
x.MBR_KEY     ,
x.MBRSHP_SOR_CD   ,
x.PRMPT_PAY_CLM_RCVD_DT ,
x.CLM_RCVD_DT ,
x.ADJDCTN_STTS_CD,
x.RPTG_CLM_ADJDCTN_STTS_CD ,
x.CLM_DISP_CD  ,
CASE  
WHEN   x.ADJDCTN_DT < x.PRMPT_PAY_CLM_RCVD_DT    THEN  x.PRMPT_PAY_CLM_RCVD_DT
  ELSE  x.ADJDCTN_DT
  END  AS      ADJDCTN_DT  , 

x.SRVC_RNDRG_TYPE_CD ,
x.SRC_BILLG_TAX_ID,
CASE  
WHEN   x.GL_POST_DT < x.PRMPT_PAY_CLM_RCVD_DT    THEN  x.PRMPT_PAY_CLM_RCVD_DT
  ELSE  x.GL_POST_DT
  END  AS       GL_POST_DT  ,

x.BNFT_PKG_ID  ,
x.INN_CD       ,
x.CLM_LINE_STTS_CD      ,
x.RPTG_CLM_LINE_ADJDCTN_STTS_CD ,
x.BNFT_PAYMNT_STTS_CD   ,
x.PAID_AMT   ,
x.CPAY_AMT  ,
x.COINSRN_AMT   ,
x.DDCTBL_AMT   ,
x.SRC_SRVC_DNL_RSN_CD     ,
x.SRC_EOB_CD   ,
x.EOB_CD ,
x.SRC_CLM_LINE_DISP_RSN_CD,
x.CLM_LINE_SRVC_STRT_DT,
x.DIAG_1_CD                       AS DIAG_1_CD ,
x.DIAG_2_CD                       AS DIAG_2_CD ,
x.DIAG_3_CD                       AS DIAG_3_CD ,
x.DIAG_4_CD                       AS DIAG_4_CD ,
x.HLTH_SRVC_CD                    AS HLTH_SRVC_CD ,
x.HLTH_SRVC_TYPE_CD              AS HLTH_SRVC_TYPE_CD,
x.ICD_PROC_CD                   AS ICD_PROC_CD ,
x.ICD_VRSN_CD                   AS ICD_VRSN_CD,
x.load_log_key,
x.load_dt   
 FROM         
( 
SELECT 
"""+reportYear+"""  as health_year,
C.CLM_ADJSTMNT_KEY       AS   CLM_ADJSTMNT_KEY  ,
CL.CLM_LINE_NBR           AS    CLM_LINE_NBR    ,
C.CLM_SOR_CD             AS    CLM_SOR_CD       ,
C.MBR_KEY                     AS   MBR_KEY     ,
C.MBRSHP_SOR_CD           AS     MBRSHP_SOR_CD   ,
CASE  
WHEN  (C.PRMPT_PAY_CLM_RCVD_DT  = '1111-01-01 00:00:00.0' or  C.PRMPT_PAY_CLM_RCVD_DT  ='8888-12-31 00:00:00.0' ) THEN  C.CLM_RCVD_DT 
WHEN  CP.GL_POST_DT < C.PRMPT_PAY_CLM_RCVD_DT  OR C.ADJDCTN_DT < C.PRMPT_PAY_CLM_RCVD_DT    THEN  C.CLM_RCVD_DT
  ELSE  C.PRMPT_PAY_CLM_RCVD_DT 
  END  AS      PRMPT_PAY_CLM_RCVD_DT  , 
C.CLM_RCVD_DT                    AS  CLM_RCVD_DT  ,
C.ADJDCTN_STTS_CD         AS   ADJDCTN_STTS_CD ,
C.RPTG_CLM_ADJDCTN_STTS_CD  AS  RPTG_CLM_ADJDCTN_STTS_CD,
C.CLM_DISP_CD                 AS  CLM_DISP_CD ,
C.ADJDCTN_DT                 AS   ADJDCTN_DT , 
C.SRVC_RNDRG_TYPE_CD       AS   SRVC_RNDRG_TYPE_CD ,
C.SRC_BILLG_TAX_ID       AS SRC_BILLG_TAX_ID,
CP.GL_POST_DT               AS   GL_POST_DT  ,
 CL.BNFT_PKG_ID               AS      BNFT_PKG_ID  ,
CL.INN_CD                          AS   INN_CD  ,
CL.CLM_LINE_STTS_CD        AS    CLM_LINE_STTS_CD  ,
CL.RPTG_CLM_LINE_ADJDCTN_STTS_CD  AS  RPTG_CLM_LINE_ADJDCTN_STTS_CD,
CL.BNFT_PAYMNT_STTS_CD           AS   BNFT_PAYMNT_STTS_CD ,
CL.PAID_AMT                    AS    PAID_AMT  ,
CL.CPAY_AMT                    AS   CPAY_AMT  ,
CL.COINSRN_AMT                 AS    COINSRN_AMT  ,
CL.DDCTBL_AMT                 AS  DDCTBL_AMT ,
CL.SRC_SRVC_DNL_RSN_CD         AS  SRC_SRVC_DNL_RSN_CD  ,
CLE.SRC_EOB_CD                AS  SRC_EOB_CD ,
CLE.EOB_CD             AS  EOB_CD ,
CLD.SRC_CLM_LINE_DISP_RSN_CD     AS  SRC_CLM_LINE_DISP_RSN_CD,
CL.CLM_LINE_SRVC_STRT_DT    AS CLM_LINE_SRVC_STRT_DT,
CL.DIAG_1_CD                      AS DIAG_1_CD ,
CL.DIAG_2_CD                      AS DIAG_2_CD ,
CL.DIAG_3_CD                      AS DIAG_3_CD ,
CL.DIAG_4_CD                      AS DIAG_4_CD ,
CL.HLTH_SRVC_CD                   AS HLTH_SRVC_CD ,
CL.HLTH_SRVC_TYPE_CD              AS HLTH_SRVC_TYPE_CD,
CIP.ICD_PROC_CD                   AS ICD_PROC_CD ,
CIP.ICD_VRSN_CD                   AS ICD_VRSN_CD,
"""+load_log_key+"""  as load_log_key,
current_timestamp as load_dt
FROM """+dbInbnd+""".CLM C
INNER JOIN """+dbInbnd+""".CLM_MAX_RVSN CMR         
ON C.CLM_ADJSTMNT_KEY=CMR.CLM_ADJSTMNT_KEY

INNER JOIN """+dbInbnd+""".CLM_LINE CL
ON C.CLM_ADJSTMNT_KEY=CL.CLM_ADJSTMNT_KEY
AND C.ADJDCTN_DT =CL.ADJDCTN_DT

LEFT OUTER JOIN """+dbInbnd+""".CLM_PAID CP
ON C.CLM_ADJSTMNT_KEY=CP.CLM_ADJSTMNT_KEY

LEFT OUTER JOIN """+dbInbnd+""".CLM_LINE_EOB CLE
ON CL.CLM_ADJSTMNT_KEY = CLE.CLM_ADJSTMNT_KEY
AND CL.CLM_LINE_NBR = CLE.CLM_LINE_NBR

LEFT OUTER JOIN """+dbInbnd+""".CLM_LINE_DISP CLD
ON CL.CLM_ADJSTMNT_KEY = CLD.CLM_ADJSTMNT_KEY
AND CL.CLM_LINE_NBR = CLD.CLM_LINE_NBR


LEFT OUTER JOIN """+dbInbnd+""".CLM_ICD_PROC CIP
ON C.CLM_ADJSTMNT_KEY = CIP.CLM_ADJSTMNT_KEY

WHERE C.SRVC_RNDRG_TYPE_CD IN (  'PHYSN' , 'PANCL' , 'HOSP' , 'FANCL' )          
AND C.CLM_DISP_CD NOT IN ('VOID','RVRSL') 
AND C.RPTG_CLM_ADJDCTN_STTS_CD NOT IN ('03','10','04','11')
AND  CL.RPTG_CLM_LINE_ADJDCTN_STTS_CD NOT IN  ('VOID')
AND ( 
(C.PRMPT_PAY_CLM_RCVD_DT BETWEEN  """+clmexRcvdStrtDt+"""  AND """+clmexRcvdEndDt+""" )
  OR ( C.PRMPT_PAY_CLM_RCVD_DT  = '1111-01-01 00:00:00.0' or  C.PRMPT_PAY_CLM_RCVD_DT  ='8888-12-31 00:00:00.0')
  OR ( C.ADJDCTN_DT  BETWEEN  """+clmexRcvdStrtDt+"""  AND """+clmexRcvdEndDt+""" ) 
    OR ( CP.GL_POST_DT  BETWEEN  """+clmexRcvdStrtDt+"""  AND """+clmexRcvdEndDt+""" ) 
    )

GROUP BY  
C.CLM_ADJSTMNT_KEY       ,
CL.CLM_LINE_NBR            ,
C.CLM_SOR_CD               ,
C.MBR_KEY                         ,
C.MBRSHP_SOR_CD              ,
C.PRMPT_PAY_CLM_RCVD_DT   , 
C.CLM_RCVD_DT                      ,
C.ADJDCTN_STTS_CD         ,
C.RPTG_CLM_ADJDCTN_STTS_CD,
C.CLM_DISP_CD                  ,
C.ADJDCTN_DT                  ,
C.SRVC_RNDRG_TYPE_CD        ,
C.SRC_BILLG_TAX_ID,
CL.BNFT_PKG_ID                 ,
CP.GL_POST_DT                ,
CL.INN_CD                            ,
CL.CLM_LINE_STTS_CD          ,
CL.RPTG_CLM_LINE_ADJDCTN_STTS_CD  ,
CL.BNFT_PAYMNT_STTS_CD         ,
CL.PAID_AMT                   ,
CL.CPAY_AMT                   ,
CL.COINSRN_AMT                ,
CL.DDCTBL_AMT               ,
CL.SRC_SRVC_DNL_RSN_CD        ,
CLE.SRC_EOB_CD              ,
CLE.EOB_CD       ,
CLD.SRC_CLM_LINE_DISP_RSN_CD,
CL.CLM_LINE_SRVC_STRT_DT,
CL.DIAG_1_CD    ,
CL.DIAG_2_CD    ,
CL.DIAG_3_CD    ,
CL.DIAG_4_CD    ,
CL.HLTH_SRVC_CD  ,
CL.HLTH_SRVC_TYPE_CD ,
CIP.ICD_PROC_CD  ,
CIP.ICD_VRSN_CD

) x

--09/17
--WHERE x.PRMPT_PAY_CLM_RCVD_DT  BETWEEN  """+clmexRcvdStrtDt+"""  AND """+clmexRcvdEndDt+"""

"""
  
  
   def sparkInIt(){
    spark.sql(naic_mcas_mclm_wrk())
  }
}
object PCADX_SCL_NAIC2018_CLMEXPHRMCY_Mclm{
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val clmexPhmy = new PCADX_SCL_NAIC2018_CLMEXPHRMCY_Mclm()
		//OEX.setYear(args(1))
		clmexPhmy.sparkInIt()
	}
}