package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit
import org.apache.hadoop.fs._;

class PCADX_SCL_NAIC2018_CLMPHRMCY_TmpWrk {
  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
                                     config("hive.exec.dynamic.partition.mode", "nonstrict").
                                     config("spark.sql.parquet.compression.codec", "snappy").
                                     config("hive.warehouse.data.skipTrash", "true").
                                     config("spark.sql.parquet.writeLegacyFormat", "true").
                                     enableHiveSupport().getOrCreate()
  import spark.implicits._
  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_CLMPHRMCY_TmpWrk])
  val dbWrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
	val wrhDb = dbProperties.getProperty("warehouse.db")
	val prcp_cd = dbProperties.getProperty("PRCP_TYPE_CD")
	val audit_log_df = spark.sql("select * from "+wrhDb+".audt_load_log") 
  val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString() 
  println("load_log_key : "+load_log_key)
  val reportYear =dbProperties.getProperty("report.year")
  
  def naic2018_mcas_clm_wrk_inter() ="""
     INSERT overwrite TABLE """+dbWrk+""".clm_inter 
SELECT     mpe.mbr_key         AS mbr_key , 
           mpe.mbrshp_sor_cd   AS mbrshp_sor_cd, 
           mpe.grndfthr_ind_cd AS grndfthr_ind_cd , 
           mpe.prod_ofrg_key, 
           mpe.mbr_prod_enrlmnt_efctv_dt, 
           mpe.mbr_prod_enrlmnt_trmntn_dt ,
           mpe.dup_data_cd	    AS dup_data_cd , 
           mpecoa.mbu_cf_cd   AS mbu_cf_cd , 
           mpecoa.prod_cf_cd  AS prod_cf_cd, 
           mpecoa.cmpny_cf_cd AS cmpny_cf_cd, 
           mpecoa.fundg_cf_cd AS fundg_cf_cd, 
           mpecoa.mbr_coa_efctv_dt	AS mbr_coa_efctv_dt, 
           mpecoa.mbr_coa_trmntn_dt AS br_coa_trmntn_dt,
           bp.bnft_pkg_key, 
           po.prchsr_org_nbr, 
           po.prchsr_org_type_cd, 
           po.rltd_prchsr_org_nbr, 
           po.rltd_prchsr_org_type_cd, 
           po.prod_ofrg_trmntn_dt, 
           PRCHSR_ORG_SUBGROUP.SRC_GRP_NBR as src_grp_nbr ,
           PRCHSR_ORG_SUBGROUP.SRC_SUBGRP_NBR as src_subgrp_nbr,
           PRCHSR_ORG_GROUP.SRC_SUBGRP_NBR as ORG_GRP_SRC_SUBGRP_NBR,
           PRCHSR_ORG_GROUP.SRC_GRP_NBR as ORG_GRP_SRC_GRP_NBR,
           PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_EFCTV_DT,
           PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TRMNTN_DT,
           PRCP.PRCP_TYPE_CD AS PRCP_TYPE_CD ,
           BPA.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD , 
           BPA.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
           BPA.EXCHNG_IND_CD AS EXCHNG_IND_CD,
           BPA.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
           BPA.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
           MHE.HIX_CD AS HIX_CD, 
           """+load_log_key+""", 
           current_timestamp 
FROM       """+dbInbnd+""".mbr_prod_enrlmnt mpe 
INNER JOIN """+dbInbnd+""".prod_ofrg po 
ON         mpe.prod_ofrg_key=po.prod_ofrg_key 
AND        po.rcrd_stts_cd <> 'DEL' 
INNER JOIN """+dbInbnd+""".bnft_pkg bp 
ON         po.bnft_pkg_key = bp.bnft_pkg_key 
AND        bp.rcrd_stts_cd <> 'DEL' 
INNER JOIN """+dbInbnd+""".bnft_pkg_prcp bpp 
ON         ( 
                      bp.bnft_pkg_key=bpp.bnft_pkg_key 
           AND        bp.prod_sor_cd=bpp.prod_sor_cd 
           AND        mpe.mbr_prod_enrlmnt_efctv_dt <= bpp.bnft_pkg_prcp_trmntn_dt 
           AND        mpe.mbr_prod_enrlmnt_trmntn_dt >= bpp.bnft_pkg_prcp_efctv_dt 
           AND        bpp.rcrd_stts_cd <> 'DEL') 
INNER JOIN """+dbInbnd+""".prcp 
ON         ( 
                      bpp.prcp_id=prcp.prcp_id 
           AND        bpp.prod_sor_cd=prcp.prod_sor_cd 
           AND        prcp.rcrd_stts_cd <> 'DEL') 
INNER JOIN """+dbInbnd+""".mbr_prod_enrlmnt_coa mpecoa 
ON         mpe.mbr_key = mpecoa.mbr_key 
AND        mpe.prod_ofrg_key = mpecoa.prod_ofrg_key 
AND        mpe.mbr_prod_enrlmnt_efctv_dt = mpecoa.mbr_prod_enrlmnt_efctv_dt 
AND        mpecoa.rcrd_stts_cd <> 'DEL' 

LEFT JOIN  """+dbInbnd+""".PRCHSR_ORG AS PRCHSR_ORG_GROUP                                                        
ON         PO.MBRSHP_SOR_CD = PRCHSR_ORG_GROUP.MBRSHP_SOR_CD                                                        
AND        PO.PRCHSR_ORG_NBR = PRCHSR_ORG_GROUP.PRCHSR_ORG_NBR                                                        
AND        PO.PRCHSR_ORG_TYPE_CD = PRCHSR_ORG_GROUP.PRCHSR_ORG_TYPE_CD      
AND        PRCHSR_ORG_GROUP.PRCHSR_ORG_TYPE_CD = '03'                                                        
AND        PRCHSR_ORG_GROUP.RCRD_STTS_CD <> 'DEL'                                                        
LEFT JOIN  """+dbInbnd+""".PRCHSR_ORG AS PRCHSR_ORG_SUBGROUP                                                        
ON         PO.MBRSHP_SOR_CD = PRCHSR_ORG_SUBGROUP.MBRSHP_SOR_CD                                                        
AND        PO.RLTD_PRCHSR_ORG_NBR = PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_NBR
AND        PO.RLTD_PRCHSR_ORG_TYPE_CD = PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TYPE_CD                                                    
AND        PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TYPE_CD = '04'                                                        
AND        PRCHSR_ORG_SUBGROUP.RCRD_STTS_CD <> 'DEL'

LEFT OUTER JOIN """ + dbInbnd + """.MBR_HIX_ENRLMNT MHE
 ON MPE.MBR_KEY = MHE.MBR_KEY
 AND MPE.PROD_OFRG_KEY = MHE.PROD_OFRG_KEY
 AND MPE.MBR_PROD_ENRLMNT_EFCTV_DT = MHE.MBR_PROD_ENRLMNT_EFCTV_DT
 AND MHE.RCRD_STTS_CD <> 'DEL'
 
LEFT OUTER JOIN """ + dbInbnd + """.BNFT_PKG_ADDNL BPA
  ON BP.BNFT_PKG_KEY = BPA.BNFT_PKG_KEY 
  AND BPA.RCRD_STTS_CD <> 'DEL' 

WHERE      mpe.rcrd_stts_cd<>'DEL' 
AND        mpe.mbrshp_sor_cd NOT LIKE '5%' 
AND        mpe.mbrshp_sor_cd <> '1104' 
AND        mpe.scrty_lvl_cd NOT IN ( 'F') 
AND        prcp.prcp_type_cd    IN ( """+prcp_cd+""" ) 
GROUP BY   mpe.mbr_key , 
           mpe.mbrshp_sor_cd , 
           mpe.grndfthr_ind_cd , 
           mpe.prod_ofrg_key,
           mpe.dup_data_cd,
           mpe.mbr_prod_enrlmnt_efctv_dt, 
           mpe.mbr_prod_enrlmnt_trmntn_dt, 
           mpecoa.mbu_cf_cd , 
           mpecoa.prod_cf_cd , 
           mpecoa.cmpny_cf_cd , 
           mpecoa.fundg_cf_cd ,
           mpecoa.mbr_coa_efctv_dt, 
           mpecoa.mbr_coa_trmntn_dt, 
           bp.bnft_pkg_key , 
           po.prchsr_org_nbr, 
           po.prchsr_org_type_cd, 
           po.rltd_prchsr_org_nbr, 
           po.rltd_prchsr_org_type_cd, 
           po.prod_ofrg_trmntn_dt,
           PRCHSR_ORG_SUBGROUP.SRC_GRP_NBR,
           PRCHSR_ORG_SUBGROUP.SRC_SUBGRP_NBR,
           PRCHSR_ORG_GROUP.SRC_SUBGRP_NBR,
           PRCHSR_ORG_GROUP.SRC_GRP_NBR,
           PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_EFCTV_DT,
           PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TRMNTN_DT,
           PRCP.PRCP_TYPE_CD,
           BPA.GRNDFTHRG_STTS_CD , 
           BPA.hcr_cmplynt_cd  ,
           BPA.EXCHNG_IND_CD ,
           BPA.EXCHNG_METL_TYPE_CD ,
           BPA.SRC_EXCHNG_CERTFN_CD ,
           MHE.HIX_CD
"""
  def sparkInIt(){
    spark.sql(naic2018_mcas_clm_wrk_inter())
    spark.close()
  }
}

object PCADX_SCL_NAIC2018_CLMPHRMCY_TmpWrk{
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val clmPhmy = new PCADX_SCL_NAIC2018_CLMPHRMCY_TmpWrk()
		clmPhmy.sparkInIt()
	}


}