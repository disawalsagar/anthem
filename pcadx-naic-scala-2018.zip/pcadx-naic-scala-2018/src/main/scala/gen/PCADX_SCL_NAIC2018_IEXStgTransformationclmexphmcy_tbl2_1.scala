package gen

import java.util.Properties
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.sql.Timestamp
import java.util.Properties
import java.io._
import java.io.FileInputStream
import java.io.IOException;

import org.apache.log4j.PropertyConfigurator
import org.slf4j.{ Logger, LoggerFactory }

import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._
import org.apache.spark.SparkContext

import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import scala.io.Source

class PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_tbl2_1(val spark: SparkSession) {

  import spark.implicits._

  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_tbl2_1])

  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clmex")
  val end_year = dbProperties.getProperty("end_year_clmex")

  def sparkInIt(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame,
                naic2018_mcas_ce_src_eob_cd_inbnd: DataFrame, naic2018_mcas_ce_eob_cd_inbnd: DataFrame, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
                naic2018_mcas_pa_eob_cd_inbnd: DataFrame, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd: DataFrame, naic2018_mcas_pa_src_eob_cd_inbnd: DataFrame,
                naic2018_mcas_ncb_eob_cd_inbnd: DataFrame, naic2018_mcas_ncb_src_eob_cd_inbnd: DataFrame, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
                naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
                naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame, load_log_key: String) {

    val oexclmphrmcy = new PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_2018(spark)

    val objDeniedOuntwk_ce = oexclmphrmcy.getDeniedOutntwkce(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk,
      naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val objDeniedOuntwk_pa = oexclmphrmcy.getDeniedOutntwkpa(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk,
      naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val objDeniedOuntwk_ncb = oexclmphrmcy.getDeniedOutntwkncb(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk,
      naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val objDeniedOuntwk_ebh = oexclmphrmcy.getDeniedOutntwkebh(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk,
      naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val objDeniedOuntwk_bh = oexclmphrmcy.getDeniedOutntwkbh(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk,
      naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val StgData_1 = getStageData(objDeniedOuntwk_ce, objDeniedOuntwk_pa, objDeniedOuntwk_ncb, objDeniedOuntwk_ebh, objDeniedOuntwk_bh)

    val f_stgData = StgData_1.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
    oexclmphrmcy.writeDataToHive(dbwrk + ".naic2018_mcas_hlthiex_clmexphmcy_DenoutColstemp_1", f_stgData)

  }

  def getStageData(objDeniedOuntwk_ce: DataFrame, objDeniedOuntwk_pa: DataFrame, objDeniedOuntwk_ncb: DataFrame, objDeniedOuntwk_ebh: DataFrame, objDeniedOuntwk_bh: DataFrame): DataFrame = {

    val rec_outntwkcepa = objDeniedOuntwk_ce.alias("parent").join(objDeniedOuntwk_pa.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"), $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"), $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"), col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"),
        col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"), col("nbrclm_denied_outntwk_ce_bronze_ms_ip"), col("nbrclm_denied_outntwk_ce_silver_ms_ip"), col("nbrclm_denied_outntwk_ce_gold_ms_ip"),
        col("nbrclm_denied_outntwk_ce_platinum_ms_ip"), col("nbrclm_denied_outntwk_ce_total_ms_ip"), col("nbrclm_denied_outntwk_ce_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ce_silver_ms_sgp"), col("nbrclm_denied_outntwk_ce_gold_ms_sgp"), col("nbrclm_denied_outntwk_ce_platinum_ms_sgp"), col("nbrclm_denied_outntwk_ce_total_ms_sgp"),
        col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"), col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"),
        col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"), col("nbrclm_denied_outntwk_pa_bronze_ms_ip"), col("nbrclm_denied_outntwk_pa_silver_ms_ip"), col("nbrclm_denied_outntwk_pa_gold_ms_ip"), col("nbrclm_denied_outntwk_pa_platinum_ms_ip"),
        col("nbrclm_denied_outntwk_pa_total_ms_ip"), col("nbrclm_denied_outntwk_pa_bronze_ms_sgp"), col("nbrclm_denied_outntwk_pa_silver_ms_sgp"), col("nbrclm_denied_outntwk_pa_gold_ms_sgp"), col("nbrclm_denied_outntwk_pa_platinum_ms_sgp"), col("nbrclm_denied_outntwk_pa_total_ms_sgp"))

    val rec_outntwk_cepaData = rec_outntwkcepa.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year")).withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny")).withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state")).withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("in_exchange", "health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip", "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp",
        "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic", "nbrclm_denied_outntwk_ce_bronze_ms_ip", "nbrclm_denied_outntwk_ce_silver_ms_ip", "nbrclm_denied_outntwk_ce_gold_ms_ip", "nbrclm_denied_outntwk_ce_platinum_ms_ip", "nbrclm_denied_outntwk_ce_total_ms_ip", "nbrclm_denied_outntwk_ce_bronze_ms_sgp",
        "nbrclm_denied_outntwk_ce_silver_ms_sgp", "nbrclm_denied_outntwk_ce_gold_ms_sgp", "nbrclm_denied_outntwk_ce_platinum_ms_sgp", "nbrclm_denied_outntwk_ce_total_ms_sgp", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic", "nbrclm_denied_outntwk_pa_bronze_ms_ip", "nbrclm_denied_outntwk_pa_silver_ms_ip", "nbrclm_denied_outntwk_pa_gold_ms_ip",
        "nbrclm_denied_outntwk_pa_platinum_ms_ip", "nbrclm_denied_outntwk_pa_total_ms_ip", "nbrclm_denied_outntwk_pa_bronze_ms_sgp", "nbrclm_denied_outntwk_pa_silver_ms_sgp", "nbrclm_denied_outntwk_pa_gold_ms_sgp", "nbrclm_denied_outntwk_pa_platinum_ms_sgp", "nbrclm_denied_outntwk_pa_total_ms_sgp")

    val rec_outntwkcepancb = rec_outntwk_cepaData.alias("parent").join(objDeniedOuntwk_ncb.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"), $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"), $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"), col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"),
        col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"), col("nbrclm_denied_outntwk_ce_bronze_ms_ip"), col("nbrclm_denied_outntwk_ce_silver_ms_ip"), col("nbrclm_denied_outntwk_ce_gold_ms_ip"),
        col("nbrclm_denied_outntwk_ce_platinum_ms_ip"), col("nbrclm_denied_outntwk_ce_total_ms_ip"), col("nbrclm_denied_outntwk_ce_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ce_silver_ms_sgp"), col("nbrclm_denied_outntwk_ce_gold_ms_sgp"), col("nbrclm_denied_outntwk_ce_platinum_ms_sgp"), col("nbrclm_denied_outntwk_ce_total_ms_sgp"),
        col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"), col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"),
        col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"), col("nbrclm_denied_outntwk_pa_bronze_ms_ip"), col("nbrclm_denied_outntwk_pa_silver_ms_ip"), col("nbrclm_denied_outntwk_pa_gold_ms_ip"), col("nbrclm_denied_outntwk_pa_platinum_ms_ip"),
        col("nbrclm_denied_outntwk_pa_total_ms_ip"), col("nbrclm_denied_outntwk_pa_bronze_ms_sgp"), col("nbrclm_denied_outntwk_pa_silver_ms_sgp"), col("nbrclm_denied_outntwk_pa_gold_ms_sgp"), col("nbrclm_denied_outntwk_pa_platinum_ms_sgp"), col("nbrclm_denied_outntwk_pa_total_ms_sgp"), col("nbrclm_denied_outntwk_ncb_bronze_ip"),
        col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"), col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"),
        col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"), col("nbrclm_denied_outntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_outntwk_ncb_silver_ms_ip"), col("nbrclm_denied_outntwk_ncb_gold_ms_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_outntwk_ncb_total_ms_ip"), col("nbrclm_denied_outntwk_ncb_bronze_ms_sgp"),
        col("nbrclm_denied_outntwk_ncb_silver_ms_sgp"), col("nbrclm_denied_outntwk_ncb_gold_ms_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_ms_sgp"), col("nbrclm_denied_outntwk_ncb_total_ms_sgp"))

    val rec_outntwkcepancb_data = rec_outntwkcepancb.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year")).withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny")).withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state")).withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("in_exchange", "health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip", "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp",
        "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic", "nbrclm_denied_outntwk_ce_bronze_ms_ip", "nbrclm_denied_outntwk_ce_silver_ms_ip", "nbrclm_denied_outntwk_ce_gold_ms_ip", "nbrclm_denied_outntwk_ce_platinum_ms_ip", "nbrclm_denied_outntwk_ce_total_ms_ip", "nbrclm_denied_outntwk_ce_bronze_ms_sgp",
        "nbrclm_denied_outntwk_ce_silver_ms_sgp", "nbrclm_denied_outntwk_ce_gold_ms_sgp", "nbrclm_denied_outntwk_ce_platinum_ms_sgp", "nbrclm_denied_outntwk_ce_total_ms_sgp", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic", "nbrclm_denied_outntwk_pa_bronze_ms_ip", "nbrclm_denied_outntwk_pa_silver_ms_ip", "nbrclm_denied_outntwk_pa_gold_ms_ip",
        "nbrclm_denied_outntwk_pa_platinum_ms_ip", "nbrclm_denied_outntwk_pa_total_ms_ip", "nbrclm_denied_outntwk_pa_bronze_ms_sgp", "nbrclm_denied_outntwk_pa_silver_ms_sgp", "nbrclm_denied_outntwk_pa_gold_ms_sgp", "nbrclm_denied_outntwk_pa_platinum_ms_sgp", "nbrclm_denied_outntwk_pa_total_ms_sgp", "nbrclm_denied_outntwk_ncb_bronze_ip",
        "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip", "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp",
        "nbrclm_denied_outntwk_ncb_catastrophic", "nbrclm_denied_outntwk_ncb_bronze_ms_ip", "nbrclm_denied_outntwk_ncb_silver_ms_ip", "nbrclm_denied_outntwk_ncb_gold_ms_ip", "nbrclm_denied_outntwk_ncb_platinum_ms_ip", "nbrclm_denied_outntwk_ncb_total_ms_ip", "nbrclm_denied_outntwk_ncb_bronze_ms_sgp", "nbrclm_denied_outntwk_ncb_silver_ms_sgp",
        "nbrclm_denied_outntwk_ncb_gold_ms_sgp", "nbrclm_denied_outntwk_ncb_platinum_ms_sgp", "nbrclm_denied_outntwk_ncb_total_ms_sgp")

    val rec_outntwkebh = rec_outntwkcepancb_data.alias("parent").join(objDeniedOuntwk_ebh.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"), $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"), $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"), col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"),
        col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"), col("nbrclm_denied_outntwk_ce_bronze_ms_ip"), col("nbrclm_denied_outntwk_ce_silver_ms_ip"), col("nbrclm_denied_outntwk_ce_gold_ms_ip"),
        col("nbrclm_denied_outntwk_ce_platinum_ms_ip"), col("nbrclm_denied_outntwk_ce_total_ms_ip"), col("nbrclm_denied_outntwk_ce_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ce_silver_ms_sgp"), col("nbrclm_denied_outntwk_ce_gold_ms_sgp"), col("nbrclm_denied_outntwk_ce_platinum_ms_sgp"), col("nbrclm_denied_outntwk_ce_total_ms_sgp"),
        col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"), col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"),
        col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"), col("nbrclm_denied_outntwk_pa_bronze_ms_ip"), col("nbrclm_denied_outntwk_pa_silver_ms_ip"), col("nbrclm_denied_outntwk_pa_gold_ms_ip"),
        col("nbrclm_denied_outntwk_pa_platinum_ms_ip"), col("nbrclm_denied_outntwk_pa_total_ms_ip"), col("nbrclm_denied_outntwk_pa_bronze_ms_sgp"), col("nbrclm_denied_outntwk_pa_silver_ms_sgp"), col("nbrclm_denied_outntwk_pa_gold_ms_sgp"), col("nbrclm_denied_outntwk_pa_platinum_ms_sgp"), col("nbrclm_denied_outntwk_pa_total_ms_sgp"),
        col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"), col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"),
        col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"), col("nbrclm_denied_outntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_outntwk_ncb_silver_ms_ip"), col("nbrclm_denied_outntwk_ncb_gold_ms_ip"),
        col("nbrclm_denied_outntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_outntwk_ncb_total_ms_ip"), col("nbrclm_denied_outntwk_ncb_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ncb_silver_ms_sgp"), col("nbrclm_denied_outntwk_ncb_gold_ms_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_ms_sgp"), col("nbrclm_denied_outntwk_ncb_total_ms_sgp"),
        col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"), col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"),
        col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"), col("nbrclm_denied_outntwk_ebh_catastrophic"), col("nbrclm_denied_outntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_outntwk_ebh_silver_ms_ip"), col("nbrclm_denied_outntwk_ebh_gold_ms_ip"),
        col("nbrclm_denied_outntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_outntwk_ebh_total_ms_ip"), col("nbrclm_denied_outntwk_ebh_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ebh_silver_ms_sgp"), col("nbrclm_denied_outntwk_ebh_gold_ms_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_ms_sgp"), col("nbrclm_denied_outntwk_ebh_total_ms_sgp"))

    val rec_outntwkebh_Data = rec_outntwkebh.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year")).withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny")).withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state")).withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("in_exchange", "health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip",
        "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip", "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp",
        "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic", "nbrclm_denied_outntwk_ce_bronze_ms_ip", "nbrclm_denied_outntwk_ce_silver_ms_ip", "nbrclm_denied_outntwk_ce_gold_ms_ip", "nbrclm_denied_outntwk_ce_platinum_ms_ip", "nbrclm_denied_outntwk_ce_total_ms_ip",
        "nbrclm_denied_outntwk_ce_bronze_ms_sgp", "nbrclm_denied_outntwk_ce_silver_ms_sgp", "nbrclm_denied_outntwk_ce_gold_ms_sgp", "nbrclm_denied_outntwk_ce_platinum_ms_sgp", "nbrclm_denied_outntwk_ce_total_ms_sgp", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip",
        "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip", "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp",
        "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic", "nbrclm_denied_outntwk_pa_bronze_ms_ip", "nbrclm_denied_outntwk_pa_silver_ms_ip", "nbrclm_denied_outntwk_pa_gold_ms_ip", "nbrclm_denied_outntwk_pa_platinum_ms_ip", "nbrclm_denied_outntwk_pa_total_ms_ip",
        "nbrclm_denied_outntwk_pa_bronze_ms_sgp", "nbrclm_denied_outntwk_pa_silver_ms_sgp", "nbrclm_denied_outntwk_pa_gold_ms_sgp", "nbrclm_denied_outntwk_pa_platinum_ms_sgp", "nbrclm_denied_outntwk_pa_total_ms_sgp", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip",
        "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip", "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp",
        "nbrclm_denied_outntwk_ncb_total_sgp", "nbrclm_denied_outntwk_ncb_catastrophic", "nbrclm_denied_outntwk_ncb_bronze_ms_ip", "nbrclm_denied_outntwk_ncb_silver_ms_ip", "nbrclm_denied_outntwk_ncb_gold_ms_ip", "nbrclm_denied_outntwk_ncb_platinum_ms_ip", "nbrclm_denied_outntwk_ncb_total_ms_ip",
        "nbrclm_denied_outntwk_ncb_bronze_ms_sgp", "nbrclm_denied_outntwk_ncb_silver_ms_sgp", "nbrclm_denied_outntwk_ncb_gold_ms_sgp", "nbrclm_denied_outntwk_ncb_platinum_ms_sgp", "nbrclm_denied_outntwk_ncb_total_ms_sgp", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip",
        "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip", "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp",
        "nbrclm_denied_outntwk_ebh_total_sgp", "nbrclm_denied_outntwk_ebh_catastrophic", "nbrclm_denied_outntwk_ebh_bronze_ms_ip", "nbrclm_denied_outntwk_ebh_silver_ms_ip", "nbrclm_denied_outntwk_ebh_gold_ms_ip", "nbrclm_denied_outntwk_ebh_platinum_ms_ip", "nbrclm_denied_outntwk_ebh_total_ms_ip",
        "nbrclm_denied_outntwk_ebh_bronze_ms_sgp", "nbrclm_denied_outntwk_ebh_silver_ms_sgp", "nbrclm_denied_outntwk_ebh_gold_ms_sgp", "nbrclm_denied_outntwk_ebh_platinum_ms_sgp", "nbrclm_denied_outntwk_ebh_total_ms_sgp")

    val rec_outntwkbh = rec_outntwkebh_Data.alias("parent").join(objDeniedOuntwk_bh.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"), $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"), $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"), col("nbrclm_denied_outntwk_ce_bronze_sgp"),
        col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"), col("nbrclm_denied_outntwk_ce_bronze_ms_ip"),
        col("nbrclm_denied_outntwk_ce_silver_ms_ip"), col("nbrclm_denied_outntwk_ce_gold_ms_ip"), col("nbrclm_denied_outntwk_ce_platinum_ms_ip"), col("nbrclm_denied_outntwk_ce_total_ms_ip"), col("nbrclm_denied_outntwk_ce_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ce_silver_ms_sgp"),
        col("nbrclm_denied_outntwk_ce_gold_ms_sgp"), col("nbrclm_denied_outntwk_ce_platinum_ms_sgp"), col("nbrclm_denied_outntwk_ce_total_ms_sgp"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"),
        col("nbrclm_denied_outntwk_pa_total_ip"), col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_ip"), col("nbrclm_denied_outntwk_pa_silver_ms_ip"), col("nbrclm_denied_outntwk_pa_gold_ms_ip"), col("nbrclm_denied_outntwk_pa_platinum_ms_ip"), col("nbrclm_denied_outntwk_pa_total_ms_ip"), col("nbrclm_denied_outntwk_pa_bronze_ms_sgp"),
        col("nbrclm_denied_outntwk_pa_silver_ms_sgp"), col("nbrclm_denied_outntwk_pa_gold_ms_sgp"), col("nbrclm_denied_outntwk_pa_platinum_ms_sgp"), col("nbrclm_denied_outntwk_pa_total_ms_sgp"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"),
        col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"), col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"),
        col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"), col("nbrclm_denied_outntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_outntwk_ncb_silver_ms_ip"), col("nbrclm_denied_outntwk_ncb_gold_ms_ip"),
        col("nbrclm_denied_outntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_outntwk_ncb_total_ms_ip"), col("nbrclm_denied_outntwk_ncb_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ncb_silver_ms_sgp"), col("nbrclm_denied_outntwk_ncb_gold_ms_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_ms_sgp"),
        col("nbrclm_denied_outntwk_ncb_total_ms_sgp"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"), col("nbrclm_denied_outntwk_ebh_bronze_sgp"),
        col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"), col("nbrclm_denied_outntwk_ebh_catastrophic"), col("nbrclm_denied_outntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_outntwk_ebh_silver_ms_ip"),
        col("nbrclm_denied_outntwk_ebh_gold_ms_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_outntwk_ebh_total_ms_ip"), col("nbrclm_denied_outntwk_ebh_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ebh_silver_ms_sgp"), col("nbrclm_denied_outntwk_ebh_gold_ms_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_ms_sgp"),
        col("nbrclm_denied_outntwk_ebh_total_ms_sgp"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"), col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"),
        col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"), col("nbrclm_denied_outntwk_bh_total_sgp"), col("nbrclm_denied_outntwk_bh_catastrophic"), col("nbrclm_denied_outntwk_bh_bronze_ms_ip"), col("nbrclm_denied_outntwk_bh_silver_ms_ip"), col("nbrclm_denied_outntwk_bh_gold_ms_ip"),
        col("nbrclm_denied_outntwk_bh_platinum_ms_ip"), col("nbrclm_denied_outntwk_bh_total_ms_ip"), col("nbrclm_denied_outntwk_bh_bronze_ms_sgp"), col("nbrclm_denied_outntwk_bh_silver_ms_sgp"), col("nbrclm_denied_outntwk_bh_gold_ms_sgp"), col("nbrclm_denied_outntwk_bh_platinum_ms_sgp"), col("nbrclm_denied_outntwk_bh_total_ms_sgp"))

    val Outntwk_outData = rec_outntwkbh.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year")).withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny")).withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state")).withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("in_exchange", "health_year", "cmpny_cf_cd", "state",
        "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip", "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp",
        "nbrclm_denied_outntwk_ce_catastrophic", "nbrclm_denied_outntwk_ce_bronze_ms_ip", "nbrclm_denied_outntwk_ce_silver_ms_ip", "nbrclm_denied_outntwk_ce_gold_ms_ip", "nbrclm_denied_outntwk_ce_platinum_ms_ip", "nbrclm_denied_outntwk_ce_total_ms_ip", "nbrclm_denied_outntwk_ce_bronze_ms_sgp", "nbrclm_denied_outntwk_ce_silver_ms_sgp", "nbrclm_denied_outntwk_ce_gold_ms_sgp",
        "nbrclm_denied_outntwk_ce_platinum_ms_sgp", "nbrclm_denied_outntwk_ce_total_ms_sgp", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip", "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp",
        "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic", "nbrclm_denied_outntwk_pa_bronze_ms_ip", "nbrclm_denied_outntwk_pa_silver_ms_ip", "nbrclm_denied_outntwk_pa_gold_ms_ip", "nbrclm_denied_outntwk_pa_platinum_ms_ip", "nbrclm_denied_outntwk_pa_total_ms_ip", "nbrclm_denied_outntwk_pa_bronze_ms_sgp",
        "nbrclm_denied_outntwk_pa_silver_ms_sgp", "nbrclm_denied_outntwk_pa_gold_ms_sgp", "nbrclm_denied_outntwk_pa_platinum_ms_sgp", "nbrclm_denied_outntwk_pa_total_ms_sgp", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp", "nbrclm_denied_outntwk_ncb_catastrophic", "nbrclm_denied_outntwk_ncb_bronze_ms_ip", "nbrclm_denied_outntwk_ncb_silver_ms_ip", "nbrclm_denied_outntwk_ncb_gold_ms_ip",
        "nbrclm_denied_outntwk_ncb_platinum_ms_ip", "nbrclm_denied_outntwk_ncb_total_ms_ip", "nbrclm_denied_outntwk_ncb_bronze_ms_sgp", "nbrclm_denied_outntwk_ncb_silver_ms_sgp", "nbrclm_denied_outntwk_ncb_gold_ms_sgp", "nbrclm_denied_outntwk_ncb_platinum_ms_sgp", "nbrclm_denied_outntwk_ncb_total_ms_sgp", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip",
        "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip", "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp", "nbrclm_denied_outntwk_ebh_total_sgp", "nbrclm_denied_outntwk_ebh_catastrophic",
        "nbrclm_denied_outntwk_ebh_bronze_ms_ip", "nbrclm_denied_outntwk_ebh_silver_ms_ip", "nbrclm_denied_outntwk_ebh_gold_ms_ip", "nbrclm_denied_outntwk_ebh_platinum_ms_ip", "nbrclm_denied_outntwk_ebh_total_ms_ip", "nbrclm_denied_outntwk_ebh_bronze_ms_sgp", "nbrclm_denied_outntwk_ebh_silver_ms_sgp", "nbrclm_denied_outntwk_ebh_gold_ms_sgp", "nbrclm_denied_outntwk_ebh_platinum_ms_sgp",
        "nbrclm_denied_outntwk_ebh_total_ms_sgp", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip", "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp",
        "nbrclm_denied_outntwk_bh_total_sgp", "nbrclm_denied_outntwk_bh_catastrophic", "nbrclm_denied_outntwk_bh_bronze_ms_ip", "nbrclm_denied_outntwk_bh_silver_ms_ip", "nbrclm_denied_outntwk_bh_gold_ms_ip", "nbrclm_denied_outntwk_bh_platinum_ms_ip", "nbrclm_denied_outntwk_bh_total_ms_ip", "nbrclm_denied_outntwk_bh_bronze_ms_sgp", "nbrclm_denied_outntwk_bh_silver_ms_sgp",
        "nbrclm_denied_outntwk_bh_gold_ms_sgp", "nbrclm_denied_outntwk_bh_platinum_ms_sgp", "nbrclm_denied_outntwk_bh_total_ms_sgp")

    Outntwk_outData

  }

}

object PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_tbl2_1 {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))

  }

}