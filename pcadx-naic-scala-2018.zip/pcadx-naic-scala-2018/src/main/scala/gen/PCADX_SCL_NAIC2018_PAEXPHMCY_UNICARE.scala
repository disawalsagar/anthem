package gen

class PCADX_SCL_NAIC2018_PAEXPHMCY_UNICARE {

	def rqstdLgrp(dbInbnd: String, tbl: String) = """ 
			SELECT 
			PA1.RFRNC_NBR AS RFRNC_NBR ,
			MPE.MBR_KEY AS MBR_KEY,
			MPE.MBRSHP_SOR_CD AS MBRSHP_SOR_CD, 
			MPE.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
			BPA.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,   
			BPA.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
			BPA.EXCHNG_IND_CD AS EXCHNG_IND_CD,
			BPA.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			BPA.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			MPECOA.MBU_CF_CD AS MBU_CF_CD ,
			MPECOA.PROD_CF_CD AS PROD_CF_CD,
			'G0365'        AS CMPNY_CF_CD,
			MPECOA.FUNDG_CF_CD AS FUNDG_CF_CD,
			'MA'  AS  State,
			NULL   AS IN_Exchange ,
			'OUTOFF'  AS OUTOFF_Exchange, 
			'LARGE GROUP CBE'  AS naic_lob,
			MED.GL_CF_DESC  as  naic_prod_desc


			FROM ad36743.PriorAuth1_Shyam PA1
			INNER JOIN EDW_ALLPHI.MBR_PROD_ENRLMNT MPE
			ON PA1.MBR_KEY = MPE.MBR_KEY
			INNER  JOIN EDW_ALLPHI.PROD_OFRG PO
			ON MPE.PROD_OFRG_KEY=PO.PROD_OFRG_KEY   
			AND PO.RCRD_STTS_CD <> 'DEL'
			INNER JOIN EDW_ALLPHI.BNFT_PKG BP
			ON PO.BNFT_PKG_KEY = BP.BNFT_PKG_KEY   
			AND BP.RCRD_STTS_CD <> 'DEL'
			INNER JOIN  EDW_ALLPHI.BNFT_PKG_PRCP BPP
			ON (BP.BNFT_PKG_KEY=BPP.BNFT_PKG_KEY   
			AND BP.PROD_SOR_CD=BPP.PROD_SOR_CD  
			AND MPE.MBR_PROD_ENRLMNT_EFCTV_DT <= BPP.BNFT_PKG_PRCP_TRMNTN_DT 
			AND MPE.MBR_PROD_ENRLMNT_TRMNTN_DT >= BPP.BNFT_PKG_PRCP_EFCTV_DT
			AND BPP.RCRD_STTS_CD <> 'DEL')  
			INNER JOIN PRCP  
			ON (BPP.PRCP_ID=PRCP.PRCP_ID   
			AND BPP.PROD_SOR_CD=PRCP.PROD_SOR_CD  
			AND PRCP.RCRD_STTS_CD <> 'DEL')  
			INNER JOIN EDW_ALLPHI.MBR_PROD_ENRLMNT_COA MPECOA
			ON MPE.MBR_KEY = MPECOA.MBR_KEY
			AND MPE.PROD_OFRG_KEY = MPECOA.PROD_OFRG_KEY
			AND MPE.MBR_PROD_ENRLMNT_EFCTV_DT = MPECOA.MBR_PROD_ENRLMNT_EFCTV_DT
			AND MPECOA.RCRD_STTS_CD <> 'DEL'

			inner join (
			select CF_CD,  GL_CF_DESC  
			from EDW_NOPHI.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			group by 1,2
			) as MED
			on MED.CF_CD = MPECOA.PROD_CF_CD

			inner join
			(
			select DISTINCT CF_CD
			from EDW_NOPHI.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from EDW_NOPHI.GL_CF_VRTCL_HRCHY  
			WHERE 1=1     
			AND     GL_CF_TYPE_DESC = 'FUND_CODE' 
			AND    ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC
			ON FC.CF_CD = MPECOA.FUNDG_CF_CD

			LEFT JOIN EDW_ALLPHI.PRCHSR_ORG AS PRCHSR_ORG_GROUP                                                        
			ON PO.MBRSHP_SOR_CD = PRCHSR_ORG_GROUP.MBRSHP_SOR_CD                                                        
			AND PO.PRCHSR_ORG_NBR = PRCHSR_ORG_GROUP.PRCHSR_ORG_NBR                                                        
			AND PO.PRCHSR_ORG_TYPE_CD = PRCHSR_ORG_GROUP.PRCHSR_ORG_TYPE_CD                                                        
			AND PRCHSR_ORG_GROUP.PRCHSR_ORG_TYPE_CD = '03'                                                        
			AND PRCHSR_ORG_GROUP.RCRD_STTS_CD <> 'DEL'                                                        
			LEFT JOIN EDW_ALLPHI.PRCHSR_ORG AS PRCHSR_ORG_SUBGROUP                                                        
			ON PO.MBRSHP_SOR_CD = PRCHSR_ORG_SUBGROUP.MBRSHP_SOR_CD                                                        
			AND PO.RLTD_PRCHSR_ORG_NBR = PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_NBR                                                        
			AND PO.RLTD_PRCHSR_ORG_TYPE_CD = PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TYPE_CD                                                        
			AND PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TYPE_CD = '04'                                                        
			AND PRCHSR_ORG_SUBGROUP.RCRD_STTS_CD <> 'DEL'            

			LEFT OUTER JOIN EDW_ALLPHI.BNFT_PKG_ADDNL BPA
			ON BP.BNFT_PKG_KEY = BPA.BNFT_PKG_KEY 
			AND BPA.RCRD_STTS_CD <> 'DEL'

			WHERE 1=1     
			AND MPE.RCRD_STTS_CD<>'DEL'
			AND MPE.MBRSHP_SOR_CD NOT LIKE '5%'
			AND MPE.MBRSHP_SOR_CD <> '1104'
			AND MPE.SCRTY_LVL_CD NOT  IN ( 'F')
			AND PRCP.PRCP_TYPE_CD IN ('01','02','03','04','49')

			and PRCHSR_ORG_SUBGROUP.SRC_GRP_NBR = '131192'

			AND (                                                        
			((PRCHSR_ORG_GROUP.PRCHSR_ORG_TRMNTN_DT >= CURRENT_DATE) 
			OR PRCHSR_ORG_GROUP.PRCHSR_ORG_TRMNTN_DT IS NULL)                                                        
			AND ((PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TRMNTN_DT >= CURRENT_DATE) 
			OR PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TRMNTN_DT IS NULL)                                                        
			AND ((PO.PROD_OFRG_TRMNTN_DT >= CURRENT_DATE) 
			OR PO.PROD_OFRG_TRMNTN_DT IS NULL)                                                             
			AND ((MPECOA.MBR_COA_TRMNTN_DT >= CURRENT_DATE)                                                        
			OR MPECOA.MBR_COA_TRMNTN_DT IS NULL)                                                        
			)    
			AND MPE.DUP_DATA_CD = '00'   

			GROUP BY 
			PA1.RFRNC_NBR  ,
			MPE.MBR_KEY ,
			MPE.MBRSHP_SOR_CD , 
			MPE.GRNDFTHR_IND_CD  ,
			BPA.GRNDFTHRG_STTS_CD ,    
			BPA.hcr_cmplynt_cd,
			BPA.EXCHNG_IND_CD ,
			BPA.EXCHNG_METL_TYPE_CD ,
			BPA.SRC_EXCHNG_CERTFN_CD ,
			MPECOA.MBU_CF_CD  ,
			MPECOA.PROD_CF_CD ,
			MPECOA.FUNDG_CF_CD ,
			MED.GL_CF_DESC 
			)
			"""
}