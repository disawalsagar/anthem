package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator

import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit
import collection.mutable.HashMap
import org.apache.hadoop.fs._;
class PCADX_SCL_NAIC2018_CLMPHRMCY_Denied{
  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()
    import spark.implicits._
  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_CLMPHRMCY_Denied])
  val wrhDb = dbProperties.getProperty("warehouse.db")
	 val audit_log_df = spark.sql("select * from "+wrhDb+".audt_load_log") 
    val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString() 
    println("load_log_key : "+load_log_key)
     val dbWrk = dbProperties.getProperty("work.db")
     val dbInbnd = dbProperties.getProperty("inbound.db")
     val reportYear =dbProperties.getProperty("report.year")
     val clm_adjStrt_dt =dbProperties.getProperty("CLM_ADJDCTN_DT_STRT_DT")
     val clm_adjEnd_dt =dbProperties.getProperty("CLM_ADJDCTN_DT_END_DT")
  def naic_mcas_pclm_denied_wrk() = """Insert overwrite table """+dbWrk+""".naic2018_mcas_pclm_denied_wrk"""+"""
    select * from              
( 
SELECT 
"""+reportYear+"""  as health_year,
pclm_wrk.MBR_KEY,
pclm_wrk.RX_FILLED_DT, 
pclm_wrk.ADJDCTN_DT,   
pclm_wrk.NDC,
pclm_wrk.RX_NBR,
pclm_wrk.SRC_GRP_NBR,
pclm_wrk.SRC_SRVC_DNL_RSN_CD,
pclm_wrk.INN_CD,
max(pclm_wrk.CLM_NBR) AS CLM_NBR,
"""+load_log_key+""",
current_timestamp

FROM """+dbWrk+""".naic2018_mcas_pclm_wrk  pclm_wrk

where  pclm_wrk.RPTG_CLM_LINE_ADJDCTN_STTS_CD in ('DND','DNDZB')
and pclm_wrk.ADJDCTN_DT BETWEEN """+clm_adjStrt_dt+"""  AND   """+clm_adjEnd_dt+"""

GROUP BY 
pclm_wrk.MBR_KEY,
pclm_wrk.RX_FILLED_DT, 
pclm_wrk.ADJDCTN_DT,   
pclm_wrk.NDC,
pclm_wrk.RX_NBR,
pclm_wrk.SRC_GRP_NBR,
pclm_wrk.SRC_SRVC_DNL_RSN_CD,
pclm_wrk.INN_CD

)"""
  
  
   def sparkInIt(){
    spark.sql(naic_mcas_pclm_denied_wrk())
    spark.close()
  }
}
object PCADX_SCL_NAIC2018_CLMPHRMCY_Denied{
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val clmPhmy = new PCADX_SCL_NAIC2018_CLMPHRMCY_Denied()
		clmPhmy.sparkInIt()
		

	}


}