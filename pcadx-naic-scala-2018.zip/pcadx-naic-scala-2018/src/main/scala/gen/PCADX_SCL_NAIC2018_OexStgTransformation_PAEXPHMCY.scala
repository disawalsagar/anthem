package gen

import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;

class PCADX_SCL_NAIC2018_OexStgTransformation_PAEXPHMCY {

  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()

  import spark.implicits._

  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_OexStgTransformation_PAEXPHMCY])

  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val tblreq = dbProperties.getProperty("requested_pa.tbl")
  val tblapp = dbProperties.getProperty("approved_pa.tbl")
  val tblden = dbProperties.getProperty("denied_pa.tbl")
  val uri: String = dbProperties.getProperty("uri")
  val mbu_cf_cdvals = dbProperties.getProperty("mbu_Cf_cdVals").split(",").toSeq

  val naic_lob_lgp = Seq("LARGE GROUP CBE EXCLUDING MEDICARE", "TOTAL NATIONAL CBE")
  val case_type_cd_val = Seq("MEH", "SUA")

  //val  mbu_cf_cdvals= Seq("EDCASH","EDCOSH","EDCTSH","EDGASH","EDINSH","EDKYSH","EDMESH","EDMOSH","EDNHSH","EDNVSH","EDNYSH","EDOHSH","EDVASH","EDWISH","SHUNCE","SHUNEA","SHUNWS")

  def sparkInIt() {

    //val objPCADX_SCL_NAIC_DataExtraction = new PCADX_SCL_NAIC_DataExtraction()
    val naic2018_mcas_hlthex_paexphmcy_reqstd_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_paexphmcy_reqstd_wrk")
    val naic2018_mcas_hlthex_paexphmcy_apprvd_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_paexphmcy_apprvd_wrk")
    val naic2018_mcas_hlthex_paexphmcy_denied_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_paexphmcy_denied_wrk")

    val stageTblData = populateStageTbl(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk, naic2018_mcas_hlthex_paexphmcy_apprvd_wrk, naic2018_mcas_hlthex_paexphmcy_denied_wrk)
    writeDataToHive(dbsg + ".naic2018_mcas_hlthoex_paexphmcy_stg", stageTblData)

    spark.close()
  }

  def writeDataToHive(tblName: String, finalDf: DataFrame) {
    finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
    println("Data added in stage table")
  }

  def readDataFromHive(tble: String): DataFrame = {
    val queryOutputTable = """SELECT * FROM """ + tble
    val tbl_data_df = spark.sql(queryOutputTable)
    //.na.fill("")
    logger.info("Read data from hive")
    tbl_data_df
  }

  def populateStageTbl(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk: DataFrame, naic2018_mcas_hlthex_paexphmcy_apprvd_wrk: DataFrame,
                       naic2018_mcas_hlthex_paexphmcy_denied_wrk: DataFrame): DataFrame = {
    val final_df = null
    val reqFinalDf = getRequestedData(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk)
    //reqFinalDf.show()
    val appFinalDf = getApprovededData(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk, naic2018_mcas_hlthex_paexphmcy_reqstd_wrk)

    val denFinalDf = getDeniedData(naic2018_mcas_hlthex_paexphmcy_denied_wrk, naic2018_mcas_hlthex_paexphmcy_reqstd_wrk)

    var load_log_key = ""

    if (!naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.take(1).isEmpty) {
      load_log_key = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk.select($"load_log_key").first.getString(0)
    }

    val stageTblData = getFinalData(reqFinalDf, appFinalDf, denFinalDf).toDF().withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());

    stageTblData

  }

  def getRequestedData(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk: DataFrame): DataFrame = {

    val nbrpa_rqstd_total_ip = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").isNull)
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").equalTo("Y")
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r1"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r1"), $"state".alias("state_r1"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_total_ip"))

    val nbrpa_rqstd_total_ip_pcols = nbrpa_rqstd_total_ip.select($"health_year_r1", $"cmpny_cf_cd_r1", $"state_r1")

    val nbrpa_rqstd_total_sgp = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").isNull)
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").equalTo("Y")
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r2"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r2"), $"state".alias("state_r2"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_total_sgp"))

    val nbrpa_rqstd_total_sgp_pcols = nbrpa_rqstd_total_sgp.select($"health_year_r2", $"cmpny_cf_cd_r2", $"state_r2")

    val nbrpa_rqstd_gtlgp = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").isin(naic_lob_lgp: _*)
        //&& (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").equalTo("YES")
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r6"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r6"), $"state".alias("state_r6"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_gtlgp"))

    val nbrpa_rqstd_gtlgp_pcols = nbrpa_rqstd_gtlgp.select($"health_year_r6", $"cmpny_cf_cd_r6", $"state_r6")

    val nbrpa_rqstd_gtsgp = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r7"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r7"), $"state".alias("state_r7"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_gtsgp"))

    val nbrpa_rqstd_gtsgp_pcols = nbrpa_rqstd_gtsgp.select($"health_year_r7", $"cmpny_cf_cd_r7", $"state_r7")

    val nbrpa_rqstd_gtip = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r8"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r8"), $"state".alias("state_r8")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_gtip"))

    val nbrpa_rqstd_gtip_pcols = nbrpa_rqstd_gtip.select($"health_year_r8", $"cmpny_cf_cd_r8", $"state_r8")

    //nbrpa_rqstd_gtlgp + nbrpa_rqstd_gtsgp + nbrpa_rqstd_gtip
    val getTotal_ip = nbrpa_rqstd_gtlgp.union(nbrpa_rqstd_gtsgp.union(nbrpa_rqstd_gtip))
      .select($"health_year_r6".alias("health_year_r11"), $"cmpny_cf_cd_r6".alias("cmpny_cf_cd_r11"), $"state_r6".alias("state_r11"), $"nbrpa_rqstd_gtlgp")

    val nbrpa_rqstd_total_gtip = getTotal_ip.groupBy("health_year_r11", "cmpny_cf_cd_r11", "state_r11")
    .agg(sum($"nbrpa_rqstd_gtlgp").alias("nbrpa_rqstd_total_gtip"))

    val nbrpa_rqstd_total_gtip_pcols = nbrpa_rqstd_total_gtip.select($"health_year_r11", $"cmpny_cf_cd_r11", $"state_r11")
    //nbrpa_rqstd_total_gtip.show()

    val nbrpa_rqstd_catastrophic = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_prod_desc").like("%CATASTROPHIC%")
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r3"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r3"), $"state".alias("state_r3"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_catastrophic"))

    val nbrpa_rqstd_catastrophic_pcols = nbrpa_rqstd_catastrophic.select($"health_year_r3", $"cmpny_cf_cd_r3", $"state_r3")

    val nbrpa_rqstd_lgp_mmcare = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").isNull)
        && (!naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*))
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r9"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r9"), $"state".alias("state_r9"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_lgp_mmcare"))

    val nbrpa_rqstd_lgp_mmcarep_pcols = nbrpa_rqstd_lgp_mmcare.select($"health_year_r9", $"cmpny_cf_cd_r9", $"state_r9")

    val nbrpa_rqstd_stucvg = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r10"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r10"), $"state".alias("state_r10"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_stucvg"))

    val nbrpa_rqstd_stucvg_pcols = nbrpa_rqstd_stucvg.select($"health_year_r10", $"cmpny_cf_cd_r10", $"state_r10")

    val nbrpa_rqstd_bh_total_ip = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").isNull)
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").equalTo("Y")
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r12"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r12"), $"state".alias("state_r12"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_bh_total_ip"))

    val nbrpa_rqstd_bh_total_ip_pcols = nbrpa_rqstd_bh_total_ip.select($"health_year_r12", $"cmpny_cf_cd_r12", $"state_r12")

    val nbrpa_rqstd_bh_total_sgp = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").isNull)
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("src_exchng_certfn_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").equalTo("Y")
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r13"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r13"), $"state".alias("state_r13"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_bh_total_sgp"))

    val nbrpa_rqstd_bh_total_sgp_pcols = nbrpa_rqstd_bh_total_sgp.select($"health_year_r13", $"cmpny_cf_cd_r13", $"state_r13")

    val nbrpa_rqstd_bh_gtlgp = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").equalTo("YES")
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r14"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r14"), $"state".alias("state_r14"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_bh_gtlgp"))

    val nbrpa_rqstd_bh_gtlgp_pcols = nbrpa_rqstd_bh_gtlgp.select($"health_year_r14", $"cmpny_cf_cd_r14", $"state_r14")

    val nbrpa_rqstd_bh_gtsgp = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r15"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r15"), $"state".alias("state_r15"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_bh_gtsgp"))

    val nbrpa_rqstd_bh_gtsgp_pcols = nbrpa_rqstd_bh_gtsgp.select($"health_year_r15", $"cmpny_cf_cd_r15", $"state_r15")

    val nbrpa_rqstd_bh_gtip = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r16"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r16"), $"state".alias("state_r16"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_bh_gtip"))

    val nbrpa_rqstd_bh_gtip_pcols = nbrpa_rqstd_bh_gtip.select($"health_year_r16", $"cmpny_cf_cd_r16", $"state_r16")

    val getTotal_bh_ip = nbrpa_rqstd_bh_gtlgp.union(nbrpa_rqstd_bh_gtsgp.union(nbrpa_rqstd_bh_gtip))
      .select($"health_year_r14".alias("health_year_r17"), $"cmpny_cf_cd_r14".alias("cmpny_cf_cd_r17"), $"state_r14".alias("state_r17"), $"nbrpa_rqstd_bh_gtlgp")
    val nbrpa_rqstd_bh_total_gtip = getTotal_bh_ip.groupBy("health_year_r17", "cmpny_cf_cd_r17", "state_r17")
        .agg(sum($"nbrpa_rqstd_bh_gtlgp").alias("nbrpa_rqstd_bh_total_gtip"))

    val nbrpa_rqstd_bh_total_gtip_pcols = nbrpa_rqstd_bh_total_gtip.select($"health_year_r17", $"cmpny_cf_cd_r17", $"state_r17")

    
    
    val nbrpa_rqstd_bh_catastrophic = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
    .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_prod_desc").like("%CATASTROPHIC%")
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("case_type_cd").isin(case_type_cd_val: _*))
      .groupBy($"health_year".alias("health_year_r18"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r18"), $"state".alias("state_r18"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_bh_catastrophic"))
      
      println("##################")
      println("nbrpa_rqstd_bh_catastrophic" + nbrpa_rqstd_bh_catastrophic.show)

    val nbrpa_rqstd_bh_catastrophic_pcols = nbrpa_rqstd_bh_catastrophic.select($"health_year_r18", $"cmpny_cf_cd_r18", $"state_r18")

    val nbrpa_rqstd_bh_lgp_mmcare = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("grndfthr_ind_cd").isNull)
        && (!naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*))
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r19"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r19"), $"state".alias("state_r19")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_bh_lgp_mmcare"))

    val nbrpa_rqstd_bh_lgp_mmcare_pcols = nbrpa_rqstd_bh_lgp_mmcare.select($"health_year_r19", $"cmpny_cf_cd_r19", $"state_r19")

    val nbrpa_rqstd_bh_stucvg = naic2018_mcas_hlthex_paexphmcy_reqstd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*)
        && naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_reqstd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r20"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r20"), $"state".alias("state_r20")).agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_rqstd_bh_stucvg"))

    val nbrpa_rqstd_bh_stucvg_pcols = nbrpa_rqstd_bh_stucvg.select($"health_year_r20", $"cmpny_cf_cd_r20", $"state_r20")

    val reqmaster = (nbrpa_rqstd_total_ip_pcols.union(nbrpa_rqstd_total_sgp_pcols.union(nbrpa_rqstd_gtlgp_pcols.union(nbrpa_rqstd_gtsgp_pcols
      .union(nbrpa_rqstd_gtip_pcols.union(nbrpa_rqstd_total_gtip_pcols.union(nbrpa_rqstd_catastrophic_pcols.union(nbrpa_rqstd_lgp_mmcarep_pcols.union(nbrpa_rqstd_stucvg_pcols
        .union(nbrpa_rqstd_bh_total_ip_pcols.union(nbrpa_rqstd_bh_total_sgp_pcols.union(nbrpa_rqstd_bh_gtlgp_pcols.union(nbrpa_rqstd_bh_gtsgp_pcols
          .union(nbrpa_rqstd_bh_gtip_pcols.union(nbrpa_rqstd_bh_total_gtip_pcols.union(nbrpa_rqstd_bh_catastrophic_pcols.union(nbrpa_rqstd_bh_lgp_mmcare_pcols
            .union(nbrpa_rqstd_bh_stucvg_pcols))))))))))))))))))
      .select($"health_year_r1".alias("health_year"), $"cmpny_cf_cd_r1".alias("cmpny_cf_cd"), $"state_r1".alias("state")).distinct

    //val reqmaster_1 = (nbrpa_rqstd_total_ms_sgp_pcols.union(nbrpa_rqstd_total_ms_ip_pcols.union(nbrpa_rqstd_catastrophic_pcols.union(nbrpa_rqstd_total_ip_pcols.union(nbrpa_rqstd_total_sgp_pcols))))).select($"health_year_r5".alias("health_year"),$"cmpny_cf_cd_r5".alias("cmpny_cf_cd"),$"state_r5".alias("state")).distinct

    val reqjoin1 = reqmaster.join(nbrpa_rqstd_total_ip, reqmaster("health_year") === nbrpa_rqstd_total_ip("health_year_r1") &&
      reqmaster("cmpny_cf_cd") === nbrpa_rqstd_total_ip("cmpny_cf_cd_r1") && reqmaster("state") === nbrpa_rqstd_total_ip("state_r1"), "left_outer").select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip")

    val reqjoin2 = reqjoin1.join(nbrpa_rqstd_total_sgp, reqjoin1("health_year") === nbrpa_rqstd_total_sgp("health_year_r2") &&
      reqjoin1("cmpny_cf_cd") === nbrpa_rqstd_total_sgp("cmpny_cf_cd_r2") && reqjoin1("state") === nbrpa_rqstd_total_sgp("state_r2"), "left_outer").select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp")

    /* val reqjoin3 = reqjoin2.join(nbrpa_rqstd_catastrophic,reqjoin2("health_year")===nbrpa_rqstd_catastrophic("health_year_r3") &&
    reqjoin2("cmpny_cf_cd")===nbrpa_rqstd_catastrophic("cmpny_cf_cd_r3") && reqjoin2("state")===nbrpa_rqstd_catastrophic("state_r3")  ,"left_outer").select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_rqstd_total_ip",$"nbrpa_rqstd_total_sgp",$"nbrpa_rqstd_catastrophic")*/

    val reqjoin3 = reqjoin2.join(nbrpa_rqstd_gtlgp, reqjoin2("health_year") === nbrpa_rqstd_gtlgp("health_year_r6") &&
      reqjoin2("cmpny_cf_cd") === nbrpa_rqstd_gtlgp("cmpny_cf_cd_r6") && reqjoin2("state") === nbrpa_rqstd_gtlgp("state_r6"), "left_outer").select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp")

    val reqjoin4 = reqjoin3.join(nbrpa_rqstd_gtsgp, reqjoin3("health_year") === nbrpa_rqstd_gtsgp("health_year_r7") &&
      reqjoin3("cmpny_cf_cd") === nbrpa_rqstd_gtsgp("cmpny_cf_cd_r7") && reqjoin3("state") === nbrpa_rqstd_gtsgp("state_r7"), "left_outer").select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp")

    val reqjoin5 = reqjoin4.join(nbrpa_rqstd_gtip, reqjoin4("health_year") === nbrpa_rqstd_gtip("health_year_r8") &&
      reqjoin4("cmpny_cf_cd") === nbrpa_rqstd_gtip("cmpny_cf_cd_r8") && reqjoin4("state") === nbrpa_rqstd_gtip("state_r8"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp",
        $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip")
    //reqjoin5.show()

    /*    val reqjoin6 = reqjoin5.join(nbrpa_rqstd_total_gtip,reqjoin5("health_year")===nbrpa_rqstd_total_gtip("health_year_r11") &&
    reqjoin5("cmpny_cf_cd")===nbrpa_rqstd_total_gtip("cmpny_cf_cd_r11") && reqjoin5("state")===nbrpa_rqstd_total_gtip("state_r11") &&
    "left_outer")
    .select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_rqstd_total_ip",$"nbrpa_rqstd_total_sgp",
        $"nbrpa_rqstd_gtlgp",$"nbrpa_rqstd_gtsgp",$"nbrpa_rqstd_gtip",$"nbrpa_rqstd_total_gtip")*/

    val reqjoin6 = reqjoin5.join(nbrpa_rqstd_total_gtip, reqjoin5("health_year") === nbrpa_rqstd_total_gtip("health_year_r11") &&
      reqjoin5("cmpny_cf_cd") === nbrpa_rqstd_total_gtip("cmpny_cf_cd_r11") && reqjoin5("state") === nbrpa_rqstd_total_gtip("state_r11"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp",
        $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip")

    val reqjoin7 = reqjoin6.join(nbrpa_rqstd_catastrophic, reqjoin6("health_year") === nbrpa_rqstd_catastrophic("health_year_r3") &&
      reqjoin6("cmpny_cf_cd") === nbrpa_rqstd_catastrophic("cmpny_cf_cd_r3") && reqjoin6("state") === nbrpa_rqstd_catastrophic("state_r3"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp",
        $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic")

    val reqjoin8 = reqjoin7.join(nbrpa_rqstd_lgp_mmcare, reqjoin7("health_year") === nbrpa_rqstd_lgp_mmcare("health_year_r9") &&
      reqjoin7("cmpny_cf_cd") === nbrpa_rqstd_lgp_mmcare("cmpny_cf_cd_r9") && reqjoin7("state") === nbrpa_rqstd_lgp_mmcare("state_r9"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp",
        $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_lgp_mmcare")

    val reqjoin9 = reqjoin8.join(nbrpa_rqstd_stucvg, reqjoin8("health_year") === nbrpa_rqstd_stucvg("health_year_r10") &&
      reqjoin8("cmpny_cf_cd") === nbrpa_rqstd_stucvg("cmpny_cf_cd_r10") && reqjoin8("state") === nbrpa_rqstd_stucvg("state_r10"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip",
        $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic",
        $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg")

    val reqjoin10 = reqjoin9.join(nbrpa_rqstd_bh_total_ip, reqjoin9("health_year") === nbrpa_rqstd_bh_total_ip("health_year_r12") &&
      reqjoin9("cmpny_cf_cd") === nbrpa_rqstd_bh_total_ip("cmpny_cf_cd_r12") && reqjoin9("state") === nbrpa_rqstd_bh_total_ip("state_r12"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip",
        $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic",
        $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg", $"nbrpa_rqstd_bh_total_ip")

    val reqjoin11 = reqjoin10.join(nbrpa_rqstd_bh_total_sgp, reqjoin10("health_year") === nbrpa_rqstd_bh_total_sgp("health_year_r13") &&
      reqjoin10("cmpny_cf_cd") === nbrpa_rqstd_bh_total_sgp("cmpny_cf_cd_r13") && reqjoin10("state") === nbrpa_rqstd_bh_total_sgp("state_r13"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip",
        $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic",
        $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp")

    val reqjoin12 = reqjoin11.join(nbrpa_rqstd_bh_gtlgp, reqjoin11("health_year") === nbrpa_rqstd_bh_gtlgp("health_year_r14") &&
      reqjoin11("cmpny_cf_cd") === nbrpa_rqstd_bh_gtlgp("cmpny_cf_cd_r14") && reqjoin11("state") === nbrpa_rqstd_bh_gtlgp("state_r14"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip",
        $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic",
        $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_gtlgp")

    val reqjoin13 = reqjoin12.join(nbrpa_rqstd_bh_gtsgp, reqjoin12("health_year") === nbrpa_rqstd_bh_gtsgp("health_year_r15") &&
      reqjoin12("cmpny_cf_cd") === nbrpa_rqstd_bh_gtsgp("cmpny_cf_cd_r15") && reqjoin12("state") === nbrpa_rqstd_bh_gtsgp("state_r15"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip",
        $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic",
        $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_gtlgp", $"nbrpa_rqstd_bh_gtsgp")

    val reqjoin14 = reqjoin13.join(nbrpa_rqstd_bh_gtip, reqjoin13("health_year") === nbrpa_rqstd_bh_gtip("health_year_r16") &&
      reqjoin13("cmpny_cf_cd") === nbrpa_rqstd_bh_gtip("cmpny_cf_cd_r16") && reqjoin13("state") === nbrpa_rqstd_bh_gtip("state_r16"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip",
        $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic",
        $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_gtlgp", $"nbrpa_rqstd_bh_gtsgp",
        $"nbrpa_rqstd_bh_gtip")

    val reqjoin15 = reqjoin14.join(nbrpa_rqstd_bh_total_gtip, reqjoin14("health_year") === nbrpa_rqstd_bh_total_gtip("health_year_r17") &&
      reqjoin14("cmpny_cf_cd") === nbrpa_rqstd_bh_total_gtip("cmpny_cf_cd_r17") && reqjoin14("state") === nbrpa_rqstd_bh_total_gtip("state_r17"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip",
        $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic",
        $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_gtlgp", $"nbrpa_rqstd_bh_gtsgp",
        $"nbrpa_rqstd_bh_gtip", $"nbrpa_rqstd_bh_total_gtip")

    val reqjoin16 = reqjoin15.join(nbrpa_rqstd_bh_catastrophic, reqjoin15("health_year") === nbrpa_rqstd_bh_catastrophic("health_year_r18") &&
      reqjoin15("cmpny_cf_cd") === nbrpa_rqstd_bh_catastrophic("cmpny_cf_cd_r18") && reqjoin15("state") === nbrpa_rqstd_bh_catastrophic("state_r18"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip",
        $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic",
        $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_gtlgp", $"nbrpa_rqstd_bh_gtsgp",
        $"nbrpa_rqstd_bh_gtip", $"nbrpa_rqstd_bh_total_gtip", $"nbrpa_rqstd_bh_catastrophic")

    val reqjoin17 = reqjoin16.join(nbrpa_rqstd_bh_lgp_mmcare, reqjoin16("health_year") === nbrpa_rqstd_bh_lgp_mmcare("health_year_r19") &&
      reqjoin16("cmpny_cf_cd") === nbrpa_rqstd_bh_lgp_mmcare("cmpny_cf_cd_r19") && reqjoin16("state") === nbrpa_rqstd_bh_lgp_mmcare("state_r19"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip",
        $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic",
        $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_gtlgp", $"nbrpa_rqstd_bh_gtsgp",
        $"nbrpa_rqstd_bh_gtip", $"nbrpa_rqstd_bh_total_gtip", $"nbrpa_rqstd_bh_catastrophic", $"nbrpa_rqstd_bh_lgp_mmcare")

    val reqFinalDf = reqjoin17.join(nbrpa_rqstd_bh_stucvg, reqjoin17("health_year") === nbrpa_rqstd_bh_stucvg("health_year_r20") &&
      reqjoin17("cmpny_cf_cd") === nbrpa_rqstd_bh_stucvg("cmpny_cf_cd_r20") && reqjoin17("state") === nbrpa_rqstd_bh_stucvg("state_r20"), "left_outer")
      .select($"health_year".alias("health_year_requested"), $"cmpny_cf_cd".alias("cmpny_cf_cd_requested"), $"state".alias("state_requested"), $"nbrpa_rqstd_total_ip",
        $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic",
        $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_gtlgp", $"nbrpa_rqstd_bh_gtsgp",
        $"nbrpa_rqstd_bh_gtip", $"nbrpa_rqstd_bh_total_gtip", $"nbrpa_rqstd_bh_catastrophic", $"nbrpa_rqstd_bh_lgp_mmcare", $"nbrpa_rqstd_bh_stucvg")

    reqFinalDf //.withColumn("outoff_exchange_requested", lit("OUTOFF"))

  }

  def getApprovededData(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk: DataFrame, naic2018_mcas_hlthex_paexphmcy_reqstd_wrk: DataFrame): DataFrame = {

    val nbrpa_aprvd_total_ip = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").isNull)
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").equalTo("Y")
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r1"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r1"), $"state".alias("state_r1"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_total_ip"))

    val nbrpa_aprvd_total_ip_pcols = nbrpa_aprvd_total_ip.select($"health_year_r1", $"cmpny_cf_cd_r1", $"state_r1")

    val nbrpa_aprvd_total_sgp = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").isNull)
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").equalTo("Y")
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r2"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r2"), $"state".alias("state_r2"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_total_sgp"))

    val nbrpa_aprvd_total_sgp_pcols = nbrpa_aprvd_total_sgp.select($"health_year_r2", $"cmpny_cf_cd_r2", $"state_r2")

    val nbrpa_aprvd_gtlgp = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").isin(naic_lob_lgp: _*)
        // on  0108 && (naic_mcas_hlthex_pa_aprvd_wrk("grndfthr_ind_cd").equalTo("YES") || naic_mcas_hlthex_pa_aprvd_wrk("hcr_cmplynt_cd").notEqual("Y")  || naic_mcas_hlthex_pa_aprvd_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").equalTo("YES")
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r6"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r6"), $"state".alias("state_r6"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_gtlgp"))

    val nbrpa_aprvd_gtlgp_pcols = nbrpa_aprvd_gtlgp.select($"health_year_r6", $"cmpny_cf_cd_r6", $"state_r6")

    val nbrpa_aprvd_gtsgp = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r7"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r7"), $"state".alias("state_r7"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_gtsgp"))

    val nbrpa_aprvd_gtsgp_pcols = nbrpa_aprvd_gtsgp.select($"health_year_r7", $"cmpny_cf_cd_r7", $"state_r7")

    val nbrpa_aprvd_gtip = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r8"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r8"), $"state".alias("state_r8"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_gtip"))

    val nbrpa_aprvd_gtip_pcols = nbrpa_aprvd_gtip.select($"health_year_r8", $"cmpny_cf_cd_r8", $"state_r8")

    //nbrpa_aprvd_gtlgp + nbrpa_aprvd_gtsgp + nbrpa_aprvd_gtip
    val getTotal_ip = nbrpa_aprvd_gtlgp.union(nbrpa_aprvd_gtsgp.union(nbrpa_aprvd_gtip))
      .select(
        $"health_year_r6".alias("health_year_r11"),
        $"cmpny_cf_cd_r6".alias("cmpny_cf_cd_r11"),
        $"state_r6".alias("state_r11"),
        $"nbrpa_aprvd_gtlgp")

    val nbrpa_aprvd_total_gtip = getTotal_ip.groupBy("health_year_r11", "cmpny_cf_cd_r11", "state_r11").agg(sum($"nbrpa_aprvd_gtlgp").alias("nbrpa_aprvd_total_gtip"))

    val nbrpa_aprvd_total_gtip_pcols = nbrpa_aprvd_total_gtip.select($"health_year_r11", $"cmpny_cf_cd_r11", $"state_r11")

    //nbrpa_aprvd_total_gtip.show()
    val nbrpa_aprvd_catastrophic = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_prod_desc").like("%CATASTROPHIC%")
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r3"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r3"), $"state".alias("state_r3"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_catastrophic"))

    val nbrpa_aprvd_catastrophic_pcols = nbrpa_aprvd_catastrophic.select($"health_year_r3", $"cmpny_cf_cd_r3", $"state_r3")

    val nbrpa_aprvd_lgp_mmcare = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").isNull)
        && (!naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*))
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r9"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r9"), $"state".alias("state_r9"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_lgp_mmcare"))

    val nbrpa_aprvd_lgp_mmcarep_pcols = nbrpa_aprvd_lgp_mmcare.select($"health_year_r9", $"cmpny_cf_cd_r9", $"state_r9")

    val nbrpa_aprvd_stucvg = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r10"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r10"), $"state".alias("state_r10"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_stucvg"))

    val nbrpa_aprvd_stucvg_pcols = nbrpa_aprvd_stucvg.select($"health_year_r10", $"cmpny_cf_cd_r10", $"state_r10")

    val nbrpa_aprvd_bh_total_ip = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").isNull)
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").equalTo("Y")
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r12"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r12"), $"state".alias("state_r12"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_bh_total_ip"))

    val nbrpa_aprvd_bh_total_ip_pcols = nbrpa_aprvd_bh_total_ip.select($"health_year_r12", $"cmpny_cf_cd_r12", $"state_r12")

    val nbrpa_aprvd_bh_total_sgp = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").isNull)
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("src_exchng_certfn_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").equalTo("Y")
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r13"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r13"), $"state".alias("state_r13"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_bh_total_sgp"))

    val nbrpa_aprvd_bh_total_sgp_pcols = nbrpa_aprvd_bh_total_sgp.select($"health_year_r13", $"cmpny_cf_cd_r13", $"state_r13")

    val nbrpa_aprvd_bh_gtlgp = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").equalTo("YES")
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r14"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r14"), $"state".alias("state_r14"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_bh_gtlgp"))

    val nbrpa_aprvd_bh_gtlgp_pcols = nbrpa_aprvd_bh_gtlgp.select($"health_year_r14", $"cmpny_cf_cd_r14", $"state_r14")

    val nbrpa_aprvd_bh_gtsgp = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r15"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r15"), $"state".alias("state_r15"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_bh_gtsgp"))

    val nbrpa_aprvd_bh_gtsgp_pcols = nbrpa_aprvd_bh_gtsgp.select($"health_year_r15", $"cmpny_cf_cd_r15", $"state_r15")

    val nbrpa_aprvd_bh_gtip = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r16"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r16"), $"state".alias("state_r16"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_bh_gtip"))

    val nbrpa_aprvd_bh_gtip_pcols = nbrpa_aprvd_bh_gtip.select($"health_year_r16", $"cmpny_cf_cd_r16", $"state_r16")

    val getTotal_bh_ip = nbrpa_aprvd_bh_gtlgp.union(nbrpa_aprvd_bh_gtsgp.union(nbrpa_aprvd_bh_gtip))
      .select($"health_year_r14".alias("health_year_r17"), $"cmpny_cf_cd_r14".alias("cmpny_cf_cd_r17"), $"state_r14".alias("state_r17"), $"nbrpa_aprvd_bh_gtlgp")

    val nbrpa_aprvd_bh_total_gtip = getTotal_bh_ip.groupBy("health_year_r17", "cmpny_cf_cd_r17", "state_r17").agg(sum($"nbrpa_aprvd_bh_gtlgp").alias("nbrpa_aprvd_bh_total_gtip"))

    val nbrpa_aprvd_bh_total_gtip_pcols = nbrpa_aprvd_bh_total_gtip.select($"health_year_r17", $"cmpny_cf_cd_r17", $"state_r17")

    val nbrpa_aprvd_bh_catastrophic = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_prod_desc").like("%CATASTROPHIC%")
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r18"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r18"), $"state".alias("state_r18"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_bh_catastrophic"))

    val nbrpa_aprvd_bh_catastrophic_pcols = nbrpa_aprvd_bh_catastrophic.select($"health_year_r18", $"cmpny_cf_cd_r18", $"state_r18")

    val nbrpa_aprvd_bh_lgp_mmcare = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("grndfthr_ind_cd").isNull)
        && (!naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*))
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r19"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r19"), $"state".alias("state_r19"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_bh_lgp_mmcare"))

    val nbrpa_aprvd_bh_lgp_mmcare_pcols = nbrpa_aprvd_bh_lgp_mmcare.select($"health_year_r19", $"cmpny_cf_cd_r19", $"state_r19")

    val nbrpa_aprvd_bh_stucvg = naic2018_mcas_hlthex_paexphmcy_apprvd_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*)
        && naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_apprvd_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r20"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r20"), $"state".alias("state_r20"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_aprvd_bh_stucvg"))

    val nbrpa_aprvd_bh_stucvg_pcols = nbrpa_aprvd_bh_stucvg.select($"health_year_r20", $"cmpny_cf_cd_r20", $"state_r20")

    //    val aprvmaster = (nbrpa_aprvd_total_ip_pcols.union(nbrpa_aprvd_total_sgp_pcols.union(nbrpa_aprvd_gtlgpcols.union(nbrpa_aprvd_gtsgpcols
    //      .union(nbrpa_aprvd_gtipcols.union(nbrpa_aprvd_total_gtipcols.union(nbrpa_aprvd_catastrophic_pcols.union(nbrpa_aprvd_lgp_mmcarepcols.union(nbrpa_aprvd_stucvgcols)))))))))
    //      .select($"health_year_r1".alias("health_year"), $"cmpny_cf_cd_r1".alias("cmpny_cf_cd"), $"state_r1".alias("state")).distinct

    val aprvmaster = (nbrpa_aprvd_total_ip_pcols.union(nbrpa_aprvd_total_sgp_pcols.union(nbrpa_aprvd_gtlgp_pcols.union(nbrpa_aprvd_gtsgp_pcols
      .union(nbrpa_aprvd_gtip_pcols.union(nbrpa_aprvd_total_gtip_pcols.union(nbrpa_aprvd_catastrophic_pcols.union(nbrpa_aprvd_lgp_mmcarep_pcols.union(nbrpa_aprvd_stucvg_pcols
        .union(nbrpa_aprvd_bh_total_ip_pcols.union(nbrpa_aprvd_bh_total_sgp_pcols.union(nbrpa_aprvd_bh_gtlgp_pcols.union(nbrpa_aprvd_bh_gtsgp_pcols
          .union(nbrpa_aprvd_bh_gtip_pcols.union(nbrpa_aprvd_bh_total_gtip_pcols.union(nbrpa_aprvd_bh_catastrophic_pcols.union(nbrpa_aprvd_bh_lgp_mmcare_pcols
            .union(nbrpa_aprvd_bh_stucvg_pcols))))))))))))))))))
      .select($"health_year_r1".alias("health_year"), $"cmpny_cf_cd_r1".alias("cmpny_cf_cd"), $"state_r1".alias("state")).distinct

    //val aprvmaster_1 = (nbrpa_aprvd_total_ms_sgp_pcols.union(nbrpa_aprvd_total_ms_ip_pcols.union(nbrpa_aprvd_catastrophic_pcols.union(nbrpa_aprvd_total_ip_pcols.union(nbrpa_aprvd_total_sgp_pcols))))).select($"health_year_r5".alias("health_year"),$"cmpny_cf_cd_r5".alias("cmpny_cf_cd"),$"state_r5".alias("state")).distinct

    val aprvjoin1 = aprvmaster.join(nbrpa_aprvd_total_ip, aprvmaster("health_year") === nbrpa_aprvd_total_ip("health_year_r1") &&
      aprvmaster("cmpny_cf_cd") === nbrpa_aprvd_total_ip("cmpny_cf_cd_r1") &&
      aprvmaster("state") === nbrpa_aprvd_total_ip("state_r1"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip")

    val aprvjoin2 = aprvjoin1.join(nbrpa_aprvd_total_sgp, aprvjoin1("health_year") === nbrpa_aprvd_total_sgp("health_year_r2") &&
      aprvjoin1("cmpny_cf_cd") === nbrpa_aprvd_total_sgp("cmpny_cf_cd_r2") &&
      aprvjoin1("state") === nbrpa_aprvd_total_sgp("state_r2"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp")

    val aprvjoin3 = aprvjoin2.join(nbrpa_aprvd_gtlgp, aprvjoin2("health_year") === nbrpa_aprvd_gtlgp("health_year_r6") &&
      aprvjoin2("cmpny_cf_cd") === nbrpa_aprvd_gtlgp("cmpny_cf_cd_r6") &&
      aprvjoin2("state") === nbrpa_aprvd_gtlgp("state_r6"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp")

    val aprvjoin4 = aprvjoin3.join(nbrpa_aprvd_gtsgp, aprvjoin3("health_year") === nbrpa_aprvd_gtsgp("health_year_r7") &&
      aprvjoin3("cmpny_cf_cd") === nbrpa_aprvd_gtsgp("cmpny_cf_cd_r7") &&
      aprvjoin3("state") === nbrpa_aprvd_gtsgp("state_r7"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp")

    val aprvjoin5 = aprvjoin4.join(nbrpa_aprvd_gtip, aprvjoin4("health_year") === nbrpa_aprvd_gtip("health_year_r8") &&
      aprvjoin4("cmpny_cf_cd") === nbrpa_aprvd_gtip("cmpny_cf_cd_r8") &&
      aprvjoin4("state") === nbrpa_aprvd_gtip("state_r8"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip")
    //aprvjoin5.show()

    val aprvjoin6 = aprvjoin5.join(nbrpa_aprvd_total_gtip, aprvjoin5("health_year") === nbrpa_aprvd_total_gtip("health_year_r11") &&
      aprvjoin5("cmpny_cf_cd") === nbrpa_aprvd_total_gtip("cmpny_cf_cd_r11") &&
      aprvjoin5("state") === nbrpa_aprvd_total_gtip("state_r11"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip",
        $"nbrpa_aprvd_total_gtip")

    val aprvjoin7 = aprvjoin6.join(nbrpa_aprvd_catastrophic, aprvjoin6("health_year") === nbrpa_aprvd_catastrophic("health_year_r3") &&
      aprvjoin6("cmpny_cf_cd") === nbrpa_aprvd_catastrophic("cmpny_cf_cd_r3") &&
      aprvjoin6("state") === nbrpa_aprvd_catastrophic("state_r3"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip",
        $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic")

    val aprvjoin8 = aprvjoin7.join(nbrpa_aprvd_lgp_mmcare, aprvjoin7("health_year") === nbrpa_aprvd_lgp_mmcare("health_year_r9") &&
      aprvjoin7("cmpny_cf_cd") === nbrpa_aprvd_lgp_mmcare("cmpny_cf_cd_r9") &&
      aprvjoin7("state") === nbrpa_aprvd_lgp_mmcare("state_r9"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip",
        $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic", $"nbrpa_aprvd_lgp_mmcare")

    val aprvjoin9 = aprvjoin8.join(nbrpa_aprvd_stucvg, aprvjoin8("health_year") === nbrpa_aprvd_stucvg("health_year_r10") &&
      aprvjoin8("cmpny_cf_cd") === nbrpa_aprvd_stucvg("cmpny_cf_cd_r10") && aprvjoin8("state") === nbrpa_aprvd_stucvg("state_r10"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip",
        $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg")

    val aprvjoin10 = aprvjoin9.join(nbrpa_aprvd_bh_total_ip, aprvjoin9("health_year") === nbrpa_aprvd_bh_total_ip("health_year_r12") &&
      aprvjoin9("cmpny_cf_cd") === nbrpa_aprvd_bh_total_ip("cmpny_cf_cd_r12") && aprvjoin9("state") === nbrpa_aprvd_bh_total_ip("state_r12"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip",
        $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg", $"nbrpa_aprvd_bh_total_ip")

    val aprvjoin11 = aprvjoin10.join(nbrpa_aprvd_bh_total_sgp, aprvjoin10("health_year") === nbrpa_aprvd_bh_total_sgp("health_year_r13") &&
      aprvjoin10("cmpny_cf_cd") === nbrpa_aprvd_bh_total_sgp("cmpny_cf_cd_r13") && aprvjoin10("state") === nbrpa_aprvd_bh_total_sgp("state_r13"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip",
        $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp")

    val aprvjoin12 = aprvjoin11.join(nbrpa_aprvd_bh_gtlgp, aprvjoin11("health_year") === nbrpa_aprvd_bh_gtlgp("health_year_r14") &&
      aprvjoin11("cmpny_cf_cd") === nbrpa_aprvd_bh_gtlgp("cmpny_cf_cd_r14") && aprvjoin11("state") === nbrpa_aprvd_bh_gtlgp("state_r14"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip",
        $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_gtlgp")

    val aprvjoin13 = aprvjoin12.join(nbrpa_aprvd_bh_gtsgp, aprvjoin12("health_year") === nbrpa_aprvd_bh_gtsgp("health_year_r15") &&
      aprvjoin12("cmpny_cf_cd") === nbrpa_aprvd_bh_gtsgp("cmpny_cf_cd_r15") && aprvjoin12("state") === nbrpa_aprvd_bh_gtsgp("state_r15"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip",
        $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_gtlgp", $"nbrpa_aprvd_bh_gtsgp")

    val aprvjoin14 = aprvjoin13.join(nbrpa_aprvd_bh_gtip, aprvjoin13("health_year") === nbrpa_aprvd_bh_gtip("health_year_r16") &&
      aprvjoin13("cmpny_cf_cd") === nbrpa_aprvd_bh_gtip("cmpny_cf_cd_r16") && aprvjoin13("state") === nbrpa_aprvd_bh_gtip("state_r16"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip",
        $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_gtlgp", $"nbrpa_aprvd_bh_gtsgp",
        $"nbrpa_aprvd_bh_gtip")

    val aprvjoin15 = aprvjoin14.join(nbrpa_aprvd_bh_total_gtip, aprvjoin14("health_year") === nbrpa_aprvd_bh_total_gtip("health_year_r17") &&
      aprvjoin14("cmpny_cf_cd") === nbrpa_aprvd_bh_total_gtip("cmpny_cf_cd_r17") && aprvjoin14("state") === nbrpa_aprvd_bh_total_gtip("state_r17"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip",
        $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_gtlgp", $"nbrpa_aprvd_bh_gtsgp",
        $"nbrpa_aprvd_bh_gtip", $"nbrpa_aprvd_bh_total_gtip")

    val aprvjoin16 = aprvjoin15.join(nbrpa_aprvd_bh_catastrophic, aprvjoin15("health_year") === nbrpa_aprvd_bh_catastrophic("health_year_r18") &&
      aprvjoin15("cmpny_cf_cd") === nbrpa_aprvd_bh_catastrophic("cmpny_cf_cd_r18") && aprvjoin15("state") === nbrpa_aprvd_bh_catastrophic("state_r18"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip",
        $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_gtlgp", $"nbrpa_aprvd_bh_gtsgp",
        $"nbrpa_aprvd_bh_gtip", $"nbrpa_aprvd_bh_total_gtip", $"nbrpa_aprvd_bh_catastrophic")

    val aprvjoin17 = aprvjoin16.join(nbrpa_aprvd_bh_lgp_mmcare, aprvjoin16("health_year") === nbrpa_aprvd_bh_lgp_mmcare("health_year_r19") &&
      aprvjoin16("cmpny_cf_cd") === nbrpa_aprvd_bh_lgp_mmcare("cmpny_cf_cd_r19") && aprvjoin16("state") === nbrpa_aprvd_bh_lgp_mmcare("state_r19"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_aprvd_total_ip",
        $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_gtlgp", $"nbrpa_aprvd_bh_gtsgp",
        $"nbrpa_aprvd_bh_gtip", $"nbrpa_aprvd_bh_total_gtip", $"nbrpa_aprvd_bh_catastrophic", $"nbrpa_aprvd_bh_lgp_mmcare")

    val aprvFinalDf = aprvjoin17.join(nbrpa_aprvd_bh_stucvg, aprvjoin17("health_year") === nbrpa_aprvd_bh_stucvg("health_year_r20") &&
      aprvjoin17("cmpny_cf_cd") === nbrpa_aprvd_bh_stucvg("cmpny_cf_cd_r20") && aprvjoin17("state") === nbrpa_aprvd_bh_stucvg("state_r20"), "left_outer")
      .select($"health_year".alias("health_year_approved"), $"cmpny_cf_cd".alias("cmpny_cf_cd_approved"), $"state".alias("state_approved"), $"nbrpa_aprvd_total_ip",
        $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic",
        $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_gtlgp", $"nbrpa_aprvd_bh_gtsgp",
        $"nbrpa_aprvd_bh_gtip", $"nbrpa_aprvd_bh_total_gtip", $"nbrpa_aprvd_bh_catastrophic", $"nbrpa_aprvd_bh_lgp_mmcare", $"nbrpa_aprvd_bh_stucvg")

    aprvFinalDf

  }

  def getDeniedData(naic2018_mcas_hlthex_paexphmcy_denied_wrk: DataFrame, naic2018_mcas_hlthex_paexphmcy_reqstd_wrk: DataFrame): DataFrame = {

    val nbrpa_denied_total_ip = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").isNull)
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").equalTo("Y")
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r1"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r1"), $"state".alias("state_r1"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_total_ip"))

    val nbrpa_denied_total_ip_pcols = nbrpa_denied_total_ip.select($"health_year_r1", $"cmpny_cf_cd_r1", $"state_r1")

    val nbrpa_denied_total_sgp = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").isNull)
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").equalTo("Y")
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r2"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r2"), $"state".alias("state_r2"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_total_sgp"))

    val nbrpa_denied_total_sgp_pcols = nbrpa_denied_total_sgp.select($"health_year_r2", $"cmpny_cf_cd_r2", $"state_r2")

    val nbrpa_denied_gtlgp = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").isin(naic_lob_lgp: _*)
        // on 0108 && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").notEqual("Y")  || naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").equalTo("YES")
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r6"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r6"), $"state".alias("state_r6"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_gtlgp"))

    val nbrpa_denied_gtlgp_pcols = nbrpa_denied_gtlgp.select($"health_year_r6", $"cmpny_cf_cd_r6", $"state_r6")

    val nbrpa_denied_gtsgp = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r7"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r7"), $"state".alias("state_r7"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_gtsgp"))

    val nbrpa_denied_gtsgp_pcols = nbrpa_denied_gtsgp.select($"health_year_r7", $"cmpny_cf_cd_r7", $"state_r7")

    val nbrpa_denied_gtip = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r8"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r8"), $"state".alias("state_r8"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_gtip"))

    val nbrpa_denied_gtip_pcols = nbrpa_denied_gtip.select($"health_year_r8", $"cmpny_cf_cd_r8", $"state_r8")

    val getTotal_ip = nbrpa_denied_gtlgp.union(nbrpa_denied_gtsgp.union(nbrpa_denied_gtip))
      .select(
        $"health_year_r6".alias("health_year_r11"),
        $"cmpny_cf_cd_r6".alias("cmpny_cf_cd_r11"),
        $"state_r6".alias("state_r11"), $"nbrpa_denied_gtlgp")

    val nbrpa_denied_total_gtip = getTotal_ip.groupBy("health_year_r11", "cmpny_cf_cd_r11", "state_r11").agg(sum($"nbrpa_denied_gtlgp").alias("nbrpa_denied_total_gtip"))

    val nbrpa_denied_total_gtip_pcols = nbrpa_denied_total_gtip.select($"health_year_r11", $"cmpny_cf_cd_r11", $"state_r11")
    //nbrpa_denied_total_gtip.show()

    val nbrpa_denied_catastrophic = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_prod_desc").like("%CATASTROPHIC%")
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r3"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r3"), $"state".alias("state_r3"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_catastrophic"))

    val nbrpa_denied_catastrophic_pcols = nbrpa_denied_catastrophic.select($"health_year_r3", $"cmpny_cf_cd_r3", $"state_r3")

    val nbrpa_denied_lgp_mmcare = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").isNull)
        && (!naic2018_mcas_hlthex_paexphmcy_denied_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*))
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r9"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r9"), $"state".alias("state_r9"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_lgp_mmcare"))

    val nbrpa_denied_lgp_mmcarep_pcols = nbrpa_denied_lgp_mmcare.select($"health_year_r9", $"cmpny_cf_cd_r9", $"state_r9")

    val nbrpa_denied_stucvg = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull)
      .groupBy($"health_year".alias("health_year_r10"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r10"), $"state".alias("state_r10"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_stucvg"))

    val nbrpa_denied_stucvg_pcols = nbrpa_denied_stucvg.select($"health_year_r10", $"cmpny_cf_cd_r10", $"state_r10")

    val nbrpa_denied_bh_total_ip = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").isNull)
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").equalTo("Y")
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r12"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r12"), $"state".alias("state_r12"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_bh_total_ip"))

    val nbrpa_denied_bh_total_ip_pcols = nbrpa_denied_bh_total_ip.select($"health_year_r12", $"cmpny_cf_cd_r12", $"state_r12")

    val nbrpa_denied_bh_total_sgp = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").isNull)
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("src_exchng_certfn_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").equalTo("Y")
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r13"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r13"), $"state".alias("state_r13"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_bh_total_sgp"))

    val nbrpa_denied_bh_total_sgp_pcols = nbrpa_denied_bh_total_sgp.select($"health_year_r13", $"cmpny_cf_cd_r13", $"state_r13")

    val nbrpa_denied_bh_gtlgp = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").equalTo("YES")
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r14"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r14"), $"state".alias("state_r14"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_bh_gtlgp"))

    val nbrpa_denied_bh_gtlgp_pcols = nbrpa_denied_bh_gtlgp.select($"health_year_r14", $"cmpny_cf_cd_r14", $"state_r14")

    val nbrpa_denied_bh_gtsgp = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r15"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r15"), $"state".alias("state_r15"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_bh_gtsgp"))

    val nbrpa_denied_bh_gtsgp_pcols = nbrpa_denied_bh_gtsgp.select($"health_year_r15", $"cmpny_cf_cd_r15", $"state_r15")

    val nbrpa_denied_bh_gtip = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("hcr_cmplynt_cd").isNull)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r16"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r16"), $"state".alias("state_r16"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_bh_gtip"))

    val nbrpa_denied_bh_gtip_pcols = nbrpa_denied_bh_gtip.select($"health_year_r16", $"cmpny_cf_cd_r16", $"state_r16")

    val getTotal_bh_ip = nbrpa_denied_bh_gtlgp.union(nbrpa_denied_bh_gtsgp.union(nbrpa_denied_bh_gtip))
      .select($"health_year_r14".alias("health_year_r17"), $"cmpny_cf_cd_r14".alias("cmpny_cf_cd_r17"), $"state_r14".alias("state_r17"), $"nbrpa_denied_bh_gtlgp")

    val nbrpa_denied_bh_total_gtip = getTotal_bh_ip.groupBy("health_year_r17", "cmpny_cf_cd_r17", "state_r17").agg(sum($"nbrpa_denied_bh_gtlgp").alias("nbrpa_denied_bh_total_gtip"))

    val nbrpa_denied_bh_total_gtip_pcols = nbrpa_denied_bh_total_gtip.select($"health_year_r17", $"cmpny_cf_cd_r17", $"state_r17")

    val nbrpa_denied_bh_catastrophic = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_prod_desc").like("%CATASTROPHIC%")
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r18"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r18"), $"state".alias("state_r18"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_bh_catastrophic"))

    val nbrpa_denied_bh_catastrophic_pcols = nbrpa_denied_bh_catastrophic.select($"health_year_r18", $"cmpny_cf_cd_r18", $"state_r18")

    val nbrpa_denied_bh_lgp_mmcare = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paexphmcy_denied_wrk("grndfthr_ind_cd").isNull)
        && (!naic2018_mcas_hlthex_paexphmcy_denied_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*))
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r19"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r19"), $"state".alias("state_r19"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_bh_lgp_mmcare"))

    val nbrpa_denied_bh_lgp_mmcare_pcols = nbrpa_denied_bh_lgp_mmcare.select($"health_year_r19", $"cmpny_cf_cd_r19", $"state_r19")

    val nbrpa_denied_bh_stucvg = naic2018_mcas_hlthex_paexphmcy_denied_wrk
      .filter(naic2018_mcas_hlthex_paexphmcy_denied_wrk("naic_lob").isin(naic_lob_lgp: _*)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*)
        && naic2018_mcas_hlthex_paexphmcy_denied_wrk("in_exchange").isNull
        && (naic2018_mcas_hlthex_paexphmcy_denied_wrk("case_type_cd").isin(case_type_cd_val: _*)))
      .groupBy($"health_year".alias("health_year_r20"), $"cmpny_cf_cd".alias("cmpny_cf_cd_r20"), $"state".alias("state_r20"))
      .agg(countDistinct($"rfrnc_nbr",$"srvc_line_nbr").alias("nbrpa_denied_bh_stucvg"))

    val nbrpa_denied_bh_stucvg_pcols = nbrpa_denied_bh_stucvg.select($"health_year_r20", $"cmpny_cf_cd_r20", $"state_r20")

    val denimaster = (nbrpa_denied_total_ip_pcols.union(nbrpa_denied_total_sgp_pcols.union(nbrpa_denied_gtlgp_pcols.union(nbrpa_denied_gtsgp_pcols
      .union(nbrpa_denied_gtip_pcols.union(nbrpa_denied_total_gtip_pcols.union(nbrpa_denied_catastrophic_pcols
        .union(nbrpa_denied_lgp_mmcarep_pcols.union(nbrpa_denied_stucvg_pcols.union(nbrpa_denied_bh_total_ip_pcols.union(nbrpa_denied_bh_total_sgp_pcols
          .union(nbrpa_denied_bh_gtlgp_pcols.union(nbrpa_denied_bh_gtsgp_pcols.union(nbrpa_denied_bh_gtip_pcols.union(nbrpa_denied_bh_total_gtip_pcols
            .union(nbrpa_denied_bh_catastrophic_pcols.union(nbrpa_denied_bh_lgp_mmcare_pcols.union(nbrpa_denied_bh_stucvg_pcols))))))))))))))))))
      .select($"health_year_r1".alias("health_year"), $"cmpny_cf_cd_r1".alias("cmpny_cf_cd"), $"state_r1".alias("state")).distinct

    val denijoin1 = denimaster.join(nbrpa_denied_total_ip, denimaster("health_year") === nbrpa_denied_total_ip("health_year_r1") &&
      denimaster("cmpny_cf_cd") === nbrpa_denied_total_ip("cmpny_cf_cd_r1") &&
      denimaster("state") === nbrpa_denied_total_ip("state_r1"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_denied_total_ip")

    val denijoin2 = denijoin1.join(nbrpa_denied_total_sgp, denijoin1("health_year") === nbrpa_denied_total_sgp("health_year_r2") &&
      denijoin1("cmpny_cf_cd") === nbrpa_denied_total_sgp("cmpny_cf_cd_r2") &&
      denijoin1("state") === nbrpa_denied_total_sgp("state_r2"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp")

    /* val denijoin3 = denijoin2.join(nbrpa_denied_catastrophic,denijoin2("health_year")===nbrpa_denied_catastrophic("health_year_r3") &&
					denijoin2("cmpny_cf_cd")===nbrpa_denied_catastrophic("cmpny_cf_cd_r3") &&
					denijoin2("state")===nbrpa_denied_catastrophic("state_r3")  ,"left_outer")
					.select($"health_year",$"cmpny_cf_cd",$"state" ,$"nbrpa_denied_total_ip",$"nbrpa_denied_total_sgp",$"nbrpa_denied_catastrophic")*/

    val denijoin3 = denijoin2.join(nbrpa_denied_gtlgp, denijoin2("health_year") === nbrpa_denied_gtlgp("health_year_r6") &&
      denijoin2("cmpny_cf_cd") === nbrpa_denied_gtlgp("cmpny_cf_cd_r6") &&
      denijoin2("state") === nbrpa_denied_gtlgp("state_r6"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_denied_total_ip",
        $"nbrpa_denied_total_sgp", $"nbrpa_denied_gtlgp")

    val denijoin4 = denijoin3.join(nbrpa_denied_gtsgp, denijoin3("health_year") === nbrpa_denied_gtsgp("health_year_r7") &&
      denijoin3("cmpny_cf_cd") === nbrpa_denied_gtsgp("cmpny_cf_cd_r7") &&
      denijoin3("state") === nbrpa_denied_gtsgp("state_r7"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_denied_total_ip",
        $"nbrpa_denied_total_sgp", $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp")

    val denijoin5 = denijoin4.join(nbrpa_denied_gtip, denijoin4("health_year") === nbrpa_denied_gtip("health_year_r8") &&
      denijoin4("cmpny_cf_cd") === nbrpa_denied_gtip("cmpny_cf_cd_r8") &&
      denijoin4("state") === nbrpa_denied_gtip("state_r8"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp",
        $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip")
    //denijoin5.show()

    val denijoin6 = denijoin5.join(nbrpa_denied_total_gtip, denijoin5("health_year") === nbrpa_denied_total_gtip("health_year_r11") &&
      denijoin5("cmpny_cf_cd") === nbrpa_denied_total_gtip("cmpny_cf_cd_r11") &&
      denijoin5("state") === nbrpa_denied_total_gtip("state_r11"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp",
        $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip")

    val denijoin7 = denijoin6.join(nbrpa_denied_catastrophic, denijoin6("health_year") === nbrpa_denied_catastrophic("health_year_r3") &&
      denijoin6("cmpny_cf_cd") === nbrpa_denied_catastrophic("cmpny_cf_cd_r3") &&
      denijoin6("state") === nbrpa_denied_catastrophic("state_r3"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp",
        $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip", $"nbrpa_denied_catastrophic")

    val denijoin8 = denijoin7.join(nbrpa_denied_lgp_mmcare, denijoin7("health_year") === nbrpa_denied_lgp_mmcare("health_year_r9") &&
      denijoin7("cmpny_cf_cd") === nbrpa_denied_lgp_mmcare("cmpny_cf_cd_r9") &&
      denijoin7("state") === nbrpa_denied_lgp_mmcare("state_r9"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp",
        $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip",
        $"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare")

    val denijoin9 = denijoin8.join(nbrpa_denied_stucvg, denijoin8("health_year") === nbrpa_denied_stucvg("health_year_r10") &&
      denijoin8("cmpny_cf_cd") === nbrpa_denied_stucvg("cmpny_cf_cd_r10") &&
      denijoin8("state") === nbrpa_denied_stucvg("state_r10"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state",
        $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp",
        $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip",
        $"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare", $"nbrpa_denied_stucvg")

    val denijoin10 = denijoin9.join(nbrpa_denied_bh_total_ip, denijoin9("health_year") === nbrpa_denied_bh_total_ip("health_year_r12") &&
      denijoin9("cmpny_cf_cd") === nbrpa_denied_bh_total_ip("cmpny_cf_cd_r12") &&
      denijoin9("state") === nbrpa_denied_bh_total_ip("state_r12"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state",
        $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp",
        $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip",
        $"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare", $"nbrpa_denied_stucvg", $"nbrpa_denied_bh_total_ip")

    val denijoin11 = denijoin10.join(nbrpa_denied_bh_total_sgp, denijoin10("health_year") === nbrpa_denied_bh_total_sgp("health_year_r13") &&
      denijoin10("cmpny_cf_cd") === nbrpa_denied_bh_total_sgp("cmpny_cf_cd_r13") &&
      denijoin10("state") === nbrpa_denied_bh_total_sgp("state_r13"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state",
        $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp",
        $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip",
        $"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare", $"nbrpa_denied_stucvg", $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp")

    val denijoin12 = denijoin11.join(nbrpa_denied_bh_gtlgp, denijoin11("health_year") === nbrpa_denied_bh_gtlgp("health_year_r14") &&
      denijoin11("cmpny_cf_cd") === nbrpa_denied_bh_gtlgp("cmpny_cf_cd_r14") &&
      denijoin11("state") === nbrpa_denied_bh_gtlgp("state_r14"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state",
        $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp",
        $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip",
        $"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare", $"nbrpa_denied_stucvg", $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp", $"nbrpa_denied_bh_gtlgp")

    val denijoin13 = denijoin12.join(nbrpa_denied_bh_gtsgp, denijoin12("health_year") === nbrpa_denied_bh_gtsgp("health_year_r15") &&
      denijoin12("cmpny_cf_cd") === nbrpa_denied_bh_gtsgp("cmpny_cf_cd_r15") &&
      denijoin12("state") === nbrpa_denied_bh_gtsgp("state_r15"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state",
        $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp",
        $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip",
        $"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare", $"nbrpa_denied_stucvg", $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp", $"nbrpa_denied_bh_gtlgp",
        $"nbrpa_denied_bh_gtsgp")

    val denijoin14 = denijoin13.join(nbrpa_denied_bh_gtip, denijoin13("health_year") === nbrpa_denied_bh_gtip("health_year_r16") &&
      denijoin13("cmpny_cf_cd") === nbrpa_denied_bh_gtip("cmpny_cf_cd_r16") &&
      denijoin13("state") === nbrpa_denied_bh_gtip("state_r16"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state",
        $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp",
        $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip",
        $"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare", $"nbrpa_denied_stucvg", $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp", $"nbrpa_denied_bh_gtlgp",
        $"nbrpa_denied_bh_gtsgp", $"nbrpa_denied_bh_gtip")

    val denijoin15 = denijoin14.join(nbrpa_denied_bh_total_gtip, denijoin14("health_year") === nbrpa_denied_bh_total_gtip("health_year_r17") &&
      denijoin14("cmpny_cf_cd") === nbrpa_denied_bh_total_gtip("cmpny_cf_cd_r17") &&
      denijoin14("state") === nbrpa_denied_bh_total_gtip("state_r17"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state",
        $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip",
        $"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare", $"nbrpa_denied_stucvg", $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp",
        $"nbrpa_denied_bh_gtlgp", $"nbrpa_denied_bh_gtsgp", $"nbrpa_denied_bh_gtip", $"nbrpa_denied_bh_total_gtip")

    val denijoin16 = denijoin15.join(nbrpa_denied_bh_catastrophic, denijoin15("health_year") === nbrpa_denied_bh_catastrophic("health_year_r18") &&
      denijoin15("cmpny_cf_cd") === nbrpa_denied_bh_catastrophic("cmpny_cf_cd_r18") &&
      denijoin15("state") === nbrpa_denied_bh_catastrophic("state_r18"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state",
        $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip",
        $"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare", $"nbrpa_denied_stucvg", $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp",
        $"nbrpa_denied_bh_gtlgp", $"nbrpa_denied_bh_gtsgp", $"nbrpa_denied_bh_gtip", $"nbrpa_denied_bh_total_gtip", $"nbrpa_denied_bh_catastrophic")

    val denijoin17 = denijoin16.join(nbrpa_denied_bh_lgp_mmcare, denijoin16("health_year") === nbrpa_denied_bh_lgp_mmcare("health_year_r19") &&
      denijoin16("cmpny_cf_cd") === nbrpa_denied_bh_lgp_mmcare("cmpny_cf_cd_r19") &&
      denijoin16("state") === nbrpa_denied_bh_lgp_mmcare("state_r19"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state",
        $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip",
        $"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare", $"nbrpa_denied_stucvg", $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp",
        $"nbrpa_denied_bh_gtlgp", $"nbrpa_denied_bh_gtsgp", $"nbrpa_denied_bh_gtip", $"nbrpa_denied_bh_total_gtip", $"nbrpa_denied_bh_catastrophic",
        $"nbrpa_denied_bh_lgp_mmcare")

    val deniFinalDf = denijoin17.join(nbrpa_denied_bh_stucvg, denijoin17("health_year") === nbrpa_denied_bh_stucvg("health_year_r20") &&
      denijoin17("cmpny_cf_cd") === nbrpa_denied_bh_stucvg("cmpny_cf_cd_r20") &&
      denijoin17("state") === nbrpa_denied_bh_stucvg("state_r20"), "left_outer")
      .select($"health_year".alias("health_year_denied"), $"cmpny_cf_cd".alias("cmpny_cf_cd_denied"), $"state".alias("state_denied"),
        $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip",
        $"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare", $"nbrpa_denied_stucvg", $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp",
        $"nbrpa_denied_bh_gtlgp", $"nbrpa_denied_bh_gtsgp", $"nbrpa_denied_bh_gtip", $"nbrpa_denied_bh_total_gtip", $"nbrpa_denied_bh_catastrophic",
        $"nbrpa_denied_bh_lgp_mmcare", $"nbrpa_denied_bh_stucvg")

    deniFinalDf

  }

  def getFinalData(reqDf: DataFrame, appDf: DataFrame, denDf: DataFrame): DataFrame = {

    val request = reqDf.select($"health_year_requested", $"cmpny_cf_cd_requested", $"state_requested")
    val approve = appDf.select($"health_year_approved", $"cmpny_cf_cd_approved", $"state_approved")
    val deny = denDf.select($"health_year_denied", $"cmpny_cf_cd_denied", $"state_denied")

    val finalmaster = deny.union(request.union(approve)).select($"health_year_denied".alias("health_year"), $"cmpny_cf_cd_denied".alias("cmpny_cf_cd"),
      $"state_denied".alias("state")).distinct

    val fjoin1 = finalmaster.join(reqDf, finalmaster("health_year") === reqDf("health_year_requested") &&
      finalmaster("cmpny_cf_cd") === reqDf("cmpny_cf_cd_requested") && finalmaster("state") === reqDf("state_requested"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrpa_rqstd_total_ip",
        $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic",
        $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_gtlgp", $"nbrpa_rqstd_bh_gtsgp",
        $"nbrpa_rqstd_bh_gtip", $"nbrpa_rqstd_bh_total_gtip", $"nbrpa_rqstd_bh_catastrophic", $"nbrpa_rqstd_bh_lgp_mmcare", $"nbrpa_rqstd_bh_stucvg")

    val fjoin2 = fjoin1.join(appDf, fjoin1("health_year") === appDf("health_year_approved") &&
      fjoin1("cmpny_cf_cd") === appDf("cmpny_cf_cd_approved") && fjoin1("state") === appDf("state_approved"), "left_outer")
      .select($"health_year", $"cmpny_cf_cd", $"state",
        $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip",
        $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg", $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_gtlgp",
        $"nbrpa_rqstd_bh_gtsgp", $"nbrpa_rqstd_bh_gtip", $"nbrpa_rqstd_bh_total_gtip", $"nbrpa_rqstd_bh_catastrophic", $"nbrpa_rqstd_bh_lgp_mmcare", $"nbrpa_rqstd_bh_stucvg",
        $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", 
        $"nbrpa_aprvd_catastrophic", $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg", $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_gtlgp", 
        $"nbrpa_aprvd_bh_gtsgp", $"nbrpa_aprvd_bh_gtip", $"nbrpa_aprvd_bh_total_gtip", $"nbrpa_aprvd_bh_catastrophic", $"nbrpa_aprvd_bh_lgp_mmcare", $"nbrpa_aprvd_bh_stucvg")

    val naicMcasHltOexPa = fjoin2.join(denDf, fjoin2("health_year") === denDf("health_year_denied") &&
      fjoin2("cmpny_cf_cd") === denDf("cmpny_cf_cd_denied") && fjoin2("state") === denDf("state_denied"), "left_outer")
      .withColumn("outoff_exchange", lit("OUTOFF"))
      .select($"outoff_exchange", $"health_year", $"cmpny_cf_cd".alias("naic_cmpny_cd"), $"state",
        $"nbrpa_rqstd_total_ip", $"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp", $"nbrpa_rqstd_gtsgp", $"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg", 
        $"nbrpa_aprvd_total_ip", $"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp", $"nbrpa_aprvd_gtsgp", $"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic", $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg",
        $"nbrpa_denied_total_ip", $"nbrpa_denied_total_sgp", $"nbrpa_denied_gtlgp", $"nbrpa_denied_gtsgp", $"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip", $"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare", $"nbrpa_denied_stucvg", 
        $"nbrpa_rqstd_bh_total_ip", $"nbrpa_rqstd_bh_total_sgp", $"nbrpa_rqstd_bh_gtlgp", $"nbrpa_rqstd_bh_gtsgp", $"nbrpa_rqstd_bh_gtip", $"nbrpa_rqstd_bh_total_gtip", $"nbrpa_rqstd_bh_catastrophic", $"nbrpa_rqstd_bh_lgp_mmcare", $"nbrpa_rqstd_bh_stucvg",
		    $"nbrpa_aprvd_bh_total_ip", $"nbrpa_aprvd_bh_total_sgp", $"nbrpa_aprvd_bh_gtlgp", $"nbrpa_aprvd_bh_gtsgp", $"nbrpa_aprvd_bh_gtip", $"nbrpa_aprvd_bh_total_gtip", $"nbrpa_aprvd_bh_catastrophic", $"nbrpa_aprvd_bh_lgp_mmcare", $"nbrpa_aprvd_bh_stucvg",
        $"nbrpa_denied_bh_total_ip", $"nbrpa_denied_bh_total_sgp", $"nbrpa_denied_bh_gtlgp", $"nbrpa_denied_bh_gtsgp", $"nbrpa_denied_bh_gtip", $"nbrpa_denied_bh_total_gtip", $"nbrpa_denied_bh_catastrophic", $"nbrpa_denied_bh_lgp_mmcare", $"nbrpa_denied_bh_stucvg")
    //.fill.na(0)
    //val naicMcasHltOexPa = naicMcasHltOexPa

    val finalMaicMcasHltOexPa = naicMcasHltOexPa.na.fill(0)

    finalMaicMcasHltOexPa
  }

}

object PCADX_SCL_NAIC2018_OexStgTransformation_PAEXPHMCY {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    new PCADX_SCL_NAIC2018_OexStgTransformation_PAEXPHMCY().sparkInIt()
  }
}