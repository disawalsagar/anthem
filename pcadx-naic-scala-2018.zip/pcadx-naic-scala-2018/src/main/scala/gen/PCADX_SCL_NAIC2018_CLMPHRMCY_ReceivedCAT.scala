package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator

import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit

import org.apache.hadoop.fs._;
class PCADX_SCL_NAIC2018_CLMPHRMCY_ReceivedCAT{
  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()
    import spark.implicits._
  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_CLMPHRMCY_ReceivedCAT])
     val dbWrk = dbProperties.getProperty("work.db")
     val dbInbnd = dbProperties.getProperty("inbound.db")
	 val wrhDb = dbProperties.getProperty("warehouse.db")
	 
	 val audit_log_df = spark.sql("select * from "+wrhDb+".audt_load_log") 
    val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString() 
    println("load_log_key : "+load_log_key)
     val reportYear =dbProperties.getProperty("report.year")
     
      val clmRcvdStrtDt = dbProperties.getProperty("CLM_RCVD_DT_STRT")
	    val clmRcvdEndDt = dbProperties.getProperty("CLM_RCVD_DT_END")
     
  def naic_mcas_hlthex_clmphmcy_received_cat_wrk() = """Insert overwrite table """+dbWrk+""".naic2018_mcas_hlthex_clmphmcy_received_cat_wrk"""+"""
    select * from              
( 
SELECT 
"""+reportYear+"""  as health_year,
 pclm_wrk.CLM_ADJSTMNT_KEY  AS CLM_ADJSTMNT_KEY,
 pclm_wrk.CLM_LINE_NBR AS CLM_LINE_NBR ,
 pclm_wrk.CLM_SOR_CD   AS CLM_SOR_CD ,
 pclm_wrk.INN_CD     AS INN_CD ,
 cl.MBR_KEY AS MBR_KEY ,
 cl.MBRSHP_SOR_CD AS MBRSHP_SOR_CD, 
 cl.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
  cl.MBU_CF_CD AS MBU_CF_CD ,
 cl.PROD_CF_CD AS PROD_CF_CD,
 cl.CMPNY_CF_CD AS CMPNY_CF_CD,
 cl.FUNDG_CF_CD AS FUNDG_CF_CD,
 BPA.EXCHNG_IND_CD AS EXCHNG_IND_CD,
 BPA.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
 BPA.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD , 
 BPA.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
 BPA.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
 MHE.HIX_CD AS HIX_CD,
 BRD.State AS  State,
 CASE WHEN substr (cl.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    and cl.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
     WHEN BPA.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN' 
     WHEN SUBSTR(cl.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( BPA.EXCHNG_IND_CD IS NULL OR BPA.EXCHNG_IND_CD ='UNK' )AND MHE.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
             END AS IN_Exchange ,
 CASE WHEN substr (cl.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and cl.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
     WHEN BPA.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
      WHEN SUBSTR(cl.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( BPA.EXCHNG_IND_CD IS NULL OR BPA.EXCHNG_IND_CD ='UNK' )AND MHE.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
     END AS OUTOFF_Exchange, 
 pclm_wrk. src_srvc_dnl_rsn_cd     AS    src_srvc_dnl_rsn_cd ,
 pclm_wrk.clm_nbr  AS  clm_nbr ,
 pclm_wrk.rx_filled_dt AS rx_filled_dt ,
 pclm_wrk.ndc   AS ndc ,
 pclm_wrk.rx_nbr  AS rx_nbr ,
 pclm_wrk.src_grp_nbr AS src_grp_nbr , 
 pclm_wrk.rptg_clm_line_adjdctn_stts_cd AS rptg_clm_line_adjdctn_stts_cd ,
 pclm_wrk.prmpt_pay_clm_rcvd_dt  AS prmpt_pay_clm_rcvd_dt ,
 pclm_wrk.clm_rcvd_dt  AS clm_rcvd_dt ,
 pclm_wrk.adjdctn_dt          AS    adjdctn_dt ,
 MED.GL_LVL_DESC AS naic_lob,
 MED.GL_CF_DESC  as  naic_prod_desc,
 --cl.src_grp_nbr,
 cl.src_subgrp_nbr,
 """+load_log_key+""",
 current_timestamp
  FROM   """+dbWrk+""".naic2018_mcas_pclm_wrk  pclm_wrk
  inner join """+dbWrk+""".clm_inter cl
  on pclm_wrk.MBR_KEY = cl.MBR_KEY
 inner join (
select CF_CD,  GL_CF_DESC, GL_LVL_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'PRODUCT' 
AND GL_CF_DESC  LIKE '%CATASTROPHIC%'
group by 1,2,3
) as MED
on MED.CF_CD = cl.PROD_CF_CD
inner join
(
select
gl.CF_CD
,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY gl
where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
and ((gl.GL_LVL_DESC like  ('NON BLUE%') or gl.GL_LVL_DESC like  ('BLUE%')) and gl.GL_LVL_DESC not like  ('%TOTAL') )
group by 1,2
) BRD
on BRD.CF_CD= cl.MBU_CF_CD 
and BRD.State <> 'LT'
inner join
(
select DISTINCT CF_CD
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where  GL_CF_TYPE_DESC = 'FUND_CODE'
and CF_CD NOT IN ( select  DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY  
          WHERE     GL_CF_TYPE_DESC = 'FUND_CODE' AND  
        ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
       )
) FC
ON FC.CF_CD = cl.FUNDG_CF_CD
 LEFT OUTER JOIN """+dbInbnd+""".MBR_HIX_ENRLMNT MHE
 ON cl.MBR_KEY = MHE.MBR_KEY
 AND cl.PROD_OFRG_KEY = MHE.PROD_OFRG_KEY
 AND cl.MBR_PROD_ENRLMNT_EFCTV_DT = MHE.MBR_PROD_ENRLMNT_EFCTV_DT
 AND MHE.RCRD_STTS_CD <> 'DEL'
 LEFT OUTER JOIN """+dbInbnd+""".BNFT_PKG_ADDNL BPA
 ON cl.BNFT_PKG_KEY = BPA.BNFT_PKG_KEY 
 AND BPA.RCRD_STTS_CD <> 'DEL'
  --added 09/17
  WHERE 
   BRD.State not in ('IL','DC','MA') 
  AND ((pclm_wrk.clm_rcvd_dt between cl.mbr_prod_enrlmnt_efctv_dt and cl.mbr_prod_enrlmnt_trmntn_dt)
        or
        (pclm_wrk.clm_line_srvc_strt_dt  between cl.mbr_prod_enrlmnt_efctv_dt and cl.mbr_prod_enrlmnt_trmntn_dt )
       )
   
   and ( pclm_wrk.CLM_RCVD_DT  BETWEEN  """+clmRcvdStrtDt+"""  AND   """+clmRcvdEndDt+""")

 GROUP BY 
 pclm_wrk.CLM_ADJSTMNT_KEY  ,
 pclm_wrk.CLM_LINE_NBR  ,
 pclm_wrk.CLM_SOR_CD   ,
 pclm_wrk.INN_CD      ,
 pclm_wrk. src_srvc_dnl_rsn_cd      ,
 pclm_wrk.clm_nbr   ,
 pclm_wrk.rx_filled_dt ,
 pclm_wrk.ndc   ,
 pclm_wrk.rx_nbr   ,
 pclm_wrk.src_grp_nbr  , 
 pclm_wrk.rptg_clm_line_adjdctn_stts_cd  ,
 pclm_wrk.prmpt_pay_clm_rcvd_dt   ,
 pclm_wrk.clm_rcvd_dt   ,
 pclm_wrk.adjdctn_dt         ,
 cl.MBR_KEY ,
 cl.MBRSHP_SOR_CD , 
 cl.GRNDFTHR_IND_CD  ,
 MHE.HIX_CD ,
 BPA.GRNDFTHRG_STTS_CD , 
 BPA.hcr_cmplynt_cd ,
 BPA.EXCHNG_IND_CD ,
 BPA.EXCHNG_METL_TYPE_CD ,
 BPA.SRC_EXCHNG_CERTFN_CD ,
 cl.MBU_CF_CD  ,
 cl.PROD_CF_CD ,
 cl.CMPNY_CF_CD ,
 cl.FUNDG_CF_CD ,
 BRD.State ,
 MED.GL_LVL_DESC,
 MED.GL_CF_DESC,
 --cl.src_grp_nbr,
cl.src_subgrp_nbr  
)x
--where x.IN_Exchange = 'IN' OR x.OUTOFF_Exchange = 'OUTOFF' 

    """
  
  
   def sparkInIt(){
    spark.sql(naic_mcas_hlthex_clmphmcy_received_cat_wrk())
    spark.close()
  }
}
object PCADX_SCL_NAIC2018_CLMPHRMCY_ReceivedCAT{
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val clmPhmy = new PCADX_SCL_NAIC2018_CLMPHRMCY_ReceivedCAT()
		clmPhmy.sparkInIt()
	}


}