package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator

import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit

import org.apache.hadoop.fs._;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

class PCADX_SCL_NAIC2018_PAPHMCY_REQSTD {

	val spark = SparkSession.builder().config("hive.exec.dynamic.partition","true").
			config("hive.exec.dynamic.partition.mode", "nonstrict").
			config("spark.sql.parquet.compression.codec", "snappy").
			config("hive.warehouse.data.skipTrash","true").
			config("spark.sql.parquet.writeLegacyFormat","true").
			enableHiveSupport().getOrCreate() 

			spark.conf.set("spark.sql.crossJoin.enabled", "true")
			import spark.implicits._

			val dbProperties = new Properties
			dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
			var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_DataExtraction])
			val dbwrk = dbProperties.getProperty("work.db")
			val dbInbnd = dbProperties.getProperty("inbound.db")
			val reportYear=dbProperties.getProperty("report.year")
			val reqstd_strtdt = dbProperties.getProperty("reqstd_pa_temp_strtDt")
			val reqstd_enddt = dbProperties.getProperty("reqstd_pa_temp_endDt")
			val wrhDb = dbProperties.getProperty("warehouse.db")
			val prcp_cd = dbProperties.getProperty("PRCP_TYPE_CD")
			val audit_log_df = spark.sql("select * from "+wrhDb+".audt_load_log") 
			val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString() 
			println("load_log_key : "+load_log_key)
			def sparkInIt(){
				   val helper = new PCADX_SCL_NAIC2018_PAPHMCY_HelperRqstd()
				   val tbl= dbwrk + ".naic2018_mcas_hlthex_paphmcy_reqstd_wrk"
				   val tb2= dbwrk + ".naic2018_mcas_hlthex_paphmcy_reqstd_wrk1"
				   val tempCol = "um_rqst_initd_dt"
				   spark.sql(helper.rqstdTrnctTbl(tbl))
				   spark.sql(helper.rqstdTrnctTbl(tb2))
					 spark.sql(helper.reqstdwrk1(dbInbnd,tb2,load_log_key,reqstd_strtdt,reqstd_enddt))
					 spark.sql(helper.rqstdTtlIndvdl(dbwrk,dbInbnd,tbl,tb2,reportYear,load_log_key,tempCol,prcp_cd))
					 spark.sql(helper.rqstdSmllGrp(dbwrk,dbInbnd,tbl,tb2,reportYear,load_log_key,tempCol,prcp_cd))
					 spark.sql(helper.rqstdAll(dbwrk,dbInbnd,tbl,tb2,reportYear,load_log_key,tempCol,prcp_cd))
           spark.sql(helper.rqstdAllEx(dbwrk,dbInbnd,tbl,tb2,reportYear,load_log_key,tempCol,prcp_cd))
					 spark.sql(helper.rqstdAllLgp(dbwrk,dbInbnd,tbl,tb2,reportYear,load_log_key,tempCol,prcp_cd))
           spark.close()
			}



}


object PCADX_SCL_NAIC2018_PAPHMCY_REQSTD{
	def main(args : Array[String]){
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		new PCADX_SCL_NAIC2018_PAPHMCY_REQSTD().sparkInIt()
		println("insert sucesfully completed")
	}
}