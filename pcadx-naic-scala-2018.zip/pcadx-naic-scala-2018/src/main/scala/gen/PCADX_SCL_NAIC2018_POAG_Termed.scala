package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator

import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit

import org.apache.hadoop.fs._;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

class PCADX_SCL_NAIC2018_POAG_Termed {

	val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
			config("hive.exec.dynamic.partition.mode", "nonstrict").
			config("spark.sql.parquet.compression.codec", "snappy").
			config("hive.warehouse.data.skipTrash", "true").
			config("spark.sql.parquet.writeLegacyFormat", "true").
			enableHiveSupport().getOrCreate()

			import spark.implicits._
			val dbProperties = new Properties
			dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
			var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_DataExtraction])
			val dbWrk = dbProperties.getProperty("work.db")
			val dbInbnd = dbProperties.getProperty("inbound.db")

			val reportYear = dbProperties.getProperty("report.year")
			val mbrEffBetFrmDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_BET_FROM")
			val mbrEffBetToDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_BET_TO")
			val mbrEffNotBetFrmDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_NOT_BET_FROM")
			val mbrEffNotBetToDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_NOT_BET_TO")
			val mbrTrmntBetFrmDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_TRMNTN_DT_BET_FROM")
			val mbrTrmntBetToDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_TRMNTN_DT_BET_TO")
			val mbrTrmntGrtr = dbProperties.getProperty("MBR_PROD_ENRLMNT_TRMNTN_DT_GREATER")
			val mbrTrmntTermed = dbProperties.getProperty("MBR_PROD_ENRLMNT_TRMNTN_DT_TERMED")
			val PRCHSREBetFrmDt = dbProperties.getProperty("PRCHSR_ORG_EFCTV_DT_BET_FROM")
			val PRCHSREBetToDt = dbProperties.getProperty("PRCHSR_ORG_EFCTV_DT_BET_TO")
			val PRCHSRENotBetFrmDt = dbProperties.getProperty("PRCHSR_ORG_EFCTV_DT_NOT_BET_FROM")
			val PRCHSRENotBetToDt = dbProperties.getProperty("PRCHSR_ORG_EFCTV_DT_NOT_BET_TO")
			val PRCHSRTrmntBetFrmDt = dbProperties.getProperty("PRCHSR_ORG_TRMNTN_DT_BET_FROM")
			val PRCHSRTrmntBetToDt = dbProperties.getProperty("PRCHSR_ORG_TRMNTN_DT_BET_TO")
			val PRCHSRTrmntGrtr = dbProperties.getProperty("PRCHSR_ORG_TRMNTN_DT_GREATER")
			val wrhDb = dbProperties.getProperty("warehouse.db")
			val audit_log_df = spark.sql("select * from " + wrhDb + ".audt_load_log")
			val load_log_key = audit_log_df.filter($"subj_area_nm" === "NAIC2018_MCAS" && $"prcs_nm" === "NAIC2018_MCAS_RPT" && $"load_stts_cd" === "S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString()
			println("load_log_key : " + load_log_key)
			println(" DB INBND : " + dbInbnd)
			println(" DB wrk : " + dbWrk)

			def termedTrnctTbl() = """Truncate table """+dbWrk+""".naic2018_mcas_hlthex_poag_termed_wrk"""

			def termedLG() = """Insert into table """+dbWrk+""".naic2018_mcas_hlthex_poag_termed_wrk

			select     z.health_year,             
			z.sbscrbr_id,              
			z.mbr_key,                 
			z.mbrshp_sor_cd,           
			z.grndfthr_ind_cd,         
			z.mbu_cf_cd,               
			z.prod_cf_cd,              
			z.cmpny_cf_cd,             
			z.fundg_cf_cd ,            
			z.exchng_ind_cd,           
			z.exchng_metl_type_cd,     
			z.grndfthrg_stts_cd ,      
			z.hcr_cmplynt_cd,          
			z.src_exchng_certfn_cd,    
			z.hix_cd,                  
			z.state ,                  
			z.in_exchange,             
			z.outoff_exchange,         
			z.naic_lob,                
			z.naic_prod_desc,          
			z.src_grp_nbr,             
			z.src_subgrp_nbr,          
			z.pog_mbrshp_sor_cd,       
			z.prchsr_org_type_cd,      
			z.prchsr_org_efctv_dt,     
			z.prchsr_org_trmntn_dt, 
      z.prchsr_org_trmntn_rsn_cd,   
			z.prchsr_org_nm,           
			z.rnwl_dt,                 
			z.bnft_pkg_nm,             
			z.bnft_pkg_id, 
			z.load_log_key,            
			z.load_dt  

			from
			(

			select 
			"""+reportYear+"""  as health_year,
			temp.SBSCRBR_ID AS SBSCRBR_ID,
			temp.MBR_KEY AS MBR_KEY,
			temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
			temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
			temp.MBR_RLTNSHP_CD AS MBR_RLTNSHP_CD,
			temp.MBR_PROD_ENRLMNT_TRMNTN_DT AS MBR_PROD_ENRLMNT_TRMNTN_DT,
			temp.MBR_PROD_ENRLMNT_EFCTV_DT AS MBR_PROD_ENRLMNT_EFCTV_DT,
			temp.MBU_CF_CD AS MBU_CF_CD ,
			temp.PROD_CF_CD AS PROD_CF_CD,
			temp.CMPNY_CF_CD AS CMPNY_CF_CD,
			temp.FUNDG_CF_CD AS FUNDG_CF_CD,
			temp.EXCHNG_IND_CD AS EXCHNG_IND_CD, 
			temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
			temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD AS HIX_CD,
			BRD.State AS  State,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    
			and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
			WHEN temp.EXCHNG_IND_CD IN ('PB') THEN 'IN' 
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'IN'
			END AS IN_Exchange ,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and 
			temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
			WHEN temp.EXCHNG_IND_CD IN ('PR' , 'OF') THEN  'OUTOFF'
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'OUTOFF'
			END AS OUTOFF_Exchange, 
			CB.GL_LVL_DESC AS naic_lob,
			MED.GL_CF_DESC  AS  naic_prod_desc,
			temp.SRC_GRP_NBR AS src_grp_nbr, 
			temp.SRC_SUBGRP_NBR AS src_subgrp_nbr,
			temp.pog_mbrshp_sor_cd   AS pog_mbrshp_sor_cd,  
			temp.prchsr_org_type_cd  AS prchsr_org_type_cd,  
			temp.prchsr_org_efctv_dt AS prchsr_org_efctv_dt,  
			temp.prchsr_org_trmntn_dt AS prchsr_org_trmntn_dt,  
			temp.prchsr_org_nm   AS prchsr_org_nm,
			temp.rnwl_dt AS rnwl_dt,
			temp.bnft_pkg_nm AS bnft_pkg_nm ,
			temp.bnft_pkg_id AS bnft_pkg_id,
			temp.pog_src_grp_nbr as pog_src_grp_nbr,
			temp.prchsr_org_trmntn_rsn_cd as prchsr_org_trmntn_rsn_cd,
			""" + load_log_key + """ AS load_log_key, 
			current_timestamp  AS load_dt

			FROM  """+dbWrk+""".naic2018_mcas_hlthex_poa_wrk temp
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE'  , 'TOTAL NATIONAL CBE' )
			group by CF_CD, GL_LVL_DESC
			) as CB
			on CB.CF_CD = temp.MBU_CF_CD
			inner join (
			select CF_CD,GL_CF_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			group by CF_CD,GL_CF_DESC
			) as MED
			on MED.CF_CD = temp.PROD_CF_CD
			inner join
			(
			select
			gl.CF_CD
			,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
			and ((gl.GL_LVL_DESC like ('NON BLUE%') or gl.GL_LVL_DESC like ('BLUE%')) and gl.GL_LVL_DESC not like '%TOTAL' )

			group by gl.CF_CD,State
			) BRD
			on BRD.CF_CD= temp.MBU_CF_CD
			and BRD.state <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE     GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC
			ON FC.CF_CD = temp.FUNDG_CF_CD

			INNER JOIN """+dbInbnd+""".naic2018_mcas_gphm_trmntn_rsncd_inbnd inbnd
			ON temp.MBR_ENRLMNT_TRMNTN_RSN_CD = inbnd.mbr_enrlmnt_trmntn_rsncd
			AND temp.SRC_MBR_ENRLMNT_TRMNTN_RSN_CD = inbnd.src_mbr_enrlmnt_trmntn_rsncd
			AND temp.mbrshp_sor_cd = inbnd.mbrshp_sor_cd

			LEFT OUTER JOIN  """+dbWrk+""".termed_prchsrcgrpnotin srcgrpim
			on temp.pog_mbrshp_sor_cd = srcgrpim.mbrshp_sor_cd
			AND temp.pog_src_grp_nbr = srcgrpim.src_grp_nbr

			WHERE

			temp.RCRD_STTS_CD <> 'DEL'
			AND srcgrpim.mbrshp_sor_cd is  null
			AND srcgrpim.src_grp_nbr is null
      AND ( temp.prchsr_org_trmntn_dt BETWEEN """ + PRCHSRTrmntBetFrmDt + """ AND """ + PRCHSRTrmntBetToDt + """
			      OR temp.prchsr_org_trmntn_dt =   """ + PRCHSRENotBetToDt + """ )
			    AND temp.prchsr_org_trmntn_dt <  """ + PRCHSRTrmntGrtr + """
			AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
			AND temp.MBU_CF_CD NOT IN ( 'EDCASH' , 'SPGAZZ','EDCOSH' , 'EDINSH')

			GROUP BY 
			temp.SBSCRBR_ID,
			temp.MBR_KEY,
			temp.MBRSHP_SOR_CD,
			temp.GRNDFTHR_IND_CD,
			temp.MBR_RLTNSHP_CD,
			temp.MBR_PROD_ENRLMNT_TRMNTN_DT,
			temp.MBR_PROD_ENRLMNT_EFCTV_DT,
			temp.MBU_CF_CD ,
			temp.PROD_CF_CD,
			temp.CMPNY_CF_CD,
			temp.FUNDG_CF_CD,
			temp.EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD,
			temp.hcr_cmplynt_cd,
			temp.SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD,
			BRD.State,
			CB.GL_LVL_DESC ,
			MED.GL_CF_DESC ,
			temp.SRC_GRP_NBR,
			temp.SRC_SUBGRP_NBR,
			temp.pog_mbrshp_sor_cd,
			temp.prchsr_org_type_cd,
			temp.prchsr_org_efctv_dt,
			temp.prchsr_org_trmntn_dt,
			temp.prchsr_org_nm,
			temp.rnwl_dt,
			temp.bnft_pkg_nm,
			temp.pog_src_grp_nbr,
			temp.bnft_pkg_id,
			temp.prchsr_org_trmntn_rsn_cd

			) z

			"""


			def termedLG_step2() = """Insert into table """+dbWrk+""".naic2018_mcas_hlthex_poag_termed_wrk

			select     z.health_year,             
			z.sbscrbr_id,              
			z.mbr_key,                 
			z.mbrshp_sor_cd,           
			z.grndfthr_ind_cd,         
			z.mbu_cf_cd,               
			z.prod_cf_cd,              
			z.cmpny_cf_cd,             
			z.fundg_cf_cd ,            
			z.exchng_ind_cd,           
			z.exchng_metl_type_cd,     
			z.grndfthrg_stts_cd ,      
			z.hcr_cmplynt_cd,          
			z.src_exchng_certfn_cd,    
			z.hix_cd,                  
			z.state ,                  
			z.in_exchange,             
			z.outoff_exchange,         
			z.naic_lob,                
			z.naic_prod_desc,          
			z.src_grp_nbr,             
			z.src_subgrp_nbr,          
			z.pog_mbrshp_sor_cd,       
			z.prchsr_org_type_cd,      
			z.prchsr_org_efctv_dt,     
			z.prchsr_org_trmntn_dt,
      z.prchsr_org_trmntn_rsn_cd,    
			z.prchsr_org_nm,           
			z.rnwl_dt,                 
			z.bnft_pkg_nm,             
			z.bnft_pkg_id,
			z.load_log_key,            
			z.load_dt  

			from
			(

			select 
			"""+reportYear+"""  as health_year,
			temp.SBSCRBR_ID AS SBSCRBR_ID,
			temp.MBR_KEY AS MBR_KEY,
			temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
			temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
			temp.MBR_RLTNSHP_CD AS MBR_RLTNSHP_CD,
			temp.MBR_PROD_ENRLMNT_TRMNTN_DT AS MBR_PROD_ENRLMNT_TRMNTN_DT,
			temp.MBR_PROD_ENRLMNT_EFCTV_DT AS MBR_PROD_ENRLMNT_EFCTV_DT,
			temp.MBU_CF_CD AS MBU_CF_CD ,
			temp.PROD_CF_CD AS PROD_CF_CD,
			temp.CMPNY_CF_CD AS CMPNY_CF_CD,
			temp.FUNDG_CF_CD AS FUNDG_CF_CD,
			temp.EXCHNG_IND_CD AS EXCHNG_IND_CD, 
			temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
			temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD AS HIX_CD,
			BRD.State AS  State,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    
			and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
			WHEN temp.EXCHNG_IND_CD IN ('PB') THEN 'IN' 
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'IN'
			END AS IN_Exchange ,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and 
			temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
			WHEN temp.EXCHNG_IND_CD IN ('PR' , 'OF') THEN  'OUTOFF'
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'OUTOFF'
			END AS OUTOFF_Exchange, 
			CB.GL_LVL_DESC AS naic_lob,
			MED.GL_CF_DESC  AS  naic_prod_desc,
			temp.SRC_GRP_NBR AS src_grp_nbr, 
			temp.SRC_SUBGRP_NBR AS src_subgrp_nbr,
			temp.pog_mbrshp_sor_cd   AS pog_mbrshp_sor_cd,  
			temp.prchsr_org_type_cd  AS prchsr_org_type_cd,  
			temp.prchsr_org_efctv_dt AS prchsr_org_efctv_dt,  
			temp.prchsr_org_trmntn_dt AS prchsr_org_trmntn_dt,  
			temp.prchsr_org_nm   AS prchsr_org_nm,
			temp.rnwl_dt AS rnwl_dt,
			temp.bnft_pkg_nm AS bnft_pkg_nm ,
			temp.bnft_pkg_id AS bnft_pkg_id,
			temp.pog_src_grp_nbr as pog_src_grp_nbr,
			temp.prchsr_org_trmntn_rsn_cd as prchsr_org_trmntn_rsn_cd,
			""" + load_log_key + """ AS load_log_key, 
			current_timestamp  AS load_dt

			FROM  """+dbWrk+""".naic2018_mcas_hlthex_poa_wrk temp
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE'  , 'TOTAL NATIONAL CBE' )
			group by CF_CD, GL_LVL_DESC
			) as CB
			on CB.CF_CD = temp.MBU_CF_CD
			inner join (
			select CF_CD,GL_CF_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			group by CF_CD,GL_CF_DESC
			) as MED
			on MED.CF_CD = temp.PROD_CF_CD
			inner join
			(
			select
			gl.CF_CD
			,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
			and ((gl.GL_LVL_DESC like ('NON BLUE%') or gl.GL_LVL_DESC like ('BLUE%')) and gl.GL_LVL_DESC not like '%TOTAL' )

			group by gl.CF_CD,State
			) BRD
			on BRD.CF_CD= temp.MBU_CF_CD
			and BRD.state <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE     GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC
			ON FC.CF_CD = temp.FUNDG_CF_CD

			INNER JOIN """+dbInbnd+""".naic2018_mcas_gphg_trmntn_rsncd_inbnd inbnd
			ON temp.prchsr_org_trmntn_rsn_cd = inbnd.prchsr_org_trmntn_rsncd
			AND temp.mbrshp_sor_cd = inbnd.mbrshp_sor_cd

			LEFT OUTER JOIN  """+dbWrk+""".termed_prchsrcgrpnotin srcgrpim
			on temp.pog_mbrshp_sor_cd = srcgrpim.mbrshp_sor_cd
			AND temp.pog_src_grp_nbr = srcgrpim.src_grp_nbr

			WHERE

			temp.RCRD_STTS_CD <> 'DEL'
			AND (srcgrpim.mbrshp_sor_cd is  null AND srcgrpim.src_grp_nbr is null)
			AND ( temp.prchsr_org_trmntn_dt BETWEEN """ + PRCHSRTrmntBetFrmDt + """ AND """ + PRCHSRTrmntBetToDt + """
			      OR temp.prchsr_org_trmntn_dt =   """ + PRCHSRENotBetToDt + """ )
			    AND temp.prchsr_org_trmntn_dt <  """ + PRCHSRTrmntGrtr + """
      AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
			AND temp.MBU_CF_CD NOT IN ( 'EDCASH' , 'SPGAZZ','EDCOSH' , 'EDINSH' )

			GROUP BY 
			temp.SBSCRBR_ID,
			temp.MBR_KEY,
			temp.MBRSHP_SOR_CD,
			temp.GRNDFTHR_IND_CD,
			temp.MBR_RLTNSHP_CD,
			temp.MBR_PROD_ENRLMNT_TRMNTN_DT,
			temp.MBR_PROD_ENRLMNT_EFCTV_DT,
			temp.MBU_CF_CD ,
			temp.PROD_CF_CD,
			temp.CMPNY_CF_CD,
			temp.FUNDG_CF_CD,
			temp.EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD,
			temp.hcr_cmplynt_cd,
			temp.SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD,
			BRD.State,
			CB.GL_LVL_DESC ,
			MED.GL_CF_DESC ,
			temp.SRC_GRP_NBR,
			temp.SRC_SUBGRP_NBR,
			temp.pog_mbrshp_sor_cd,
			temp.prchsr_org_type_cd,
			temp.prchsr_org_efctv_dt,
			temp.prchsr_org_trmntn_dt,
			temp.prchsr_org_nm,
			temp.rnwl_dt,
			temp.bnft_pkg_nm,
			temp.pog_src_grp_nbr,
			temp.bnft_pkg_id,
			temp.prchsr_org_trmntn_rsn_cd

			) z

			"""

			def termedLG_SrcGrp() = """Insert into table """+dbWrk+""".naic2018_mcas_hlthex_poag_termed_wrk
			select     z.health_year,             
			z.sbscrbr_id,
			z.mbr_key,
			z.mbrshp_sor_cd,
			z.grndfthr_ind_cd,
			z.mbu_cf_cd,
			z.prod_cf_cd,
			z.cmpny_cf_cd,
			z.fundg_cf_cd,
			z.exchng_ind_cd,
			z.exchng_metl_type_cd,
			z.grndfthrg_stts_cd,
			z.hcr_cmplynt_cd,
			z.src_exchng_certfn_cd,
			z.hix_cd,
			z.state,
			z.in_exchange,
			z.outoff_exchange,
			z.naic_lob,
			z.naic_prod_desc,
			z.src_grp_nbr,
			z.src_subgrp_nbr,
			z.pog_mbrshp_sor_cd,
			z.prchsr_org_type_cd,
			z.prchsr_org_efctv_dt,
			z.prchsr_org_trmntn_dt,
      z.prchsr_org_trmntn_rsn_cd,
			z.prchsr_org_nm,
			z.rnwl_dt,
			z.bnft_pkg_nm,
			z.bnft_pkg_id,
			z.load_log_key,
			z.load_dt  
			from
			(
			select 
			"""+reportYear+"""  as health_year,
			temp.SBSCRBR_ID AS SBSCRBR_ID,
			temp.MBR_KEY AS MBR_KEY,
			temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
			temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
			temp.MBR_RLTNSHP_CD AS MBR_RLTNSHP_CD,
			temp.MBR_PROD_ENRLMNT_TRMNTN_DT AS MBR_PROD_ENRLMNT_TRMNTN_DT,
			temp.MBR_PROD_ENRLMNT_EFCTV_DT AS MBR_PROD_ENRLMNT_EFCTV_DT,
			temp.MBU_CF_CD AS MBU_CF_CD ,
			temp.PROD_CF_CD AS PROD_CF_CD,
			temp.CMPNY_CF_CD AS CMPNY_CF_CD,
			temp.FUNDG_CF_CD AS FUNDG_CF_CD,
			temp.EXCHNG_IND_CD AS EXCHNG_IND_CD, 
			temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
			temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD AS HIX_CD,
			BRD.State AS  State,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    
			and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
			WHEN temp.EXCHNG_IND_CD IN ('PB') THEN 'IN' 
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'IN'
			END AS IN_Exchange ,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and 
			temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
			WHEN temp.EXCHNG_IND_CD IN ('PR' , 'OF') THEN  'OUTOFF'
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'OUTOFF'
			END AS OUTOFF_Exchange, 
			CB.GL_LVL_DESC AS naic_lob,
			MED.GL_CF_DESC  AS  naic_prod_desc,
			temp.SRC_GRP_NBR AS src_grp_nbr, 
			temp.SRC_SUBGRP_NBR AS src_subgrp_nbr,
			temp.pog_mbrshp_sor_cd   AS pog_mbrshp_sor_cd,  
			temp.prchsr_org_type_cd  AS prchsr_org_type_cd,  
			temp.prchsr_org_efctv_dt AS prchsr_org_efctv_dt,  
			temp.prchsr_org_trmntn_dt AS prchsr_org_trmntn_dt,  
			temp.prchsr_org_nm   AS prchsr_org_nm,
			temp.rnwl_dt AS rnwl_dt,
			temp.bnft_pkg_nm AS bnft_pkg_nm ,
			temp.bnft_pkg_id AS bnft_pkg_id,
			temp.pog_src_grp_nbr as pog_src_grp_nbr,
			temp.prchsr_org_trmntn_rsn_cd as prchsr_org_trmntn_rsn_cd,
			""" + load_log_key + """ AS load_log_key, 
			current_timestamp  AS load_dt

			FROM  """+dbWrk+""".naic2018_mcas_hlthex_poa_wrk temp
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE'  , 'TOTAL NATIONAL CBE' )
			group by CF_CD, GL_LVL_DESC
			) as CB
			on CB.CF_CD = temp.MBU_CF_CD
			inner join (
			select CF_CD,GL_CF_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			group by CF_CD,GL_CF_DESC
			) as MED
			on MED.CF_CD = temp.PROD_CF_CD
			inner join
			(
			select
			gl.CF_CD
			,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
			and ((gl.GL_LVL_DESC like ('NON BLUE%') or gl.GL_LVL_DESC like ('BLUE%')) and gl.GL_LVL_DESC not like '%TOTAL' )

			group by gl.CF_CD,State
			) BRD
			on BRD.CF_CD= temp.MBU_CF_CD
			and BRD.state <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE     GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC
			ON FC.CF_CD = temp.FUNDG_CF_CD

			INNER JOIN """+dbInbnd+""".naic2018_mcas_gphm_trmntn_rsncd_inbnd inbnd
			ON temp.MBR_ENRLMNT_TRMNTN_RSN_CD = inbnd.mbr_enrlmnt_trmntn_rsncd
			AND temp.SRC_MBR_ENRLMNT_TRMNTN_RSN_CD = inbnd.src_mbr_enrlmnt_trmntn_rsncd
			AND temp.mbrshp_sor_cd = inbnd.mbrshp_sor_cd

			LEFT OUTER JOIN  """+dbWrk+""".termed_prchsrcgrpnotin srcgrpim
			on temp.pog_mbrshp_sor_cd = srcgrpim.mbrshp_sor_cd
			AND temp.pog_src_grp_nbr = srcgrpim.src_grp_nbr

			WHERE

			temp.RCRD_STTS_CD <> 'DEL'
			AND (srcgrpim.mbrshp_sor_cd is  null AND srcgrpim.src_grp_nbr is null)
			AND ( temp.prchsr_org_trmntn_dt BETWEEN """ + PRCHSRTrmntBetFrmDt + """ AND """ + PRCHSRTrmntBetToDt + """
			      OR temp.prchsr_org_trmntn_dt =   """ + PRCHSRENotBetToDt + """ )
			    AND temp.prchsr_org_trmntn_dt <  """ + PRCHSRTrmntGrtr + """
			AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
			AND temp.MBU_CF_CD  IN ('EDCASH', 'SPGAZZ', 'EDCOSH' , 'EDINSH' )
			AND ( temp.pog_src_grp_nbr IN ( '278777'  , '175089' , '175147' , '276470' ,'276500' , '277956' , '277960' , '278547' , '280438' , '280531' , '281249' , '281285' ,'281297'  , 'GA7649','175093' , '281729' , '196519' , '196614'  , 'IN2008') or
			temp.pog_src_subgrp_nbr IN   ( '278777'  , '175089' , '175147' , '276470' ,'276500' , '277956' , '277960' , '278547' , '280438' , '280531' , '281249' , '281285' ,'281297'  , 'GA7649' ,'175093' , '281729' , '196519' , '196614'  , 'IN2008')
			)
			GROUP BY 
			temp.SBSCRBR_ID,
			temp.MBR_KEY,
			temp.MBRSHP_SOR_CD,
			temp.GRNDFTHR_IND_CD,
			temp.MBR_RLTNSHP_CD,
			temp.MBR_PROD_ENRLMNT_TRMNTN_DT,
			temp.MBR_PROD_ENRLMNT_EFCTV_DT,
			temp.MBU_CF_CD ,
			temp.PROD_CF_CD,
			temp.CMPNY_CF_CD,
			temp.FUNDG_CF_CD,
			temp.EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD,
			temp.hcr_cmplynt_cd,
			temp.SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD,
			BRD.State,
			CB.GL_LVL_DESC ,
			MED.GL_CF_DESC ,
			temp.SRC_GRP_NBR,
			temp.SRC_SUBGRP_NBR,
			temp.pog_mbrshp_sor_cd,
			temp.prchsr_org_type_cd,
			temp.prchsr_org_efctv_dt,
			temp.prchsr_org_trmntn_dt,
			temp.prchsr_org_nm,
			temp.rnwl_dt,
			temp.bnft_pkg_nm,
			temp.pog_src_grp_nbr,
			temp.bnft_pkg_id,
			temp.prchsr_org_trmntn_rsn_cd

			) z

			"""
			def termedLG_SrcGrp_step2() = """
					Insert into table """+dbWrk+""".naic2018_mcas_hlthex_poag_termed_wrk
					select     z.health_year,             
					z.sbscrbr_id,
					z.mbr_key,
					z.mbrshp_sor_cd,
					z.grndfthr_ind_cd,
					z.mbu_cf_cd,
					z.prod_cf_cd,
					z.cmpny_cf_cd,
					z.fundg_cf_cd,
					z.exchng_ind_cd,
					z.exchng_metl_type_cd,
					z.grndfthrg_stts_cd,
					z.hcr_cmplynt_cd,
					z.src_exchng_certfn_cd,
					z.hix_cd,
					z.state,
					z.in_exchange,
					z.outoff_exchange,
					z.naic_lob,
					z.naic_prod_desc,
					z.src_grp_nbr,
					z.src_subgrp_nbr,
					z.pog_mbrshp_sor_cd,
					z.prchsr_org_type_cd,
					z.prchsr_org_efctv_dt,
					z.prchsr_org_trmntn_dt,
          z.prchsr_org_trmntn_rsn_cd,
					z.prchsr_org_nm,
					z.rnwl_dt,
					z.bnft_pkg_nm,
					z.bnft_pkg_id,
					z.load_log_key,
					z.load_dt  
					from
					(
					select 
					"""+reportYear+"""  as health_year,
					temp.SBSCRBR_ID AS SBSCRBR_ID,
					temp.MBR_KEY AS MBR_KEY,
					temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
					temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
					temp.MBR_RLTNSHP_CD AS MBR_RLTNSHP_CD,
					temp.MBR_PROD_ENRLMNT_TRMNTN_DT AS MBR_PROD_ENRLMNT_TRMNTN_DT,
					temp.MBR_PROD_ENRLMNT_EFCTV_DT AS MBR_PROD_ENRLMNT_EFCTV_DT,
					temp.MBU_CF_CD AS MBU_CF_CD ,
					temp.PROD_CF_CD AS PROD_CF_CD,
					temp.CMPNY_CF_CD AS CMPNY_CF_CD,
					temp.FUNDG_CF_CD AS FUNDG_CF_CD,
					temp.EXCHNG_IND_CD AS EXCHNG_IND_CD, 
					temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
					temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
					temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
					temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
					temp.HIX_CD AS HIX_CD,
					BRD.State AS  State,
					CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    
					and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
					WHEN temp.EXCHNG_IND_CD IN ('PB') THEN 'IN' 
					WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
					HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'IN'
					END AS IN_Exchange ,
					CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and 
					temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
					WHEN temp.EXCHNG_IND_CD IN ('PR' , 'OF') THEN  'OUTOFF'
					WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
					HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'OUTOFF'
					END AS OUTOFF_Exchange, 
					CB.GL_LVL_DESC AS naic_lob,
					MED.GL_CF_DESC  AS  naic_prod_desc,
					temp.SRC_GRP_NBR AS src_grp_nbr, 
					temp.SRC_SUBGRP_NBR AS src_subgrp_nbr,
					temp.pog_mbrshp_sor_cd   AS pog_mbrshp_sor_cd,  
					temp.prchsr_org_type_cd  AS prchsr_org_type_cd,  
					temp.prchsr_org_efctv_dt AS prchsr_org_efctv_dt,  
					temp.prchsr_org_trmntn_dt AS prchsr_org_trmntn_dt,  
					temp.prchsr_org_nm   AS prchsr_org_nm,
					temp.rnwl_dt AS rnwl_dt,
					temp.bnft_pkg_nm AS bnft_pkg_nm ,
					temp.bnft_pkg_id AS bnft_pkg_id,
					temp.pog_src_grp_nbr as pog_src_grp_nbr,
					temp.prchsr_org_trmntn_rsn_cd as prchsr_org_trmntn_rsn_cd,
					""" + load_log_key + """ AS load_log_key, 
					current_timestamp  AS load_dt

					FROM  """+dbWrk+""".naic2018_mcas_hlthex_poa_wrk temp
					inner join (
					select CF_CD, GL_LVL_DESC 
					from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
					WHERE GL_CF_TYPE_DESC = 'CBE'
					AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE'  , 'TOTAL NATIONAL CBE' )
					group by CF_CD, GL_LVL_DESC
					) as CB
					on CB.CF_CD = temp.MBU_CF_CD
					inner join (
					select CF_CD,GL_CF_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
					where GL_CF_TYPE_DESC = 'PRODUCT' 
					group by CF_CD,GL_CF_DESC
					) as MED
					on MED.CF_CD = temp.PROD_CF_CD
					inner join
					(
					select
					gl.CF_CD
					,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
					from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
					where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
					and ((gl.GL_LVL_DESC like ('NON BLUE%') or gl.GL_LVL_DESC like ('BLUE%')) and gl.GL_LVL_DESC not like '%TOTAL' )

					group by gl.CF_CD,State
					) BRD
					on BRD.CF_CD= temp.MBU_CF_CD
					and BRD.state <> 'LT'
					inner join
					(
					select DISTINCT CF_CD
					from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
					where  GL_CF_TYPE_DESC = 'FUND_CODE'
					and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
					WHERE     GL_CF_TYPE_DESC = 'FUND_CODE' AND  
					( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
					)
					) FC
					ON FC.CF_CD = temp.FUNDG_CF_CD

					INNER JOIN """+dbInbnd+""".naic2018_mcas_gphg_trmntn_rsncd_inbnd inbnd
					ON  temp.prchsr_org_trmntn_rsn_cd = inbnd.prchsr_org_trmntn_rsncd
					AND temp.mbrshp_sor_cd = inbnd.mbrshp_sor_cd

					LEFT OUTER JOIN  """+dbWrk+""".termed_prchsrcgrpnotin srcgrpim
					on temp.pog_mbrshp_sor_cd = srcgrpim.mbrshp_sor_cd
					AND temp.pog_src_grp_nbr = srcgrpim.src_grp_nbr

					WHERE

					temp.RCRD_STTS_CD <> 'DEL'
					AND (srcgrpim.mbrshp_sor_cd is  null AND srcgrpim.src_grp_nbr is null)
					AND ( temp.prchsr_org_trmntn_dt BETWEEN """ + PRCHSRTrmntBetFrmDt + """ AND """ + PRCHSRTrmntBetToDt + """
			      OR temp.prchsr_org_trmntn_dt =   """ + PRCHSRENotBetToDt + """ )
			    AND temp.prchsr_org_trmntn_dt <  """ + PRCHSRTrmntGrtr + """
			  
					AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
					AND temp.MBU_CF_CD IN ( 'EDCASH' , 'SPGAZZ','EDCOSH' , 'EDINSH' )
					AND ( temp.pog_src_grp_nbr IN ( '278777'  , '175089' , '175147' , '276470' ,'276500' , '277956' , '277960' , '278547' , '280438' , '280531' , '281249' , '281285' ,'281297'  , 'GA7649','175093' , '281729' , '196519' , '196614'  , 'IN2008') 
					or  temp.pog_src_subgrp_nbr IN   ( '278777'  , '175089' , '175147' , '276470' ,'276500' , '277956' , '277960' , '278547' , '280438' , '280531' , '281249' , '281285' ,'281297'  , 'GA7649' ,'175093' , '281729' , '196519' , '196614'  , 'IN2008')
					)

					GROUP BY 
					temp.SBSCRBR_ID,
					temp.MBR_KEY,
					temp.MBRSHP_SOR_CD,
					temp.GRNDFTHR_IND_CD,
					temp.MBR_RLTNSHP_CD,
					temp.MBR_PROD_ENRLMNT_TRMNTN_DT,
					temp.MBR_PROD_ENRLMNT_EFCTV_DT,
					temp.MBU_CF_CD ,
					temp.PROD_CF_CD,
					temp.CMPNY_CF_CD,
					temp.FUNDG_CF_CD,
					temp.EXCHNG_IND_CD,
					temp.EXCHNG_METL_TYPE_CD,
					temp.GRNDFTHRG_STTS_CD,
					temp.hcr_cmplynt_cd,
					temp.SRC_EXCHNG_CERTFN_CD,
					temp.HIX_CD,
					BRD.State,
					CB.GL_LVL_DESC ,
					MED.GL_CF_DESC ,
					temp.SRC_GRP_NBR,
					temp.SRC_SUBGRP_NBR,
					temp.pog_mbrshp_sor_cd,
					temp.prchsr_org_type_cd,
					temp.prchsr_org_efctv_dt,
					temp.prchsr_org_trmntn_dt,
					temp.prchsr_org_nm,
					temp.rnwl_dt,
					temp.bnft_pkg_nm,
					temp.pog_src_grp_nbr,
					temp.bnft_pkg_id,
					temp.prchsr_org_trmntn_rsn_cd

					) z

					"""



			def sparkInIt(){
			spark.sql(termedTrnctTbl())
				spark.sql(termedLG())
				spark.sql(termedLG_step2())  // 2018 new query for group  level lookup
				spark.sql(termedLG_SrcGrp())
				spark.sql(termedLG_SrcGrp_step2()) // 2018 new query for group  level lookup
				spark.stop()
			}

}

object PCADX_SCL_NAIC2018_POAG_Termed {
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val term = new PCADX_SCL_NAIC2018_POAG_Termed()
		term.sparkInIt()
		println("$$$$$$$$$$$$$$$$$")
	}
}