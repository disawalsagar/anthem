package gen
import java.util.Properties
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.sql.Timestamp
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import scala.io.Source
import org.slf4j.{ Logger, LoggerFactory }
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit
import org.apache.log4j.PropertyConfigurator
import org.apache.hadoop.fs._;

class PCADX_SCL_NAIC2018_PAEXPHMCY_UNICARE_DENIED {

	val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
			config("hive.exec.dynamic.partition.mode", "nonstrict").
			config("spark.sql.parquet.compression.codec", "snappy").
			config("hive.warehouse.data.skipTrash", "true").
			config("spark.sql.parquet.writeLegacyFormat", "true").
			enableHiveSupport().getOrCreate()

			import spark.implicits._

			var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_PAEXPHMCY_UNICARE_DENIED])

			val dbProperties = new Properties
			dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
			val dbStg = dbProperties.getProperty("work.db")
			val dbInbnd = dbProperties.getProperty("inbound.db")
			val dbWrk = dbProperties.getProperty("work.db")
			val reportYear = dbProperties.getProperty("report.year")
			val wrhDb = dbProperties.getProperty("warehouse.db")
			val audit_log_df = spark.sql("select * from " + wrhDb + ".audt_load_log")

			val load_log_key = audit_log_df.filter($"subj_area_nm" === "NAIC2018_MCAS" && $"prcs_nm" === "NAIC2018_MCAS_RPT" && $"load_stts_cd" === "S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0)
			println("load_log_key : " + load_log_key)
			val denied_strtdt = dbProperties.getProperty("denied_pa_temp_strtDt")
			val denied_enddt = dbProperties.getProperty("denied_pa_temp_endDt")

			def naic2018_mcas_hlthex_paexphmcy_unicare_ma_denied_wrk(tblwrk1: String) = """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_unicare_denied_wrk""" + """
					select * from              
					( 
					SELECT 
					""" + reportYear + """  as health_year,
					PA1.RFRNC_NBR AS RFRNC_NBR ,
          PA1.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
          UNI.MBR_KEY AS MBR_KEY,
					UNI.MBRSHP_SOR_CD AS MBRSHP_SOR_CD, 
					UNI.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
					UNI.MBU_CF_CD AS MBU_CF_CD ,
					UNI.PROD_CF_CD AS PROD_CF_CD,
					'G0365' AS CMPNY_CF_CD,
					UNI.FUNDG_CF_CD AS FUNDG_CF_CD,
					UNI.EXCHNG_IND_CD AS EXCHNG_IND_CD,
					UNI.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
					UNI.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,   
					UNI.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
					UNI.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
					'MA'  AS  State,
					NULL   AS IN_Exchange ,
					'OUTOFF'  AS OUTOFF_Exchange, 
					'LARGE GROUP CBE'  AS naic_lob,
					MED.GL_CF_DESC  as  naic_prod_desc,
					UNI.PRCP_TYPE_CD as prcp_type_cd ,
					PA1.case_type_cd as case_type_cd,
					UNI.src_grp_nbr,
					UNI.src_subgrp_nbr,			
					$1 as load_log_key,
					current_timestamp as load_dt

					from
					(select * from """ + tblwrk1 + """ )  PA1
					INNER JOIN """+dbWrk+""".clm_inter UNI
					ON PA1.MBR_KEY = UNI.MBR_KEY

					inner join (
					select CF_CD,  GL_CF_DESC  
					from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
					where GL_CF_TYPE_DESC = 'PRODUCT' 
					group by 1,2
					) as MED
					on MED.CF_CD = UNI.PROD_CF_CD

					inner join
					(
					select DISTINCT CF_CD
					from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
					where  GL_CF_TYPE_DESC = 'FUND_CODE'
					and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
					where  GL_CF_TYPE_DESC = 'FUND_CODE' 
					AND    ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
					)
					) FC
					ON FC.CF_CD = UNI.FUNDG_CF_CD

					WHERE (UNI.SRC_GRP_NBR = '131192' or UNI.ORG_GRP_SRC_GRP_NBR  = '131192')
					AND PA1.STTS_DT  between UNI.mbr_prod_enrlmnt_efctv_dt and UNI.mbr_prod_enrlmnt_trmntn_dt
					AND ( ( UNI.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN UNI.prchsr_org_efctv_dt AND UNI.prchsr_org_trmntn_dt) OR UNI.prchsr_org_trmntn_dt IS NULL)
					AND ( UNI.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN UNI.MBR_COA_EFCTV_DT AND UNI.MBR_COA_TRMNTN_DT) 
					AND UNI.DUP_DATA_CD = '00'
					GROUP BY 
					PA1.RFRNC_NBR  ,
          PA1.SRVC_LINE_NBR  ,
          UNI.MBR_KEY ,
					UNI.MBRSHP_SOR_CD , 
					UNI.GRNDFTHR_IND_CD  ,
					UNI.GRNDFTHRG_STTS_CD ,    
					UNI.hcr_cmplynt_cd,
					UNI.EXCHNG_IND_CD ,
					UNI.EXCHNG_METL_TYPE_CD ,
					UNI.SRC_EXCHNG_CERTFN_CD ,
					UNI.MBU_CF_CD  ,
					UNI.PROD_CF_CD ,
					UNI.FUNDG_CF_CD ,
					MED.GL_CF_DESC,
					UNI.PRCP_TYPE_CD,
					PA1.case_type_cd,
					UNI.src_grp_nbr,
					UNI.src_subgrp_nbr
					)"""

					def naic2018_mcas_hlthex_paexphmcy_unicare_il_denied_wrk(tblwrk1: String) = """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_unicare_denied_wrk""" + """
							select * from              
							( 
							SELECT 
							""" + reportYear + """  as health_year,
							PA1.RFRNC_NBR AS RFRNC_NBR ,
							PA1.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
							UNI.MBR_KEY AS MBR_KEY,
							UNI.MBRSHP_SOR_CD AS MBRSHP_SOR_CD, 
							UNI.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
							UNI.MBU_CF_CD AS MBU_CF_CD ,
							UNI.PROD_CF_CD AS PROD_CF_CD,
							'G0365'        AS CMPNY_CF_CD,
							UNI.FUNDG_CF_CD AS FUNDG_CF_CD,
							UNI.EXCHNG_IND_CD AS EXCHNG_IND_CD,
							UNI.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
							UNI.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,   
							UNI.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
							UNI.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
							'IL'  AS  State,
							NULL   AS IN_Exchange ,
							'OUTOFF'  AS OUTOFF_Exchange, 
							'LARGE GROUP GRAND'  AS naic_lob,
							MED.GL_CF_DESC  as  naic_prod_desc,
							UNI.PRCP_TYPE_CD as prcp_type_cd ,
							PA1.case_type_cd as case_type_cd,
							UNI.src_grp_nbr,
							UNI.src_subgrp_nbr,
							$1 as load_log_key,
							current_timestamp as load_dt

							from
							(select * from """ + tblwrk1 + """ )  PA1
							INNER JOIN """+dbWrk+""".clm_inter UNI
							ON PA1.MBR_KEY = UNI.MBR_KEY

							inner join (
							select CF_CD,  GL_CF_DESC  
							from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
							where GL_CF_TYPE_DESC = 'PRODUCT' 
							group by 1,2
							) as MED
							on MED.CF_CD = UNI.PROD_CF_CD

							inner join
							(
							select DISTINCT CF_CD
							from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
							where  GL_CF_TYPE_DESC = 'FUND_CODE'
							and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
							where  GL_CF_TYPE_DESC = 'FUND_CODE' 
							AND    ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
							)
							) FC
							ON FC.CF_CD = UNI.FUNDG_CF_CD


							where (UNI.SRC_SUBGRP_NBR in (       
							'131195M001',       
							'131196M001',       
							'141333M001',       
							'145447M001'       
							)    or
							UNI.ORG_GRP_SRC_SUBGRP_NBR in (
							'131195M001',       
							'131196M001',       
							'141333M001',       
							'145447M001'))

							AND PA1.STTS_DT  between UNI.mbr_prod_enrlmnt_efctv_dt and UNI.mbr_prod_enrlmnt_trmntn_dt

							AND ( ( UNI.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN UNI.prchsr_org_efctv_dt AND UNI.prchsr_org_trmntn_dt) OR UNI.prchsr_org_trmntn_dt IS NULL)
							AND ( UNI.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN UNI.MBR_COA_EFCTV_DT AND UNI.MBR_COA_TRMNTN_DT) 
							AND UNI.DUP_DATA_CD = '00' 

							GROUP BY 
							PA1.RFRNC_NBR  ,
							PA1.SRVC_LINE_NBR,
							UNI.MBR_KEY ,
							UNI.MBRSHP_SOR_CD , 
							UNI.GRNDFTHR_IND_CD  ,
							UNI.GRNDFTHRG_STTS_CD ,    
							UNI.hcr_cmplynt_cd,
							UNI.EXCHNG_IND_CD ,
							UNI.EXCHNG_METL_TYPE_CD ,
							UNI.SRC_EXCHNG_CERTFN_CD ,
							UNI.MBU_CF_CD  ,
							UNI.PROD_CF_CD ,
							UNI.FUNDG_CF_CD ,
							MED.GL_CF_DESC ,
							UNI.PRCP_TYPE_CD,
							PA1.case_type_cd,
							UNI.src_grp_nbr,
							UNI.src_subgrp_nbr
							)"""

							def naic2018_mcas_hlthex_paexphmcy_unicare_dc_denied_wrk(tblwrk1: String) = """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_unicare_denied_wrk""" + """
									select * from              
									( 
									SELECT 
									""" + reportYear + """  as health_year,
									PA1.RFRNC_NBR AS RFRNC_NBR ,
                	PA1.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
                  UNI.MBR_KEY AS MBR_KEY,
									UNI.MBRSHP_SOR_CD AS MBRSHP_SOR_CD, 
									UNI.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
									UNI.MBU_CF_CD AS MBU_CF_CD ,
									UNI.PROD_CF_CD AS PROD_CF_CD,
									'G0365'        AS CMPNY_CF_CD,
									UNI.FUNDG_CF_CD AS FUNDG_CF_CD,
									UNI.EXCHNG_IND_CD AS EXCHNG_IND_CD,
									UNI.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
									UNI.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,   
									UNI.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
									UNI.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
									'DC'  AS  State,
									NULL   AS IN_Exchange ,
									'OUTOFF'  AS OUTOFF_Exchange, 
									'INDIVIDUAL GRAND'  AS naic_lob,
									MED.GL_CF_DESC  as  naic_prod_desc,
									UNI.PRCP_TYPE_CD as prcp_type_cd ,
									PA1.case_type_cd as case_type_cd,
									UNI.src_grp_nbr,
									UNI.src_subgrp_nbr,
									$1 as load_log_key,
									current_timestamp as load_dt

									from
									(select * from """ + tblwrk1 + """ )  PA1
									INNER JOIN """+dbWrk+""".clm_inter UNI
									ON PA1.MBR_KEY = UNI.MBR_KEY

									inner join (
									select CF_CD,  GL_CF_DESC  
									from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
									where GL_CF_TYPE_DESC = 'PRODUCT' 
									group by 1,2
									) as MED
									on MED.CF_CD = UNI.PROD_CF_CD

									inner join
									(
									select DISTINCT CF_CD
									from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
									where  GL_CF_TYPE_DESC = 'FUND_CODE'
									and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
									where  GL_CF_TYPE_DESC = 'FUND_CODE' 
									AND    ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
									)
									) FC
									ON FC.CF_CD = UNI.FUNDG_CF_CD
									where ( UNI.SRC_SUBGRP_NBR in ( 'G97600' ) or UNI.ORG_GRP_SRC_SUBGRP_NBR in ( 'G97600' ) )    
									AND PA1.STTS_DT  between UNI.mbr_prod_enrlmnt_efctv_dt and UNI.mbr_prod_enrlmnt_trmntn_dt

									AND ( ( UNI.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN UNI.prchsr_org_efctv_dt AND UNI.prchsr_org_trmntn_dt) OR UNI.prchsr_org_trmntn_dt IS NULL)
									AND ( UNI.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN UNI.MBR_COA_EFCTV_DT AND UNI.MBR_COA_TRMNTN_DT) 
									AND UNI.DUP_DATA_CD = '00'

									GROUP BY 
									PA1.RFRNC_NBR  ,
									PA1.SRVC_LINE_NBR,
									UNI.MBR_KEY ,
									UNI.MBRSHP_SOR_CD , 
									UNI.GRNDFTHR_IND_CD  ,
									UNI.GRNDFTHRG_STTS_CD ,    
									UNI.hcr_cmplynt_cd,
									UNI.EXCHNG_IND_CD ,
									UNI.EXCHNG_METL_TYPE_CD ,
									UNI.SRC_EXCHNG_CERTFN_CD ,
									UNI.MBU_CF_CD  ,
									UNI.PROD_CF_CD ,
									UNI.FUNDG_CF_CD ,
									MED.GL_CF_DESC,
									UNI.PRCP_TYPE_CD,
									PA1.case_type_cd,
									UNI.src_grp_nbr,
									UNI.src_subgrp_nbr
									)"""

									def sparkInIt() {

				val helper = new PCADX_SCL_NAIC2018_PAEXPHMCY_HelperRqstd()
						val tbl = dbWrk + ".naic2018_mcas_hlthex_paexphmcy_unicare_denied_wrk"
						val tblwrk1 = dbWrk + ".naic2018_mcas_hlthex_paexphmcy_denied_wrk1"

						spark.sql(helper.rqstdTrnctTbl(tbl))
						//spark.sql(helper.deniedWrk1(dbWrk,tblwrk1, String.valueOf(load_log_key), denied_strtdt,denied_enddt))

						var paexphmcy_unicare_ma_denied = naic2018_mcas_hlthex_paexphmcy_unicare_ma_denied_wrk(tblwrk1)
						paexphmcy_unicare_ma_denied = paexphmcy_unicare_ma_denied.replace("$1", String.valueOf(load_log_key))

						var paexphmcy_unicare_il_denied = naic2018_mcas_hlthex_paexphmcy_unicare_il_denied_wrk(tblwrk1)
						paexphmcy_unicare_il_denied = paexphmcy_unicare_il_denied.replace("$1", String.valueOf(load_log_key))

						var paexphmcy_unicare_dc_denied = naic2018_mcas_hlthex_paexphmcy_unicare_dc_denied_wrk(tblwrk1)
						paexphmcy_unicare_dc_denied = paexphmcy_unicare_dc_denied.replace("$1", String.valueOf(load_log_key))

						spark.sql(paexphmcy_unicare_ma_denied)
						spark.sql(paexphmcy_unicare_il_denied)
						spark.sql(paexphmcy_unicare_dc_denied)

						spark.close()
			}

}

object PCADX_SCL_NAIC2018_PAEXPHMCY_UNICARE_DENIED {

	def main(args: Array[String]) {

		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		new PCADX_SCL_NAIC2018_PAEXPHMCY_UNICARE_DENIED().sparkInIt()
		println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
	}
}