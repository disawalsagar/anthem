package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row
import org.apache.spark.storage.StorageLevel
 import org.apache.spark.sql.functions.{ row_number, current_timestamp, when, lit }
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.apache.spark.sql.functions.unix_timestamp

import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode


import org.apache.spark.sql.types._

class PCADX_SCL_NAIC2018_DQ{
  
  
  /**
   * 
   * Initialize Spark session and define class variables
   */
  
val spark = SparkSession.builder().config("hive.exec.dynamic.partition","true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash","true").
    config("spark.sql.parquet.writeLegacyFormat","true").
    enableHiveSupport().getOrCreate()  
  
  import spark.implicits._
  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_DQ])
  val dbOu = dbProperties.getProperty("outbound.db")
  val dbWh = dbProperties.getProperty("warehouse.db")
  val audit_log_df = spark.sql("select * from "+dbWh+".audt_load_log") 
  val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString() 
  val tblOu = "naic2018_mcas_report_outbnd"
  //val time_stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-mm-dd hh:mm:ss"));
  val time_stamp = unix_timestamp()


  
  def sparkInIt(){
  
  //spark.sql("truncate table "+dbOu+".naic_mcas_report_qlty_outbnd")
  println("########")
  val outDf=readDataFromHive(tblOu).persist(StorageLevel.MEMORY_ONLY)//.withColumn("RuleNo", 0)
 val qltyTble=dbOu+".naic2018_mcas_report_qlty_outbnd"
   val writeDf= processDataQuality(outDf)
  
  val vert_df = vertical_Rules(outDf)
  val final_dq = writeDf.union(vert_df)
  writeDataToHive(qltyTble,final_dq)
  val dq_1 = new PCADX_SCL_NAIC2018_DQ_v1(spark)
  dq_1.sparkInIt()
    spark.close()
  }
  
   /**
  * 
  *
 *
 * report_val_6 + report_val_7 + report_val_8 +report_val_9 = report_val_10   
 * where line_nbr in ( '19', '22' , '23' , '26', '27' , '29' , '33' , '34' , '35' , '36' ,
 *  '37' , '38' , '39', '40' , '41' , '42' , '43' , '44' , '45' , '46' ,'47' , '48' , '49' , 
 *  '50' , '51' , '52' , '53', '54' , '55' , '56' , '57' ,'58' , '59' , '69' , '70', '71', '72'  ) 
 *  and schedule not in ('HLTHIEXCAT') 
 *  
 *  report_val_6 + report_val_7 + report_val_8 +report_val_9 = report_val_10 
 *  where line_nbr in ( '20' ,'21' , '24', '25' ) and 
 *  schedule not in ('HLTHIEXCAT' , 'HLTHIEXMSSGRP' , 'HLTHIEXMSSGRP' )
 *  
 *  report_val_6 + report_val_7 + report_val_8 +report_val_9 = report_val_10  
 *  where line_nbr in ( '76' , '79', '80' , '83' , '84', '86' , '90' , '91' , '92', '93' , '94' , 
 *  '95' , '96' , '97' , '98' , '99' , '100' , '101' , '102' , '103' , '104', '105' , '106' , '107', 
 *  '108', '109', '110' , '111', '112', '113' , '114' , '115', '116', '126', '127', '128', '129'   )
 *   and schedule in ('HLTHOEXINDIV' , 'HLTHOEXSMGRP' ) 
 *  
 *  report_val_6 + report_val_7 + report_val_8 +report_val_9 = report_val_10  
 *   where line_nbr in ( '77' , '78' , '81' , '82'  ) and schedule in ('HLTHOEXINDIV' ) 
 *  
 *  report_val_6 + report_val_7 + report_val_8 = report_val_9   where line_nbr in 
 *  ( '76'  , '79' , '80' , '83', '84' , '85' , '86' , '87' , '88' , '89' , '90' , '91',
 *   '92', '93' , '94' , '95' , '96' , '97', '98' , '99' , '100', '101' , '102', '103', 
 *   '104' , '105' , '106','107', '108' , '109', '110' , '111' , '112' , '113' , '114'
 *    , '115', '116', '117' , '118', '119', '120', '121', '122', '123', '124', '125' ,
 *     '126', '127', '128', '129', '130', '131', '132'   ) and schedule in ('HLTHOEXGRFTHD' ) 
 *  
 */

/*
 * 
 * "select  
report_val_6 as report_val_6_20,
report_val_7 as report_val_7_20,
report_val_8 as report_val_8_20,
report_val_9 as report_val_9_20,
report_val_10 as report_val_10_20,
from  naic_mcas_report_outbnd
where line_nbr='20'
and schedule  in ('HLTHIEXINDIV'  , 'HLTHIEXCAT', 'HLTHIEXMSIND') 

select  
report_val_6 as report_val_6_22,
report_val_7 as report_val_7_22,
report_val_8 as report_val_8_22,
report_val_9 as report_val_9_22,
report_val_10 as report_val_10_22,
from  naic_mcas_report_outbnd
where line_nbr='22'
and schedule  in ('HLTHIEXINDIV' , 'HLTHIEXCAT',  'HLTHIEXMSIND'  ) 

report_val_6_22 >= report_val_6_20 then flag = 'Y' else 'N'
report_val_7_22 >= report_val_7_20 then flag = 'Y' else 'N'
report_val_8_22 >= report_val_8_20 then flag = 'Y' else 'N'
report_val_9_22 >= report_val_9_20 then flag = 'Y' else 'N'
report_val_10_22 >= report_val_10_20 then flag = 'Y' else 'N'"
 * 
 */


  def processDataQuality(outDf:DataFrame):DataFrame={
  val lineNoList_1= Seq( "19", "22" , "23" , "26", "27" , "29" , "39" , "40" , "41" , "42" ,
      "43" , "44" , "45", "46" ,"47" , "48" , "49" , "50" , "51" ,  "52" , "53", "54" , "55" ,
      "56" , "57" ,"58" , "59" , "60", "61","62" ,"63" , "64" , "65" , "66" , "67" , "68" , "69", "70" ,
      "71" , "72" , "73" ,"74" , "75" ,"85" , "86", "87", "88"    )

  val lineNoList_2=Seq("20","21","24","25")
  val lineNoList_3=Seq("92" , "95", "96" , "99" , "100", "102" , "112" , "113" , "114", "115" , "116" ,
      "117" , "118" , "119" , "120" , "121" , "122" , "123" , "124" , "125" , "126" , "127" , "128" , "129" ,
      "130" , "131" , "132" , "133" ,"134" , "135" ,"136", "137" , "138" , "139", "140", "141", "142" , "143",
      "144", "145" , "146" , "147", "148", "158", "159", "160", "161"   )
 val lineNoList_4=Seq("93" , "94" , "97" , "98")
 val lineNoList_5=Seq( "92"  , "95" , "96" , "99", "100" , "101" , "102" , "103" , "104" , "105" , "106" , "107" ,
     "108" , "109" , "110" , "111" ,  "112" , "113", "114", "115" , "116" , "117" , "118" , "119", "120" , "121" ,
     "122" , "123" , "124", "125" , "126" , "127", "128" , "129", "130" , "131" , "132", "133" , "134","135", "136" , 
     "137" , "138","139", "140" , "141", "142" , "143" , "144" , "145" , "146" , "147", "148", "149" , "150", "151", 
     "152", "153", "154", "155", "156", "157" , "158", "159", "160", "161", "162", "163", "164" )
  val checkDf_1=outDf.filter($"schedule"=!="HLTHIEXCAT").filter($"line_nbr".isin(lineNoList_1:_*)).withColumn("RuleNo",lit(1)).withColumn("Rule_Description",lit("metal_cnt_blnc_check"))
  val checkDf_2=outDf.filter($"schedule"=!="HLTHIEXCAT" && $"schedule"=!="HLTHIEXMSSGRP" &&  $"schedule"=!="HLTHIEXMSSGRP").filter($"line_nbr".isin(lineNoList_2:_*)).withColumn("RuleNo",lit(2)).withColumn("Rule_Description",lit("metal_cnt_blnc_check"))
  val checkDf_3=outDf.filter($"schedule"==="HLTHOEXINDIV" && $"schedule"==="HLTHOEXSMGRP").filter($"line_nbr".isin(lineNoList_3:_*)).withColumn("RuleNo",lit(3)).withColumn("Rule_Description",lit("metal_cnt_blnc_check"))
  val checkDf_4=outDf.filter($"schedule"==="HLTHOEXINDIV").filter($"line_nbr".isin(lineNoList_4:_*)).withColumn("RuleNo",lit(4)).withColumn("Rule_Description",lit("metal_cnt_blnc_check"))
  val checkDf_5=outDf.filter($"schedule"==="HLTHOEXGRFTHD").filter($"line_nbr".isin(lineNoList_5:_*)).withColumn("RuleNo",lit(5)).withColumn("Rule_Description",lit("metal_cnt_blnc_check"))

    
  var finalDf_1=checkDf_1.withColumn("QualityIndicator",
      when(($"report_val_6"+$"report_val_7"+$"report_val_8"+$"report_val_9")===$"report_val_10",          
      "Y").otherwise("N"))
  /*finalDf_1 = finalDf_1.withColumn("QualityIndicator",
      when(($"report_val_6".isNull && $"report_val_7".isNull && $"report_val_8".isNull && $"report_val_9".isNull && $"report_val_10".isNull) , "aa"))*/
  var finalDf_2=checkDf_2.withColumn("QualityIndicator",
      when(($"report_val_6"+$"report_val_7"+$"report_val_8"+$"report_val_9")===$"report_val_10" ,
      "Y").otherwise("N")).union(finalDf_1)
  /*finalDf_2 = finalDf_2.withColumn("QualityIndicator",
      when(($"report_val_6".isNull && $"report_val_7".isNull && $"report_val_8".isNull && $"report_val_9".isNull && $"report_val_10".isNull) , "aa"))*/
   
      
  var finalDf_3=checkDf_3.withColumn("QualityIndicator",
      when(($"report_val_6"+$"report_val_7"+$"report_val_8"+$"report_val_9")===$"report_val_10",
      "Y").otherwise("N")).union(finalDf_2)
  /*finalDf_3 = finalDf_3.withColumn("QualityIndicator",
      when(($"report_val_6".isNull && $"report_val_7".isNull && $"report_val_8".isNull && $"report_val_9".isNull && $"report_val_10".isNull) , "aa"))*/
      
  var finalDf_4=checkDf_4.withColumn("QualityIndicator",
      when(($"report_val_6"+$"report_val_7"+$"report_val_8"+$"report_val_9")===$"report_val_10" ,
      "Y").otherwise("N")).union(finalDf_3)
   /*finalDf_4 = finalDf_4.withColumn("QualityIndicator",
      when(($"report_val_6".isNull && $"report_val_7".isNull && $"report_val_8".isNull && $"report_val_9".isNull && $"report_val_10".isNull) , "aa"))*/
      
      
  var finalDf_5=checkDf_5.withColumn("QualityIndicator",
      when(($"report_val_6"+$"report_val_7"+$"report_val_8")===$"report_val_9" ,
      "Y").otherwise("N")).union(finalDf_4)
  finalDf_5 = finalDf_5.withColumn("QualityIndicator",
      when(($"report_val_6".isNull && $"report_val_7".isNull && $"report_val_8".isNull && $"report_val_9".isNull && $"report_val_10".isNull) , "NA").otherwise($"QualityIndicator"))
  /* finalDf_1.show()   
   finalDf_5.filter($"schedule".equalTo("HLTHIEXSMGRP")).show()   
   finalDf_1.show()*/
   val finalDf=finalDf_5.withColumn("load_log_key",lit(load_log_key)).withColumn("load_dt", lit(time_stamp)).select("health_year","naic_cmpny_cd","state","schedule","line_nbr","report_val_6","report_val_7","report_val_8","report_val_9","report_val_10","format_nbr","format_field_nbr","sel_priority","RuleNo","Rule_Description","QualityIndicator","load_log_key","load_dt")
  
    finalDf.printSchema()
    finalDf
    
 
}
  
  
  def vertical_Rules(outDf:DataFrame):DataFrame={
    
    /*select  
report_val_6 as report_val_6_20,
report_val_7 as report_val_7_20,
report_val_8 as report_val_8_20,
report_val_9 as report_val_9_20,
report_val_10 as report_val_10_20,
from  naic_mcas_report_outbnd
where line_nbr='20'
and schedule  in ('HLTHIEXINDIV'  , 'HLTHIEXCAT', 'HLTHIEXMSIND') 

select  
report_val_6 as report_val_6_22,
report_val_7 as report_val_7_22,
report_val_8 as report_val_8_22,
report_val_9 as report_val_9_22,
report_val_10 as report_val_10_22,
from  naic_mcas_report_outbnd
where line_nbr='22'
and schedule  in ('HLTHIEXINDIV' , 'HLTHIEXCAT',  'HLTHIEXMSIND'  ) 

report_val_6_22 >= report_val_6_20 then flag = 'Y' else 'N'
report_val_7_22 >= report_val_7_20 then flag = 'Y' else 'N'
report_val_8_22 >= report_val_8_20 then flag = 'Y' else 'N'
report_val_9_22 >= report_val_9_20 then flag = 'Y' else 'N'
report_val_10_22 >= report_val_10_20 then flag = 'Y' else 'N'*


"select  
report_val_6 as report_val_6_77,
report_val_7 as report_val_7_77,
report_val_8 as report_val_8_77,
report_val_9 as report_val_9_77,
report_val_10 as report_val_10_77,
from  naic_mcas_report_outbnd
where line_nbr='77'
and schedule  in ('HLTHOEXINDIV'   ) 

select  
report_val_6 as report_val_6_79,
report_val_7 as report_val_7_79,
report_val_8 as report_val_8_79,
report_val_9 as report_val_9_79,
report_val_10 as report_val_10_79,
from  naic_mcas_report_outbnd
where line_nbr='79'
and schedule  in ('HLTHOEXINDIV'   ) 

report_val_6_79 >= report_val_6_77 then flag = 'Y' else 'N'
report_val_7_79 >= report_val_7_77 then flag = 'Y' else 'N'
report_val_8_79 >= report_val_8_77 then flag = 'Y' else 'N'
report_val_9_79 >= report_val_9_77 then flag = 'Y' else 'N'
report_val_10_79 >= report_val_10_77 then flag = 'Y' else 'N'"

 * /
 */
    //changed 2018
  var schedule_data = Seq("HLTHIEXINDIV" , "HLTHIEXCAT", "HLTHIEXMSIND")  
  var  first_df = outDf.filter($"line_nbr".equalTo("20") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_1")).withColumn("Rule_Description",lit("nbrpoa_issued_cnt_check"))    
  var  second_df = outDf.filter($"line_nbr".equalTo("22") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_1")).withColumn("Rule_Description",lit("nbrpoa_issued_cnt_check"))
  var merged_df = get_vertical_ruleset_1(first_df,second_df)
  
  
  //changed 2018
    
  first_df = outDf.filter($"line_nbr".equalTo("21") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_2")).withColumn("Rule_Description",lit("nbrpoa_renewed_cnt_check"))    
  second_df = outDf.filter($"line_nbr".equalTo("23") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_2")).withColumn("Rule_Description",lit("nbrpoa_renewed_cnt_check"))
  merged_df = merged_df.union(get_vertical_ruleset_1(first_df,second_df))
  
   //changed 2018
  first_df = outDf.filter($"line_nbr".equalTo("24") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_3")).withColumn("Rule_Description",lit("nbrpoa_termed_cnt_check"))    
  second_df = outDf.filter($"line_nbr".equalTo("26") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_3")).withColumn("Rule_Description",lit("nbrpoa_termed_cnt_check"))
  merged_df = merged_df.union(get_vertical_ruleset_1(first_df,second_df)) 

  //changed 2018 
  first_df = outDf.filter($"line_nbr".equalTo("25") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_4")).withColumn("Rule_Description",lit("nbrpoa_termed_nonpay_cnt_check"))    
  second_df = outDf.filter($"line_nbr".equalTo("27") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_4")).withColumn("Rule_Description",lit("nbrpoa_termed_nonpay_cnt_check"))
  merged_df = merged_df.union(get_vertical_ruleset_1(first_df,second_df)) 
  
  //changed 2018 33--> 39
  schedule_data = Seq("HLTHIEXINDIV" , "HLTHIEXSMGRP", "HLTHIEXMSIND", "HLTHIEXMSSGRP")
  
  first_df = outDf.filter($"line_nbr".equalTo("39") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_5")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))    
  second_df = outDf.filter($"line_nbr".equalTo("40") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_5")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))                              
  var third_df = outDf.filter($"line_nbr".equalTo("41") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_5")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))
  merged_df = merged_df.union(get_vertical_ruleset_2(first_df,second_df,third_df))
  
  
  
  //changed 2018
  schedule_data = Seq("HLTHIEXCAT")
  
  first_df = outDf.filter($"line_nbr".equalTo("39") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_11")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))    
  second_df = outDf.filter($"line_nbr".equalTo("40") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_11")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))                              
  third_df = outDf.filter($"line_nbr".equalTo("41") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_11")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))
  merged_df = merged_df.union(get_vertical_ruleset_4(first_df,second_df,third_df))
  
  
  
  schedule_data = Seq("HLTHOEXINDIV")
  
  //changed 2018 77--> 93
  first_df = outDf.filter($"line_nbr".equalTo("93") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_18")).withColumn("Rule_Description",lit("nbrpoa_issued_cnt_check"))    
  second_df = outDf.filter($"line_nbr".equalTo("95") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_18")).withColumn("Rule_Description",lit("nbrpoa_issued_cnt_check"))
  merged_df = merged_df.union(get_vertical_ruleset_1(first_df,second_df))
  
  //changed 2018 74--> 98
  first_df = outDf.filter($"line_nbr".equalTo("94") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_19")).withColumn("Rule_Description",lit("nbrpoa_renewed_cnt_check"))    
  second_df = outDf.filter($"line_nbr".equalTo("96") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_19")).withColumn("Rule_Description",lit("nbrpoa_renewed_cnt_check"))
  merged_df = merged_df.union(get_vertical_ruleset_1(first_df,second_df))
  
  //changed 2018 81--> 97
  first_df = outDf.filter($"line_nbr".equalTo("97") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_20")).withColumn("Rule_Description",lit("nbrpoa_termed_cnt_check"))    
  second_df = outDf.filter($"line_nbr".equalTo("99") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_20")).withColumn("Rule_Description",lit("nbrpoa_termed_cnt_check"))
  merged_df = merged_df.union(get_vertical_ruleset_1(first_df,second_df))
  
  //changed 2018 82--> 98
  first_df = outDf.filter($"line_nbr".equalTo("98") &&   $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_21")).withColumn("Rule_Description",lit("nbrpoa_termed_nonpay_cnt_check"))
  second_df = outDf.filter($"line_nbr".equalTo("100") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_21")).withColumn("Rule_Description",lit("nbrpoa_termed_nonpay_cnt_check"))
  merged_df = merged_df.union(get_vertical_ruleset_1(first_df,second_df))
  
  
  
 
  schedule_data = Seq("HLTHOEXGRFTHD")
  //changed 2018 90--> 112
  first_df = outDf.filter($"line_nbr".equalTo("112") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_31")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))    
  second_df = outDf.filter($"line_nbr".equalTo("113") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_31")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))
  third_df = outDf.filter($"line_nbr".equalTo("114") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_31")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))
  merged_df = merged_df.union(get_vertical_ruleset_5(first_df,second_df,third_df))
  
 
   schedule_data = Seq("HLTHOEXCAT" , "HLTHOEXLGGRP" ,"HLTHOEXSTDNT")
   

  //New code added in 2018
  first_df = outDf.filter($"line_nbr".equalTo("93") &&   $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_36")).withColumn("Rule_Description",lit("nbrpoa_issued_cnt_check"))    
  second_df = outDf.filter($"line_nbr".equalTo("95") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_36")).withColumn("Rule_Description",lit("nbrpoa_issued_cnt_check"))
   merged_df = merged_df.union(get_vertical_ruleset_6(first_df,second_df))
 
   schedule_data = Seq("HLTHOEXCAT" , "HLTHOEXLGGRP")
   //New code added in 2018
  first_df = outDf.filter($"line_nbr".equalTo("94") &&   $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_37")).withColumn("Rule_Description",lit("nbrpoa_renewed_cnt_check"))    
  second_df = outDf.filter($"line_nbr".equalTo("96") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_37")).withColumn("Rule_Description",lit("nbrpoa_renewed_cnt_check"))
   merged_df = merged_df.union(get_vertical_ruleset_6(first_df,second_df))
  
   //New code added in 2018
   schedule_data = Seq("HLTHOEXCAT" , "HLTHOEXLGGRP" ,"HLTHOEXSTDNT")
  first_df = outDf.filter($"line_nbr".equalTo("97") &&   $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_38")).withColumn("Rule_Description",lit("nbrpoa_termed_cnt_check"))    
  second_df = outDf.filter($"line_nbr".equalTo("99") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_38")).withColumn("Rule_Description",lit("nbrpoa_termed_cnt_check"))
   merged_df = merged_df.union(get_vertical_ruleset_6(first_df,second_df))
 
  //changed 2018 82--> 98
  
   first_df = outDf.filter($"line_nbr".equalTo("98") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_39")).withColumn("Rule_Description",lit("nbrpoa_termed_nonpay_cnt_check"))
    
  second_df = outDf.filter($"line_nbr".equalTo("100") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_39")).withColumn("Rule_Description",lit("nbrpoa_termed_nonpay_cnt_check"))
  
  merged_df = merged_df.union(get_vertical_ruleset_6(first_df,second_df))
 
   //changed 2018 90--> 112
  first_df = outDf.filter($"line_nbr".equalTo("112") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_40")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))
    
  second_df = outDf.filter($"line_nbr".equalTo("113") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_40")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))
                              
  third_df = outDf.filter($"line_nbr".equalTo("114") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_40")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))
  merged_df = merged_df.union(get_vertical_ruleset_4(first_df,second_df,third_df))
  
 //changed 2018 126-->158
  
  first_df = outDf.filter($"line_nbr".equalTo("158") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_45")).withColumn("Rule_Description",lit("ganum_curseq_cnt_blnc_check"))
    
  second_df = outDf.filter($"line_nbr".equalTo("159") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_45")).withColumn("Rule_Description",lit("ganum_curseq_cnt_blnc_check"))
                              
  third_df = outDf.filter($"line_nbr".equalTo("160") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_45")).withColumn("Rule_Description",lit("ganum_curseq_cnt_blnc_check"))
  merged_df = merged_df.union(get_vertical_ruleset_4(first_df,second_df,third_df))
  
  
  schedule_data = Seq("HLTHOEXGRFTHD") 
  
  //changed 2018 77-->79
  first_df = outDf.filter($"line_nbr".equalTo("93") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_27")).withColumn("Rule_Description",lit("nbrpoa_issued_cnt_check"))
    
  second_df = outDf.filter($"line_nbr".equalTo("95") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_27")).withColumn("Rule_Description",lit("nbrpoa_issued_cnt_check"))
  merged_df = merged_df.union(get_vertical_ruleset_7(first_df,second_df))
  
    //changed 2018 78-->96
  first_df = outDf.filter($"line_nbr".equalTo("94") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_28")).withColumn("Rule_Description",lit("nbrpoa_renewed_cnt_check"))
    
  second_df = outDf.filter($"line_nbr".equalTo("96") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_28")).withColumn("Rule_Description",lit("nbrpoa_renewed_cnt_check"))
  merged_df = merged_df.union(get_vertical_ruleset_7(first_df,second_df))
   
    //changed 2018 81-->97
  first_df = outDf.filter($"line_nbr".equalTo("97") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_29")).withColumn("Rule_Description",lit("nbrpoa_termed_cnt_check"))
    
  second_df = outDf.filter($"line_nbr".equalTo("99") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_29")).withColumn("Rule_Description",lit("nbrpoa_termed_cnt_check"))
  merged_df = merged_df.union(get_vertical_ruleset_7(first_df,second_df))
  
  
    //changed 2018 98-->100
  first_df = outDf.filter($"line_nbr".equalTo("98") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_30")).withColumn("Rule_Description",lit("nbrpoa_termed_nonpay_cnt_check"))
    
  second_df = outDf.filter($"line_nbr".equalTo("100") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_30")).withColumn("Rule_Description",lit("nbrpoa_termed_nonpay_cnt_check"))
  merged_df = merged_df.union(get_vertical_ruleset_7(first_df,second_df))
  
   schedule_data = Seq("HLTHOEXINDIV", "HLTHOEXSMGRP")
    first_df = outDf.filter($"line_nbr".equalTo("112") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_22")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))
    
  second_df = outDf.filter($"line_nbr".equalTo("113") &&  $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_22")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))
                              
  third_df = outDf.filter($"line_nbr".equalTo("114") && $"schedule".isin(schedule_data:_*)).withColumn("RuleNo",lit("v_22")).withColumn("Rule_Description",lit("nbrclm_received_cnt_blnc_check"))
  merged_df = merged_df.union(get_vertical_ruleset_2(first_df,second_df,third_df))
  
  merged_df = merged_df.withColumn("QualityIndicator",
      when(($"report_val_6".isNull && $"report_val_7".isNull && $"report_val_8".isNull && $"report_val_9".isNull && $"report_val_10".isNull) , "NA").otherwise($"QualityIndicator"))
    
  
  
  
//  merged_df.show()
    merged_df= merged_df.withColumn("load_log_key",lit(load_log_key)).withColumn("load_dt", lit(time_stamp)).select("health_year","naic_cmpny_cd","state","schedule","line_nbr","report_val_6","report_val_7","report_val_8","report_val_9","report_val_10","format_nbr","format_field_nbr","sel_priority","RuleNo","Rule_Description","QualityIndicator","load_log_key","load_dt")
    merged_df
  
  }
  
  def get_vertical_ruleset_1(first_df:DataFrame,second_df:DataFrame):DataFrame = {
    var flag = false;
    val merged_df = first_df.alias("parent").join(second_df.alias("child"), $"parent.health_year"===$"child.health_year" 
          && $"parent.naic_cmpny_cd"===$"child.naic_cmpny_cd" && $"parent.state" === $"child.state" && $"parent.schedule"===$"child.schedule", "inner")
          .withColumn("QualityIndicator", 
              /*when($"child.report_val_6" >= $"parent.report_val_6"  && 
                  $"child.report_val_7" >= $"parent.report_val_7" &&
                  $"child.report_val_8" >= $"parent.report_val_8"  &&
                  $"child.report_val_9" >= $"parent.report_val_9"  &&
                  $"child.report_val_10" >= $"parent.report_val_10"  , "Y").otherwise("N"))*/
              when(($"child.report_val_6" >= $"parent.report_val_6" ||  ($"child.report_val_6".isNull && $"parent.report_val_6".isNull)) && 
                  ($"child.report_val_7" >= $"parent.report_val_7" ||  ($"child.report_val_7".isNull && $"parent.report_val_7".isNull)) &&
                  ($"child.report_val_8" >= $"parent.report_val_8" ||  ($"child.report_val_8".isNull && $"parent.report_val_8".isNull)) &&
                  ($"child.report_val_9" >= $"parent.report_val_9" ||  ($"child.report_val_9".isNull && $"parent.report_val_9".isNull)) &&
                  ($"child.report_val_10" >= $"parent.report_val_10" ||  ($"child.report_val_10".isNull && $"parent.report_val_10".isNull)) , "Y").otherwise("N"))
                  
    
   val Components = List("parent", "child")
    
    val final_df = getUnionDf(merged_df,Components.toSeq)
    final_df
    
  }
  
 def get_vertical_ruleset_2(first_df:DataFrame,second_df:DataFrame, third_df:DataFrame):DataFrame = {
    var flag = false;
    val merged_Df = first_df.alias("parent").join(second_df.alias("child"), $"parent.health_year"===$"child.health_year" 
          && $"parent.naic_cmpny_cd"===$"child.naic_cmpny_cd" && $"parent.state" === $"child.state" && $"parent.schedule"===$"child.schedule", "outer").
          join(third_df.alias("t_child"), $"parent.health_year"===$"t_child.health_year" 
          && $"parent.naic_cmpny_cd"===$"t_child.naic_cmpny_cd" && $"parent.state" === $"t_child.state" && $"parent.schedule"===$"t_child.schedule", "outer")
          .withColumn("QualityIndicator",
              /*when($"child.report_val_6"+$"t_child.report_val_6" === $"parent.report_val_6" &&
                  $"child.report_val_7"+$"t_child.report_val_7" === $"parent.report_val_7"  &&
                  $"child.report_val_8"+$"t_child.report_val_8" === $"parent.report_val_8"  &&
                  $"child.report_val_9"+$"t_child.report_val_9" === $"parent.report_val_9"  &&
                  $"child.report_val_10"+$"t_child.report_val_10" === $"parent.report_val_10", "Y").otherwise("N"))*/
              when(($"child.report_val_6"+$"t_child.report_val_6" === $"parent.report_val_6" ||  ($"child.report_val_6".isNull && $"parent.report_val_6".isNull && $"t_child.report_val_6".isNull))  &&
                  ($"child.report_val_7"+$"t_child.report_val_7" === $"parent.report_val_7" ||  ($"child.report_val_7".isNull && $"parent.report_val_7".isNull && $"t_child.report_val_7".isNull)) &&
                  ($"child.report_val_8"+$"t_child.report_val_8" === $"parent.report_val_8" ||  ($"child.report_val_8".isNull && $"parent.report_val_8".isNull && $"t_child.report_val_8".isNull)) &&
                  ($"child.report_val_9"+$"t_child.report_val_9" === $"parent.report_val_9" ||  ($"child.report_val_9".isNull && $"parent.report_val_9".isNull && $"t_child.report_val_9".isNull)) &&
                  ($"child.report_val_10"+$"t_child.report_val_10" === $"parent.report_val_10" ||  ($"child.report_val_10".isNull && $"parent.report_val_10".isNull && $"t_child.report_val_10".isNull)), "Y").otherwise("N"))
           
    
   val Components = List("parent", "child", "t_child")
    
    val final_df = getUnionDf(merged_Df,Components)
    final_df
    
  }
 
 def get_vertical_ruleset_4(first_df:DataFrame,second_df:DataFrame, third_df:DataFrame):DataFrame = {
    var flag = false;
    
    val merged_Df = first_df.alias("parent").join(second_df.alias("child"), $"parent.health_year"===$"child.health_year" 
          && $"parent.naic_cmpny_cd"===$"child.naic_cmpny_cd" && $"parent.state" === $"child.state" && $"parent.schedule"===$"child.schedule", "outer").
          join(third_df.alias("t_child"), $"parent.health_year"===$"t_child.health_year" 
          && $"parent.naic_cmpny_cd"===$"t_child.naic_cmpny_cd" && $"parent.state" === $"t_child.state" && $"parent.schedule"===$"t_child.schedule", "outer")
          .withColumn("QualityIndicator",
          when(($"child.report_val_6"+$"t_child.report_val_6" === $"parent.report_val_6" ||  ($"child.report_val_6".isNull && $"parent.report_val_6".isNull && $"t_child.report_val_6".isNull)) , "Y").otherwise("N"))
    
    
    val Components = List("parent", "child", "t_child")
    
    val final_df = getUnionDf(merged_Df,Components)
    final_df
    
   
    
  }
 def get_vertical_ruleset_5(first_df:DataFrame,second_df:DataFrame, third_df:DataFrame):DataFrame = {
    var flag = false;
     val merged_Df = first_df.alias("parent").join(second_df.alias("child"), $"parent.health_year"===$"child.health_year" 
          && $"parent.naic_cmpny_cd"===$"child.naic_cmpny_cd" && $"parent.state" === $"child.state" && $"parent.schedule"===$"child.schedule", "outer").
          join(third_df.alias("t_child"), $"parent.health_year"===$"t_child.health_year" 
          && $"parent.naic_cmpny_cd"===$"t_child.naic_cmpny_cd" && $"parent.state" === $"t_child.state" && $"parent.schedule"===$"t_child.schedule", "outer")
          .withColumn("QualityIndicator",
               when(($"child.report_val_6"+$"t_child.report_val_6" === $"parent.report_val_6" ||  ($"child.report_val_6".isNull && $"parent.report_val_6".isNull && $"t_child.report_val_6".isNull))  &&
                  ($"child.report_val_7"+$"t_child.report_val_7" === $"parent.report_val_7" ||  ($"child.report_val_7".isNull && $"parent.report_val_7".isNull && $"t_child.report_val_7".isNull)) &&
                  ($"child.report_val_8"+$"t_child.report_val_8" === $"parent.report_val_8" ||  ($"child.report_val_8".isNull && $"parent.report_val_8".isNull && $"t_child.report_val_8".isNull)) &&
                  ($"child.report_val_9"+$"t_child.report_val_9" === $"parent.report_val_9" ||  ($"child.report_val_9".isNull && $"parent.report_val_9".isNull && $"t_child.report_val_9".isNull)) , "Y").otherwise("N"))
          
   
          
   val Components = List("parent", "child", "t_child")//, "f_child", "ff_child")
    
    val final_df = getUnionDf(merged_Df,Components)
    final_df          
    
  }
def get_vertical_ruleset_6(first_df:DataFrame,second_df:DataFrame):DataFrame = {
    var flag = false;
    val merged_df = first_df.alias("parent").join(second_df.alias("child"), $"parent.health_year"===$"child.health_year" 
          && $"parent.naic_cmpny_cd"===$"child.naic_cmpny_cd" && $"parent.state" === $"child.state" && $"parent.schedule"===$"child.schedule", "outer")
          .withColumn("QualityIndicator", 
              when(($"child.report_val_6" >= $"parent.report_val_6"  || ($"child.report_val_6".isNull && $"parent.report_val_6".isNull))  , "Y").otherwise("N"))
                 
    
    val Components = List("parent", "child")//, "t_child", "f_child", "ff_child")
    
    val final_df = getUnionDf(merged_df,Components)
    final_df
    
  }
  def get_vertical_ruleset_7(first_df:DataFrame,second_df:DataFrame):DataFrame = {
    var flag = false;
    val merged_df = first_df.alias("parent").join(second_df.alias("child"), $"parent.health_year"===$"child.health_year" 
          && $"parent.naic_cmpny_cd"===$"child.naic_cmpny_cd" && $"parent.state" === $"child.state" && $"parent.schedule"===$"child.schedule", "outer")
          .withColumn("QualityIndicator", 
              when(($"child.report_val_6" >= $"parent.report_val_6" || ($"child.report_val_6".isNull && $"parent.report_val_6".isNull )) && 
                  ($"child.report_val_8" >= $"parent.report_val_8" || ($"child.report_val_8".isNull &&  $"parent.report_val_8".isNull)), "Y").otherwise("N"))
                  
    
    val Components = List("parent", "child")
    
    val final_df = getUnionDf(merged_df,Components)
    final_df
    
  }
  
  def get_vertical_ruleset_8(first_df:DataFrame,second_df:DataFrame, third_df:DataFrame,fourth_df:DataFrame,fifth_df:DataFrame):DataFrame = {
    var flag = false;
       
     //outer join
                     //select statement
    //make sure that rule are not overwritten
    val merged_Df = first_df.alias("parent").join(second_df.alias("child"), $"parent.health_year"===$"child.health_year" 
          && $"parent.naic_cmpny_cd"===$"child.naic_cmpny_cd" && $"parent.state" === $"child.state" && $"parent.schedule"===$"child.schedule", "outer").
          join(third_df.alias("t_child"), $"parent.health_year"===$"t_child.health_year" 
          && $"parent.naic_cmpny_cd"===$"t_child.naic_cmpny_cd" && $"parent.state" === $"t_child.state" && $"parent.schedule"===$"t_child.schedule", "outer").
          join(fourth_df.alias("f_child"), $"parent.health_year"===$"f_child.health_year" 
          && $"parent.naic_cmpny_cd"===$"f_child.naic_cmpny_cd" && $"parent.state" === $"f_child.state" && $"parent.schedule"===$"f_child.schedule", "outer").
          join(fifth_df.alias("ff_child"), $"parent.health_year"===$"ff_child.health_year" 
          && $"parent.naic_cmpny_cd"===$"ff_child.naic_cmpny_cd" && $"parent.state" === $"ff_child.state" && $"parent.schedule"===$"ff_child.schedule", "outer").
          withColumn("QualityIndicator",
              when($"child.report_val_6" + $"t_child.report_val_6" + $"f_child.report_val_6" + $"ff_child.report_val_6" === $"parent.report_val_6" &&
                 $"child.report_val_7" + $"t_child.report_val_7" + $"f_child.report_val_7" + $"ff_child.report_val_7" === $"parent.report_val_7" &&
                 $"child.report_val_8" + $"t_child.report_val_8" + $"f_child.report_val_8" + $"ff_child.report_val_8" === $"parent.report_val_8" &&
                 $"child.report_val_9" + $"t_child.report_val_9" + $"f_child.report_val_9" + $"ff_child.report_val_9" === $"parent.report_val_9" &&
                 $"child.report_val_10" + $"t_child.report_val_10" + $"f_child.report_val_10" + $"ff_child.report_val_10" === $"parent.report_val_10" , "Y").otherwise("N"))
           
    val Components = List("parent", "child", "t_child", "f_child", "ff_child")
    
    val final_df = getUnionDf(merged_Df,Components.toSeq)
    final_df
    
  }
  
  def get_vertical_ruleset_9(first_df:DataFrame,second_df:DataFrame, third_df:DataFrame,fourth_df:DataFrame,fifth_df:DataFrame):DataFrame = {
    var flag = false;
       
     //outer join
                     //select statement
    //make sure that rule are not overwritten
    val merged_Df = first_df.alias("parent").join(second_df.alias("child"), $"parent.health_year"===$"child.health_year" 
          && $"parent.naic_cmpny_cd"===$"child.naic_cmpny_cd" && $"parent.state" === $"child.state" && $"parent.schedule"===$"child.schedule", "outer").
          join(third_df.alias("t_child"), $"parent.health_year"===$"t_child.health_year" 
          && $"parent.naic_cmpny_cd"===$"t_child.naic_cmpny_cd" && $"parent.state" === $"t_child.state" && $"parent.schedule"===$"t_child.schedule", "outer").
          join(fourth_df.alias("f_child"), $"parent.health_year"===$"f_child.health_year" 
          && $"parent.naic_cmpny_cd"===$"f_child.naic_cmpny_cd" && $"parent.state" === $"f_child.state" && $"parent.schedule"===$"f_child.schedule", "outer").
          join(fifth_df.alias("ff_child"), $"parent.health_year"===$"ff_child.health_year" 
          && $"parent.naic_cmpny_cd"===$"ff_child.naic_cmpny_cd" && $"parent.state" === $"ff_child.state" && $"parent.schedule"===$"ff_child.schedule", "outer").
          withColumn("QualityIndicator",
              when($"child.report_val_6" + $"t_child.report_val_6" + $"f_child.report_val_6" + $"ff_child.report_val_6" === $"parent.report_val_6",
                   "Y").otherwise("N"))
           
    val Components = List("parent", "child", "t_child", "f_child", "ff_child")
    
    val final_df = getUnionDf(merged_Df,Components.toSeq)
    final_df
    
  }
  
  def get_vertical_ruleset_10(first_df:DataFrame,second_df:DataFrame, third_df:DataFrame,fourth_df:DataFrame,fifth_df:DataFrame):DataFrame = {
    var flag = false;
       
     //outer join
                     //select statement
    //make sure that rule are not overwritten
    val merged_Df = first_df.alias("parent").join(second_df.alias("child"), $"parent.health_year"===$"child.health_year" 
          && $"parent.naic_cmpny_cd"===$"child.naic_cmpny_cd" && $"parent.state" === $"child.state" && $"parent.schedule"===$"child.schedule", "outer").
          join(third_df.alias("t_child"), $"parent.health_year"===$"t_child.health_year" 
          && $"parent.naic_cmpny_cd"===$"t_child.naic_cmpny_cd" && $"parent.state" === $"t_child.state" && $"parent.schedule"===$"t_child.schedule", "outer").
          join(fourth_df.alias("f_child"), $"parent.health_year"===$"f_child.health_year" 
          && $"parent.naic_cmpny_cd"===$"f_child.naic_cmpny_cd" && $"parent.state" === $"f_child.state" && $"parent.schedule"===$"f_child.schedule", "outer").
          join(fifth_df.alias("ff_child"), $"parent.health_year"===$"ff_child.health_year" 
          && $"parent.naic_cmpny_cd"===$"ff_child.naic_cmpny_cd" && $"parent.state" === $"ff_child.state" && $"parent.schedule"===$"ff_child.schedule", "outer").
          withColumn("QualityIndicator",
              when($"child.report_val_6" + $"t_child.report_val_6" + $"f_child.report_val_6" + $"ff_child.report_val_6" === $"parent.report_val_6" &&
                 $"child.report_val_7" + $"t_child.report_val_7" + $"f_child.report_val_7" + $"ff_child.report_val_7" === $"parent.report_val_7" &&
                 $"child.report_val_8" + $"t_child.report_val_8" + $"f_child.report_val_8" + $"ff_child.report_val_8" === $"parent.report_val_8" &&
                 $"child.report_val_9" + $"t_child.report_val_9" + $"f_child.report_val_9" + $"ff_child.report_val_9" === $"parent.report_val_9"   , "Y").otherwise("N"))
           
    val Components = List("parent", "child", "t_child", "f_child", "ff_child")
    
    val final_df = getUnionDf(merged_Df,Components.toSeq)
    final_df
    
  }
  
  def getUnionDf(df:DataFrame,sSeq:Seq[String]):DataFrame={
    var unionDf:DataFrame=null
    var first_df:Boolean  = true
  for (x <- sSeq){
       val df1 = df.select(x+".health_year",x+".naic_cmpny_cd",x+".state",x+".schedule",x+".line_nbr",x+".report_val_6",x+".report_val_7",x+".report_val_8",x+".report_val_9",x+".report_val_10",x+".format_nbr",x+".format_field_nbr",x+".sel_priority",x+".RuleNo",x+".Rule_Description","QualityIndicator")
       if(first_df){
         println("First df true")
         unionDf = df1
         first_df=false
       }else{
         println("Union true")
        unionDf = unionDf.union(df1)
       }
  }
    unionDf
  }
 def get_vertical_ruleset_3(df:DataFrame)={
   
   df.createOrReplaceTempView("outtable")
   
   
   val ruleSql = """
    
     SELECT  
     
     o1.health_year,
     o2.naic_cmpny_cd, 
     o3.state,
     o4.schedule,
     
    CASE WHEN  
    o1.report_val_6 + o2.report_val_6 + o3.report_val_6 + o4.report_val_6 = o5.report_val_6 
    and 
    o1.report_val_7 + o2.report_val_7 + o3.report_val_7 + o4.report_val_7 = o5.report_val_7
    and
    o1.report_val_8 + o2.report_val_8 + o3.report_val_8 + o4.report_val_8 = o5.report_val_8
    and 
    o1.report_val_9 + o2.report_val_9 + o3.report_val_9 + o4.report_val_9 = o5.report_val_9
    and 
    o1.report_val_10 + o2.report_val_10 + o3.report_val_10 + o4.report_val_10 = o5.report_val_10
    THEN 'Y' ELSE 'N'
    END AS qualityindicator 
    
     FROM
     outtable o1 JOIN outtable o2 ON 
     o1.schedule=o2.schedule AND o1.naic_cmpny_cd = o2.naic_cmpny_cd
     JOIN outtable o3 ON 
     o1.schedule=o3.schedule and O1.naic_cmpny_cd = o3.naic_cmpny_cd
     JOIN outtable o4 ON 
     o1.schedule=o4.schedule and o1.naic_cmpny_cd = o4.naic_cmpny_cd
     JOIN outtable o5 ON 
     o1.schedule=o5.schedule and o1.naic_cmpny_cd = o5.naic_cmpny_cd
     
     WHERE
     o1.line_nbr=37 AND o2.line_nbr=38 AND o3.line_nbr=39 AND o4.line_nbr=40 AND o5.line_nbr=36
     AND o1.schedule in ("HLTHIEXINDIV" , "HLTHIEXSMGRP" , "HLTHIEXMSIND" , "HLTHIEXMSSGRP")
    
     """
   
     val df1 =spark.sql(ruleSql)
     
     val df3 = df.alias("parent").join(df1.alias("child"), $"parent.f_health_year"===$"child.health_year" && $"parent.f_line_nbr"===$"child.line_nbr" 
          && $"parent.f_naic_cmpny_cd"===$"child.naic_cmpny_cd" && $"parent.f_state" === $"child.state" && $"parent.f_schedule"===$"child.schedule", "outer")
          .select("health_year","naic_cmpny_cd","state","schedule","line_nbr","report_val_6","report_val_7","report_val_8","report_val_9","report_val_10","format_nbr","format_field_nbr","sel_priority","RuleNo","Rule_Description","QualityIndicator")
      
  
     

 


   
 }
   /**
   * Reads output table data from hive into Dataframe
   * @param : Table name 
   * @return: output table dataframe
   * 
   */
  def readDataFromHive(tble: String): DataFrame = {
    val queryOutputTable="""SELECT * FROM """ + dbOu + """.""" + tble

    val tbl_data_df = spark.sql(queryOutputTable)//.na.fill(0)
    logger.info("Read data from hive")
    //val col_seq = Seq("report_val_6","report_val_7","report_val_8","report_val_9","report_val_10")
    //val df2 = tbl_data_df.na.fill(0, col_seq)
    val final_tbl_df = tbl_data_df.withColumn("report_val_6",$"report_val_6".cast(IntegerType))
                          .withColumn("report_val_7",$"report_val_7".cast(IntegerType))
                          .withColumn("report_val_8",$"report_val_8".cast(IntegerType))
                          .withColumn("report_val_9",$"report_val_9".cast(IntegerType))
                          .withColumn("report_val_10",$"report_val_10".cast(IntegerType))
    final_tbl_df
    }
  

 /**
  * This method writes the dataframe to the hive table
  * @param :  table Name and datfarme to be written to the table
  */
 def writeDataToHive(tblName: String, finalDf: DataFrame) {
				finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
      // finalDf.write.mode(SaveMode.Append).insertInto(tblName)
			  println("Data added in stage table")
			}

}

object PCADX_SCL_NAIC_DQ{
  def main(args : Array[String]){
     PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
     new PCADX_SCL_NAIC2018_DQ().sparkInIt()
     
     //new PCADX_SCL_NAIC_DQ_v1.sparkInIt()
  }
}