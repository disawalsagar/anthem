package gen

import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import org.apache.hadoop.fs.Options.Rename

class PCADX_SCL_NAIC2018_UnicareStgTransformationPOA {


	val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
			config("hive.exec.dynamic.partition.mode", "nonstrict").
			config("spark.sql.parquet.compression.codec", "snappy").
			config("hive.warehouse.data.skipTrash", "true").
			config("spark.sql.parquet.writeLegacyFormat", "true").
			enableHiveSupport().getOrCreate()

			import org.apache.spark.sql.types._
			import spark.implicits._

			val dbProperties = new Properties
			dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
			var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_UnicareStgTransformationPOA])
			val dbsg = dbProperties.getProperty("stage.db")
			val dbwrk = dbProperties.getProperty("work.db")
			val uri: String = dbProperties.getProperty("uri")
			val  mbu_cf_cdvals= Seq("EDCASH","EDCOSH","EDCTSH","EDGASH","EDINSH","EDKYSH","EDMESH","EDMOSH","EDNHSH","EDNVSH","EDNYSH","EDOHSH","EDVASH","EDWISH","SHUNCE","SHUNEA","SHUNWS")
			val strt_year = dbProperties.getProperty("strt_year_poa")
			val end_year =dbProperties.getProperty("end_year_poa")
			val date1 =  LocalDate.parse(end_year)
			val date2= LocalDate.parse(strt_year)
			val strt_year_sql = dbProperties.getProperty("strt_year_poa_sql")
			val end_year_sql =dbProperties.getProperty("end_year_poa_sql")
			val mmissue_const_date =dbProperties.getProperty("const_date_mmissued")

			def sparkInIt(){

				val naic2018_mcas_hlthex_poa_issued_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poa_unicare_issued_wrk"  )
						val naic2018_mcas_hlthex_poa_renewed_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poa_unicare_renewed_wrk")
						val naic2018_mcas_hlthex_poa_mmissued_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poa_unicare_mmissued_wrk")
						val naic2018_mcas_hlthex_poa_mmrenewed_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poa_unicare_mmrenewed_wrk")
						val naic2018_mcas_hlthex_poa_termed_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poa_unicare_termed_wrk")
						val naic2018_mcas_hlthex_poa_termed_nonpay_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poa_unicare_termed_nonpay_wrk")
						val naic2018_mcas_hlthex_poa_termed_lives_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poa_unicare_termed_lives_wrk")
						val naic2018_mcas_hlthex_poa_termed_nonpay_lives_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poa_unicare_termed_nonpay_lives_wrk")
						val naic2018_mcas_hlthex_poag_issued_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poag_unicare_issued_wrk")
						val naic2018_mcas_hlthex_poag_renewed_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poag_unicare_renewed_wrk")
						val naic2018_mcas_hlthex_poag_mmissued_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poag_unicare_mmissued_wrk")
						val naic2018_mcas_hlthex_poag_mmrenewed_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poag_unicare_mmrenewed_wrk")
						val naic2018_mcas_hlthex_poag_termed_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poag_unicare_termed_wrk")
						val naic2018_mcas_hlthex_poag_termed_nonpay_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poag_unicare_termed_nonpay_wrk")						
						val naic2018_mcas_hlthex_poag_termed_lives_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poag_unicare_termed_lives_wrk")
						val naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_poag_unicare_termed_nonpay_lives_wrk")


						val stgData = populateStageTbl(naic2018_mcas_hlthex_poa_issued_wrk, naic2018_mcas_hlthex_poa_renewed_wrk,naic2018_mcas_hlthex_poa_mmissued_wrk, naic2018_mcas_hlthex_poa_mmrenewed_wrk, 
								naic2018_mcas_hlthex_poa_termed_wrk, naic2018_mcas_hlthex_poa_termed_nonpay_wrk,naic2018_mcas_hlthex_poa_termed_lives_wrk,naic2018_mcas_hlthex_poa_termed_nonpay_lives_wrk,
								naic2018_mcas_hlthex_poag_issued_wrk ,naic2018_mcas_hlthex_poag_renewed_wrk ,naic2018_mcas_hlthex_poag_mmissued_wrk,
								naic2018_mcas_hlthex_poag_mmrenewed_wrk,naic2018_mcas_hlthex_poag_termed_wrk  ,naic2018_mcas_hlthex_poag_termed_nonpay_wrk,
								naic2018_mcas_hlthex_poag_termed_lives_wrk,naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk )
						stgData.repartition(50)

						writeDataToHive(dbsg+"."+"naic2018_mcas_hlthoex_poa_stg", stgData)
						println("Done writing")
						spark.close()

			}

			def writeDataToHive(tblName: String, finalDf: DataFrame) {
				finalDf.write.mode(SaveMode.Append).insertInto(tblName)
				println("Data added in stage table")
			}


			def readDataFromHive(tble: String): DataFrame = {
					val queryOutputTable="""SELECT * FROM """ +  tble 
							val tbl_data_df = spark.sql(queryOutputTable)//.na.fill("")
							logger.info("Read data from hive")
							tbl_data_df
			}


			def populateStageTbl(naic2018_mcas_hlthex_poa_issued_wrk: DataFrame, naic2018_mcas_hlthex_poa_renewed_wrk:DataFrame, naic2018_mcas_hlthex_poa_mmissued_wrk:DataFrame,
					naic2018_mcas_hlthex_poa_mmrenewed_wrk:DataFrame,naic2018_mcas_hlthex_poa_termed_wrk:DataFrame, naic2018_mcas_hlthex_poa_termed_nonpay_wrk:DataFrame,
					naic2018_mcas_hlthex_poa_termed_lives_wrk:DataFrame,naic2018_mcas_hlthex_poa_termed_nonpay_lives_wrk:DataFrame,
					naic2018_mcas_hlthex_poag_issued_wrk:DataFrame ,naic2018_mcas_hlthex_poag_renewed_wrk:DataFrame ,
					naic2018_mcas_hlthex_poag_mmissued_wrk:DataFrame,naic2018_mcas_hlthex_poag_mmrenewed_wrk:DataFrame,
					naic2018_mcas_hlthex_poag_termed_wrk:DataFrame  ,naic2018_mcas_hlthex_poag_termed_nonpay_wrk:DataFrame,
					naic2018_mcas_hlthex_poag_termed_lives_wrk:DataFrame,naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk:DataFrame):DataFrame=  {

							val issueFinalDf=getInitialData(naic2018_mcas_hlthex_poa_issued_wrk,naic2018_mcas_hlthex_poag_issued_wrk,"issued")
							  val rennewedFinalDf = getInitialData(naic2018_mcas_hlthex_poa_renewed_wrk,naic2018_mcas_hlthex_poag_renewed_wrk,"renewed")      
									val termedFinalDf = gettermedInitialData(naic2018_mcas_hlthex_poa_termed_wrk,naic2018_mcas_hlthex_poag_termed_wrk,"termed")
									val termed_nonpayFinalDf = gettermedInitialData(naic2018_mcas_hlthex_poa_termed_nonpay_wrk,naic2018_mcas_hlthex_poag_termed_nonpay_wrk,"termed_nonpay")
									val termed_livesFinalDf = getTermedLivesData(naic2018_mcas_hlthex_poa_termed_lives_wrk,naic2018_mcas_hlthex_poag_termed_lives_wrk, "termed_lives")
									val termed_nonpay_livesFinalDf = getTermedLivesData(naic2018_mcas_hlthex_poa_termed_nonpay_lives_wrk,naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk,"termed_nonpay_lives")
									val mmissuedFinalDf = getMemberIssuedData( naic2018_mcas_hlthex_poa_mmissued_wrk,naic2018_mcas_hlthex_poag_mmissued_wrk)
									val mmrenewedFinalDf = getMemberRenewedData( naic2018_mcas_hlthex_poa_mmrenewed_wrk,naic2018_mcas_hlthex_poag_mmrenewed_wrk)
									val oex = new PCADX_SCL_NAIC2018_OEXStgTransformationPOA()
									val stgData = oex.getStageData(issueFinalDf,rennewedFinalDf,mmissuedFinalDf,mmrenewedFinalDf,termedFinalDf,termed_nonpayFinalDf,
											termed_livesFinalDf,termed_nonpay_livesFinalDf)
									var load_log_key = ""
									if(!naic2018_mcas_hlthex_poa_issued_wrk.take(1).isEmpty){
										load_log_key = naic2018_mcas_hlthex_poa_issued_wrk.select($"load_log_key").first.getString(0)
									}
							val finalStgdata =stgData.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());

							finalStgdata
			}

			def getMemberRenewedData(naic_mcas_hlthex_poa_wrk:DataFrame,naic_mcas_hlthex_poag_wrk:DataFrame ) : DataFrame = {

					naic_mcas_hlthex_poa_wrk.createOrReplaceTempView("mmrenewed_wrk")
					naic_mcas_hlthex_poag_wrk.createOrReplaceTempView("POAMMRENEWED")

					val mbrmpoa_renewed_bronze_ip=   naic_mcas_hlthex_poa_wrk
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_renewed_bronze_ip"))

					val mbrmpoa_renewed_silver_ip=   naic_mcas_hlthex_poa_wrk
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_renewed_silver_ip"))

					val mbrmpoa_renewed_gold_ip=   naic_mcas_hlthex_poa_wrk
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_renewed_gold_ip"))

					val mbrmpoa_renewed_platinum_ip=   naic_mcas_hlthex_poa_wrk
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_renewed_platinum_ip"))

					val mbrmpoa_renewed_bronze_sgp=   naic_mcas_hlthex_poa_wrk
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_renewed_bronze_sgp"))

					val mbrmpoa_renewed_silver_sgp=   naic_mcas_hlthex_poa_wrk
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_renewed_silver_sgp"))

					val mbrmpoa_renewed_gold_sgp=   naic_mcas_hlthex_poa_wrk
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_renewed_gold_sgp"))

					val mbrmpoa_renewed_platinum_sgp=   naic_mcas_hlthex_poa_wrk
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_renewed_platinum_sgp"))


					val mbrmpoa_renewed_gtlgp = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state,outoff_exchange, cast(round(round(SUM( Member_Months ),0) ,0) as int) as mbrmpoa_renewed_gtlgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,outoff_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """+end_year_sql+"""  AND
							( """+strt_year_sql+""" BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """+end_year_sql+""") THEN  round(MONTHS_BETWEEN ( """+end_year_sql+""" ,  """+strt_year_sql+"""  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """+end_year_sql+"""  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """+strt_year_sql+""" THEN  round(MONTHS_BETWEEN ( """+end_year_sql+""" , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """+end_year_sql+"""  AND
							( """+strt_year_sql+""" BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """+end_year_sql+""") THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """+strt_year_sql+"""   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """+end_year_sql+"""  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """+strt_year_sql+""" THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM POAMMRENEWED
							where naic_lob = 'LARGE GROUP GRAND'
							and state = 'IL'	
							GROUP BY health_year,cmpny_cf_cd,state,outoff_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,outoff_exchange""" )

					val mbrmpoa_renewed_gtsgp=   naic_mcas_hlthex_poa_wrk
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_renewed_gtsgp"))



					val mbrmpoa_renewed_gtip = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state,outoff_exchange, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_gtip
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,outoff_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """+end_year_sql+"""  AND
							( """+strt_year_sql+""" BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """+end_year_sql+""") THEN  round(MONTHS_BETWEEN ( """+end_year_sql+""" ,  """+strt_year_sql+"""  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """+end_year_sql+"""  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """+strt_year_sql+""" THEN  round(MONTHS_BETWEEN ( """+end_year_sql+""" , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """+end_year_sql+"""  AND
							( """+strt_year_sql+""" BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """+end_year_sql+""") THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """+strt_year_sql+"""   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """+end_year_sql+"""  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """+strt_year_sql+""" THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'INDIVIDUAL GRAND'
							and state = 'DC'		
							GROUP BY health_year,cmpny_cf_cd,state,outoff_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,outoff_exchange""" )

					val mbrmpoa_renewed_catastrophic=   naic_mcas_hlthex_poa_wrk
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_renewed_catastrophic"))


					val mbrmpoa_renewed_lgp_mmcare = 	spark.sql("""

							SELECT health_year,cmpny_cf_cd,state,outoff_exchange, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_lgp_mmcare
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,outoff_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """+end_year_sql+"""  AND
							( """+strt_year_sql+""" BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """+end_year_sql+""") THEN  round(MONTHS_BETWEEN ( """+end_year_sql+""" ,  """+strt_year_sql+"""  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """+end_year_sql+"""  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """+strt_year_sql+""" THEN  round(MONTHS_BETWEEN ( """+end_year_sql+""" , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """+end_year_sql+"""  AND
							( """+strt_year_sql+""" BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """+end_year_sql+""") THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """+strt_year_sql+"""   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """+end_year_sql+"""  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """+strt_year_sql+""" THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM POAMMRENEWED
							where naic_lob = 'LARGE GROUP CBE'
							and state = 'MA'
							GROUP BY health_year,cmpny_cf_cd,state,outoff_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,outoff_exchange""" )


					val mbrmpoa_renewed_stucvg=   naic_mcas_hlthex_poa_wrk
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_renewed_stucvg"))


					val brSil = mbrmpoa_renewed_bronze_ip.alias("bsg").join(mbrmpoa_renewed_silver_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"))


					val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_silver_ip")


					val bsGld = brSilData.alias("bsg").join(mbrmpoa_renewed_gold_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"))


					val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip","mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip")                                  


					val bsgPlt = bsGldData.alias("bsg").join(mbrmpoa_renewed_platinum_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"),col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"))


					val bsgPltData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip","mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip")                                  


					//"mbrmpoa_renewed_bronze_ip + mbrmpoa_renewed_silver_ip + mbrmpoa_renewed_gold_ip + mbrmpoa_renewed_platinum_ip"

					val getTotal_ip =  mbrmpoa_renewed_bronze_ip.union(mbrmpoa_renewed_silver_ip.union(mbrmpoa_renewed_gold_ip.union(mbrmpoa_renewed_platinum_ip)))
					.select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"mbrmpoa_renewed_bronze_ip")

					val mbrmpoa_renewed_total_ip = getTotal_ip.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum($"mbrmpoa_renewed_bronze_ip").alias("mbrmpoa_renewed_total_ip"))


					val ip = bsgPltData.alias("bsg").join(mbrmpoa_renewed_total_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"),col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"))


					val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip","mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip"
							,"mbrmpoa_renewed_total_ip")   


					val ipBrz = ipData.alias("bsg").join(mbrmpoa_renewed_bronze_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"),col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"))


					val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip","mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip"
							,"mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp")                           


					val ipbSil = ipBrzData.alias("bsg").join(mbrmpoa_renewed_silver_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"),col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"))


					val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip","mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip"
							,"mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp")                       


					val ipbsGld = ipbSilData.alias("bsg").join(mbrmpoa_renewed_gold_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"))


					val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip","mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip"
							,"mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp")                      


					val ipbsgPlt = ipbsGldData.alias("bsg").join(mbrmpoa_renewed_platinum_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"),col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"))


					val ipbsgPltData = ipbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip","mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip"
							,"mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp")                    

					val getTotal_sgp =  mbrmpoa_renewed_bronze_sgp.union(mbrmpoa_renewed_silver_sgp.union(mbrmpoa_renewed_gold_sgp.union(mbrmpoa_renewed_platinum_sgp)))
					.select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"mbrmpoa_renewed_bronze_sgp")

					val mbrmpoa_renewed_total_sgp = getTotal_sgp.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum($"mbrmpoa_renewed_bronze_sgp").alias("mbrmpoa_renewed_total_sgp"))


					val ipSgp = ipbsgPltData.alias("bsg").join(mbrmpoa_renewed_total_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"),col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"))



					val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip","mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip"
							,"mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp","mbrmpoa_renewed_total_sgp")                       


					val ipSgpgtLgp = ipSgpData.alias("bsg").join(mbrmpoa_renewed_gtlgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"),col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"))



					val ipSgpgtLgpData = ipSgpgtLgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip","mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip"
							,"mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp","mbrmpoa_renewed_total_sgp",
							"mbrmpoa_renewed_gtlgp")                       

					val ipSgpgtLgpgtSgp = ipSgpgtLgpData.alias("bsg").join(mbrmpoa_renewed_gtsgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"),col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"), col("mbrmpoa_renewed_gtsgp"))



					val ipSgpgtLgpgtSgpData = ipSgpgtLgpgtSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip"
							,"mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp",
							"mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp")                                



					val ipSgpgtLgpgtSgpip = ipSgpgtLgpgtSgpData.alias("bsg").join(mbrmpoa_renewed_gtip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"), col("mbrmpoa_renewed_gtsgp"), col("mbrmpoa_renewed_gtip"))



					val ipSgpgtLgpgtSgpipData = ipSgpgtLgpgtSgpip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip","mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip"
							,"mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp","mbrmpoa_renewed_total_sgp",
							"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip")                        

					val getTotal_gtip = mbrmpoa_renewed_gtlgp.union(mbrmpoa_renewed_gtsgp.union(mbrmpoa_renewed_gtip))
					.select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"mbrmpoa_renewed_gtlgp")

					val mbrmpoa_renewed_total_gtip = getTotal_gtip.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum($"mbrmpoa_renewed_gtlgp").alias("mbrmpoa_renewed_total_gtip")).withColumn("mbrmpoa_renewed_total_gtip",$"mbrmpoa_renewed_total_gtip".cast(IntegerType))

					val ipSgpgtLgpgtSgpipgtTot = ipSgpgtLgpgtSgpipData.alias("bsg").join(mbrmpoa_renewed_total_gtip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"),col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"), col("mbrmpoa_renewed_gtsgp"), col("mbrmpoa_renewed_gtip"), col("mbrmpoa_renewed_total_gtip"))



					val ipSgpgtLgpgtSgpipgtTotData = ipSgpgtLgpgtSgpipgtTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip","mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip"
							,"mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp","mbrmpoa_renewed_total_sgp",
							"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip", "mbrmpoa_renewed_total_gtip")                        



					val ipSgpgtLgpgtSgpipgtTotCat = ipSgpgtLgpgtSgpipgtTotData.alias("bsg").join(mbrmpoa_renewed_catastrophic.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"),col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"), col("mbrmpoa_renewed_gtsgp"), col("mbrmpoa_renewed_gtip"), col("mbrmpoa_renewed_total_gtip"),
							col("mbrmpoa_renewed_catastrophic"))



					val ipSgpgtLgpgtSgpipgtTotCatData = ipSgpgtLgpgtSgpipgtTotCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip"
							,"mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp","mbrmpoa_renewed_total_sgp",
							"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip", "mbrmpoa_renewed_total_gtip", "mbrmpoa_renewed_catastrophic")                        




					val ipSgpgtLgpgtSgpipgtTotCatmm = ipSgpgtLgpgtSgpipgtTotCatData.alias("bsg").join(mbrmpoa_renewed_lgp_mmcare.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"),col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"), col("mbrmpoa_renewed_gtsgp"), col("mbrmpoa_renewed_gtip"), col("mbrmpoa_renewed_total_gtip"),
							col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_lgp_mmcare"))



					val ipSgpgtLgpgtSgpipgtTotCatmmData = ipSgpgtLgpgtSgpipgtTotCatmm.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip","mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip"
							,"mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp","mbrmpoa_renewed_total_sgp",
							"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip", "mbrmpoa_renewed_total_gtip", "mbrmpoa_renewed_catastrophic", 
							"mbrmpoa_renewed_lgp_mmcare")                        


					val ipSgpgtLgpgtSgpipgtTotCatmmSt = ipSgpgtLgpgtSgpipgtTotCatmmData.alias("bsg").join(mbrmpoa_renewed_stucvg.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
					&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
					.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
							$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
							$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
							$"plt.outoff_exchange".alias("s_inx"),col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"),col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"), col("mbrmpoa_renewed_gtsgp"), col("mbrmpoa_renewed_gtip"), col("mbrmpoa_renewed_total_gtip"),
							col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_lgp_mmcare"), col("mbrmpoa_renewed_stucvg"))



					val finalData = ipSgpgtLgpgtSgpipgtTotCatmmSt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
					.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_renewed_bronze_ip" ,"mbrmpoa_renewed_bronze_ip","mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip"
							,"mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp","mbrmpoa_renewed_total_sgp",
							"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip", "mbrmpoa_renewed_total_gtip", "mbrmpoa_renewed_catastrophic", 
							"mbrmpoa_renewed_lgp_mmcare", "mbrmpoa_renewed_stucvg")                        





					finalData                      

			}


			def getMemberIssuedData(naic_mcas_hlthex_poa_wrk:DataFrame,naic_mcas_hlthex_poag_wrk:DataFrame ) : DataFrame = {

					var mmissued_wrk = naic_mcas_hlthex_poa_wrk.withColumn("Const_date", lit(mmissue_const_date))
							mmissued_wrk.withColumn("Const_date", to_date($"Const_date"))


							var mmissued_wrk1 = naic_mcas_hlthex_poag_wrk.withColumn("Const_date", lit(mmissue_const_date))
							mmissued_wrk1.withColumn("Const_date", to_date($"Const_date"))






							val out_exchngVal = "OUTOFF"
							val mbrmpoa_issued_bronze_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_issued_bronze_ip")).withColumn("mbrmpoa_issued_bronze_ip",$"mbrmpoa_issued_bronze_ip".cast(IntegerType))

							val mbrmpoa_issued_silver_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_issued_silver_ip")).withColumn("mbrmpoa_issued_silver_ip",$"mbrmpoa_issued_silver_ip".cast(IntegerType)) 

							val brSil = mbrmpoa_issued_bronze_ip.alias("bsg").join(mbrmpoa_issued_silver_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"))


							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip")

							val mbrmpoa_issued_gold_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_issued_gold_ip")).withColumn("mbrmpoa_issued_gold_ip",$"mbrmpoa_issued_gold_ip".cast(IntegerType))

							val bsGld = brSilData.alias("bsg").join(mbrmpoa_issued_gold_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"))


							val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,
									"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip")                                  

							val mbrmpoa_issued_platinum_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_issued_platinum_ip")).withColumn("mbrmpoa_issued_platinum_ip",$"mbrmpoa_issued_platinum_ip".cast(IntegerType))

							val bsgPlt = bsGldData.alias("bsg").join(mbrmpoa_issued_platinum_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), 
									col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"))


							val bsgPltData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip")                                  



							val getTotal_ip =  mbrmpoa_issued_bronze_ip.union(mbrmpoa_issued_silver_ip.union(mbrmpoa_issued_gold_ip.union(mbrmpoa_issued_platinum_ip)))
							.select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"mbrmpoa_issued_bronze_ip")

							val mbrmpoa_issued_total_ip = getTotal_ip.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange")
							.agg(sum($"mbrmpoa_issued_bronze_ip").alias("mbrmpoa_issued_total_ip"))


							val ip = bsgPltData.alias("bsg").join(mbrmpoa_issued_total_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"))


							val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,
									"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip","mbrmpoa_issued_total_ip")   


							val mbrmpoa_issued_bronze_sgp = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_issued_bronze_sgp")).withColumn("mbrmpoa_issued_bronze_sgp",$"mbrmpoa_issued_bronze_sgp".cast(IntegerType))

							val ipBrz = ipData.alias("bsg").join(mbrmpoa_issued_bronze_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"),
									col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"))


							val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip",
									"mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip","mbrmpoa_issued_total_ip","mbrmpoa_issued_bronze_sgp")   


							val mbrmpoa_issued_silver_sgp = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_issued_silver_sgp")).withColumn("mbrmpoa_issued_silver_sgp",$"mbrmpoa_issued_silver_sgp".cast(IntegerType))

							val ipbSil = ipBrzData.alias("bsg").join(mbrmpoa_issued_silver_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"))


							val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip", 
									"mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip","mbrmpoa_issued_total_ip","mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp")                                    

							val mbrmpoa_issued_gold_sgp = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_issued_gold_sgp")).withColumn("mbrmpoa_issued_gold_sgp",$"mbrmpoa_issued_gold_sgp".cast(IntegerType))

							val ipbsGld = ipbSilData.alias("bsg").join(mbrmpoa_issued_gold_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange",
									"outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"),
									col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"),
									col("mbrmpoa_issued_gold_sgp"))


							val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip",
									"mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip","mbrmpoa_issued_total_ip","mbrmpoa_issued_bronze_sgp","mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp")                                       
							val mbrmpoa_issued_platinum_sgp = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_issued_platinum_sgp")).withColumn("mbrmpoa_issued_platinum_sgp",$"mbrmpoa_issued_platinum_sgp".cast(IntegerType))

							val ipbsgPlt = ipbsGldData.alias("bsg").join(mbrmpoa_issued_platinum_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"),col("mbrmpoa_issued_platinum_sgp"))


							val ipbsgPltData = ipbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip","mbrmpoa_issued_total_ip","mbrmpoa_issued_bronze_sgp","mbrmpoa_issued_silver_sgp","mbrmpoa_issued_gold_sgp", 
									"mbrmpoa_issued_platinum_sgp")  

							val getTotal_sgp =  mbrmpoa_issued_bronze_sgp.union(mbrmpoa_issued_silver_sgp.union(mbrmpoa_issued_gold_sgp.union(mbrmpoa_issued_platinum_sgp)))
							.select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"mbrmpoa_issued_bronze_sgp")

							val mbrmpoa_issued_total_sgp = getTotal_sgp.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange")
							.agg(sum($"mbrmpoa_issued_bronze_sgp").alias("mbrmpoa_issued_total_sgp"))

							val ipsgp = ipbsgPltData.alias("bsg").join(mbrmpoa_issued_total_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"),col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"))


							val ipsgpData = ipsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip","mbrmpoa_issued_total_ip","mbrmpoa_issued_bronze_sgp","mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp")


							val mbrmpoa_issued_gtlgp = mmissued_wrk1.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("LARGE GROUP GRAND") &&
									naic_mcas_hlthex_poag_wrk("state").equalTo("IL"))// && $"outoff_exchange".equalTo("OUTOFF"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"SBSCRBR_ID",  $"MBR_RLTNSHP_CD" ,$"Const_date",
									$"MBR_PROD_ENRLMNT_TRMNTN_DT" , $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)),round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("Member Months"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum($"Member Months").alias("mbrmpoa_issued_gtlgp")).withColumn("mbrmpoa_issued_gtlgp",round($"mbrmpoa_issued_gtlgp",0).cast(IntegerType))

							val ipbsgtlgp = ipsgpData.alias("bsg").join(mbrmpoa_issued_gtlgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange",
									"outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), 
									col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"),
									col("mbrmpoa_issued_gold_sgp"),col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"),col("mbrmpoa_issued_gtlgp"))


							val ipbsgtlgpData = ipbsgtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip","mbrmpoa_issued_total_ip","mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp","mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp","mbrmpoa_issued_gtlgp")		


							val mbrmpoa_issued_gtsgp = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_issued_gtsgp")).withColumn("mbrmpoa_issued_gtsgp",round($"mbrmpoa_issued_gtsgp",0).cast(IntegerType))


							val ipbsgtsgp = ipbsgtlgpData.alias("bsg").join(mbrmpoa_issued_gtsgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange",
									"outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), 
									col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"),
									col("mbrmpoa_issued_gold_sgp"),col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"),col("mbrmpoa_issued_gtlgp"),col("mbrmpoa_issued_gtsgp"))


							val ipbsgtsgpData = ipbsgtsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip","mbrmpoa_issued_total_ip","mbrmpoa_issued_bronze_sgp","mbrmpoa_issued_silver_sgp","mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp","mbrmpoa_issued_gtlgp","mbrmpoa_issued_gtsgp")	


							val mbrmpoa_issued_gtip = mmissued_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("INDIVIDUAL GRAND") &&
									naic_mcas_hlthex_poa_wrk("state").equalTo("DC"))// && $"outoff_exchange".equalTo("OUTOFF"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"SBSCRBR_ID",  $"MBR_RLTNSHP_CD" ,$"Const_date",
									$"MBR_PROD_ENRLMNT_TRMNTN_DT" , $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)),round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0) ).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("Member Months"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum($"Member Months").alias("mbrmpoa_issued_gtip")).withColumn("mbrmpoa_issued_gtip",round($"mbrmpoa_issued_gtip",0).cast(IntegerType))

							val ipbsgtip = ipbsgtsgpData.alias("bsg").join(mbrmpoa_issued_gtip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange",
									"outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), 
									col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"),
									col("mbrmpoa_issued_gold_sgp"),col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"),col("mbrmpoa_issued_gtlgp"),col("mbrmpoa_issued_gtsgp"),col("mbrmpoa_issued_gtip"))


							val ipbsgtipData = ipbsgtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip","mbrmpoa_issued_total_ip","mbrmpoa_issued_bronze_sgp","mbrmpoa_issued_silver_sgp","mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp","mbrmpoa_issued_gtlgp","mbrmpoa_issued_gtsgp","mbrmpoa_issued_gtip")	

							val get_total_gtip =  mbrmpoa_issued_gtlgp.union(mbrmpoa_issued_gtsgp.union(mbrmpoa_issued_gtip))
							.select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"mbrmpoa_issued_gtlgp")	

							val mbrmpoa_issued_total_gtip = get_total_gtip.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange")
							.agg(sum($"mbrmpoa_issued_gtlgp").alias("mbrmpoa_issued_total_gtip"))



							val gtlp = ipbsgtipData.alias("bsg").join(mbrmpoa_issued_total_gtip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"),col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"),col("mbrmpoa_issued_gtlgp"),col("mbrmpoa_issued_gtsgp"),col("mbrmpoa_issued_gtip"),
									col("mbrmpoa_issued_total_gtip"))


							val ipgtlpData = gtlp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip","mbrmpoa_issued_total_ip","mbrmpoa_issued_bronze_sgp","mbrmpoa_issued_silver_sgp","mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp","mbrmpoa_issued_gtlgp","mbrmpoa_issued_gtsgp","mbrmpoa_issued_gtip","mbrmpoa_issued_total_gtip")






							val mbrmpoa_issued_catastrophic = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_issued_catastrophic")).withColumn("mbrmpoa_issued_catastrophic",round($"mbrmpoa_issued_catastrophic",0).cast(IntegerType))

							val ipCat = ipgtlpData.alias("bsg").join(mbrmpoa_issued_catastrophic.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"),col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"),col("mbrmpoa_issued_gtlgp"),col("mbrmpoa_issued_gtsgp"),col("mbrmpoa_issued_gtip"),
									col("mbrmpoa_issued_total_gtip"), col("mbrmpoa_issued_catastrophic"))


							val ipCatData = ipCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip","mbrmpoa_issued_total_ip","mbrmpoa_issued_bronze_sgp","mbrmpoa_issued_silver_sgp","mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp","mbrmpoa_issued_gtsgp","mbrmpoa_issued_gtip",
									"mbrmpoa_issued_total_gtip","mbrmpoa_issued_catastrophic")

							val mbrmpoa_issued_lgp_mmcare = mmissued_wrk1.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("LARGE GROUP CBE") &&
									naic_mcas_hlthex_poag_wrk("state").equalTo("MA"))// && $"outoff_exchange".equalTo("OUTOFF"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"SBSCRBR_ID",  $"MBR_RLTNSHP_CD" ,$"Const_date",
									$"MBR_PROD_ENRLMNT_TRMNTN_DT" , $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)),round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0) ).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("Member Months"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum($"Member Months").alias("mbrmpoa_issued_lgp_mmcare")).withColumn("mbrmpoa_issued_lgp_mmcare",round($"mbrmpoa_issued_lgp_mmcare",0).cast(IntegerType))

							val ipLgpmm = ipCatData.alias("bsg").join(mbrmpoa_issued_lgp_mmcare.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"),col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"),col("mbrmpoa_issued_gtlgp"),col("mbrmpoa_issued_gtsgp"),col("mbrmpoa_issued_gtip"),
									col("mbrmpoa_issued_total_gtip"), col("mbrmpoa_issued_catastrophic"),col("mbrmpoa_issued_lgp_mmcare"))


							val ipLgpmmData = ipLgpmm.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip","mbrmpoa_issued_total_ip","mbrmpoa_issued_bronze_sgp","mbrmpoa_issued_silver_sgp","mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp","mbrmpoa_issued_gtsgp","mbrmpoa_issued_gtip",
									"mbrmpoa_issued_total_gtip","mbrmpoa_issued_catastrophic","mbrmpoa_issued_lgp_mmcare")

							val mbrmpoa_issued_stucvg = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias("mbrmpoa_issued_stucvg")).withColumn("mbrmpoa_issued_stucvg",round($"mbrmpoa_issued_stucvg",0).cast(IntegerType))


							val ipStu = ipLgpmmData.alias("bsg").join(mbrmpoa_issued_stucvg.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_oux"),
									$"plt.outoff_exchange".alias("s_oux"),col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"),col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"),col("mbrmpoa_issued_gtlgp"),col("mbrmpoa_issued_gtsgp"),col("mbrmpoa_issued_gtip"),
									col("mbrmpoa_issued_total_gtip"), col("mbrmpoa_issued_catastrophic"),col("mbrmpoa_issued_lgp_mmcare"),col("mbrmpoa_issued_stucvg"))


							val finalData = ipStu.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "mbrmpoa_issued_bronze_ip" ,"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip","mbrmpoa_issued_total_ip","mbrmpoa_issued_bronze_sgp","mbrmpoa_issued_silver_sgp","mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp","mbrmpoa_issued_gtsgp","mbrmpoa_issued_gtip",
									"mbrmpoa_issued_total_gtip","mbrmpoa_issued_catastrophic","mbrmpoa_issued_lgp_mmcare","mbrmpoa_issued_stucvg")




							finalData

			}



			def getInitialData(naic_mcas_hlthex_poa_wrk: DataFrame,naic_mcas_hlthex_poag_issued_wrk:DataFrame,typeOfData:String) :DataFrame = {

					val out_exchngVal = "OUTOFF"

							val nbrpoa_bronze_ip = "nbrpoa_"+typeOfData+"_bronze_ip"
							val nbrpoa_issued_bronze_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_bronze_ip))

							val nbrpoa_silver_ip = "nbrpoa_"+typeOfData+"_silver_ip"
							val nbrpoa_issued_silver_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_silver_ip))

							val brSil = nbrpoa_issued_bronze_ip.alias("bronze").join(nbrpoa_issued_silver_ip.alias("silver") , $"bronze.health_year"===$"silver.health_year" 
							&& $"bronze.cmpny_cf_cd"===$"silver.cmpny_cf_cd" && $"bronze.state" === $"silver.state" && $"bronze.outoff_exchange"===$"silver.outoff_exchange", "outer")
							.select($"bronze.health_year".alias("b_year"),$"silver.health_year".alias("s_year"), 
									$"bronze.cmpny_cf_cd".alias("b_cmpny"),$"silver.cmpny_cf_cd".alias("s_cmpny") , $"bronze.state".alias("b_state"), 
									$"silver.state".alias("s_state") , $"bronze.outoff_exchange".alias("b_inx"),
									$"silver.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip))

							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip)

							val nbrpoa_gold_ip = "nbrpoa_"+typeOfData+"_gold_ip" 
							val nbrpoa_issued_gold_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_gold_ip))

							val bsGold = brSilData.alias("brsil").join(nbrpoa_issued_gold_ip.alias("gold") , $"brsil.health_year"===$"gold.health_year" 
							&& $"brsil.cmpny_cf_cd"===$"gold.cmpny_cf_cd" && $"brsil.state" === $"gold.state" && $"brsil.outoff_exchange"===$"gold.outoff_exchange", "outer")
							.select($"brsil.health_year".alias("b_year"),$"gold.health_year".alias("s_year"), 
									$"brsil.cmpny_cf_cd".alias("b_cmpny"),$"gold.cmpny_cf_cd".alias("s_cmpny") , $"brsil.state".alias("b_state"), 
									$"gold.state".alias("s_state") , $"brsil.outoff_exchange".alias("b_inx"),
									$"gold.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip))

							val bsGoldData = bsGold.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip)


							val nbrpoa_platinum_ip = "nbrpoa_"+typeOfData+"_platinum_ip"   
							val nbrpoa_issued_platinum_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_platinum_ip))



							val bsgPlt = bsGoldData.alias("bsg").join(nbrpoa_issued_platinum_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip))


							val bsgPltinumData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip)

							val nbrpoa_total_ip = "nbrpoa_"+typeOfData+"_total_ip"   
							val getTotal_ip =  nbrpoa_issued_bronze_ip.union(nbrpoa_issued_silver_ip.union(nbrpoa_issued_gold_ip.union(nbrpoa_issued_platinum_ip)))
							.select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", col(nbrpoa_bronze_ip))

							val nbrpoa_issued_total_ip = getTotal_ip.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum(col(nbrpoa_bronze_ip)).alias(nbrpoa_total_ip))


							val bsgpTot = bsgPltinumData.alias("bsg").join(nbrpoa_issued_total_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip))


							val bsgPTotData = bsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip)

							val nbrpoa_gtlgp = "nbrpoa_"+typeOfData+"_gtlgp"

							val nbrpoa_issued_gtlgp= naic_mcas_hlthex_poag_issued_wrk.filter(naic_mcas_hlthex_poag_issued_wrk("naic_lob").equalTo("LARGE GROUP GRAND") &&							                                                                                                       
									naic_mcas_hlthex_poag_issued_wrk("state").equalTo("IL"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state",$"outoff_exchange",$"mbrshp_sor_cd",$"src_grp_nbr").agg(lit(1).alias("count_Val"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state",$"outoff_exchange").agg(sum("count_Val").alias(nbrpoa_gtlgp)) 							



							val ipgtlgp = bsgPTotData.alias("bsg").join(nbrpoa_issued_gtlgp.alias("plt"),$"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp))


							val ipgtlgpData = ipgtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_gtlgp)                      

							val nbrpoa_gtip = "nbrpoa_"+typeOfData+"_gtip"
							val nbrpoa_issued_gtip= naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("INDIVIDUAL GRAND") && 
									naic_mcas_hlthex_poa_wrk("state").equalTo("DC"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_gtip))           

							val ipgtlgpip = ipgtlgpData.alias("bsg").join(nbrpoa_issued_gtip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp), col(nbrpoa_gtip))


							val ipgtlgpipData = ipgtlgpip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_gtlgp, nbrpoa_gtip)                      


							val nbrpoa_catastrophic =  "nbrpoa_"+typeOfData+"_catastrophic"
							val nbrpoa_issued_catastrophic = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_catastrophic))


							val bsgptCat = ipgtlgpipData.alias("bsg").join(nbrpoa_issued_catastrophic.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp), col(nbrpoa_gtip) ,col(nbrpoa_catastrophic))


							val bsgptCatData = bsgptCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip,nbrpoa_gtlgp, nbrpoa_gtip, nbrpoa_catastrophic)


							val nbrpoa_lgp_mmcare="nbrpoa_"+typeOfData+"_lgp_mmcare"
							val  nbrpoa_issued_lgp_mmcare= naic_mcas_hlthex_poag_issued_wrk.filter(naic_mcas_hlthex_poag_issued_wrk  ("naic_lob").equalTo("LARGE GROUP CBE") &&
									naic_mcas_hlthex_poag_issued_wrk("state").equalTo("MA"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange",$"mbrshp_sor_cd", $"src_grp_nbr").agg(lit(1).alias("count_Val"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state",$"outoff_exchange").agg(sum("count_Val").alias(nbrpoa_lgp_mmcare)) 



							val bsgptcMmcare = bsgptCatData.alias("bsg").join(nbrpoa_issued_lgp_mmcare.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp), col(nbrpoa_gtip) ,col(nbrpoa_catastrophic), col(nbrpoa_lgp_mmcare))


							val bsgptcMmcareData = bsgptcMmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip,nbrpoa_gtlgp, nbrpoa_gtip, nbrpoa_catastrophic, nbrpoa_lgp_mmcare)



							val nbrpoa_stucvg="nbrpoa_"+typeOfData+"_stucvg"
							val  nbrpoa_issued_stucvg= naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_stucvg)) 

							val bsgptcmmcStuvg = bsgptcMmcareData.alias("bsg").join(nbrpoa_issued_stucvg.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp), col(nbrpoa_gtip) ,col(nbrpoa_catastrophic), col(nbrpoa_lgp_mmcare), col(nbrpoa_stucvg))


							val finalData = bsgptcmmcStuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip,nbrpoa_gtlgp, nbrpoa_gtip, nbrpoa_catastrophic, nbrpoa_lgp_mmcare, nbrpoa_stucvg)
							//println("Temrd Lives ")
							finalData             
			}

			def gettermedInitialData(naic_mcas_hlthex_poa_wrk: DataFrame,naic_mcas_hlthex_poag_wrk:DataFrame,typeOfData:String):DataFrame = {

					val out_exchngVal = "OUTOFF"

							val nbrpoa_bronze_ip = "nbrpoa_"+typeOfData+"_bronze_ip"
							val nbrpoa_issued_bronze_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_bronze_ip))

							val nbrpoa_silver_ip = "nbrpoa_"+typeOfData+"_silver_ip"
							val nbrpoa_issued_silver_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_silver_ip))

							val brSil = nbrpoa_issued_bronze_ip.alias("bronze").join(nbrpoa_issued_silver_ip.alias("silver") , $"bronze.health_year"===$"silver.health_year" 
							&& $"bronze.cmpny_cf_cd"===$"silver.cmpny_cf_cd" && $"bronze.state" === $"silver.state" && $"bronze.outoff_exchange"===$"silver.outoff_exchange", "outer")
							.select($"bronze.health_year".alias("b_year"),$"silver.health_year".alias("s_year"), 
									$"bronze.cmpny_cf_cd".alias("b_cmpny"),$"silver.cmpny_cf_cd".alias("s_cmpny") , $"bronze.state".alias("b_state"), 
									$"silver.state".alias("s_state") , $"bronze.outoff_exchange".alias("b_inx"),
									$"silver.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip))

							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip)

							val nbrpoa_gold_ip = "nbrpoa_"+typeOfData+"_gold_ip" 
							val nbrpoa_issued_gold_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_gold_ip))

							val bsGold = brSilData.alias("brsil").join(nbrpoa_issued_gold_ip.alias("gold") , $"brsil.health_year"===$"gold.health_year" 
							&& $"brsil.cmpny_cf_cd"===$"gold.cmpny_cf_cd" && $"brsil.state" === $"gold.state" && $"brsil.outoff_exchange"===$"gold.outoff_exchange", "outer")
							.select($"brsil.health_year".alias("b_year"),$"gold.health_year".alias("s_year"), 
									$"brsil.cmpny_cf_cd".alias("b_cmpny"),$"gold.cmpny_cf_cd".alias("s_cmpny") , $"brsil.state".alias("b_state"), 
									$"gold.state".alias("s_state") , $"brsil.outoff_exchange".alias("b_inx"),
									$"gold.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip))

							val bsGoldData = bsGold.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip)


							val nbrpoa_platinum_ip = "nbrpoa_"+typeOfData+"_platinum_ip"   
							val nbrpoa_issued_platinum_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_platinum_ip))



							val bsgPlt = bsGoldData.alias("bsg").join(nbrpoa_issued_platinum_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip))


							val bsgPltinumData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip)

							val nbrpoa_total_ip = "nbrpoa_"+typeOfData+"_total_ip"   
							val getTotal_ip =  nbrpoa_issued_bronze_ip.union(nbrpoa_issued_silver_ip.union(nbrpoa_issued_gold_ip.union(nbrpoa_issued_platinum_ip)))
							.select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", col(nbrpoa_bronze_ip))

							val nbrpoa_issued_total_ip = getTotal_ip.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum(col(nbrpoa_bronze_ip)).alias(nbrpoa_total_ip))


							val bsgpTot = bsgPltinumData.alias("bsg").join(nbrpoa_issued_total_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip))


							val bsgPTotData = bsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip)

							val nbrpoa_gtlgp = "nbrpoa_"+typeOfData+"_gtlgp"
							val nbrpoa_issued_gtlgp= naic_mcas_hlthex_poag_wrk.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("LARGE GROUP GRAND") &&
									naic_mcas_hlthex_poag_wrk("state").equalTo("IL"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state",$"outoff_exchange",$"mbrshp_sor_cd",$"src_grp_nbr").agg(lit(1).alias("count_Val"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state",$"outoff_exchange").agg(sum("count_Val").alias(nbrpoa_gtlgp))


							val ipgtlgp = bsgPTotData.alias("bsg").join(nbrpoa_issued_gtlgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp))


							val ipgtlgpData = ipgtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_gtlgp)                      

							val nbrpoa_gtip = "nbrpoa_"+typeOfData+"_gtip"

							val nbrpoa_issued_gtip= naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("INDIVIDUAL GRAND") && 
									naic_mcas_hlthex_poa_wrk("state").equalTo("DC"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_gtip))           

							val ipgtlgpip = ipgtlgpData.alias("bsg").join(nbrpoa_issued_gtip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp), col(nbrpoa_gtip))


							val ipgtlgpipData = ipgtlgpip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_gtlgp, nbrpoa_gtip)                      


							val nbrpoa_catastrophic =  "nbrpoa_"+typeOfData+"_catastrophic"
							val nbrpoa_issued_catastrophic = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_catastrophic))


							val bsgptCat = ipgtlgpipData.alias("bsg").join(nbrpoa_issued_catastrophic.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp), col(nbrpoa_gtip) ,col(nbrpoa_catastrophic))


							val bsgptCatData = bsgptCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip,nbrpoa_gtlgp, nbrpoa_gtip, nbrpoa_catastrophic)


							val nbrpoa_lgp_mmcare="nbrpoa_"+typeOfData+"_lgp_mmcare"
							val  nbrpoa_issued_lgp_mmcare= naic_mcas_hlthex_poag_wrk.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("LARGE GROUP CBE") &&
									naic_mcas_hlthex_poag_wrk("state").equalTo("MA"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state",$"outoff_exchange",$"mbrshp_sor_cd",$"src_grp_nbr").agg(lit(1).alias("count_Val"))
              .groupBy($"health_year", $"cmpny_cf_cd", $"state",$"outoff_exchange").agg(sum("count_Val").alias(nbrpoa_lgp_mmcare))

							val bsgptcMmcare = bsgptCatData.alias("bsg").join(nbrpoa_issued_lgp_mmcare.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp), col(nbrpoa_gtip) ,col(nbrpoa_catastrophic), col(nbrpoa_lgp_mmcare))


							val bsgptcMmcareData = bsgptcMmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip,nbrpoa_gtlgp, nbrpoa_gtip, nbrpoa_catastrophic, nbrpoa_lgp_mmcare)



							val nbrpoa_stucvg="nbrpoa_"+typeOfData+"_stucvg"
							val  nbrpoa_issued_stucvg= naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_stucvg)) 

							val bsgptcmmcStuvg = bsgptcMmcareData.alias("bsg").join(nbrpoa_issued_stucvg.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp), col(nbrpoa_gtip) ,col(nbrpoa_catastrophic), col(nbrpoa_lgp_mmcare), col(nbrpoa_stucvg))


							val finalData = bsgptcmmcStuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip,nbrpoa_gtlgp, nbrpoa_gtip, nbrpoa_catastrophic, nbrpoa_lgp_mmcare, nbrpoa_stucvg)
							//println("Temrd Lives ")
							finalData             
			}



			def getTermedLivesData(naic_mcas_hlthex_poa_wrk: DataFrame,naic_mcas_hlthex_poag_wrk:DataFrame,typeOfData:String) :DataFrame = {
					val out_exchngVal = "OUTOFF"
							val nbrpoa_bronze_ip = "nbrpoa_"+typeOfData+"_bronze_ip"
							val nbrpoa_termed_nonpay_lives_bronze_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_bronze_ip))



							val nbrpoa_silver_ip = "nbrpoa_"+typeOfData+"_silver_ip"                                        
							val nbrpoa_termed_nonpay_lives_silver_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_silver_ip))


							val brSil = nbrpoa_termed_nonpay_lives_bronze_ip.alias("bronze").join(nbrpoa_termed_nonpay_lives_silver_ip.alias("silver") , $"bronze.health_year"===$"silver.health_year" 
							&& $"bronze.cmpny_cf_cd"===$"silver.cmpny_cf_cd" && $"bronze.state" === $"silver.state" && $"bronze.outoff_exchange"===$"silver.outoff_exchange", "outer")
							.select($"bronze.health_year".alias("b_year"),$"silver.health_year".alias("s_year"), 
									$"bronze.cmpny_cf_cd".alias("b_cmpny"),$"silver.cmpny_cf_cd".alias("s_cmpny") , $"bronze.state".alias("b_state"), 
									$"silver.state".alias("s_state") , $"bronze.outoff_exchange".alias("b_inx"),
									$"silver.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip))


							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip)
							val nbrpoa_gold_ip = "nbrpoa_"+typeOfData+"_gold_ip"                                        
							val nbrpoa_termed_nonpay_lives_gold_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_gold_ip))

							val bsGold = brSilData.alias("brsil").join(nbrpoa_termed_nonpay_lives_gold_ip.alias("gold") , $"brsil.health_year"===$"gold.health_year" 
							&& $"brsil.cmpny_cf_cd"===$"gold.cmpny_cf_cd" && $"brsil.state" === $"gold.state" && $"brsil.outoff_exchange"===$"gold.outoff_exchange", "outer")
							.select($"brsil.health_year".alias("b_year"),$"gold.health_year".alias("s_year"), 
									$"brsil.cmpny_cf_cd".alias("b_cmpny"),$"gold.cmpny_cf_cd".alias("s_cmpny") , $"brsil.state".alias("b_state"), 
									$"gold.state".alias("s_state") , $"brsil.outoff_exchange".alias("b_inx"),
									$"gold.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip))


							val bsGoldData = bsGold.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip)

							val nbrpoa_platinum_ip = "nbrpoa_"+typeOfData+"_platinum_ip"                                        
							val nbrpoa_termed_nonpay_lives_platinum_ip = naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_platinum_ip))

							val bsgPlt = bsGoldData.alias("bsg").join(nbrpoa_termed_nonpay_lives_platinum_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip))


							val bsgPltinumData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip)

							val nbrpoa_total_ip = "nbrpoa_"+typeOfData+"_total_ip"   
							val getTotal_ip =  nbrpoa_termed_nonpay_lives_bronze_ip.union(nbrpoa_termed_nonpay_lives_silver_ip.union(nbrpoa_termed_nonpay_lives_gold_ip.union(nbrpoa_termed_nonpay_lives_platinum_ip)))
							.select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", col(nbrpoa_bronze_ip))

							val nbrpoa_termed_nonpay_lives_total_ip = getTotal_ip.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum(col(nbrpoa_bronze_ip)).alias(nbrpoa_total_ip))

							val bsgpTot = bsgPltinumData.alias("bsg").join(nbrpoa_termed_nonpay_lives_total_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip))


							val ipTotData = bsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip)     
							val nbrpoa_bronze_sgp = "nbrpoa_"+typeOfData+"_bronze_sgp"                                            
							val nbrpoa_termed_nonpay_lives_bronze_sgp=   naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_bronze_sgp))

							val ipBrz = ipTotData.alias("bsg").join(nbrpoa_termed_nonpay_lives_bronze_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp))


							val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_bronze_sgp)   


							val nbrpoa_silver_sgp = "nbrpoa_"+typeOfData+"_silver_sgp"                                            
							val nbrpoa_termed_nonpay_lives_silver_sgp=   naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_silver_sgp))

							val ipbSil = ipBrzData.alias("bsg").join(nbrpoa_termed_nonpay_lives_silver_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp))


							val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp)                           

							val nbrpoa_gold_sgp = "nbrpoa_"+typeOfData+"_gold_sgp"                                            
							val nbrpoa_termed_nonpay_lives_gold_sgp=   naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_gold_sgp))

							val ipbsGld = ipbSilData.alias("bsg").join(nbrpoa_termed_nonpay_lives_gold_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp))


							val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp)  


							val nbrpoa_platinum_sgp = "nbrpoa_"+typeOfData+"_platinum_sgp"                                            
							val nbrpoa_termed_nonpay_lives_platimun_sgp=   naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_platinum_sgp))

							val ipbsgPlt = ipbsGldData.alias("bsg").join(nbrpoa_termed_nonpay_lives_platimun_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp))


							val ipbsgPltData = ipbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp)

							val nbrpoa_total_sgp = "nbrpoa_"+typeOfData+"_total_sgp"   
							val getTotal_sgp =  nbrpoa_termed_nonpay_lives_bronze_sgp.union(nbrpoa_termed_nonpay_lives_silver_sgp.union(nbrpoa_termed_nonpay_lives_gold_sgp.union(nbrpoa_termed_nonpay_lives_platimun_sgp)))
							.select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", col(nbrpoa_bronze_sgp))

							val nbrpoa_termed_nonpay_lives_total_sgp = getTotal_sgp.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum(col(nbrpoa_bronze_sgp)).alias(nbrpoa_total_sgp))

							val ipbsgpTot = ipbsgPltData.alias("bsg").join(nbrpoa_termed_nonpay_lives_total_sgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp))


							val ipsgpData = ipbsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,nbrpoa_total_sgp) 
							val nbrpoa_gtlgp = "nbrpoa_"+typeOfData+"_gtlgp"

							val nbrpoa_termed_lives_gtlgp = 	 naic_mcas_hlthex_poag_wrk
							.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("LARGE GROUP GRAND") && 
									naic_mcas_hlthex_poag_wrk("state").equalTo("IL"))// && $"outoff_exchange".equalTo("OUTOFF"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"sbscrbr_id",$"mbr_rltnshp_cd").agg((lit(1)).alias("Count_vl"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum($"Count_vl").alias(nbrpoa_gtlgp))

							val ipbsgpTotgtLgp = ipsgpData.alias("bsg").join(nbrpoa_termed_lives_gtlgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
									col(nbrpoa_gtlgp))


							val ipbsgpTotgtLgpData = ipbsgpTotgtLgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,nbrpoa_total_sgp, nbrpoa_gtlgp) 		

							val nbrpoa_gtsgp = "nbrpoa_"+typeOfData+"_gtsgp"

							val nbrpoa_termed_lives_gtsgp = 	 naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_gtsgp))

							val ipbsgpTotgtLgpgtsgp = ipbsgpTotgtLgpData.alias("bsg").join(nbrpoa_termed_lives_gtsgp.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
									col(nbrpoa_gtlgp), col(nbrpoa_gtsgp))


							val ipbsgpTotgtLgpgtsgpData = ipbsgpTotgtLgpgtsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,nbrpoa_total_sgp, nbrpoa_gtlgp, nbrpoa_gtsgp)		

							val nbrpoa_gtip = "nbrpoa_"+typeOfData+"_gtip"

							val nbrpoa_termed_lives_gtip = 	 naic_mcas_hlthex_poag_wrk
							.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("INDIVIDUAL GRAND") && 
									naic_mcas_hlthex_poag_wrk("state").equalTo("DC"))// && $"outoff_exchange".equalTo("OUTOFF"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"sbscrbr_id",$"mbr_rltnshp_cd").agg((lit(1)).alias("Count_vl"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum($"Count_vl").alias(nbrpoa_gtip))


							val ipbsgpTotgtLgpgtsgpip = ipbsgpTotgtLgpgtsgpData.alias("bsg").join(nbrpoa_termed_lives_gtip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
									col(nbrpoa_gtlgp), col(nbrpoa_gtsgp), col(nbrpoa_gtip))


							val ipbsgpTotgtLgpgtsgpipData = ipbsgpTotgtLgpgtsgpip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,nbrpoa_total_sgp, nbrpoa_gtlgp, nbrpoa_gtsgp,
									nbrpoa_gtip)			
							val nbrpoa_total_gtip = "nbrpoa_"+typeOfData+"_total_gtip"
							val getTotal_gtip =  nbrpoa_termed_lives_gtlgp.union(nbrpoa_termed_lives_gtsgp.union(nbrpoa_termed_lives_gtip))
							.select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", col(nbrpoa_gtlgp))

							val mbrmpoa_renewed_total_ip = getTotal_gtip.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum(nbrpoa_gtlgp).alias(nbrpoa_total_gtip))

							val ipbsgpTotgtLgpgtsgpipTot = ipbsgpTotgtLgpgtsgpipData.alias("bsg").join(mbrmpoa_renewed_total_ip.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
									col(nbrpoa_gtlgp), col(nbrpoa_gtsgp), col(nbrpoa_gtip), col(nbrpoa_total_gtip))


							val ipbsgpTotgtLgpgtsgpipTotData = ipbsgpTotgtLgpgtsgpipTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,nbrpoa_total_sgp, nbrpoa_gtlgp, nbrpoa_gtsgp,
									nbrpoa_gtip,nbrpoa_total_gtip)







							val nbrpoa_catastrophic = "nbrpoa_"+typeOfData+"_catastrophic"  
							val nbrpoa_termed_nonpay_lives_catastrophic=   naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_catastrophic))


							val ipbsgpCat = ipbsgpTotgtLgpgtsgpipTotData.alias("bsg").join(nbrpoa_termed_nonpay_lives_catastrophic.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
									col(nbrpoa_gtlgp), col(nbrpoa_gtsgp), col(nbrpoa_gtip), col(nbrpoa_total_gtip),col(nbrpoa_catastrophic))


							val ipbsgpCatData = ipbsgpCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,nbrpoa_total_sgp,
									nbrpoa_gtlgp, nbrpoa_gtsgp,
									nbrpoa_gtip,nbrpoa_total_gtip,nbrpoa_catastrophic) 


							val nbrpoa_mmcare="nbrpoa_"+typeOfData+"_lgp_mmcare"
							val  nbrpoa_termed_nonpay_lives_mmcare= naic_mcas_hlthex_poag_wrk
							.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("LARGE GROUP CBE") && 
									naic_mcas_hlthex_poag_wrk("state").equalTo("MA"))// && $"outoff_exchange".equalTo("OUTOFF"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"sbscrbr_id",$"mbr_rltnshp_cd").agg((lit(1)).alias("Count_vl"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum($"Count_vl").alias(nbrpoa_mmcare))


							val ipbsgpcMmcare = ipbsgpCatData.alias("bsg").join(nbrpoa_termed_nonpay_lives_mmcare.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
									col(nbrpoa_gtlgp), col(nbrpoa_gtsgp), col(nbrpoa_gtip), col(nbrpoa_total_gtip),col(nbrpoa_catastrophic),
									col(nbrpoa_mmcare))


							val ipbsgpcMmcareData = ipbsgpcMmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,nbrpoa_total_sgp,
									nbrpoa_gtlgp, nbrpoa_gtsgp,
									nbrpoa_gtip,nbrpoa_total_gtip,nbrpoa_catastrophic,
									nbrpoa_mmcare) 



							val nbrpoa_stucvg="nbrpoa_"+typeOfData+"_stucvg"
							val  nbrpoa_termed_nonpay_stucvg= naic_mcas_hlthex_poa_wrk
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(lit(0).alias(nbrpoa_stucvg)) 

							val ipbsgpcMmcStucvg = ipbsgpcMmcareData.alias("bsg").join(nbrpoa_termed_nonpay_stucvg.alias("plt") , $"bsg.health_year"===$"plt.health_year" 
							&& $"bsg.cmpny_cf_cd"===$"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.outoff_exchange"===$"plt.outoff_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"),$"plt.health_year".alias("s_year"), 
									$"bsg.cmpny_cf_cd".alias("b_cmpny"),$"plt.cmpny_cf_cd".alias("s_cmpny") , $"bsg.state".alias("b_state"), 
									$"plt.state".alias("s_state") , $"bsg.outoff_exchange".alias("b_inx"),
									$"plt.outoff_exchange".alias("s_inx"),col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp), 
									col(nbrpoa_gtlgp), col(nbrpoa_gtsgp), col(nbrpoa_gtip), col(nbrpoa_total_gtip),col(nbrpoa_catastrophic),
									col(nbrpoa_mmcare), col(nbrpoa_stucvg))


							val finalData = ipbsgpcMmcStucvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
							.select("health_year","cmpny_cf_cd", "state", "outoff_exchange", nbrpoa_bronze_ip ,nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,nbrpoa_total_sgp,nbrpoa_gtlgp, nbrpoa_gtsgp,
									nbrpoa_gtip,nbrpoa_total_gtip,nbrpoa_catastrophic,
									nbrpoa_mmcare,nbrpoa_stucvg )              
							finalData
			}



}

object PCADX_SCL_NAIC2018_UnicareStgTransformationPOA{
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val OEX = new PCADX_SCL_NAIC2018_UnicareStgTransformationPOA()
		OEX.sparkInIt()

	}


}