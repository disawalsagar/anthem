package gen

import org.apache.log4j.PropertyConfigurator
import org.slf4j.{ Logger, LoggerFactory }

import java.sql.Timestamp
import scala.io.Source
import java.io._
import java.util.Properties

import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit
import org.apache.hadoop.fs._;


class PCADX_SCL_NAIC2018_PA_TEMP_WRK {
  
  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()

  import spark.implicits._

  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_PA_TEMP_WRK])

  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  
  val dbWrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val wrhDb = dbProperties.getProperty("warehouse.db")
  val prcp_cd = dbProperties.getProperty("PRCP_TYPE_CD")
  val reportYear = dbProperties.getProperty("report.year")

  val audit_log_df = spark.sql("select * from " + wrhDb + ".audt_load_log")
  val load_log_key = audit_log_df.filter($"subj_area_nm" === "NAIC2018_MCAS" && $"prcs_nm" === "NAIC2018_MCAS_RPT" && $"load_stts_cd" === "S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0)
  println("load_log_key : " + load_log_key)
  
  
  def naic2018_mcas_pa_temp_wrk() = """insert overwrite table """ + dbWrk + """.naic2018_mcas_pa_temptable_wrk""" + """
		  SELECT * from (
      SELECT MPE.MBR_KEY AS MBR_KEY,
		  MPE.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,
		  MPE.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
      MPE.MBR_PROD_ENRLMNT_EFCTV_DT,
      MPE.MBR_PROD_ENRLMNT_TRMNTN_DT, 
		  MPECOA.MBU_CF_CD AS MBU_CF_CD ,
		  MPECOA.PROD_CF_CD AS PROD_CF_CD,
		  MPECOA.CMPNY_CF_CD AS CMPNY_CF_CD,
		  MPECOA.FUNDG_CF_CD AS FUNDG_CF_CD,
		  BPA.EXCHNG_IND_CD AS EXCHNG_IND_CD,
		  BPA.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
		  BPA.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
		  BPA.HCR_CMPLYNT_CD AS HCR_CMPLYNT_CD ,
		  BPA.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
		  MHE.HIX_CD AS HIX_CD,
		  PRCP.PRCP_TYPE_CD AS PRCP_TYPE_CD,
		  PRCHSR_ORG_SUBGROUP.SRC_GRP_NBR AS SRC_GRP_NBR,
		  PRCHSR_ORG_SUBGROUP.SRC_SUBGRP_NBR AS SRC_SUBGRP_NBR,
		  PRCHSR_ORG_GROUP.SRC_GRP_NBR AS ORG_GRP_SRC_GRP_NBR, 
		  PRCHSR_ORG_GROUP.SRC_SUBGRP_NBR AS ORG_GRP_SRC_SUBGRP_NBR,
      PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_EFCTV_DT AS  PRCHSR_ORG_EFCTV_DT,
      PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TRMNTN_DT AS  PRCHSR_ORG_TRMNTN_DT,
      MPECOA.MBR_COA_EFCTV_DT AS  MBR_COA_EFCTV_DT,
      MPECOA.MBR_COA_TRMNTN_DT AS MBR_COA_TRMNTN_DT,
      """ + load_log_key + """ as LOAD_LOG_KEY,
		  current_timestamp as load_dt
		  from """ + dbInbnd + """.MBR_PROD_ENRLMNT MPE
		  INNER  JOIN """ + dbInbnd + """.PROD_OFRG PO
		  ON MPE.PROD_OFRG_KEY=PO.PROD_OFRG_KEY
		  AND PO.RCRD_STTS_CD <> 'DEL'
		  INNER JOIN """ + dbInbnd + """.BNFT_PKG BP
		  ON PO.BNFT_PKG_KEY = BP.BNFT_PKG_KEY
		  AND BP.RCRD_STTS_CD <> 'DEL'

		  INNER JOIN  """ + dbInbnd + """.BNFT_PKG_PRCP BPP
		  ON (BP.BNFT_PKG_KEY=BPP.BNFT_PKG_KEY
		  AND BP.PROD_SOR_CD=BPP.PROD_SOR_CD
		  AND MPE.MBR_PROD_ENRLMNT_EFCTV_DT <= BPP.BNFT_PKG_PRCP_TRMNTN_DT
		  AND MPE.MBR_PROD_ENRLMNT_TRMNTN_DT >= BPP.BNFT_PKG_PRCP_EFCTV_DT
		  AND BPP.RCRD_STTS_CD <> 'DEL')

		  INNER JOIN """ + dbInbnd + """.PRCP
		  ON (BPP.PRCP_ID=PRCP.PRCP_ID
		  AND BPP.PROD_SOR_CD=PRCP.PROD_SOR_CD
		  AND PRCP.RCRD_STTS_CD <> 'DEL')

		  INNER JOIN """ + dbInbnd + """.MBR_PROD_ENRLMNT_COA MPECOA
		  ON MPE.MBR_KEY = MPECOA.MBR_KEY
		  AND MPE.PROD_OFRG_KEY = MPECOA.PROD_OFRG_KEY
		  AND MPE.MBR_PROD_ENRLMNT_EFCTV_DT = MPECOA.MBR_PROD_ENRLMNT_EFCTV_DT
		  AND MPECOA.RCRD_STTS_CD <> 'DEL'

		  LEFT OUTER JOIN """ + dbInbnd + """.MBR_HIX_ENRLMNT MHE
		  ON MPE.MBR_KEY = MHE.MBR_KEY
		  AND MPE.PROD_OFRG_KEY = MHE.PROD_OFRG_KEY
		  AND MPE.MBR_PROD_ENRLMNT_EFCTV_DT = MHE.MBR_PROD_ENRLMNT_EFCTV_DT
		  AND MHE.RCRD_STTS_CD <> 'DEL'

		  LEFT OUTER JOIN """ + dbInbnd + """.BNFT_PKG_ADDNL BPA
		  ON BP.BNFT_PKG_KEY = BPA.BNFT_PKG_KEY
		  AND BPA.RCRD_STTS_CD <> 'DEL'

		  LEFT JOIN """ + dbInbnd + """.PRCHSR_ORG AS PRCHSR_ORG_GROUP
		  ON PO.MBRSHP_SOR_CD = PRCHSR_ORG_GROUP.MBRSHP_SOR_CD
		  AND PO.PRCHSR_ORG_NBR = PRCHSR_ORG_GROUP.PRCHSR_ORG_NBR
		  AND PO.PRCHSR_ORG_TYPE_CD = PRCHSR_ORG_GROUP.PRCHSR_ORG_TYPE_CD
		  AND PRCHSR_ORG_GROUP.PRCHSR_ORG_TYPE_CD = '03'
		  AND PRCHSR_ORG_GROUP.RCRD_STTS_CD <> 'DEL'

		  LEFT JOIN """ + dbInbnd + """.PRCHSR_ORG AS PRCHSR_ORG_SUBGROUP
		  ON PO.MBRSHP_SOR_CD = PRCHSR_ORG_SUBGROUP.MBRSHP_SOR_CD
		  AND PO.RLTD_PRCHSR_ORG_NBR = PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_NBR
		  AND PO.RLTD_PRCHSR_ORG_TYPE_CD = PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TYPE_CD
		  AND PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TYPE_CD = '04'
		  AND PRCHSR_ORG_SUBGROUP.RCRD_STTS_CD <> 'DEL'

		  WHERE MPE.RCRD_STTS_CD<>'DEL'
		  AND MPE.MBRSHP_SOR_CD NOT LIKE '5%'
		  AND MPE.MBRSHP_SOR_CD <> '1104'
		  AND MPE.SCRTY_LVL_CD NOT  IN ( 'F')
		  AND PRCP.PRCP_TYPE_CD IN ( """ + prcp_cd + """ )
		    
		  GROUP BY
		  MPE.MBR_KEY,
		  MPE.MBRSHP_SOR_CD,
		  MPE.GRNDFTHR_IND_CD,
		  MPE.MBR_PROD_ENRLMNT_EFCTV_DT,
      MPE.MBR_PROD_ENRLMNT_TRMNTN_DT, 
		  MHE.HIX_CD,
		  BPA.GRNDFTHRG_STTS_CD,
		  BPA.HCR_CMPLYNT_CD,
		  BPA.EXCHNG_IND_CD ,
		  BPA.EXCHNG_METL_TYPE_CD,
		  BPA.SRC_EXCHNG_CERTFN_CD,
		  MPECOA.MBU_CF_CD,
		  MPECOA.PROD_CF_CD,
		  MPECOA.CMPNY_CF_CD,
		  MPECOA.FUNDG_CF_CD,
			PRCP.PRCP_TYPE_CD,
		  PRCHSR_ORG_SUBGROUP.SRC_GRP_NBR,
		  PRCHSR_ORG_SUBGROUP.SRC_SUBGRP_NBR,
		  PRCHSR_ORG_GROUP.SRC_GRP_NBR, 
		  PRCHSR_ORG_GROUP.SRC_SUBGRP_NBR,
      PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_EFCTV_DT,
      PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TRMNTN_DT,
      MPECOA.MBR_COA_EFCTV_DT,
      MPECOA.MBR_COA_TRMNTN_DT
)
		  """

	def sparkInIt() {
    	var obj_naic2018_pa_temp_wrk = naic2018_mcas_pa_temp_wrk()
    	spark.sql(obj_naic2018_pa_temp_wrk)
    	spark.close()
 }

}

object PCADX_SCL_NAIC2018_PA_TEMP_WRK {

	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val paWrk = new PCADX_SCL_NAIC2018_PA_TEMP_WRK()
		 
		paWrk.sparkInIt()
		println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
	}

}