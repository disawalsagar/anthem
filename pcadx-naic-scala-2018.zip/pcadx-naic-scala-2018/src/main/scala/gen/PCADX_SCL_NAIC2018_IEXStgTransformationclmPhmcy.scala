package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit
class PCADX_SCL_NAIC2018_IEXStgTransformationclmPhmcy {
  var year =""
  val dbProperties = new Properties
  
  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()

  import spark.implicits._
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_IEXStgTransformationclmPhmcy])
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbin = dbProperties.getProperty("inbound.db")
  val tblreceived_ip = dbProperties.getProperty("received_ip")
  val tblreceived_sgp = dbProperties.getProperty("received_sgp")
  val tblreceived_cat = dbProperties.getProperty("received_cat")
  val tblpclm_denied = dbProperties.getProperty("pclm_denied")
  
  
  val tblpclm_paid = dbProperties.getProperty("pclm_paid")  
  val tblpaid_ip = dbProperties.getProperty("paid_ip")
  val tblpaid_sgp = dbProperties.getProperty("paid_sgp")
  val tblpaid_cat = dbProperties.getProperty("paid_cat")
  val tblsrvc_dnl = dbProperties.getProperty("srvc_dnl")
   var naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk :DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_received_cat_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_denied_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_paid_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_paid_cat_wrk:DataFrame = null
  var naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd:DataFrame = null
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clm")
  val end_year =dbProperties.getProperty("end_year_clm")
  //val strt_year =  LocalDate.parse(date1)
   // val end_year= LocalDate.parse(date2)
  def setyear(yr:String){
    year = yr
  }
  def sparkInIt(){
     naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk = readDataFromHive(dbwrk+"."+tblreceived_ip)
     naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk = readDataFromHive(dbwrk+"."+tblreceived_sgp)
     naic2018_mcas_hlthex_clmPhmcy_received_cat_wrk = readDataFromHive(dbwrk+"."+tblreceived_cat)
     naic2018_mcas_hlthex_clmPhmcy_denied_wrk = readDataFromHive(dbwrk+"."+tblpclm_denied)
     naic2018_mcas_hlthex_clmPhmcy_paid_wrk = readDataFromHive(dbwrk+"."+tblpclm_paid)
     naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk = readDataFromHive(dbwrk+"."+tblpaid_ip)
     naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk = readDataFromHive(dbwrk+"."+tblpaid_sgp)
     naic2018_mcas_hlthex_clmPhmcy_paid_cat_wrk = readDataFromHive(dbwrk+"."+tblpaid_cat)
     println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
     println(dbin+"."+tblsrvc_dnl)
     naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd = readDataFromHive(dbin+"."+tblsrvc_dnl)
    val finalReceivedData = getClmReceivedData()
    val finalDeniedInntwk = getDeniedInntwkData()
    val finalDeniedOutntwk = getDeniedOutntwkData()
    val finalPaidInntwk = getPaidInntwkData()
    val finalPaidOutntwk=getPaidOutntwkData()
    val finalPay = getTotalPaidCpaid("PAID_AMT","paid")
    val finalCPay = getTotalPaidCpaid("CPAY_AMT","copay")
    val finalCoinSrcPay = getTotalPaidCpaid("COINSRN_AMT","coinsrn")
    val finalddctblPay = getTotalPaidCpaid("DDCTBL_AMT","ddctbl")
    var load_log_key = ""
    if(!naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.take(1).isEmpty){
     load_log_key = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.select($"load_log_key").first.getString(0)
    }
    //val load_log_key = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.select($"load_log_key").first.getString(0)
    val stagData = getStgdata(finalReceivedData,finalDeniedInntwk,finalDeniedOutntwk,finalPaidInntwk,finalPaidOutntwk,finalPay,
        finalCPay,finalCoinSrcPay,finalddctblPay)
        val finalStgData = stagData.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
     
    writeDataToHive(dbsg+".naic2018_mcas_hlthiex_clmphmcy_stg",finalStgData) 
    spark.close()
  }
  def truncateTbl(tblName:String){
			  spark.sql("TRUNCATE TABLE "+tblName)
	}
  def writeDataToHive(tblName: String, finalDf: DataFrame) {
    finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
    println("Data added in stage table")
  }
 def readDataFromHive(tble: String): DataFrame = {
    val queryOutputTable="""SELECT * FROM """ +  tble
    val tbl_data_df = spark.sql(queryOutputTable)//.na.fill("")
    logger.info("Read data from hive")
    tbl_data_df
 } 
 
 
 def getClmReceivedData():DataFrame={
 
  val nbrclm_received_total_ip = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                              ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull) &&
                              $"in_exchange".equalTo("IN"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange",$"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_total_ip")).withColumn("nbrclm_received_total_ip",$"nbrclm_received_total_ip".cast(IntegerType))
                              
    val nbrclm_received_total_sgp = naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                               ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull)  &&
                              $"in_exchange".equalTo("IN"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_total_sgp")).withColumn("nbrclm_received_total_sgp",$"nbrclm_received_total_sgp".cast(IntegerType))
    
    val ipSgp=  nbrclm_received_total_ip.alias("parent").join(nbrclm_received_total_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"))
                                            
     val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp")                         
           
      val nbrclm_received_catastrophic  = naic2018_mcas_hlthex_clmPhmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                              $"in_exchange".equalTo("IN"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_catastrophic")).withColumn("nbrclm_received_catastrophic",$"nbrclm_received_catastrophic".cast(IntegerType))
    
    val ipSgpcat=  ipSgpData.alias("parent").join(nbrclm_received_catastrophic.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"))
                                            
     val ipSgpcatData = ipSgpcat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp", "nbrclm_received_catastrophic")                         
   
                           
      val nbrclm_received_total_ms_ip =  naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") && 
                              $"src_exchng_certfn_cd".equalTo("M") &&
                              $"in_exchange".equalTo("IN"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange",$"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_total_ms_ip")).withColumn("nbrclm_received_total_ms_ip",$"nbrclm_received_total_ms_ip".cast(IntegerType))
                           
       val ipSgpcatmsIp=  ipSgpcatData.alias("parent").join(nbrclm_received_total_ms_ip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_total_ms_ip"))
                                            
     val ipSgpcatmsIpData = ipSgpcatmsIp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_total_ms_ip")                         
                       
      val nbrclm_received_total_ms_sgp  =  naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") && 
                              $"src_exchng_certfn_cd".equalTo("M") &&
                              $"in_exchange".equalTo("IN"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange",$"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_total_ms_sgp")).withColumn("nbrclm_received_total_ms_sgp",$"nbrclm_received_total_ms_sgp".cast(IntegerType))
                                  
       val ipSgpcatmsIpmsSgp=  ipSgpcatmsIpData.alias("parent").join(nbrclm_received_total_ms_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_total_ms_ip"),
           col("nbrclm_received_total_ms_sgp"))
                                            
     val receivedData = ipSgpcatmsIpmsSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_total_ms_ip",
                               "nbrclm_received_total_ms_sgp")                         
                                    
    receivedData   
 }
 def getDeniedJoindataFrame(naic2018_mcas_pclm_denied_wrk:DataFrame, naic2018_mcas_hlthex_clmphmcy_received_wrk:DataFrame,  
     naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd:DataFrame) :DataFrame = {
   
   val joinedDf = naic2018_mcas_hlthex_clmphmcy_received_wrk.alias("received_wrk").join(naic2018_mcas_pclm_denied_wrk.alias("denied_wrk"), 
                                                                   $"received_wrk.CLM_NBR" === $"denied_wrk.CLM_NBR" &&
                                                                   $"received_wrk.MBR_KEY" === $"denied_wrk.MBR_KEY" &&
                                                                   $"received_wrk.RX_FILLED_DT" === $"denied_wrk.RX_FILLED_DT" &&
                                                                   $"received_wrk.ADJDCTN_DT" === $"denied_wrk.ADJDCTN_DT" &&
                                                                   $"received_wrk.NDC" === $"denied_wrk.NDC" &&
                                                                   $"received_wrk.RX_NBR" === $"denied_wrk.RX_NBR" , "inner")
                                                                   .join(naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd.alias("sec"),
                                                                        $"received_wrk.src_srvc_dnl_rsn_cd" === $"sec.src_srvc_dnl_rsn_cd" &&
                                                                        $"received_wrk.clm_sor_cd" === $"sec.clm_sor_cd", "left_outer")
                                                                    .filter( $"sec.src_srvc_dnl_rsn_cd".isNull && 
                                                                     $"sec.clm_sor_cd".isNull)
                                                                     .groupBy($"received_wrk.health_year".alias("health_year"), $"received_wrk.cmpny_cf_cd".alias("cmpny_cf_cd"), $"received_wrk.state".alias("state"),$"received_wrk.in_exchange".alias("in_exchange"), 
                                                                       $"received_wrk.CLM_NBR", $"received_wrk.CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                                        
    joinedDf                                                                
 }
 
 def getDeniedInntwkData() : DataFrame = {
   val clminn_cd = Seq("IN", "PAR")
    
   val clmLineAdjdctn = Seq("DND","DNDZB")
   val receivedipFilters = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                               ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull)  &&
                              $"in_exchange".equalTo("IN") &&
                              $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
     /*val secFilters =  naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd.filter($"src_srvc_dnl_rsn_cd".isNull && 
                                                                   $"clm_sor_cd".isNull) */           
   
   
   val denied_ip = getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedipFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   /*val secipFilters =  denied_ip.filter($"src_srvc_dnl_rsn_cd".isNull && 
                                                                   $"clm_sor_cd".isNull)*/
   
   val nbrclm_denied_inntwk_total_ip = denied_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_total_ip"))
   //val nbrclm_denied_inntwk_total_ip = secipFilters.groupBy($"received_wrk.health_year".alias("health_year"), $"received_wrk.cmpny_cf_cd".alias("cmpny_cf_cd"), $"received_wrk.state".alias("state"),$"received_wrk.in_exchange".alias("in_exchange"), 
     //                                                                   $"received_wrk.CLM_ADJSTMNT_KEY", $"received_wrk.CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_total_ip"))
   
   val receivedsgpFilters = naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                               ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull)  &&
                              $"in_exchange".equalTo("IN") &&
                               $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_sgp =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedsgpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  /* val secsgpFilters =  denied_sgp.filter($"src_srvc_dnl_rsn_cd".isNull && 
                                                                   $"clm_sor_cd".isNull)*/
   
   /*val nbrclm_denied_inntwk_total_sgp  = denied_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange",$"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_total_sgp"))*/
    val nbrclm_denied_inntwk_total_sgp  = denied_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_total_sgp"))

  val ipSgp=  nbrclm_denied_inntwk_total_ip.alias("parent").join(nbrclm_denied_inntwk_total_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"))
                                            
     val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp")   
                           
  val receivecatFilters = naic2018_mcas_hlthex_clmPhmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                                                                   $"in_exchange".equalTo("IN") && 
                                                                   $"inn_cd".isin(clminn_cd:_*))
                                                                   
   val denied_cat = getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivecatFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)     
   
   
   /*val seccatFilters =  denied_cat.filter($"src_srvc_dnl_rsn_cd".isNull && 
                                                                   $"clm_sor_cd".isNull)*/
   val nbrclm_denied_inntwk_catastrophic = denied_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_catastrophic"))
   //val nbrclm_denied_inntwk_catastrophic = denied_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_catastrophic"))
    val ipSgpCat=  ipSgpData.alias("parent").join(nbrclm_denied_inntwk_catastrophic.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"))
                                            
     val ipSgpCatData = ipSgpCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic")   
                           
                           
    val receiveMsIpFilters = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") && 
                              $"src_exchng_certfn_cd".equalTo("M") &&
                              $"in_exchange".equalTo("IN") &&
                                $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
    val denied_msip = getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receiveMsIpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)     
   
    
   
   val nbrclm_denied_inntwk_total_ms_ip  = denied_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_total_ms_ip"))
    
   // val nbrclm_denied_inntwk_total_ms_ip  = denied_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_total_ms_ip"))
    val ipSgpCatmsIp=  ipSgpCatData.alias("parent").join(nbrclm_denied_inntwk_total_ms_ip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_total_ms_ip"))
                                            
     val ipSgpCatmsIpData = ipSgpCatmsIp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_total_ms_ip")   
                                    
   val receiveMsSgpFilters = naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") && 
                              $"src_exchng_certfn_cd".equalTo("M") &&
                              $"in_exchange".equalTo("IN") &&
                               $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
    val denied_ms_sgp = getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receiveMsSgpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)     
   
    
   
   val nbrclm_denied_inntwk_total_ms_sgp   = denied_ms_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_total_ms_sgp"))
    //val nbrclm_denied_inntwk_total_ms_sgp   = denied_ms_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_total_ms_sgp"))
   val ipSgpCatmsIpmsSgp=  ipSgpCatmsIpData.alias("parent").join(nbrclm_denied_inntwk_total_ms_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_total_ms_ip"),
           col("nbrclm_denied_inntwk_total_ms_sgp"))
                                            
   val denied_inntwk = ipSgpCatmsIpmsSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_total_ms_ip", "nbrclm_denied_inntwk_total_ms_sgp")   
    denied_inntwk                                                        
 }
 
 def getDeniedOutntwkData():DataFrame={
   
   val clmLineAdjdctn = Seq("DND","DNDZB")
   val clminn_cd = Seq("IN", "PAR")
   val receivedipFilters = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                               ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull)  &&
                              $"in_exchange".equalTo("IN") &&
                              (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
    // )
                                                                   
   val denied_ip = getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedipFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
  
    val nbrclm_denied_outntwk_total_ip = denied_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_total_ip"))
   //val nbrclm_denied_outntwk_total_ip = denied_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_total_ip"))
                          
    val receivedsgpFilters = naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                               ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull)  &&
                              $"in_exchange".equalTo("IN") &&
                               (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))                      
    val denied_sgp = getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedsgpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
    
   val nbrclm_denied_outntwk_total_sgp  = denied_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_total_sgp"))
     // val nbrclm_denied_outntwk_total_sgp  = denied_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_total_sgp"))                            
     val ipSgp=  nbrclm_denied_outntwk_total_ip.alias("parent").join(nbrclm_denied_outntwk_total_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"))
                                            
     val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp")                       
    val receivedCatFilters = naic2018_mcas_hlthex_clmPhmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                              $"in_exchange".equalTo("IN") &&
                               (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))                      
    val denied_cat = getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedCatFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
    
    val nbrclm_denied_outntwk_catastrophic   = denied_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_catastrophic"))
    //val nbrclm_denied_outntwk_catastrophic   = denied_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_catastrophic"))
    val ipSgpCat=  ipSgpData.alias("parent").join(nbrclm_denied_outntwk_catastrophic.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
            $"child.in_exchange".alias("s_inx"),col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"))
                                            
     val ipSgpCatData = ipSgpCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic")   
                                    
                                                
                          
    val receiveMsIpFilters = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") && 
                              $"src_exchng_certfn_cd".equalTo("M") &&
                              $"in_exchange".equalTo("IN") &&
                               (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
    val denied_msip = getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receiveMsIpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)     
   
   
   
   val nbrclm_denied_outntwk_total_ms_ip   = denied_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_total_ms_ip")) 
    //val nbrclm_denied_outntwk_total_ms_ip   = denied_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_total_ms_ip")) 
                          
       val ipSgpCatmsIp=  ipSgpCatData.alias("parent").join(nbrclm_denied_outntwk_total_ms_ip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_total_ms_ip"))
                                            
     val ipSgpCatmsIpData = ipSgpCatmsIp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_total_ms_ip")   
                            
                          
    val receiveMsSgpFilters = naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") && 
                              $"src_exchng_certfn_cd".equalTo("M") &&
                              $"in_exchange".equalTo("IN") &&
                              (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
    val denied_ms_sgp = getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receiveMsSgpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)     
  
   
   
   val nbrclm_denied_outntwk_total_ms_sgp   = denied_ms_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_total_ms_sgp"))                      
    //val nbrclm_denied_outntwk_total_ms_sgp   = denied_ms_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_total_ms_sgp"))                       
                          
     val ipSgpCatmsIpmsSgp=  ipSgpCatmsIpData.alias("parent").join(nbrclm_denied_outntwk_total_ms_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_total_ms_ip"),
           col("nbrclm_denied_outntwk_total_ms_sgp"))
                                            
   val denied_outntwk = ipSgpCatmsIpmsSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic","nbrclm_denied_outntwk_total_ms_ip", "nbrclm_denied_outntwk_total_ms_sgp")   
    denied_outntwk

 }
 
 def getPaidInntwkData():DataFrame = {
   val clminn_cd = Seq("IN", "PAR")
   val nbrclm_paid_inntwk_total_ip = naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                               ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull)  &&
                              $"in_exchange".equalTo("IN") &&
                              $"inn_cd".isin(clminn_cd:_*))// &&
                              //$"inn_paid".equalTo("innetwork_paid"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_total_ip"))
  val nbrclm_paid_inntwk_total_sgp = naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                               ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull)  &&
                              $"in_exchange".equalTo("IN") &&
                             $"inn_cd".isin(clminn_cd:_*)) //&&
                             // $"inn_paid".equalTo("innetwork_paid"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_total_sgp"))                          
   
   val ipSgp=  nbrclm_paid_inntwk_total_ip.alias("parent").join(nbrclm_paid_inntwk_total_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"))
                                            
     val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp") 
                           
      val nbrclm_paid_inntwk_catastrophic   = naic2018_mcas_hlthex_clmPhmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                              $"in_exchange".equalTo("IN") &&  $"inn_cd".isin(clminn_cd:_*) )
                              //&& $"inn_paid".equalTo("innetwork_paid"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_catastrophic"))
    
    val ipSgpcat=  ipSgpData.alias("parent").join(nbrclm_paid_inntwk_catastrophic.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"))
                                            
     val ipSgpcatData = ipSgpcat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic")                         
   
                           
      val nbrclm_paid_inntwk_total_ms_ip  =  naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") && 
                              $"src_exchng_certfn_cd".equalTo("M") &&
                              $"in_exchange".equalTo("IN") &&  $"inn_cd".isin(clminn_cd:_*))// &&
                              //$"inn_paid".equalTo("innetwork_paid"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange",$"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_total_ms_ip"))
                           
       val ipSgpcatmsIp=  ipSgpcatData.alias("parent").join(nbrclm_paid_inntwk_total_ms_ip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_total_ms_ip"))
                                            
     val ipSgpcatmsIpData = ipSgpcatmsIp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange","nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_total_ms_ip")                         
                       
      val nbrclm_paid_inntwk_total_ms_sgp   =  naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") && 
                              $"src_exchng_certfn_cd".equalTo("M") &&
                              $"in_exchange".equalTo("IN") &&  $"inn_cd".isin(clminn_cd:_*)) //&&
                             // $"inn_paid".equalTo("innetwork_paid"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange",$"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_total_ms_sgp"))
                                  
       val ipSgpcatmsIpmsSgp=  ipSgpcatmsIpData.alias("parent").join(nbrclm_paid_inntwk_total_ms_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_total_ms_ip"),
           col("nbrclm_paid_inntwk_total_ms_sgp"))
                                            
     val paidIntwrkData = ipSgpcatmsIpmsSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_total_ms_ip",
                               "nbrclm_paid_inntwk_total_ms_sgp")                      
                           
    paidIntwrkData
   
 }
 def getPaidOutntwkData():DataFrame={
   val  clm_inn_cd =  Seq("IN", "PAR")
    val nbrclm_paid_outntwk_total_ip = naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                               ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull)  &&
                              $"in_exchange".equalTo("IN") &&
                              (!$"inn_cd".isin(clm_inn_cd:_*)))// &&
                              //$"inn_paid".equalTo("outnetwork_paid"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_total_ip"))
  val nbrclm_paid_outntwk_total_sgp = naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                               ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull)  &&
                              $"in_exchange".equalTo("IN") &&
                             (!$"inn_cd".isin(clm_inn_cd:_*)))//   &&
                             // $"inn_paid".equalTo("outnetwork_paid"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_total_sgp"))                          
   
   val ipSgp=  nbrclm_paid_outntwk_total_ip.alias("parent").join(nbrclm_paid_outntwk_total_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"))
                                            
     val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp") 
                           
      val nbrclm_paid_outntwk_catastrophic   = naic2018_mcas_hlthex_clmPhmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                              $"in_exchange".equalTo("IN") && (!$"inn_cd".isin(clm_inn_cd:_*)))// &&
                             // $"inn_paid".equalTo("outnetwork_paid"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_catastrophic"))
    
    val ipSgpcat=  ipSgpData.alias("parent").join(nbrclm_paid_outntwk_catastrophic.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"))
                                            
     val ipSgpcatData = ipSgpcat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic")                         
   
                           
      val nbrclm_paid_outntwk_total_ms_ip  =  naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") && 
                              $"src_exchng_certfn_cd".equalTo("M") &&
                              $"in_exchange".equalTo("IN") && (!$"inn_cd".isin(clm_inn_cd:_*)))// &&
                              //$"inn_paid".equalTo("outnetwork_paid"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange",$"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_total_ms_ip"))
                           
       val ipSgpcatmsIp=  ipSgpcatData.alias("parent").join(nbrclm_paid_outntwk_total_ms_ip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_total_ms_ip"))
                                            
     val ipSgpcatmsIpData = ipSgpcatmsIp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange","nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_total_ms_ip")                         
                       
      val nbrclm_paid_outntwk_total_ms_sgp   =  naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") && 
                              $"src_exchng_certfn_cd".equalTo("M") &&
                              $"in_exchange".equalTo("IN") &&  (!$"inn_cd".isin(clm_inn_cd:_*)))// &&
                             // $"inn_paid".equalTo("outnetwork_paid"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange",$"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_total_ms_sgp"))
                                  
       val ipSgpcatmsIpmsSgp=  ipSgpcatmsIpData.alias("parent").join(nbrclm_paid_outntwk_total_ms_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_total_ms_ip"),
           col("nbrclm_paid_outntwk_total_ms_sgp"))
                                            
     val paidOutwrkData = ipSgpcatmsIpmsSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_total_ms_ip",
                               "nbrclm_paid_outntwk_total_ms_sgp")                      
                           
    paidOutwrkData
 }
 def getTotalPaidCpaid(paid_col:String, typeOfPay:String):DataFrame={
   val total_ip = "clm_total_"+typeOfPay+"_amt_total_ip"
   val clm_total_paid_amt_total_ip = naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                               ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull)  &&
                              $"in_exchange".equalTo("IN"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(col(paid_col)).alias(total_ip)).withColumn(total_ip,col(total_ip).cast(IntegerType))
  val total_sgp = "clm_total_"+typeOfPay+"_amt_total_sgp" 
  val clm_total_paid_amt_total_sgp = naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                               ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull)  &&
                              $"in_exchange".equalTo("IN"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR",  col(paid_col)).agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(col(paid_col)).alias(total_sgp)).withColumn(total_sgp,col(total_sgp).cast(IntegerType))
   
   
   val ipSgp=  clm_total_paid_amt_total_ip.alias("parent").join(clm_total_paid_amt_total_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col(total_ip), col(total_sgp))
                                            
     val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", total_ip ,total_sgp) 
     val total_cat = "clm_total_"+typeOfPay+"_amt_catastrophic"                      
     val clm_total_paid_amt_catastrophic  = naic2018_mcas_hlthex_clmPhmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") && 
                                     $"in_exchange".equalTo("IN"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(col(paid_col)).alias(total_cat)).withColumn(total_cat,col(total_cat).cast(IntegerType))                      
                           
     val ipSgpcat=  ipSgpData.alias("parent").join(clm_total_paid_amt_catastrophic.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col(total_ip), col(total_sgp), col(total_cat))
                                            
     val ipSgpcatData = ipSgpcat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", total_ip ,total_sgp, total_cat)   
                           
       val total_ms_ip = "clm_total_"+typeOfPay+"_amt_total_ms_ip"                     
      val clm_total_paid_amt_total_ms_ip   =  naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") && 
                              $"src_exchng_certfn_cd".equalTo("M") &&
                              $"in_exchange".equalTo("IN"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange",$"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(col(paid_col)).alias(total_ms_ip)).withColumn(total_ms_ip,col(total_ms_ip).cast(IntegerType))
                           
       val ipSgpcatmsIp=  ipSgpcatData.alias("parent").join(clm_total_paid_amt_total_ms_ip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col(total_ip), col(total_sgp), col(total_cat), col(total_ms_ip))
                                            
     val ipSgpcatmsIpData = ipSgpcatmsIp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange",total_ip ,total_sgp, total_cat, total_ms_ip)                         
      val total_ms_sgp = "clm_total_"+typeOfPay+"_amt_total_ms_sgp"                  
      val clm_total_paid_amt_total_ms_sgp   =  naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") && 
                              $"src_exchng_certfn_cd".equalTo("M") &&
                              $"in_exchange".equalTo("IN"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange",$"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
                          .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(col(paid_col)).alias(total_ms_sgp)).withColumn(total_ms_sgp,col(total_ms_sgp).cast(IntegerType))
                                  
       val ipSgpcatmsIpmsSgp=  ipSgpcatmsIpData.alias("parent").join(clm_total_paid_amt_total_ms_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),
           $"child.in_exchange".alias("s_inx"),col(total_ip), col(total_sgp), col(total_cat), col(total_ms_ip),
           col(total_ms_sgp))
                                            
     val clmPaidData = ipSgpcatmsIpmsSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "in_exchange", total_ip ,total_sgp, total_cat, total_ms_ip,
                              total_ms_sgp)                      
                           
    clmPaidData                  
   
   
 }
 def getStgdata(finalReceivedData:DataFrame,finalDeniedInntwk:DataFrame,finalDeniedOutntwk:DataFrame,finalPaidInntwk:DataFrame,finalPaidOutntwk:DataFrame,finalPay:DataFrame,
        finalCPay:DataFrame,finalCoinSrcPay:DataFrame,finalddctblPay:DataFrame):DataFrame={
   
   val rec_denied = finalReceivedData.alias("parent").join(finalDeniedInntwk.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_total_ms_ip"),
           col("nbrclm_received_total_ms_sgp"),col("nbrclm_denied_inntwk_total_ip"),col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_total_ms_ip"),
           col("nbrclm_denied_inntwk_total_ms_sgp"),col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_total_ms_ip"),
           col("nbrclm_denied_inntwk_total_ms_sgp"))
           
   val rdData = rec_denied.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                            .select("in_exchange","health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_total_ms_ip",
                               "nbrclm_received_total_ms_sgp","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_total_ms_ip", "nbrclm_denied_inntwk_total_ms_sgp") 
   
   val deniedOut_master=rdData.alias("parent").join(finalDeniedOutntwk.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),$"child.in_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_total_ms_ip"),
           col("nbrclm_received_total_ms_sgp"),col("nbrclm_denied_inntwk_total_ip"),col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_total_ms_ip"),
           col("nbrclm_denied_inntwk_total_ms_sgp"),col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_total_ms_ip"),
           col("nbrclm_denied_inntwk_total_ms_sgp"),col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_total_ms_ip"),
           col("nbrclm_denied_outntwk_total_ms_sgp"))//nbrclm_denied_inntwk_total_ms_sgp nbrclm_denied_outntwk_total_ms_ip
           
           
 val deniedOut_data = deniedOut_master.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                            .select("in_exchange","health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_total_ms_ip",
                               "nbrclm_received_total_ms_sgp","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_total_ms_ip","nbrclm_denied_inntwk_total_ms_sgp",
                               "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic","nbrclm_denied_outntwk_total_ms_ip", "nbrclm_denied_outntwk_total_ms_sgp")//nbrclm_denied_outntwk_total_ip
                               
  val paidIn_Master=deniedOut_data.alias("parent").join(finalPaidInntwk.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),$"child.in_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_total_ms_ip"),
           col("nbrclm_received_total_ms_sgp"),col("nbrclm_denied_inntwk_total_ip"),col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_total_ms_ip"),
           col("nbrclm_denied_inntwk_total_ms_sgp"),col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_total_ms_ip"),
           col("nbrclm_denied_outntwk_total_ms_sgp"),col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_total_ms_ip"),
           col("nbrclm_paid_inntwk_total_ms_sgp"))
           
 val paidIn_Data = paidIn_Master.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                            .select("in_exchange","health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_total_ms_ip",
                               "nbrclm_received_total_ms_sgp","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_total_ms_ip","nbrclm_denied_inntwk_total_ms_sgp",
                               "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_total_ms_ip","nbrclm_denied_outntwk_total_ms_sgp",
                               "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_total_ms_ip","nbrclm_paid_inntwk_total_ms_sgp")
                               
                               
  val paidOut_Master =paidIn_Data.alias("parent").join(finalPaidOutntwk.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),$"child.in_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_total_ms_ip"),
           col("nbrclm_received_total_ms_sgp"),col("nbrclm_denied_inntwk_total_ip"),col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_total_ms_ip"),
           col("nbrclm_denied_inntwk_total_ms_sgp"),col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_total_ms_ip"),
           col("nbrclm_denied_outntwk_total_ms_sgp"),col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_total_ms_ip"),
           col("nbrclm_paid_inntwk_total_ms_sgp"),col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_total_ms_ip"),
           col("nbrclm_paid_outntwk_total_ms_sgp"))//nbrclm_paid_inntwk_total_ms_sgp
 val paidOut_Data = paidOut_Master.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                            .select("in_exchange","health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_total_ms_ip",
                               "nbrclm_received_total_ms_sgp","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_total_ms_ip","nbrclm_denied_inntwk_total_ms_sgp",
                               "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_total_ms_ip","nbrclm_denied_outntwk_total_ms_sgp",
                               "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_total_ms_ip","nbrclm_paid_inntwk_total_ms_sgp",//nbrclm_paid_outntwk_total_ms_ip
                               "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_total_ms_ip","nbrclm_paid_outntwk_total_ms_sgp")
                                                    
  val pay_Master =paidOut_Data.alias("parent").join(finalPay.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),$"child.in_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_total_ms_ip"),
           col("nbrclm_received_total_ms_sgp"),col("nbrclm_denied_inntwk_total_ip"),col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_total_ms_ip"),
           col("nbrclm_denied_inntwk_total_ms_sgp"),col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_total_ms_ip"),
           col("nbrclm_denied_outntwk_total_ms_sgp"),col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_total_ms_ip"),
           col("nbrclm_paid_inntwk_total_ms_sgp"),col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_total_ms_ip"),
           col("nbrclm_paid_outntwk_total_ms_sgp"),col("clm_total_paid_amt_total_ip"),col("clm_total_paid_amt_total_sgp"),col("clm_total_paid_amt_catastrophic"),col("clm_total_paid_amt_total_ms_ip"),col("clm_total_paid_amt_total_ms_sgp")) 
   
  val pay_Data = pay_Master.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                            .select("in_exchange","health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_total_ms_ip",
                                "nbrclm_received_total_ms_sgp","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_total_ms_ip","nbrclm_denied_inntwk_total_ms_sgp",
                               "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_total_ms_ip","nbrclm_denied_outntwk_total_ms_sgp",
                               "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_total_ms_ip","nbrclm_paid_inntwk_total_ms_sgp",
                               "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_total_ms_ip","nbrclm_paid_outntwk_total_ms_sgp",
                               "clm_total_paid_amt_total_ip","clm_total_paid_amt_total_sgp","clm_total_paid_amt_catastrophic","clm_total_paid_amt_total_ms_ip","clm_total_paid_amt_total_ms_sgp")
                               
 val coPay_Master =pay_Data.alias("parent").join(finalCPay.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),$"child.in_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_total_ms_ip"),
           col("nbrclm_received_total_ms_sgp"),col("nbrclm_denied_inntwk_total_ip"),col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_total_ms_ip"),
           col("nbrclm_denied_inntwk_total_ms_sgp"),col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_total_ms_ip"),
           col("nbrclm_denied_outntwk_total_ms_sgp"),col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_total_ms_ip"),
           col("nbrclm_paid_inntwk_total_ms_sgp"),col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_total_ms_ip"),
           col("nbrclm_paid_outntwk_total_ms_sgp"),col("clm_total_paid_amt_total_ip"),col("clm_total_paid_amt_total_sgp"),col("clm_total_paid_amt_catastrophic"),col("clm_total_paid_amt_total_ms_ip"),col("clm_total_paid_amt_total_ms_sgp"),
           col("clm_total_copay_amt_total_ip"),col("clm_total_copay_amt_total_sgp"),col("clm_total_copay_amt_catastrophic"),col("clm_total_copay_amt_total_ms_ip"),col("clm_total_copay_amt_total_ms_sgp"))
           
val cpay_Data = coPay_Master.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                            .select("in_exchange","health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_total_ms_ip",
                               "nbrclm_received_total_ms_sgp","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_total_ms_ip","nbrclm_denied_inntwk_total_ms_sgp",
                               "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_total_ms_ip","nbrclm_denied_outntwk_total_ms_sgp",
                               "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_total_ms_ip","nbrclm_paid_inntwk_total_ms_sgp",
                               "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_total_ms_ip","nbrclm_paid_outntwk_total_ms_sgp",
                               "clm_total_paid_amt_total_ip","clm_total_paid_amt_total_sgp","clm_total_paid_amt_catastrophic","clm_total_paid_amt_total_ms_ip","clm_total_paid_amt_total_ms_sgp",
                               "clm_total_copay_amt_total_ip",	"clm_total_copay_amt_total_sgp","clm_total_copay_amt_catastrophic","clm_total_copay_amt_total_ms_ip","clm_total_copay_amt_total_ms_sgp")
                                  
                                    
  val coinSrc_Master =  cpay_Data.alias("parent").join(finalCoinSrcPay.alias("child"),  $"parent.health_year"===$"child.health_year" &&
                   $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),$"child.in_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_total_ms_ip"),
           col("nbrclm_received_total_ms_sgp"),col("nbrclm_denied_inntwk_total_ip"),col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_total_ms_ip"),
           col("nbrclm_denied_inntwk_total_ms_sgp"),col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_total_ms_ip"),
           col("nbrclm_denied_outntwk_total_ms_sgp"),col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_total_ms_ip"),
           col("nbrclm_paid_inntwk_total_ms_sgp"),col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_total_ms_ip"),
           col("nbrclm_paid_outntwk_total_ms_sgp"),col("clm_total_paid_amt_total_ip"),col("clm_total_paid_amt_total_sgp"),col("clm_total_paid_amt_catastrophic"),col("clm_total_paid_amt_total_ms_ip"),col("clm_total_paid_amt_total_ms_sgp"),
           col("clm_total_copay_amt_total_ip"),col("clm_total_copay_amt_total_sgp"),col("clm_total_copay_amt_catastrophic"),col("clm_total_copay_amt_total_ms_ip"),col("clm_total_copay_amt_total_ms_sgp"),
           col("clm_total_coinsrn_amt_total_ip"),	col("clm_total_coinsrn_amt_total_sgp"),col("clm_total_coinsrn_amt_catastrophic"),col("clm_total_coinsrn_amt_total_ms_ip"),col("clm_total_coinsrn_amt_total_ms_sgp"))
           
 val coinSrc_Data = coinSrc_Master.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                            .select("in_exchange","health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_total_ms_ip",
                                "nbrclm_received_total_ms_sgp","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_total_ms_ip","nbrclm_denied_inntwk_total_ms_sgp",
                               "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_total_ms_ip","nbrclm_denied_outntwk_total_ms_sgp",
                               "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_total_ms_ip","nbrclm_paid_inntwk_total_ms_sgp",
                               "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_total_ms_ip","nbrclm_paid_outntwk_total_ms_sgp",
                               "clm_total_paid_amt_total_ip","clm_total_paid_amt_total_sgp","clm_total_paid_amt_catastrophic","clm_total_paid_amt_total_ms_ip","clm_total_paid_amt_total_ms_sgp",
                               "clm_total_copay_amt_total_ip",	"clm_total_copay_amt_total_sgp","clm_total_copay_amt_catastrophic","clm_total_copay_amt_total_ms_ip","clm_total_copay_amt_total_ms_sgp",
                               "clm_total_coinsrn_amt_total_ip",	"clm_total_coinsrn_amt_total_sgp","clm_total_coinsrn_amt_catastrophic","clm_total_coinsrn_amt_total_ms_ip","clm_total_coinsrn_amt_total_ms_sgp")
                               
  val ddcTbl_Master =  coinSrc_Data.alias("parent").join(finalddctblPay.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange"===$"child.in_exchange", "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , $"parent.in_exchange".alias("b_inx"),$"child.in_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_total_ms_ip"),
           col("nbrclm_received_total_ms_sgp"),col("nbrclm_denied_inntwk_total_ip"),col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_total_ms_ip"),
           col("nbrclm_denied_inntwk_total_ms_sgp"),col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_total_ms_ip"),
           col("nbrclm_denied_outntwk_total_ms_sgp"),col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_total_ms_ip"),
           col("nbrclm_paid_inntwk_total_ms_sgp"),col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_total_ms_ip"),
           col("nbrclm_paid_outntwk_total_ms_sgp"),col("clm_total_paid_amt_total_ip"),col("clm_total_paid_amt_total_sgp"),col("clm_total_paid_amt_catastrophic"),col("clm_total_paid_amt_total_ms_ip"),col("clm_total_paid_amt_total_ms_sgp"),
           col("clm_total_copay_amt_total_ip"),col("clm_total_copay_amt_total_sgp"),col("clm_total_copay_amt_catastrophic"),col("clm_total_copay_amt_total_ms_ip"),col("clm_total_copay_amt_total_ms_sgp"),
           col("clm_total_coinsrn_amt_total_ip"),	col("clm_total_coinsrn_amt_total_sgp"),col("clm_total_coinsrn_amt_catastrophic"),col("clm_total_coinsrn_amt_total_ms_ip"),col("clm_total_coinsrn_amt_total_ms_sgp"),
           col("clm_total_ddctbl_amt_total_ip"),	col("clm_total_ddctbl_amt_total_sgp"),col("clm_total_ddctbl_amt_catastrophic"),col("clm_total_ddctbl_amt_total_ms_ip"),col("clm_total_ddctbl_amt_total_ms_sgp"))
val ddcTbl_Data = ddcTbl_Master.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) //
                            .select("in_exchange","health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_total_ms_ip",
                                "nbrclm_received_total_ms_sgp","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_total_ms_ip","nbrclm_denied_inntwk_total_ms_sgp",
                               "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_total_ms_ip","nbrclm_denied_outntwk_total_ms_sgp",
                               "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_total_ms_ip","nbrclm_paid_inntwk_total_ms_sgp",
                               "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_total_ms_ip","nbrclm_paid_outntwk_total_ms_sgp",
                               "clm_total_paid_amt_total_ip","clm_total_paid_amt_total_sgp","clm_total_paid_amt_catastrophic","clm_total_paid_amt_total_ms_ip","clm_total_paid_amt_total_ms_sgp",
                               "clm_total_copay_amt_total_ip",	"clm_total_copay_amt_total_sgp","clm_total_copay_amt_catastrophic","clm_total_copay_amt_total_ms_ip","clm_total_copay_amt_total_ms_sgp",
                               "clm_total_coinsrn_amt_total_ip",	"clm_total_coinsrn_amt_total_sgp","clm_total_coinsrn_amt_catastrophic","clm_total_coinsrn_amt_total_ms_ip","clm_total_coinsrn_amt_total_ms_sgp",
                               "clm_total_ddctbl_amt_total_ip",	"clm_total_ddctbl_amt_total_sgp","clm_total_ddctbl_amt_catastrophic","clm_total_ddctbl_amt_total_ms_ip","clm_total_ddctbl_amt_total_ms_sgp")
                               
                                            
   ddcTbl_Data
   
 }
 
}

object PCADX_SCL_NAIC2018_IEXStgTransformationclmPhmcy{
  def main(args: Array[String]) {
  PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
  val iex =  new PCADX_SCL_NAIC2018_IEXStgTransformationclmPhmcy()
  //iex.setyear(args(1))
  iex.sparkInIt()
  }
}




