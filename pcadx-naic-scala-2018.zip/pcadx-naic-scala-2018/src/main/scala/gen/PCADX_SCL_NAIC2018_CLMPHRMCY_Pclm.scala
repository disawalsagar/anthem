package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator

import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit

import org.apache.hadoop.fs._;
class PCADX_SCL_NAIC2018_CLMPHRMCY_Pclm{
	val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
			config("hive.exec.dynamic.partition.mode", "nonstrict").
			config("spark.sql.parquet.compression.codec", "snappy").
			config("hive.warehouse.data.skipTrash", "true").
			config("spark.sql.parquet.writeLegacyFormat", "true").
			enableHiveSupport().getOrCreate()
			import spark.implicits._
			val dbProperties = new Properties
			dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
			var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_CLMPHRMCY_Pclm])
			val dbWrk = dbProperties.getProperty("work.db")
			val dbInbnd = dbProperties.getProperty("inbound.db")
			val clmRcvdStrtDt = dbProperties.getProperty("CLM_RCVD_DT_STRT")
			val clmRcvdEndDt = dbProperties.getProperty("CLM_RCVD_DT_END")
			val wrhDb = dbProperties.getProperty("warehouse.db")
			val audit_log_df = spark.sql("select * from "+wrhDb+".audt_load_log") 
			val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString() 
			println("load_log_key : "+load_log_key)
			val reportYear =dbProperties.getProperty("report.year")

			def naic_mcas_pclm_wrk_Trunc() = """Truncate table """+dbWrk+""".naic2018_mcas_pclm_wrk"""

			def naic_mcas_pclm_wrk() = """Insert into table """+dbWrk+""".naic2018_mcas_pclm_wrk"""+"""
					select * from              
					( 
					SELECT 
					"""+reportYear+"""  as health_year,
					C.CLM_ADJSTMNT_KEY       AS   CLM_ADJSTMNT_KEY  ,
					CL.CLM_LINE_NBR           AS    CLM_LINE_NBR    ,
					C.CLM_SOR_CD             AS    CLM_SOR_CD       ,
					C.MBR_KEY                     AS   MBR_KEY     ,
					C.MBRSHP_SOR_CD           AS     MBRSHP_SOR_CD   ,
					C.PRMPT_PAY_CLM_RCVD_DT   AS      PRMPT_PAY_CLM_RCVD_DT  , 
					C.CLM_RCVD_DT                    AS  CLM_RCVD_DT  ,
					C.ADJDCTN_STTS_CD         AS   ADJDCTN_STTS_CD ,
					C.RPTG_CLM_ADJDCTN_STTS_CD  AS  RPTG_CLM_ADJDCTN_STTS_CD,
					C.CLM_DISP_CD                 AS  CLM_DISP_CD ,
					-- 09/17
					--C.ADJDCTN_DT                 AS   ADJDCTN_DT ,
					CASE  
					WHEN   C.ADJDCTN_DT < C.CLM_RCVD_DT     THEN  C.CLM_RCVD_DT 
					ELSE  C.ADJDCTN_DT
					END  AS      ADJDCTN_DT  ,  
					C.SRVC_RNDRG_TYPE_CD       AS   SRVC_RNDRG_TYPE_CD ,
					C.SRC_BILLG_TAX_ID  AS SRC_BILLG_TAX_ID,
					--CP.GL_POST_DT               AS   GL_POST_DT  ,
					CASE  
					WHEN   CP.GL_POST_DT  <  C.CLM_RCVD_DT    THEN  C.CLM_RCVD_DT 
					ELSE  CP.GL_POST_DT
					END  AS       GL_POST_DT  , 
					CL.BNFT_PKG_ID               AS      BNFT_PKG_ID  ,
					CL.INN_CD                          AS   INN_CD  ,
					CL.CLM_LINE_STTS_CD        AS    CLM_LINE_STTS_CD  ,
					CL.RPTG_CLM_LINE_ADJDCTN_STTS_CD  AS  RPTG_CLM_LINE_ADJDCTN_STTS_CD,
					CL.BNFT_PAYMNT_STTS_CD           AS   BNFT_PAYMNT_STTS_CD ,
					CL.PAID_AMT                    AS    PAID_AMT  ,
					CL.CPAY_AMT                    AS   CPAY_AMT  ,
					CL.COINSRN_AMT                 AS    COINSRN_AMT  ,
					CL.DDCTBL_AMT                 AS  DDCTBL_AMT ,
					CL.SRC_SRVC_DNL_RSN_CD         AS  SRC_SRVC_DNL_RSN_CD  ,
					C.CLM_NBR    AS  CLM_NBR  ,
					C.RX_FILLED_DT AS RX_FILLED_DT ,
					C.NDC      AS NDC ,
					C.RX_NBR    AS RX_NBR ,
					CL.SRC_GRP_NBR AS SRC_GRP_NBR,
					CL.CLM_LINE_SRVC_STRT_DT AS CLM_LINE_SRVC_STRT_DT,
					"""+load_log_key+""",
					current_timestamp
					FROM """+dbInbnd+""".CLM C
					INNER JOIN """+dbInbnd+""".CLM_LINE CL
					ON C.CLM_ADJSTMNT_KEY=CL.CLM_ADJSTMNT_KEY
					AND C.ADJDCTN_DT =CL.ADJDCTN_DT
					LEFT OUTER JOIN """+dbInbnd+""".CLM_MAX_RVSN CMR         
					ON C.CLM_ADJSTMNT_KEY=CMR.CLM_ADJSTMNT_KEY
					LEFT OUTER JOIN """+dbInbnd+""".CLM_PAID CP
					ON C.CLM_ADJSTMNT_KEY=CP.CLM_ADJSTMNT_KEY

					WHERE  C.SRVC_RNDRG_TYPE_CD =  'PHMCY'      
					AND C.CLM_DISP_CD NOT IN ('VOID','RVRSL') 
					AND C.RPTG_CLM_ADJDCTN_STTS_CD NOT IN ('03','10','04','11')
					AND  CL.RPTG_CLM_LINE_ADJDCTN_STTS_CD NOT IN  ('VOID')
					--AND ( C.CLM_RCVD_DT BETWEEN  """+clmRcvdStrtDt+"""  AND   """+clmRcvdEndDt+""" )

					--added 09/17
					AND  ( ( C.CLM_RCVD_DT BETWEEN  """+clmRcvdStrtDt+"""  AND   """+clmRcvdEndDt+""" )
					OR ( C.ADJDCTN_DT  BETWEEN  """+clmRcvdStrtDt+"""  AND   """+clmRcvdEndDt+""" ) 
					OR ( CP.GL_POST_DT  BETWEEN  """+clmRcvdStrtDt+"""  AND   """+clmRcvdEndDt+"""  )
					) 

					GROUP BY  
					C.CLM_ADJSTMNT_KEY       ,
					CL.CLM_LINE_NBR            ,
					C.CLM_SOR_CD               ,
					C.MBR_KEY                         ,
					C.MBRSHP_SOR_CD              ,
					C.PRMPT_PAY_CLM_RCVD_DT   , 
					C.CLM_RCVD_DT                      ,
					C.ADJDCTN_STTS_CD         ,
					C.RPTG_CLM_ADJDCTN_STTS_CD,
					C.CLM_DISP_CD                  ,
					C.ADJDCTN_DT                  ,
					C.SRVC_RNDRG_TYPE_CD        ,
					C.SRC_BILLG_TAX_ID,
					CL.BNFT_PKG_ID                 ,
					CP.GL_POST_DT                ,
					CL.INN_CD                            ,
					CL.CLM_LINE_STTS_CD          ,
					CL.RPTG_CLM_LINE_ADJDCTN_STTS_CD  ,
					CL.BNFT_PAYMNT_STTS_CD         ,
					CL.PAID_AMT                   ,
					CL.CPAY_AMT                   ,
					CL.COINSRN_AMT                ,
					CL.DDCTBL_AMT               ,
					CL.SRC_SRVC_DNL_RSN_CD        ,
					C.CLM_NBR      ,
					C.RX_FILLED_DT  ,
					C.NDC       ,
					C.RX_NBR     ,
					CL.SRC_GRP_NBR,
					CL.CLM_LINE_SRVC_STRT_DT
					)"""

def naic_mcas_pclm_wrk_1() = """Insert into table """+dbWrk+""".naic2018_mcas_pclm_wrk"""+
							"""

SELECT 
"""+reportYear+"""  as health_year,
A.CLM_ADJSTMNT_KEY       AS   CLM_ADJSTMNT_KEY  ,
A.CLM_LINE_NBR           AS    CLM_LINE_NBR    ,
A.CLM_SOR_CD             AS    CLM_SOR_CD       ,
A.MBR_KEY                     AS   MBR_KEY     ,
A.MBRSHP_SOR_CD           AS     MBRSHP_SOR_CD   ,
A.PRMPT_PAY_CLM_RCVD_DT     AS      PRMPT_PAY_CLM_RCVD_DT  , 
A.CLM_RCVD_DT                    AS  CLM_RCVD_DT  ,
A.ADJDCTN_STTS_CD         AS   ADJDCTN_STTS_CD ,
A.RPTG_CLM_ADJDCTN_STTS_CD  AS  RPTG_CLM_ADJDCTN_STTS_CD,
A.CLM_DISP_CD                 AS  CLM_DISP_CD ,
CASE  
WHEN   A.ADJDCTN_DT < A.PRMPT_PAY_CLM_RCVD_DT    THEN  A.PRMPT_PAY_CLM_RCVD_DT
ELSE  A.ADJDCTN_DT
END  AS      ADJDCTN_DT  , 
A.SRVC_RNDRG_TYPE_CD       AS   SRVC_RNDRG_TYPE_CD ,
A.SRC_BILLG_TAX_ID     AS   SRC_BILLG_TAX_ID   ,
CASE  
WHEN   A.GL_POST_DT < A.PRMPT_PAY_CLM_RCVD_DT    THEN  A.PRMPT_PAY_CLM_RCVD_DT
ELSE  A.GL_POST_DT
END  AS       GL_POST_DT  ,
A.BNFT_PKG_ID               AS      BNFT_PKG_ID  ,
A.INN_CD                          AS   INN_CD  ,
A.CLM_LINE_STTS_CD        AS    CLM_LINE_STTS_CD  ,
A.RPTG_CLM_LINE_ADJDCTN_STTS_CD  AS  RPTG_CLM_LINE_ADJDCTN_STTS_CD,
A.BNFT_PAYMNT_STTS_CD           AS   BNFT_PAYMNT_STTS_CD ,
A.PAID_AMT                    AS    PAID_AMT  ,
A.CPAY_AMT                    AS   CPAY_AMT  ,
A.COINSRN_AMT                 AS    COINSRN_AMT  ,
A.DDCTBL_AMT                 AS  DDCTBL_AMT ,
A.SRC_SRVC_DNL_RSN_CD         AS  SRC_SRVC_DNL_RSN_CD  ,
A.CLM_NBR    AS  CLM_NBR  ,
A.RX_FILLED_DT AS RX_FILLED_DT ,
A.NDC      AS NDC ,
A.RX_NBR    AS RX_NBR ,
A.SRC_GRP_NBR AS SRC_GRP_NBR ,
A.CLM_LINE_SRVC_STRT_DT AS CLM_LINE_SRVC_STRT_DT ,
"""+load_log_key+""",
current_timestamp

FROM
(

SELECT 
C.CLM_ADJSTMNT_KEY       AS   CLM_ADJSTMNT_KEY  ,
CL.CLM_LINE_NBR           AS    CLM_LINE_NBR    ,
C.CLM_SOR_CD             AS    CLM_SOR_CD       ,
C.MBR_KEY                     AS   MBR_KEY     ,
C.MBRSHP_SOR_CD           AS     MBRSHP_SOR_CD   ,
CASE  
WHEN  (C.PRMPT_PAY_CLM_RCVD_DT  = '1111-01-01 00:00:00.0' or  C.PRMPT_PAY_CLM_RCVD_DT  ='8888-12-31 00:00:00.0' ) THEN  C.CLM_RCVD_DT 
WHEN  CP.GL_POST_DT < C.PRMPT_PAY_CLM_RCVD_DT  OR C.ADJDCTN_DT < C.PRMPT_PAY_CLM_RCVD_DT    THEN  C.CLM_RCVD_DT
ELSE  C.PRMPT_PAY_CLM_RCVD_DT 
END  AS      PRMPT_PAY_CLM_RCVD_DT  , 
C.CLM_RCVD_DT                    AS  CLM_RCVD_DT  ,
C.ADJDCTN_STTS_CD         AS   ADJDCTN_STTS_CD ,
C.RPTG_CLM_ADJDCTN_STTS_CD  AS  RPTG_CLM_ADJDCTN_STTS_CD,
C.CLM_DISP_CD                 AS  CLM_DISP_CD ,
C.ADJDCTN_DT                 AS   ADJDCTN_DT ,
C.SRVC_RNDRG_TYPE_CD       AS   SRVC_RNDRG_TYPE_CD ,
CP.GL_POST_DT               AS   GL_POST_DT  ,
CL.BNFT_PKG_ID               AS      BNFT_PKG_ID  ,
CL.INN_CD                          AS   INN_CD  ,
CL.CLM_LINE_STTS_CD        AS    CLM_LINE_STTS_CD  ,
CL.RPTG_CLM_LINE_ADJDCTN_STTS_CD  AS  RPTG_CLM_LINE_ADJDCTN_STTS_CD,
CL.BNFT_PAYMNT_STTS_CD           AS   BNFT_PAYMNT_STTS_CD ,
CL.PAID_AMT                    AS    PAID_AMT  ,
CL.CPAY_AMT                    AS   CPAY_AMT  ,
CL.COINSRN_AMT                 AS    COINSRN_AMT  ,
CL.DDCTBL_AMT                 AS  DDCTBL_AMT ,
CL.SRC_SRVC_DNL_RSN_CD         AS  SRC_SRVC_DNL_RSN_CD  ,
C.CLM_NBR    AS  CLM_NBR  ,
C.RX_FILLED_DT AS RX_FILLED_DT ,
C.NDC      AS NDC ,
C.RX_NBR    AS RX_NBR ,
CL.SRC_GRP_NBR AS SRC_GRP_NBR ,
CL.CLM_LINE_SRVC_STRT_DT AS CLM_LINE_SRVC_STRT_DT ,
C.SRC_BILLG_TAX_ID

FROM """+dbInbnd+""".CLM C
INNER JOIN """+dbInbnd+""".CLM_MAX_RVSN CMR         
ON C.CLM_ADJSTMNT_KEY=CMR.CLM_ADJSTMNT_KEY

INNER JOIN """+dbInbnd+""".CLM_LINE CL
ON C.CLM_ADJSTMNT_KEY=CL.CLM_ADJSTMNT_KEY
AND C.ADJDCTN_DT =CL.ADJDCTN_DT

LEFT OUTER JOIN """+dbInbnd+""".CLM_PAID CP
ON C.CLM_ADJSTMNT_KEY=CP.CLM_ADJSTMNT_KEY

WHERE
C.SRC_BILLG_TAX_ID = '000000005'      
AND C.CLM_DISP_CD NOT IN ('VOID','RVRSL') 
AND C.RPTG_CLM_ADJDCTN_STTS_CD NOT IN ('03','10','04','11')
AND  CL.RPTG_CLM_LINE_ADJDCTN_STTS_CD NOT IN  ('VOID')
AND ( 
(C.PRMPT_PAY_CLM_RCVD_DT BETWEEN  """+clmRcvdStrtDt+"""  AND """+clmRcvdEndDt+""" )
OR ( C.PRMPT_PAY_CLM_RCVD_DT  = '1111-01-01 00:00:00.0' or  C.PRMPT_PAY_CLM_RCVD_DT  ='8888-12-31 00:00:00.0')
OR ( C.ADJDCTN_DT  BETWEEN  """+clmRcvdStrtDt+"""  AND """+clmRcvdEndDt+""" ) 
OR ( CP.GL_POST_DT  BETWEEN  """+clmRcvdStrtDt+"""  AND """+clmRcvdEndDt+""" ) 
)   



GROUP BY  
C.CLM_ADJSTMNT_KEY       ,
CL.CLM_LINE_NBR            ,
C.CLM_SOR_CD               ,
C.MBR_KEY                         ,
C.MBRSHP_SOR_CD              ,
C.PRMPT_PAY_CLM_RCVD_DT   , 
C.CLM_RCVD_DT                      ,
C.ADJDCTN_STTS_CD         ,
C.RPTG_CLM_ADJDCTN_STTS_CD,
C.CLM_DISP_CD                  ,
C.ADJDCTN_DT                  ,
C.SRVC_RNDRG_TYPE_CD        ,
C.SRC_BILLG_TAX_ID ,
CL.BNFT_PKG_ID                 ,
CP.GL_POST_DT                ,
CL.INN_CD                            ,
CL.CLM_LINE_STTS_CD          ,
CL.RPTG_CLM_LINE_ADJDCTN_STTS_CD  ,
CL.BNFT_PAYMNT_STTS_CD         ,
CL.PAID_AMT                   ,
CL.CPAY_AMT                   ,
CL.COINSRN_AMT                ,
CL.DDCTBL_AMT               ,
CL.SRC_SRVC_DNL_RSN_CD        ,
C.CLM_NBR      ,
C.RX_FILLED_DT  ,
C.NDC       ,
C.RX_NBR     ,
CL.SRC_GRP_NBR ,
CL.CLM_LINE_SRVC_STRT_DT 


) A



"""
def sparkInIt(){
				spark.sql(naic_mcas_pclm_wrk_Trunc())
				spark.sql(naic_mcas_pclm_wrk())
				spark.sql(naic_mcas_pclm_wrk_1())
				//println(naic_mcas_pclm_wrk())
				spark.close()
			}
}
object PCADX_SCL_NAIC2018_CLMPHRMCY_Pclm{
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val clmPhmy = new PCADX_SCL_NAIC2018_CLMPHRMCY_Pclm()
		clmPhmy.sparkInIt()
	}


}