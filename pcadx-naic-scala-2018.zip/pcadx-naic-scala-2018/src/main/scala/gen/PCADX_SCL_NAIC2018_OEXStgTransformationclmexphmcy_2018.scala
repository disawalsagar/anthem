package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_2018(val spark: SparkSession) {

  val clmexphmcy = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy(spark)
  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clmex")
  val end_year = dbProperties.getProperty("end_year_clmex")
  val mbu_cf_cdvals = dbProperties.getProperty("mbu_Cf_cdVals").split(",").toSeq
  import spark.implicits._

  def joinedDfbhebhIn(type_of_data: String,naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame,
               naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame,naic2018_mcas_nmn_eob_cd_inbnd: DataFrame,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
               naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame):
               DataFrame = {



					val joined_df = naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.alias("received_wrk").join(naic2018_mcas_nmn_src_eob_cd_inbnd.alias("sec"),
							$"received_wrk.src_eob_cd" === $"sec.src_eob_cd" &&
							$"received_wrk.clm_sor_cd" === $"sec.clm_sor_cd","leftouter")
							.join(naic2018_mcas_nmn_eob_cd_inbnd.alias("chip"),
									$"received_wrk.eob_cd" === $"chip.eob_cd" &&    
									$"received_wrk.clm_sor_cd" === $"chip.clm_sor_cd","leftouter")
							.join(naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd.alias("aces"),
									$"received_wrk.src_clm_line_disp_rsn_cd" === $"aces.src_clm_line_disp_rsn_cd" &&
									$"received_wrk.clm_sor_cd" === $"aces.clm_sor_cd","leftouter")
							.join(naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc1"),
									$"received_wrk.diag_1_cd" === $"idc1.icd_diag_cd","leftouter")
/*							.join(naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc2"),
									$"received_wrk.diag_2_cd" === $"idc2.icd_diag_cd","leftouter")
							.join(naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc3"),
									$"received_wrk.diag_3_cd" === $"idc3.icd_diag_cd","leftouter")
							.join(naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc4"),
									$"received_wrk.diag_4_cd" === $"idc4.icd_diag_cd","leftouter")
							.join(naic2018_mcas_nmnbh_icd_proc_cd_inbnd.alias("ipc"),
									$"received_wrk.icd_proc_cd" === $"ipc.icd_proc_cd","leftouter")
							.join(naic2018_mcas_nmnbh_hlth_srvc_cd_inbnd.alias("hsc"),
									$"received_wrk.hlth_srvc_cd" === $"hsc.hlth_srvc_cd","leftouter")*/

							var filteredjoineddf : DataFrame = null

							if ( type_of_data == "ebh")

							{

								filteredjoineddf = joined_df.filter(((!$"sec.src_eob_cd".isNull && !$"sec.clm_sor_cd".isNull) || 
								                                     (!$"chip.eob_cd".isNull  && !$"chip.clm_sor_cd".isNull) || 
								                                     (!$"aces.src_clm_line_disp_rsn_cd".isNull && !$"aces.clm_sor_cd".isNull)) &&
								                                     ($"idc1.icd_diag_cd".isNull))
								                                      /*&& $"idc2.icd_diag_cd".isNull && $"idc3.icd_diag_cd".isNull   && 
								                                      $"idc4.icd_diag_cd".isNull) && ($"ipc.icd_proc_cd".isNull) && ($"hsc.hlth_srvc_cd".isNull)))*/
							}

							else 
							{

								filteredjoineddf = joined_df.filter(((!$"sec.src_eob_cd".isNull && !$"sec.clm_sor_cd".isNull) || 
								                                      (!$"chip.eob_cd".isNull && !$"chip.clm_sor_cd".isNull) ||
									  	                                (!$"aces.src_clm_line_disp_rsn_cd".isNull && !$"aces.clm_sor_cd".isNull)) &&
										                                  (!$"idc1.icd_diag_cd".isNull ))
										                        /*|| !$"idc2.icd_diag_cd".isNull || !$"idc3.icd_diag_cd".isNull || !$"idc4.icd_diag_cd".isNull) ||
												                     (!$"ipc.icd_proc_cd".isNull ) || (!$"hsc.hlth_srvc_cd".isNull)))*/
							}

							filteredjoineddf  
			}
    

  
def joinedDf_typeOfData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame,
    naic2018_mcas_ce_src_eob_cd_inbnd: DataFrame,naic2018_mcas_ce_eob_cd_inbnd: DataFrame,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
    naic2018_mcas_pa_src_eob_cd_inbnd: DataFrame,naic2018_mcas_pa_eob_cd_inbnd: DataFrame,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
    naic2018_mcas_ncb_src_eob_cd_inbnd:DataFrame,naic2018_mcas_ncb_eob_cd_inbnd: DataFrame,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
    type_of_data :String):DataFrame={
    
  //println(type_of_data)
  var src_eob_cd_inbnd:DataFrame = null
  var eob_cd_inbnd:DataFrame = null
  var clm_line_disp : DataFrame = null
    
    if (type_of_data == ("ce")){   
     src_eob_cd_inbnd =naic2018_mcas_ce_src_eob_cd_inbnd
     eob_cd_inbnd=naic2018_mcas_ce_eob_cd_inbnd
     clm_line_disp=naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd
    }
    else if (type_of_data == ("pa")){
     src_eob_cd_inbnd=naic2018_mcas_pa_src_eob_cd_inbnd
    eob_cd_inbnd=naic2018_mcas_pa_eob_cd_inbnd
    clm_line_disp=naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd
    }
    else {
    src_eob_cd_inbnd=naic2018_mcas_ncb_src_eob_cd_inbnd
    eob_cd_inbnd=naic2018_mcas_ncb_eob_cd_inbnd
    clm_line_disp=naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd
    }

 val joined_df=naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.alias("received_wrk")
      .join(
          src_eob_cd_inbnd.alias("sec"),
          $"received_wrk.src_eob_cd" === $"sec.src_eob_cd" &&
          $"received_wrk.clm_sor_cd" === $"sec.clm_sor_cd", "left_outer")
      .join(
          eob_cd_inbnd.alias("chip"),
          $"received_wrk.eob_cd" === $"chip.eob_cd" &&
          $"received_wrk.clm_sor_cd" === $"chip.clm_sor_cd", "left_outer")
      .join(
         clm_line_disp.alias("aces"),
         $"received_wrk.src_clm_line_disp_rsn_cd" === $"aces.src_clm_line_disp_rsn_cd" &&
         $"received_wrk.clm_sor_cd" === $"aces.clm_sor_cd", "left_outer")
      .filter(((!$"sec.src_eob_cd".isNull) && (!$"sec.clm_sor_cd".isNull)) ||
         ((!$"chip.eob_cd".isNull) && (!$"chip.clm_sor_cd".isNull)) ||
         (!$"aces.src_clm_line_disp_rsn_cd".isNull) && (!$"aces.clm_sor_cd".isNull))
   
  //joined_df.limit(20).show()           
    joined_df
    }

def getDeniedInntwk_typeOfData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, 
                  naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
                  naic2018_mcas_ce_src_eob_cd_inbnd: DataFrame, naic2018_mcas_ce_eob_cd_inbnd: DataFrame,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
                  naic2018_mcas_pa_src_eob_cd_inbnd: DataFrame, naic2018_mcas_pa_eob_cd_inbnd: DataFrame,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
                  naic2018_mcas_ncb_src_eob_cd_inbnd: DataFrame,naic2018_mcas_ncb_eob_cd_inbnd:DataFrame,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
                  type_of_data:String): DataFrame={
    
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)
    
    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
                                  $"inn_cd".isin(clminn_cd: _*) &&
                                  $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                  $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_brz = joinedDf_typeOfData(received_brnz,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_inntwk_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                         .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"))
   
    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
                                   $"inn_cd".isin(clminn_cd: _*) &&
                                   $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                   $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sil = joinedDf_typeOfData(received_silver,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_inntwk_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                            .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"))
                                            
    val BrzSilMaster = nbrclm_denied_inntwk_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
              && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
              .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
               $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
               $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip")
    
   val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
                              $"inn_cd".isin(clminn_cd: _*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                              $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gld = joinedDf_typeOfData(received_gold,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_inntwk_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                       .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                    $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
                              $"inn_cd".isin(clminn_cd: _*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                              $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_plt = joinedDf_typeOfData(received_platinum,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_inntwk_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                           .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                    $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip")

    val tot_ip =  nbrclm_denied_inntwk_bronze_ip.union(nbrclm_denied_inntwk_silver_ip.union(nbrclm_denied_inntwk_gold_ip.union(nbrclm_denied_inntwk_platinum_ip)))
                   .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"))
   
    val nbrclm_denied_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip").alias("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"),
                      col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                          .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                          .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                          .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip")                        
   
                          
    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)  
    
    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
                                    $"inn_cd".isin(clminn_cd: _*) &&
                                    $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                    $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_brz = joinedDf_typeOfData(received_sgp_bronze,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)
   
    val nbrclm_denied_inntwk_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                          .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                         $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                         $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                            .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                            .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                            .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                            "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp")    
                           
    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
                              $"inn_cd".isin(clminn_cd: _*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                              $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_sil = joinedDf_typeOfData(received_sgp_silver,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_inntwk_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                          .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                            .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                            .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                            .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                            "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp")
                           
   val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
                           $"inn_cd".isin(clminn_cd: _*) &&
                           $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                           $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_gld = joinedDf_typeOfData(received_sgp_gold,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_inntwk_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"))
 
    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                            .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                            .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                            .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                            "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp")                            

   val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
                          $"inn_cd".isin(clminn_cd: _*) &&
                          $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                          $"ADJDCTN_DT".between(strt_year, end_year))

   val denied_in_sgp_plt = joinedDf_typeOfData(received_sgp_plt,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_inntwk_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                            .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                        .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                        "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp")   


    val tot_sgp = nbrclm_denied_inntwk_bronze_sgp.union(nbrclm_denied_inntwk_silver_sgp.union(nbrclm_denied_inntwk_gold_sgp.union(nbrclm_denied_inntwk_platinum_sgp)))
                  .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"))
   

    val nbrclm_denied_inntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp").alias("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"),col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp")) 

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                            .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                            .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                            .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                            "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp")
    lob_type = ""
    var islgp = true
   
    val lgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp)

    val received_gtlgp =  lgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
                          $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                          $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gtlgp = joinedDf_typeOfData(received_gtlgp,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_inntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                     .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"))
    val gtlgpMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                      col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                          .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                          .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                          .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                            "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp")
    
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gtsgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type, islgp)

    val received_gtsgp = gtsgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
                         $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                         $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gtsgp = joinedDf_typeOfData(received_gtsgp,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)
    val nbrclm_denied_inntwk_gtsgp = denied_in_gtsgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                     .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                      col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                          .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                          .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                          .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                          "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp","nbrclm_denied_inntwk_"+type_of_data+"_gtsgp")                             

    lob_type = "TOTAL INDIVIDUAL CBE"
    val gtip_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp)

    val received_gtip = gtip_df.filter($"inn_cd".isin(clminn_cd: _*) &&
                        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                        $"ADJDCTN_DT".between(strt_year, end_year))
    val denied_in_gtip = joinedDf_typeOfData(received_gtip,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)
    val nbrclm_denied_inntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
                     && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                    $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                      col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                         .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                          "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp","nbrclm_denied_inntwk_"+type_of_data+"_gtsgp","nbrclm_denied_inntwk_"+type_of_data+"_gtip")




    
    val tot_gt =nbrclm_denied_inntwk_gtip.union(nbrclm_denied_inntwk_gtsgp.union(nbrclm_denied_inntwk_gtlgp))
                .select($"health_year",$"cmpny_cf_cd",$"state",col("nbrclm_denied_inntwk_"+type_of_data+"_gtip"))

    
    val nbrclm_denied_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col("nbrclm_denied_inntwk_" + type_of_data + "_gtip")).alias("nbrclm_denied_inntwk_" + type_of_data + "_total_gtip"))
    /*val nbrclm_denied_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_denied_inntwk_"+type_of_data+"_gtip").alias("nbrclm_denied_inntwk_"+type_of_data+"_total_gtip"))*/

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                      col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                          .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                          .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                          .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                          "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp","nbrclm_denied_inntwk_"+type_of_data+"_gtsgp","nbrclm_denied_inntwk_"+type_of_data+"_gtip","nbrclm_denied_inntwk_"+type_of_data+"_total_gtip")

    val received_cat = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                        $"in_Exchange".isNull &&
                        $"inn_cd".isin(clminn_cd: _*) &&
                        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                        $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_cat = joinedDf_typeOfData(received_cat,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)
    val nbrclm_denied_inntwk_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                           .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_catastrophic"))
    val catMaster = gttotMasterData.alias("parent").join(nbrclm_denied_inntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                    $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                      col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                        .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                          "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp","nbrclm_denied_inntwk_"+type_of_data+"_gtsgp","nbrclm_denied_inntwk_"+type_of_data+"_gtip","nbrclm_denied_inntwk_"+type_of_data+"_total_gtip","nbrclm_denied_inntwk_"+type_of_data+"_catastrophic") 

 val received_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                          (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) &&
                          $"in_exchange".isNull &&
                          $"inn_cd".isin(clminn_cd: _*) &&
                          $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                          $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_lgpmmcare = joinedDf_typeOfData(received_lgpmmcare,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)
    val nbrclm_denied_inntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                          .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_lgp_mmcare"))

    val lgpmmcareMaster = catMasterData.alias("parent").join(nbrclm_denied_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
                          && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                          .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                          $"child.state".alias("s_state"),  col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                          col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_catastrophic"),col("nbrclm_denied_inntwk_"+type_of_data+"_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                              .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                              .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                              "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp","nbrclm_denied_inntwk_"+type_of_data+"_gtsgp","nbrclm_denied_inntwk_"+type_of_data+"_gtip","nbrclm_denied_inntwk_"+type_of_data+"_total_gtip","nbrclm_denied_inntwk_"+type_of_data+"_catastrophic","nbrclm_denied_inntwk_"+type_of_data+"_lgp_mmcare")

    val received_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
        $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) &&
        $"in_exchange".isNull &&
        $"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_stucvg = joinedDf_typeOfData(received_stucvg,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)
    val nbrclm_denied_inntwk_stucvg = denied_in_stucvg.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"),  col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                          col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_catastrophic"),col("nbrclm_denied_inntwk_"+type_of_data+"_lgp_mmcare"),col("nbrclm_denied_inntwk_"+type_of_data+"_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                            "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp","nbrclm_denied_inntwk_"+type_of_data+"_gtsgp","nbrclm_denied_inntwk_"+type_of_data+"_gtip","nbrclm_denied_inntwk_"+type_of_data+"_total_gtip","nbrclm_denied_inntwk_"+type_of_data+"_catastrophic","nbrclm_denied_inntwk_"+type_of_data+"_lgp_mmcare","nbrclm_denied_inntwk_"+type_of_data+"_stucvg") 
    stucvgMasterData

}


def getDeniedOutntwk_typeOfData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, 
                  naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
                  naic2018_mcas_ce_src_eob_cd_inbnd: DataFrame, naic2018_mcas_ce_eob_cd_inbnd: DataFrame,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
                  naic2018_mcas_pa_src_eob_cd_inbnd: DataFrame, naic2018_mcas_pa_eob_cd_inbnd: DataFrame,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
                  naic2018_mcas_ncb_src_eob_cd_inbnd: DataFrame,naic2018_mcas_ncb_eob_cd_inbnd:DataFrame,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
                  type_of_data:String): DataFrame ={
    
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)
    
    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_brz = joinedDf_typeOfData(received_brnz,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)
    val nbrclm_denied_outntwk_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                          .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"))                                           
    
   val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
                               (!$"inn_cd".isin(clminn_cd: _*)) &&
                                $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sil = joinedDf_typeOfData(received_silver,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_outntwk_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"))  

    val BrzSilMaster = nbrclm_denied_outntwk_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                                                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                                                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                                                         $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                                                         $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                       .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                       .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                       .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip")

                                   
    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
                              (!$"inn_cd".isin(clminn_cd: _*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                              $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gld = joinedDf_typeOfData(received_gold,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_outntwk_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                                    $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                  .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                  .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                  .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip")                                       

val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
                              (!$"inn_cd".isin(clminn_cd: _*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                              $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_plt = joinedDf_typeOfData(received_platinum,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_outntwk_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                         .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                    $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                 .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                 .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                 .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip")


    val tot_ip = nbrclm_denied_outntwk_bronze_ip.union(nbrclm_denied_outntwk_silver_ip.union(nbrclm_denied_outntwk_gold_ip.union(nbrclm_denied_outntwk_platinum_ip)))
              .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"))

    val nbrclm_denied_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip").alias("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"),col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"))
        

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                          .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                          .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                          .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip","nbrclm_denied_outntwk_"+ type_of_data +"_total_ip")


    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
                                    (!$"inn_cd".isin(clminn_cd: _*)) &&
                                    $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                    $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_brz = joinedDf_typeOfData(received_sgp_bronze,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_outntwk_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                           .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                         $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"),
                        col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"))


    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                            .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                            .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                            .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip","nbrclm_denied_outntwk_"+ type_of_data +"_total_ip",
                            "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp")


    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
                                    (!$"inn_cd".isin(clminn_cd: _*)) &&
                                    $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                    $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_sil = joinedDf_typeOfData(received_sgp_silver,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_outntwk_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                                          && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                                          .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                                           $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                                            $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"),
                                            col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                          .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                          .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                          .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip","nbrclm_denied_outntwk_"+ type_of_data +"_total_ip",
                                          "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp")


    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
                                  (!$"inn_cd".isin(clminn_cd: _*)) &&
                                   $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                   $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_gld = joinedDf_typeOfData(received_sgp_gold,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_outntwk_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                          .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                                         && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                                         .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                                         $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                                         $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"),
                                            col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                          .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip","nbrclm_denied_outntwk_"+ type_of_data +"_total_ip",
                                          "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp")


    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
                              (!$"inn_cd".isin(clminn_cd: _*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                              $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_plt = joinedDf_typeOfData(received_sgp_plt,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_outntwk_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                                          && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                                          .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                                          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                                          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"),
                                          col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                  .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                  .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                  .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip","nbrclm_denied_outntwk_"+ type_of_data +"_total_ip",
                                  "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp")

    val tot_sgp = nbrclm_denied_outntwk_bronze_sgp.union(nbrclm_denied_outntwk_silver_sgp.union(nbrclm_denied_outntwk_gold_sgp.union(nbrclm_denied_outntwk_platinum_sgp)))
                                              .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"))

    val nbrclm_denied_outntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp").alias("nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                                          && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                                          .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                                          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                                          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"),
                                          col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                         .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip","nbrclm_denied_outntwk_"+ type_of_data +"_total_ip",
                                         "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp")                                  


    lob_type = ""
    var islgp = true
    val lgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp)

    val received_gtlgp = lgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
                                $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gtlgp = joinedDf_typeOfData(received_gtlgp,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)

    val nbrclm_denied_outntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp"))

    val gtlgpMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
                                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                                        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"),
                                        col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip","nbrclm_denied_outntwk_"+ type_of_data +"_total_ip",
                                      "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp")

    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gtsgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type, islgp)

    val received_gtsgp = gtsgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
                                  $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                  $"ADJDCTN_DT".between(strt_year, end_year))
    val denied_in_gtsgp = joinedDf_typeOfData(received_gtsgp,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)
    val nbrclm_denied_outntwk_gtsgp = denied_in_gtsgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                     .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data  +"_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
                                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                                      $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"),
                                      col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp"),col("nbrclm_denied_outntwk_"+ type_of_data  +"_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip","nbrclm_denied_outntwk_"+ type_of_data +"_total_ip",
                                      "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp","nbrclm_denied_outntwk_"+ type_of_data  +"_gtsgp")


    lob_type = "TOTAL INDIVIDUAL CBE"
    val gtip_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp)

    val received_gtip = gtip_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
                                $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                $"ADJDCTN_DT".between(strt_year, end_year))
       
    val denied_in_gtip = joinedDf_typeOfData(received_gtip,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)
       
    val nbrclm_denied_outntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
                                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                                      $"child.state".alias("s_state"),  col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"),
                                      col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp"),col("nbrclm_denied_outntwk_"+ type_of_data  +"_gtsgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                   .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                   .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                   .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip","nbrclm_denied_outntwk_"+ type_of_data +"_total_ip",
                                    "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp","nbrclm_denied_outntwk_"+ type_of_data  +"_gtsgp","nbrclm_denied_outntwk_"+ type_of_data +"_gtip")




   
     val tot_gt = nbrclm_denied_outntwk_gtip.union(nbrclm_denied_outntwk_gtsgp.union(nbrclm_denied_outntwk_gtlgp))
                  .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_"+ type_of_data +"_gtip"))

    val nbrclm_denied_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state")
                                           .agg(sum(col("nbrclm_denied_outntwk_"+ type_of_data +"_gtip")).alias("nbrclm_denied_outntwk_"+ type_of_data +"_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
                                     && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                                     .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                                     $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                                     $"child.state".alias("s_state"),  col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"),
                                     col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp"),col("nbrclm_denied_outntwk_"+ type_of_data  +"_gtsgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gtip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                     .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                     .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                     .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip","nbrclm_denied_outntwk_"+ type_of_data +"_total_ip",
                                    "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp","nbrclm_denied_outntwk_"+ type_of_data  +"_gtsgp","nbrclm_denied_outntwk_"+ type_of_data +"_gtip","nbrclm_denied_outntwk_"+ type_of_data +"_total_gtip")


      val received_cat = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                         $"in_Exchange".isNull &&
                         (!$"inn_cd".isin(clminn_cd: _*)) &&
                         $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                         $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_cat = joinedDf_typeOfData(received_cat,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)
    val nbrclm_denied_outntwk_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                             .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_catastrophic"))
   
    val catMaster = gttotMasterData.alias("parent").join(nbrclm_denied_outntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                    $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"),
                    col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp"),col("nbrclm_denied_outntwk_"+ type_of_data  +"_gtsgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gtip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_gtip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip","nbrclm_denied_outntwk_"+ type_of_data +"_total_ip",
                                    "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp","nbrclm_denied_outntwk_"+ type_of_data  +"_gtsgp","nbrclm_denied_outntwk_"+ type_of_data +"_gtip","nbrclm_denied_outntwk_"+ type_of_data +"_total_gtip","nbrclm_denied_outntwk_"+ type_of_data +"_catastrophic")


    val received_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                        (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) &&
                        $"in_exchange".isNull &&
                        (!$"inn_cd".isin(clminn_cd: _*)) &&
                        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                        $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_lgpmmcare = joinedDf_typeOfData(received_lgpmmcare,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)
                                           
    val nbrclm_denied_outntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                           .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_lgp_mmcare"))

    val lgpmmcareMaster = catMasterData.alias("parent").join(nbrclm_denied_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
                          && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                          .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"),
                          col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp"),col("nbrclm_denied_outntwk_"+ type_of_data  +"_gtsgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gtip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_gtip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_catastrophic"),col("nbrclm_denied_outntwk_"+ type_of_data +"_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                              .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                              .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip","nbrclm_denied_outntwk_"+ type_of_data +"_total_ip",
                                    "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp","nbrclm_denied_outntwk_"+ type_of_data  +"_gtsgp","nbrclm_denied_outntwk_"+ type_of_data +"_gtip","nbrclm_denied_outntwk_"+ type_of_data +"_total_gtip","nbrclm_denied_outntwk_"+ type_of_data +"_catastrophic","nbrclm_denied_outntwk_"+ type_of_data +"_lgp_mmcare")

val received_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                      $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) &&
                      $"in_exchange".isNull &&
                      (!$"inn_cd".isin(clminn_cd: _*)) &&
                      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_stucvg = joinedDf_typeOfData(received_stucvg,
                                           naic2018_mcas_ce_src_eob_cd_inbnd,naic2018_mcas_ce_eob_cd_inbnd,naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd,
                                           naic2018_mcas_ncb_src_eob_cd_inbnd,naic2018_mcas_ncb_eob_cd_inbnd,naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd,
                                           type_of_data)
    val nbrclm_denied_outntwk_stucvg = denied_in_stucvg.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
                       && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                       .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                       $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                       $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_ip"),
                       col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp"),col("nbrclm_denied_outntwk_"+ type_of_data  +"_gtsgp"),col("nbrclm_denied_outntwk_"+ type_of_data +"_gtip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_total_gtip"),col("nbrclm_denied_outntwk_"+ type_of_data +"_catastrophic"),col("nbrclm_denied_outntwk_"+ type_of_data +"_lgp_mmcare"),col("nbrclm_denied_outntwk_"+ type_of_data +"_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip","nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_ip","nbrclm_denied_outntwk_"+ type_of_data +"_total_ip",
                           "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_silver_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gold_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_platinum_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_total_sgp","nbrclm_denied_outntwk_"+ type_of_data +"_gtlgp","nbrclm_denied_outntwk_"+ type_of_data  +"_gtsgp","nbrclm_denied_outntwk_"+ type_of_data +"_gtip","nbrclm_denied_outntwk_"+ type_of_data +"_total_gtip","nbrclm_denied_outntwk_"+ type_of_data +"_catastrophic","nbrclm_denied_outntwk_"+ type_of_data +"_lgp_mmcare","nbrclm_denied_outntwk_"+ type_of_data +"_stucvg")
 
    stucvgMasterData

}
  
  
def getdeniedbhebhInntwk(type_of_data:String,naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame,
			    naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame,
			    naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame,naic2018_mcas_nmn_eob_cd_inbnd:DataFrame,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd:DataFrame,
					naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame): DataFrame =

				{
		var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    
    val ip_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
                        $"inn_cd".isin(clminn_cd: _*) &&
                        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                        $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_brz = joinedDfbhebhIn(type_of_data,received_brnz,
                        naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                        naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
               

    val nbrclm_denied_inntwk_ebh_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                            .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+ type_of_data +"_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
                                $"inn_cd".isin(clminn_cd: _*) &&
                                $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sil = joinedDfbhebhIn(type_of_data,received_silver,
                        naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                        naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_inntwk_ebh_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                          .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+ type_of_data +"_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_ebh_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_ebh_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_inntwk_"+ type_of_data +"_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                       .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                       .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                       
                                       .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_inntwk_"+ type_of_data +"_silver_ip")
    
   val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
                             $"inn_cd".isin(clminn_cd: _*) &&
                             $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                             $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gld = joinedDfbhebhIn(type_of_data,received_gold,
                        naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                        naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_inntwk_ebh_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+ type_of_data +"_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                    $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                 .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                 .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                 
                                 .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_inntwk_"+type_of_data+"_gold_ip")			  

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
                                  $"inn_cd".isin(clminn_cd: _*) &&
                                  $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                  $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_plt = joinedDfbhebhIn(type_of_data,received_platinum,
                        naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                        naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_inntwk_ebh_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                    $"child.state".alias("s_state"),  col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                 .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                 .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                 
                                 .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_inntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip")                                 
				
	  val tot_ip = nbrclm_denied_inntwk_ebh_bronze_ip.union(nbrclm_denied_inntwk_ebh_silver_ip.union(nbrclm_denied_inntwk_ebh_gold_ip.union(nbrclm_denied_inntwk_ebh_platinum_ip)))
               .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"))

    val nbrclm_denied_inntwk_ebh_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip").alias("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"), 
                      col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                     .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                     .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                     
                                     .select("health_year", "cmpny_cf_cd", "state",  "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_inntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip", "nbrclm_denied_inntwk_"+type_of_data+"_total_ip")
			
    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
                              $"inn_cd".isin(clminn_cd: _*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                              $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_brz = joinedDfbhebhIn(type_of_data,received_sgp_bronze,
                        naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                        naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_inntwk_ebh_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                               .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"),  col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                         
                                         .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_inntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip", "nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                                         "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp")
                                         
    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
                                     $"inn_cd".isin(clminn_cd: _*) &&
                                     $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                     $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_sil = joinedDfbhebhIn(type_of_data,received_sgp_silver,
                            naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                            naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_inntwk_ebh_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                               .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                         
                                         .select("health_year", "cmpny_cf_cd", "state",  "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_inntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip", "nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                                         "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp", "nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp")                                         

  val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
                                 $"inn_cd".isin(clminn_cd: _*) &&
                                 $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                 $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_gld = joinedDfbhebhIn(type_of_data,received_sgp_gold,
                            naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                            naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_inntwk_ebh_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                             .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"), col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                         
                                         .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_inntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip", "nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                                         "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp", "nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp", "nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp")
                                         
    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
                                  $"inn_cd".isin(clminn_cd: _*) &&
                                  $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                  $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_plt = joinedDfbhebhIn(type_of_data,received_sgp_plt,
                            naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                            naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_inntwk_ebh_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                                 .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"), col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"), col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                        
                                         .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_inntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip", "nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                                         "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp", "nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp", "nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp", "nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp")                                         
    
    val tot_sgp = nbrclm_denied_inntwk_ebh_bronze_sgp.union(nbrclm_denied_inntwk_ebh_silver_sgp.union(nbrclm_denied_inntwk_ebh_gold_sgp.union(nbrclm_denied_inntwk_ebh_platinum_sgp)))
                  .select($"health_year", $"cmpny_cf_cd", $"state",  col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"))

    val nbrclm_denied_inntwk_ebh_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state" ).agg(sum("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp").alias("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"), col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"), col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"), col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                         
                                         .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_inntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip", "nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                                          "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp", "nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp", "nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp", "nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp", "nbrclm_denied_inntwk_"+type_of_data+"_total_sgp")				
    
    lob_type = ""
    var islgp = true   
    val lgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp)

    val received_gtlgp =  lgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
                                 $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                 $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gtlgp = joinedDfbhebhIn(type_of_data,received_gtlgp,
                            naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                            naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
                            
    val nbrclm_denied_inntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"))
    val gtlgpMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                      col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                     .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                     .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                     .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                                     "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp")
    
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gtsgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type, islgp)

    val received_gtsgp = gtsgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
                                  $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                  $"ADJDCTN_DT".between(strt_year, end_year))
     
    val denied_in_gtsgp = joinedDfbhebhIn(type_of_data,received_gtsgp,
                            naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                            naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
                            
    val nbrclm_denied_inntwk_gtsgp = denied_in_gtsgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                      col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                          .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                          .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                          .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                          "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp","nbrclm_denied_inntwk_"+type_of_data+"_gtsgp")                             
    
    lob_type = "TOTAL INDIVIDUAL CBE"
    val gtip_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp)

    val received_gtip = gtip_df.filter($"inn_cd".isin(clminn_cd: _*) &&
                                $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                $"ADJDCTN_DT".between(strt_year, end_year))
    val denied_in_gtip = joinedDfbhebhIn(type_of_data,received_gtip,
                            naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                            naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
                            
    val nbrclm_denied_inntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                  .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
                     && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                     .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                     $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                     $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                     col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                         .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                         "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp","nbrclm_denied_inntwk_"+type_of_data+"_gtsgp","nbrclm_denied_inntwk_"+type_of_data+"_gtip")
   
    val tot_gt =nbrclm_denied_inntwk_gtip.union(nbrclm_denied_inntwk_gtsgp.union(nbrclm_denied_inntwk_gtlgp))
                .select($"health_year",$"cmpny_cf_cd",$"state",col("nbrclm_denied_inntwk_"+type_of_data+"_gtip"))
    
    val nbrclm_denied_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col("nbrclm_denied_inntwk_" + type_of_data + "_gtip")).alias("nbrclm_denied_inntwk_" + type_of_data + "_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                      col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                          .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                          .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                          .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                          "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp","nbrclm_denied_inntwk_"+type_of_data+"_gtsgp","nbrclm_denied_inntwk_"+type_of_data+"_gtip","nbrclm_denied_inntwk_"+type_of_data+"_total_gtip")

    val received_cat = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                                                                        $"in_Exchange".isNull &&
                                                                        $"inn_cd".isin(clminn_cd: _*) &&
                                                                        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                                                        $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_cat = joinedDfbhebhIn(type_of_data,received_cat,
                        naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                        naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
    
   val nbrclm_denied_inntwk_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                           .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_catastrophic"))
    val catMaster = gttotMasterData.alias("parent").join(nbrclm_denied_inntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                    $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                      col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                        .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                        "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp","nbrclm_denied_inntwk_"+type_of_data+"_gtsgp","nbrclm_denied_inntwk_"+type_of_data+"_gtip","nbrclm_denied_inntwk_"+type_of_data+"_total_gtip","nbrclm_denied_inntwk_"+type_of_data+"_catastrophic") 

   val received_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                                                                             (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) &&
                                                                             $"in_exchange".isNull &&
                                                                             $"inn_cd".isin(clminn_cd: _*) &&
                                                                             $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                                                             $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_lgpmmcare = joinedDfbhebhIn(type_of_data,received_lgpmmcare,
                              naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                              naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
    
    val nbrclm_denied_inntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                             .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_lgp_mmcare"))

    val lgpmmcareMaster = catMasterData.alias("parent").join(nbrclm_denied_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
                          && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                          .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                          $"child.state".alias("s_state"),  col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                          col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_catastrophic"),col("nbrclm_denied_inntwk_"+type_of_data+"_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                              .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                              .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                              "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp","nbrclm_denied_inntwk_"+type_of_data+"_gtsgp","nbrclm_denied_inntwk_"+type_of_data+"_gtip","nbrclm_denied_inntwk_"+type_of_data+"_total_gtip","nbrclm_denied_inntwk_"+type_of_data+"_catastrophic","nbrclm_denied_inntwk_"+type_of_data+"_lgp_mmcare")
    
   val received_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                                                                          $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) &&
                                                                          $"in_exchange".isNull &&
                                                                          $"inn_cd".isin(clminn_cd: _*) &&
                                                                          $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                                                          $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_stucvg = joinedDfbhebhIn(type_of_data,received_stucvg,
                              naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                              naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
                              
    val nbrclm_denied_inntwk_stucvg = denied_in_stucvg.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_"+type_of_data+"_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"),  col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_inntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_inntwk_"+type_of_data+"_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_total_gtip"),col("nbrclm_denied_inntwk_"+type_of_data+"_catastrophic"),col("nbrclm_denied_inntwk_"+type_of_data+"_lgp_mmcare"),col("nbrclm_denied_inntwk_"+type_of_data+"_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_inntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_inntwk_"+type_of_data+"_silver_ip","nbrclm_denied_inntwk_"+type_of_data+"_gold_ip","nbrclm_denied_inntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_inntwk_"+type_of_data+"_total_ip",
                           "nbrclm_denied_inntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_inntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_inntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_inntwk_"+type_of_data+"_total_sgp","nbrclm_denied_inntwk_"+type_of_data+"_gtlgp","nbrclm_denied_inntwk_"+type_of_data+"_gtsgp","nbrclm_denied_inntwk_"+type_of_data+"_gtip","nbrclm_denied_inntwk_"+type_of_data+"_total_gtip","nbrclm_denied_inntwk_"+type_of_data+"_catastrophic","nbrclm_denied_inntwk_"+type_of_data+"_lgp_mmcare","nbrclm_denied_inntwk_"+type_of_data+"_stucvg") 
    stucvgMasterData				
				
				
				}


def getdeniedbhebhOutntwk(type_of_data:String,naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame,
			    naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame,
			    naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame,naic2018_mcas_nmn_eob_cd_inbnd:DataFrame,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd:DataFrame,
					naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame): DataFrame =

				{
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    
    val ip_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
                        !$"inn_cd".isin(clminn_cd: _*) &&
                        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                        $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_brz = joinedDfbhebhIn(type_of_data,received_brnz,
                        naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                        naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
               

    val nbrclm_denied_outntwk_bhebh_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                            .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
                                !$"inn_cd".isin(clminn_cd: _*) &&
                                $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sil = joinedDfbhebhIn(type_of_data,received_silver,
                        naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                        naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_outntwk_bhebh_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                          .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_bhebh_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_bhebh_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip"), col("nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                       .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                       .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                       
                                       .select("health_year", "cmpny_cf_cd", "state",  "nbrclm_denied_outntwk_"+ type_of_data +"_bronze_ip", "nbrclm_denied_outntwk_"+ type_of_data +"_silver_ip")
    
   val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
                             !$"inn_cd".isin(clminn_cd: _*) &&
                             $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                             $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gld = joinedDfbhebhIn(type_of_data,received_gold,
                        naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                        naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_outntwk_bhebh_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+ type_of_data +"_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_bhebh_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                    $"child.state".alias("s_state"),  col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                 .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                 .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                 
                                 .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_outntwk_"+type_of_data+"_gold_ip")			  

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
                                  !$"inn_cd".isin(clminn_cd: _*) &&
                                  $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                  $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_plt = joinedDfbhebhIn(type_of_data,received_platinum,
                        naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                        naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_outntwk_bhebh_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_bhebh_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                    $"child.state".alias("s_state"),  col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                 .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                 .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                 
                                 .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_outntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip")                                 
				
	  val tot_ip = nbrclm_denied_outntwk_bhebh_bronze_ip.union(nbrclm_denied_outntwk_bhebh_silver_ip.union(nbrclm_denied_outntwk_bhebh_gold_ip.union(nbrclm_denied_outntwk_bhebh_platinum_ip)))
               .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"))

    val nbrclm_denied_outntwk_bhebh_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip").alias("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_bhebh_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"), 
                      col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                     .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                     .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                     
                                     .select("health_year", "cmpny_cf_cd", "state",  "nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_outntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip", "nbrclm_denied_outntwk_"+type_of_data+"_total_ip")
			
    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
                              !$"inn_cd".isin(clminn_cd: _*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                              $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_brz = joinedDfbhebhIn(type_of_data,received_sgp_bronze,
                        naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                        naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_outntwk_bhebh_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                               .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_bhebh_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                         
                                         .select("health_year", "cmpny_cf_cd", "state",  "nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_outntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip", "nbrclm_denied_outntwk_"+type_of_data+"_total_ip",
                                         "nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp")
                                         
    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
                                     !$"inn_cd".isin(clminn_cd: _*) &&
                                     $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                     $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_sil = joinedDfbhebhIn(type_of_data,received_sgp_silver,
                            naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                            naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_outntwk_bhebh_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                               .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_bhebh_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                         
                                         .select("health_year", "cmpny_cf_cd", "state",  "nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_outntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip", "nbrclm_denied_outntwk_"+type_of_data+"_total_ip",
                                         "nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp", "nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp")                                         

  val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
                                 !$"inn_cd".isin(clminn_cd: _*) &&
                                 $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                 $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_gld = joinedDfbhebhIn(type_of_data,received_sgp_gold,
                            naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                            naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_outntwk_bhebh_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                             .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_bhebh_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp"), col("nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                         
                                         .select("health_year", "cmpny_cf_cd", "state",  "nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_outntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip", "nbrclm_denied_outntwk_"+type_of_data+"_total_ip",
                                         "nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp", "nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp", "nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp")
                                         
    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
                                  !$"inn_cd".isin(clminn_cd: _*) &&
                                  $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                  $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_plt = joinedDfbhebhIn(type_of_data,received_sgp_plt,
                            naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                            naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val nbrclm_denied_outntwk_bhebh_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                                 .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_bhebh_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp"), col("nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp"), col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                         
                                         .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_outntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip", "nbrclm_denied_outntwk_"+type_of_data+"_total_ip",
                                         "nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp", "nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp", "nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp", "nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp")                                         
    
    val tot_sgp = nbrclm_denied_outntwk_bhebh_bronze_sgp.union(nbrclm_denied_outntwk_bhebh_silver_sgp.union(nbrclm_denied_outntwk_bhebh_gold_sgp.union(nbrclm_denied_outntwk_bhebh_platinum_sgp)))
                  .select($"health_year", $"cmpny_cf_cd", $"state",  col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"))

    val nbrclm_denied_outntwk_bhebh_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp").alias("nbrclm_denied_outntwk_"+type_of_data+"_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_bhebh_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"),  col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp"), col("nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp"), col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp"), col("nbrclm_denied_outntwk_"+type_of_data+"_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))                                         
                                         .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip", "nbrclm_denied_outntwk_"+type_of_data+"_gold_ip", "nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip", "nbrclm_denied_outntwk_"+type_of_data+"_total_ip",
                                          "nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp", "nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp", "nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp", "nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp", "nbrclm_denied_outntwk_"+type_of_data+"_total_sgp")				
    
    lob_type = ""
    var islgp = true   
    val lgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp)

    val received_gtlgp =  lgp_df.filter(!$"inn_cd".isin(clminn_cd: _*) &&
                                 $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                 $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gtlgp = joinedDfbhebhIn(type_of_data,received_gtlgp,
                            naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                            naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
                            
    val nbrclm_denied_outntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+type_of_data+"_gtlgp"))
    val gtlgpMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"),
                      col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                                     .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                                     .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                                     .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip","nbrclm_denied_outntwk_"+type_of_data+"_gold_ip","nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_outntwk_"+type_of_data+"_total_ip",
                                     "nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_outntwk_"+type_of_data+"_total_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gtlgp")
    
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gtsgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type, islgp)

    val received_gtsgp = gtsgp_df.filter(!$"inn_cd".isin(clminn_cd: _*) &&
                                  $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                  $"ADJDCTN_DT".between(strt_year, end_year))
     
    val denied_in_gtsgp = joinedDfbhebhIn(type_of_data,received_gtsgp,
                            naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                            naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
                            
    val nbrclm_denied_outntwk_gtsgp = denied_in_gtsgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+type_of_data+"_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"),
                      col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                          .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                          .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                          .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip","nbrclm_denied_outntwk_"+type_of_data+"_gold_ip","nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_outntwk_"+type_of_data+"_total_ip",
                          "nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_outntwk_"+type_of_data+"_total_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gtlgp","nbrclm_denied_outntwk_"+type_of_data+"_gtsgp")                             
    
    lob_type = "TOTAL INDIVIDUAL CBE"
    val gtip_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp)

    val received_gtip = gtip_df.filter(!$"inn_cd".isin(clminn_cd: _*) &&
                                $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                $"ADJDCTN_DT".between(strt_year, end_year))
    val denied_in_gtip = joinedDfbhebhIn(type_of_data,received_gtip,
                            naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                            naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
                            
    val nbrclm_denied_outntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                  .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+type_of_data+"_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
                     && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                     .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                     $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                     $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"),
                     col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                         .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                         .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                         .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip","nbrclm_denied_outntwk_"+type_of_data+"_gold_ip","nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_outntwk_"+type_of_data+"_total_ip",
                         "nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_outntwk_"+type_of_data+"_total_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gtlgp","nbrclm_denied_outntwk_"+type_of_data+"_gtsgp","nbrclm_denied_outntwk_"+type_of_data+"_gtip")
   
    val tot_gt =nbrclm_denied_outntwk_gtip.union(nbrclm_denied_outntwk_gtsgp.union(nbrclm_denied_outntwk_gtlgp))
                .select($"health_year",$"cmpny_cf_cd",$"state",col("nbrclm_denied_outntwk_"+type_of_data+"_gtip"))
    
    val nbrclm_denied_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col("nbrclm_denied_outntwk_" + type_of_data + "_gtip")).alias("nbrclm_denied_outntwk_" + type_of_data + "_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
                      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                      $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                      $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"),
                      col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtip"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                          .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                          .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                          .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip","nbrclm_denied_outntwk_"+type_of_data+"_gold_ip","nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_outntwk_"+type_of_data+"_total_ip",
                          "nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_outntwk_"+type_of_data+"_total_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gtlgp","nbrclm_denied_outntwk_"+type_of_data+"_gtsgp","nbrclm_denied_outntwk_"+type_of_data+"_gtip","nbrclm_denied_outntwk_"+type_of_data+"_total_gtip")

    val received_cat = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                                                                        $"in_Exchange".isNull &&
                                                                        !$"inn_cd".isin(clminn_cd: _*) &&
                                                                        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                                                        $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_cat = joinedDfbhebhIn(type_of_data,received_cat,
                        naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                        naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
    
   val nbrclm_denied_outntwk_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                           .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+type_of_data+"_catastrophic"))
    val catMaster = gttotMasterData.alias("parent").join(nbrclm_denied_outntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
                    && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                    .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                    $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                    $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"),
                      col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtip"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_gtip"),col("nbrclm_denied_outntwk_"+type_of_data+"_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                        .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip","nbrclm_denied_outntwk_"+type_of_data+"_gold_ip","nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_outntwk_"+type_of_data+"_total_ip",
                        "nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_outntwk_"+type_of_data+"_total_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gtlgp","nbrclm_denied_outntwk_"+type_of_data+"_gtsgp","nbrclm_denied_outntwk_"+type_of_data+"_gtip","nbrclm_denied_outntwk_"+type_of_data+"_total_gtip","nbrclm_denied_outntwk_"+type_of_data+"_catastrophic") 

   val received_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                                                                             (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) &&
                                                                             $"in_exchange".isNull &&
                                                                             !$"inn_cd".isin(clminn_cd: _*) &&
                                                                             $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                                                             $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_lgpmmcare = joinedDfbhebhIn(type_of_data,received_lgpmmcare,
                              naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                              naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
    
    val nbrclm_denied_outntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                             .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+type_of_data+"_lgp_mmcare"))

    val lgpmmcareMaster = catMasterData.alias("parent").join(nbrclm_denied_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
                          && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                          .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                          $"child.state".alias("s_state"),  col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"),
                          col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtip"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_gtip"),col("nbrclm_denied_outntwk_"+type_of_data+"_catastrophic"),col("nbrclm_denied_outntwk_"+type_of_data+"_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                              .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                              .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip","nbrclm_denied_outntwk_"+type_of_data+"_gold_ip","nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_outntwk_"+type_of_data+"_total_ip",
                              "nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_outntwk_"+type_of_data+"_total_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gtlgp","nbrclm_denied_outntwk_"+type_of_data+"_gtsgp","nbrclm_denied_outntwk_"+type_of_data+"_gtip","nbrclm_denied_outntwk_"+type_of_data+"_total_gtip","nbrclm_denied_outntwk_"+type_of_data+"_catastrophic","nbrclm_denied_outntwk_"+type_of_data+"_lgp_mmcare")
    
   val received_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
                                                                          $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) &&
                                                                          $"in_exchange".isNull &&
                                                                          !$"inn_cd".isin(clminn_cd: _*) &&
                                                                          $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
                                                                          $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_stucvg = joinedDfbhebhIn(type_of_data,received_stucvg,
                              naic2018_mcas_nmn_src_eob_cd_inbnd,naic2018_mcas_nmn_eob_cd_inbnd,naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd,
                              naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
                              
    val nbrclm_denied_outntwk_stucvg = denied_in_stucvg.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_"+type_of_data+"_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
                        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
                        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
                        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
                        $"child.state".alias("s_state"),  col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip"), col("nbrclm_denied_outntwk_"+type_of_data+"_silver_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_ip"),
                        col("nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_sgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtlgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtsgp"),col("nbrclm_denied_outntwk_"+type_of_data+"_gtip"),col("nbrclm_denied_outntwk_"+type_of_data+"_total_gtip"),col("nbrclm_denied_outntwk_"+type_of_data+"_catastrophic"),col("nbrclm_denied_outntwk_"+type_of_data+"_lgp_mmcare"),col("nbrclm_denied_outntwk_"+type_of_data+"_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year", "cmpny_cf_cd", "state","nbrclm_denied_outntwk_"+type_of_data+"_bronze_ip", "nbrclm_denied_outntwk_"+type_of_data+"_silver_ip","nbrclm_denied_outntwk_"+type_of_data+"_gold_ip","nbrclm_denied_outntwk_"+type_of_data+"_platinum_ip","nbrclm_denied_outntwk_"+type_of_data+"_total_ip",
                           "nbrclm_denied_outntwk_"+type_of_data+"_bronze_sgp","nbrclm_denied_outntwk_"+type_of_data+"_silver_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gold_sgp","nbrclm_denied_outntwk_"+type_of_data+"_platinum_sgp","nbrclm_denied_outntwk_"+type_of_data+"_total_sgp","nbrclm_denied_outntwk_"+type_of_data+"_gtlgp","nbrclm_denied_outntwk_"+type_of_data+"_gtsgp","nbrclm_denied_outntwk_"+type_of_data+"_gtip","nbrclm_denied_outntwk_"+type_of_data+"_total_gtip","nbrclm_denied_outntwk_"+type_of_data+"_catastrophic","nbrclm_denied_outntwk_"+type_of_data+"_lgp_mmcare","nbrclm_denied_outntwk_"+type_of_data+"_stucvg") 
    stucvgMasterData				
				
				
				}



}
