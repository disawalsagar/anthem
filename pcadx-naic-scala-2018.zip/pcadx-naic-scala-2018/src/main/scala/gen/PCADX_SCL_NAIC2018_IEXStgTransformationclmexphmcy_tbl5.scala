package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_tbl5(val spark: SparkSession) {

  /*val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()*/

  import spark.implicits._

  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_tbl5])

  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))

  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clmex")
  val end_year = dbProperties.getProperty("end_year_clmex")
  var naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame = null

  def sparkInIt(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame, load_log_key: String) {
    val oexclmphrmcy = new PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy(spark)
    val obj_clmsExPhrmcy = new PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_part2(spark)
    /*naic_mcas_hlthex_clmexphmcy_paid_ip_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic_mcas_hlthex_clmexphmcy_paid_ip_wrk")

     naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk")
      naic_mcas_hlthex_clmexphmcy_paid_cat_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic_mcas_hlthex_clmexphmcy_paid_cat_wrk")
      */
    val clm_paidamt = obj_clmsExPhrmcy.getamtData("PAID_AMT", "paid", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
    val clm_cpayamt = obj_clmsExPhrmcy.getamtData("CPAY_AMT", "copay", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
    val clm_coinsrnamt = obj_clmsExPhrmcy.getamtData("COINSRN_AMT", "coinsrn", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
    val clm_ddctblamt = obj_clmsExPhrmcy.getamtData("DDCTBL_AMT", "ddctbl", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
    println("Done ")
    val StgData_1 = getStageData(clm_paidamt, clm_cpayamt, clm_coinsrnamt, clm_ddctblamt)
    /* var load_log_key = ""
    if(!naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.take(1).isEmpty){
     load_log_key = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.select($"load_log_key").first.getString(0)
    }*/
    val f_stgData = StgData_1.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
    oexclmphrmcy.writeDataToHive(dbwrk + ".naic2018_mcas_hlthiex_clmexphmcy_amtColstemp", f_stgData)

  }
  def getStageData(clm_paidamt: DataFrame, clm_cpayamt: DataFrame, clm_coinsrnamt: DataFrame, clm_ddctblamt: DataFrame): DataFrame = {

    val clm_cpay = clm_paidamt.alias("parent").join(clm_cpayamt.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"), $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"), $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"), col("clm_total_paid_amt_bronze_ip"), col("clm_total_paid_amt_silver_ip"), col("clm_total_paid_amt_gold_ip"), col("clm_total_paid_amt_platinum_ip"), col("clm_total_paid_amt_total_ip"), col("clm_total_paid_amt_bronze_sgp"), col("clm_total_paid_amt_silver_sgp"), col("clm_total_paid_amt_gold_sgp"), col("clm_total_paid_amt_platinum_sgp"), col("clm_total_paid_amt_total_sgp"),
        col("clm_total_paid_amt_bronze_ms_ip"), col("clm_total_paid_amt_silver_ms_ip"), col("clm_total_paid_amt_gold_ms_ip"), col("clm_total_paid_amt_platinum_ms_ip"), col("clm_total_paid_amt_total_ms_ip"), col("clm_total_paid_amt_bronze_ms_sgp"), col("clm_total_paid_amt_silver_ms_sgp"), col("clm_total_paid_amt_gold_ms_sgp"), col("clm_total_paid_amt_platinum_ms_sgp"), col("clm_total_paid_amt_total_ms_sgp"), col("clm_total_paid_amt_catastrophic"),
        col("clm_total_copay_amt_bronze_ip"), col("clm_total_copay_amt_silver_ip"), col("clm_total_copay_amt_gold_ip"), col("clm_total_copay_amt_platinum_ip"), col("clm_total_copay_amt_total_ip"), col("clm_total_copay_amt_bronze_sgp"), col("clm_total_copay_amt_silver_sgp"), col("clm_total_copay_amt_gold_sgp"), col("clm_total_copay_amt_platinum_sgp"), col("clm_total_copay_amt_total_sgp"),
        col("clm_total_copay_amt_bronze_ms_ip"), col("clm_total_copay_amt_silver_ms_ip"), col("clm_total_copay_amt_gold_ms_ip"), col("clm_total_copay_amt_platinum_ms_ip"), col("clm_total_copay_amt_total_ms_ip"), col("clm_total_copay_amt_bronze_ms_sgp"), col("clm_total_copay_amt_silver_ms_sgp"), col("clm_total_copay_amt_gold_ms_sgp"), col("clm_total_copay_amt_platinum_ms_sgp"), col("clm_total_copay_amt_total_ms_sgp"), col("clm_total_copay_amt_catastrophic"))
    val clm_cpayData = clm_cpay.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year")).withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny")).withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state")).withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("in_exchange", "health_year", "cmpny_cf_cd", "state", "clm_total_paid_amt_bronze_ip", "clm_total_paid_amt_silver_ip", "clm_total_paid_amt_gold_ip", "clm_total_paid_amt_platinum_ip", "clm_total_paid_amt_total_ip", "clm_total_paid_amt_bronze_sgp", "clm_total_paid_amt_silver_sgp", "clm_total_paid_amt_gold_sgp", "clm_total_paid_amt_platinum_sgp", "clm_total_paid_amt_total_sgp", "clm_total_paid_amt_catastrophic",
        "clm_total_paid_amt_bronze_ms_ip", "clm_total_paid_amt_silver_ms_ip", "clm_total_paid_amt_gold_ms_ip", "clm_total_paid_amt_platinum_ms_ip", "clm_total_paid_amt_total_ms_ip", "clm_total_paid_amt_bronze_ms_sgp", "clm_total_paid_amt_silver_ms_sgp", "clm_total_paid_amt_gold_ms_sgp", "clm_total_paid_amt_platinum_ms_sgp", "clm_total_paid_amt_total_ms_sgp",
        "clm_total_copay_amt_bronze_ip", "clm_total_copay_amt_silver_ip", "clm_total_copay_amt_gold_ip", "clm_total_copay_amt_platinum_ip", "clm_total_copay_amt_total_ip", "clm_total_copay_amt_bronze_sgp", "clm_total_copay_amt_silver_sgp", "clm_total_copay_amt_gold_sgp", "clm_total_copay_amt_platinum_sgp", "clm_total_copay_amt_total_sgp", "clm_total_copay_amt_catastrophic",
        "clm_total_copay_amt_bronze_ms_ip", "clm_total_copay_amt_silver_ms_ip", "clm_total_copay_amt_gold_ms_ip", "clm_total_copay_amt_platinum_ms_ip", "clm_total_copay_amt_total_ms_ip", "clm_total_copay_amt_bronze_ms_sgp", "clm_total_copay_amt_silver_ms_sgp", "clm_total_copay_amt_gold_ms_sgp", "clm_total_copay_amt_platinum_ms_sgp", "clm_total_copay_amt_total_ms_sgp")

    val clm_coinsrn = clm_cpayData.alias("parent").join(clm_coinsrnamt.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"), $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"), $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"), col("clm_total_paid_amt_bronze_ip"), col("clm_total_paid_amt_silver_ip"), col("clm_total_paid_amt_gold_ip"), col("clm_total_paid_amt_platinum_ip"), col("clm_total_paid_amt_total_ip"), col("clm_total_paid_amt_bronze_sgp"), col("clm_total_paid_amt_silver_sgp"), col("clm_total_paid_amt_gold_sgp"), col("clm_total_paid_amt_platinum_sgp"), col("clm_total_paid_amt_total_sgp"),
        col("clm_total_paid_amt_bronze_ms_ip"), col("clm_total_paid_amt_silver_ms_ip"), col("clm_total_paid_amt_gold_ms_ip"), col("clm_total_paid_amt_platinum_ms_ip"), col("clm_total_paid_amt_total_ms_ip"), col("clm_total_paid_amt_bronze_ms_sgp"), col("clm_total_paid_amt_silver_ms_sgp"), col("clm_total_paid_amt_gold_ms_sgp"), col("clm_total_paid_amt_platinum_ms_sgp"), col("clm_total_paid_amt_total_ms_sgp"), col("clm_total_paid_amt_catastrophic"),
        col("clm_total_copay_amt_bronze_ip"), col("clm_total_copay_amt_silver_ip"), col("clm_total_copay_amt_gold_ip"), col("clm_total_copay_amt_platinum_ip"), col("clm_total_copay_amt_total_ip"), col("clm_total_copay_amt_bronze_sgp"), col("clm_total_copay_amt_silver_sgp"), col("clm_total_copay_amt_gold_sgp"), col("clm_total_copay_amt_platinum_sgp"), col("clm_total_copay_amt_total_sgp"),
        col("clm_total_copay_amt_bronze_ms_ip"), col("clm_total_copay_amt_silver_ms_ip"), col("clm_total_copay_amt_gold_ms_ip"), col("clm_total_copay_amt_platinum_ms_ip"), col("clm_total_copay_amt_total_ms_ip"), col("clm_total_copay_amt_bronze_ms_sgp"), col("clm_total_copay_amt_silver_ms_sgp"), col("clm_total_copay_amt_gold_ms_sgp"), col("clm_total_copay_amt_platinum_ms_sgp"), col("clm_total_copay_amt_total_ms_sgp"), col("clm_total_copay_amt_catastrophic"),
        col("clm_total_coinsrn_amt_bronze_ip"), col("clm_total_coinsrn_amt_silver_ip"), col("clm_total_coinsrn_amt_gold_ip"), col("clm_total_coinsrn_amt_platinum_ip"), col("clm_total_coinsrn_amt_total_ip"), col("clm_total_coinsrn_amt_bronze_sgp"), col("clm_total_coinsrn_amt_silver_sgp"), col("clm_total_coinsrn_amt_gold_sgp"), col("clm_total_coinsrn_amt_platinum_sgp"), col("clm_total_coinsrn_amt_total_sgp"),
        col("clm_total_coinsrn_amt_bronze_ms_ip"), col("clm_total_coinsrn_amt_silver_ms_ip"), col("clm_total_coinsrn_amt_gold_ms_ip"), col("clm_total_coinsrn_amt_platinum_ms_ip"), col("clm_total_coinsrn_amt_total_ms_ip"), col("clm_total_coinsrn_amt_bronze_ms_sgp"), col("clm_total_coinsrn_amt_silver_ms_sgp"), col("clm_total_coinsrn_amt_gold_ms_sgp"), col("clm_total_coinsrn_amt_platinum_ms_sgp"), col("clm_total_coinsrn_amt_total_ms_sgp"), col("clm_total_coinsrn_amt_catastrophic"))
    val clm_coinsrnData = clm_coinsrn.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year")).withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny")).withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state")).withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("in_exchange", "health_year", "cmpny_cf_cd", "state", "clm_total_paid_amt_bronze_ip", "clm_total_paid_amt_silver_ip", "clm_total_paid_amt_gold_ip", "clm_total_paid_amt_platinum_ip", "clm_total_paid_amt_total_ip", "clm_total_paid_amt_bronze_sgp", "clm_total_paid_amt_silver_sgp", "clm_total_paid_amt_gold_sgp", "clm_total_paid_amt_platinum_sgp", "clm_total_paid_amt_total_sgp", "clm_total_paid_amt_catastrophic",
        "clm_total_paid_amt_bronze_ms_ip", "clm_total_paid_amt_silver_ms_ip", "clm_total_paid_amt_gold_ms_ip", "clm_total_paid_amt_platinum_ms_ip", "clm_total_paid_amt_total_ms_ip", "clm_total_paid_amt_bronze_ms_sgp", "clm_total_paid_amt_silver_ms_sgp", "clm_total_paid_amt_gold_ms_sgp", "clm_total_paid_amt_platinum_ms_sgp", "clm_total_paid_amt_total_ms_sgp",
        "clm_total_copay_amt_bronze_ip", "clm_total_copay_amt_silver_ip", "clm_total_copay_amt_gold_ip", "clm_total_copay_amt_platinum_ip", "clm_total_copay_amt_total_ip", "clm_total_copay_amt_bronze_sgp", "clm_total_copay_amt_silver_sgp", "clm_total_copay_amt_gold_sgp", "clm_total_copay_amt_platinum_sgp", "clm_total_copay_amt_total_sgp", "clm_total_copay_amt_catastrophic",
        "clm_total_copay_amt_bronze_ms_ip", "clm_total_copay_amt_silver_ms_ip", "clm_total_copay_amt_gold_ms_ip", "clm_total_copay_amt_platinum_ms_ip", "clm_total_copay_amt_total_ms_ip", "clm_total_copay_amt_bronze_ms_sgp", "clm_total_copay_amt_silver_ms_sgp", "clm_total_copay_amt_gold_ms_sgp", "clm_total_copay_amt_platinum_ms_sgp", "clm_total_copay_amt_total_ms_sgp",
        "clm_total_coinsrn_amt_bronze_ip", "clm_total_coinsrn_amt_silver_ip", "clm_total_coinsrn_amt_gold_ip", "clm_total_coinsrn_amt_platinum_ip", "clm_total_coinsrn_amt_total_ip", "clm_total_coinsrn_amt_bronze_sgp", "clm_total_coinsrn_amt_silver_sgp", "clm_total_coinsrn_amt_gold_sgp", "clm_total_coinsrn_amt_platinum_sgp", "clm_total_coinsrn_amt_total_sgp", "clm_total_coinsrn_amt_catastrophic",
        "clm_total_coinsrn_amt_bronze_ms_ip", "clm_total_coinsrn_amt_silver_ms_ip", "clm_total_coinsrn_amt_gold_ms_ip", "clm_total_coinsrn_amt_platinum_ms_ip", "clm_total_coinsrn_amt_total_ms_ip", "clm_total_coinsrn_amt_bronze_ms_sgp", "clm_total_coinsrn_amt_silver_ms_sgp", "clm_total_coinsrn_amt_gold_ms_sgp", "clm_total_coinsrn_amt_platinum_ms_sgp", "clm_total_coinsrn_amt_total_ms_sgp")

    val clm_ddctbl = clm_coinsrnData.alias("parent").join(clm_ddctblamt.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"), $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"), $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"), col("clm_total_paid_amt_bronze_ip"), col("clm_total_paid_amt_silver_ip"), col("clm_total_paid_amt_gold_ip"), col("clm_total_paid_amt_platinum_ip"), col("clm_total_paid_amt_total_ip"), col("clm_total_paid_amt_bronze_sgp"), col("clm_total_paid_amt_silver_sgp"), col("clm_total_paid_amt_gold_sgp"), col("clm_total_paid_amt_platinum_sgp"), col("clm_total_paid_amt_total_sgp"),
        col("clm_total_paid_amt_bronze_ms_ip"), col("clm_total_paid_amt_silver_ms_ip"), col("clm_total_paid_amt_gold_ms_ip"), col("clm_total_paid_amt_platinum_ms_ip"), col("clm_total_paid_amt_total_ms_ip"), col("clm_total_paid_amt_bronze_ms_sgp"), col("clm_total_paid_amt_silver_ms_sgp"), col("clm_total_paid_amt_gold_ms_sgp"), col("clm_total_paid_amt_platinum_ms_sgp"), col("clm_total_paid_amt_total_ms_sgp"), col("clm_total_paid_amt_catastrophic"),
        col("clm_total_copay_amt_bronze_ip"), col("clm_total_copay_amt_silver_ip"), col("clm_total_copay_amt_gold_ip"), col("clm_total_copay_amt_platinum_ip"), col("clm_total_copay_amt_total_ip"), col("clm_total_copay_amt_bronze_sgp"), col("clm_total_copay_amt_silver_sgp"), col("clm_total_copay_amt_gold_sgp"), col("clm_total_copay_amt_platinum_sgp"), col("clm_total_copay_amt_total_sgp"),
        col("clm_total_copay_amt_bronze_ms_ip"), col("clm_total_copay_amt_silver_ms_ip"), col("clm_total_copay_amt_gold_ms_ip"), col("clm_total_copay_amt_platinum_ms_ip"), col("clm_total_copay_amt_total_ms_ip"), col("clm_total_copay_amt_bronze_ms_sgp"), col("clm_total_copay_amt_silver_ms_sgp"), col("clm_total_copay_amt_gold_ms_sgp"), col("clm_total_copay_amt_platinum_ms_sgp"), col("clm_total_copay_amt_total_ms_sgp"), col("clm_total_copay_amt_catastrophic"),
        col("clm_total_coinsrn_amt_bronze_ip"), col("clm_total_coinsrn_amt_silver_ip"), col("clm_total_coinsrn_amt_gold_ip"), col("clm_total_coinsrn_amt_platinum_ip"), col("clm_total_coinsrn_amt_total_ip"), col("clm_total_coinsrn_amt_bronze_sgp"), col("clm_total_coinsrn_amt_silver_sgp"), col("clm_total_coinsrn_amt_gold_sgp"), col("clm_total_coinsrn_amt_platinum_sgp"), col("clm_total_coinsrn_amt_total_sgp"),
        col("clm_total_coinsrn_amt_bronze_ms_ip"), col("clm_total_coinsrn_amt_silver_ms_ip"), col("clm_total_coinsrn_amt_gold_ms_ip"), col("clm_total_coinsrn_amt_platinum_ms_ip"), col("clm_total_coinsrn_amt_total_ms_ip"), col("clm_total_coinsrn_amt_bronze_ms_sgp"), col("clm_total_coinsrn_amt_silver_ms_sgp"), col("clm_total_coinsrn_amt_gold_ms_sgp"), col("clm_total_coinsrn_amt_platinum_ms_sgp"), col("clm_total_coinsrn_amt_total_ms_sgp"), col("clm_total_coinsrn_amt_catastrophic"),
        col("clm_total_ddctbl_amt_bronze_ip"), col("clm_total_ddctbl_amt_silver_ip"), col("clm_total_ddctbl_amt_gold_ip"), col("clm_total_ddctbl_amt_platinum_ip"), col("clm_total_ddctbl_amt_total_ip"), col("clm_total_ddctbl_amt_bronze_sgp"), col("clm_total_ddctbl_amt_silver_sgp"), col("clm_total_ddctbl_amt_gold_sgp"), col("clm_total_ddctbl_amt_platinum_sgp"), col("clm_total_ddctbl_amt_total_sgp"),
        col("clm_total_ddctbl_amt_bronze_ms_ip"), col("clm_total_ddctbl_amt_silver_ms_ip"), col("clm_total_ddctbl_amt_gold_ms_ip"), col("clm_total_ddctbl_amt_platinum_ms_ip"), col("clm_total_ddctbl_amt_total_ms_ip"), col("clm_total_ddctbl_amt_bronze_ms_sgp"), col("clm_total_ddctbl_amt_silver_ms_sgp"), col("clm_total_ddctbl_amt_gold_ms_sgp"), col("clm_total_ddctbl_amt_platinum_ms_sgp"), col("clm_total_ddctbl_amt_total_ms_sgp"), col("clm_total_ddctbl_amt_catastrophic"))

    val clm_ddctblData = clm_ddctbl.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year")).withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny")).withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state")).withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("in_exchange", "health_year", "cmpny_cf_cd", "state", "clm_total_paid_amt_bronze_ip", "clm_total_paid_amt_silver_ip", "clm_total_paid_amt_gold_ip", "clm_total_paid_amt_platinum_ip", "clm_total_paid_amt_total_ip", "clm_total_paid_amt_bronze_sgp", "clm_total_paid_amt_silver_sgp", "clm_total_paid_amt_gold_sgp", "clm_total_paid_amt_platinum_sgp", "clm_total_paid_amt_total_sgp", "clm_total_paid_amt_catastrophic",
        "clm_total_paid_amt_bronze_ms_ip", "clm_total_paid_amt_silver_ms_ip", "clm_total_paid_amt_gold_ms_ip", "clm_total_paid_amt_platinum_ms_ip", "clm_total_paid_amt_total_ms_ip", "clm_total_paid_amt_bronze_ms_sgp", "clm_total_paid_amt_silver_ms_sgp", "clm_total_paid_amt_gold_ms_sgp", "clm_total_paid_amt_platinum_ms_sgp", "clm_total_paid_amt_total_ms_sgp",
        "clm_total_copay_amt_bronze_ip", "clm_total_copay_amt_silver_ip", "clm_total_copay_amt_gold_ip", "clm_total_copay_amt_platinum_ip", "clm_total_copay_amt_total_ip", "clm_total_copay_amt_bronze_sgp", "clm_total_copay_amt_silver_sgp", "clm_total_copay_amt_gold_sgp", "clm_total_copay_amt_platinum_sgp", "clm_total_copay_amt_total_sgp", "clm_total_copay_amt_catastrophic",
        "clm_total_copay_amt_bronze_ms_ip", "clm_total_copay_amt_silver_ms_ip", "clm_total_copay_amt_gold_ms_ip", "clm_total_copay_amt_platinum_ms_ip", "clm_total_copay_amt_total_ms_ip", "clm_total_copay_amt_bronze_ms_sgp", "clm_total_copay_amt_silver_ms_sgp", "clm_total_copay_amt_gold_ms_sgp", "clm_total_copay_amt_platinum_ms_sgp", "clm_total_copay_amt_total_ms_sgp",
        "clm_total_coinsrn_amt_bronze_ip", "clm_total_coinsrn_amt_silver_ip", "clm_total_coinsrn_amt_gold_ip", "clm_total_coinsrn_amt_platinum_ip", "clm_total_coinsrn_amt_total_ip", "clm_total_coinsrn_amt_bronze_sgp", "clm_total_coinsrn_amt_silver_sgp", "clm_total_coinsrn_amt_gold_sgp", "clm_total_coinsrn_amt_platinum_sgp", "clm_total_coinsrn_amt_total_sgp", "clm_total_coinsrn_amt_catastrophic",
        "clm_total_coinsrn_amt_bronze_ms_ip", "clm_total_coinsrn_amt_silver_ms_ip", "clm_total_coinsrn_amt_gold_ms_ip", "clm_total_coinsrn_amt_platinum_ms_ip", "clm_total_coinsrn_amt_total_ms_ip", "clm_total_coinsrn_amt_bronze_ms_sgp", "clm_total_coinsrn_amt_silver_ms_sgp", "clm_total_coinsrn_amt_gold_ms_sgp", "clm_total_coinsrn_amt_platinum_ms_sgp", "clm_total_coinsrn_amt_total_ms_sgp", "clm_total_ddctbl_amt_bronze_ip", "clm_total_ddctbl_amt_silver_ip", "clm_total_ddctbl_amt_gold_ip", "clm_total_ddctbl_amt_platinum_ip", "clm_total_ddctbl_amt_total_ip", "clm_total_ddctbl_amt_bronze_sgp", "clm_total_ddctbl_amt_silver_sgp", "clm_total_ddctbl_amt_gold_sgp", "clm_total_ddctbl_amt_platinum_sgp", "clm_total_ddctbl_amt_total_sgp", "clm_total_ddctbl_amt_catastrophic",
        "clm_total_ddctbl_amt_bronze_ms_ip", "clm_total_ddctbl_amt_silver_ms_ip", "clm_total_ddctbl_amt_gold_ms_ip", "clm_total_ddctbl_amt_platinum_ms_ip", "clm_total_ddctbl_amt_total_ms_ip", "clm_total_ddctbl_amt_bronze_ms_sgp", "clm_total_ddctbl_amt_silver_ms_sgp", "clm_total_ddctbl_amt_gold_ms_sgp", "clm_total_ddctbl_amt_platinum_ms_sgp", "clm_total_ddctbl_amt_total_ms_sgp")

    clm_ddctblData
  }
}
object PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_tbl5 {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    //new PCADX_SCL_NAIC_IEXStgTransformationclmexphmcy_tbl5().sparkInIt()
  }
}