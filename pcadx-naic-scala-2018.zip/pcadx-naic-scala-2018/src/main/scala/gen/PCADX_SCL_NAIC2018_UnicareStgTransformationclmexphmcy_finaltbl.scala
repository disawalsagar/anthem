package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row
import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class PCADX_SCL_NAIC2018_UnicareStgTransformationclmexphmcy_finaltbl {

  val dbProperties = new Properties

  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()

  import spark.implicits._
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy])

  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val wrhDb = dbProperties.getProperty("warehouse.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clmex")
  val end_year = dbProperties.getProperty("end_year_clmex")
  def final_main() {

    val oexclmphrmcy = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy(spark)
    val unicare = new PCADX_SCL_NAIC2018_UnicareStgTransformationclmexphmcy(spark)

    val unicare1 = new PCADX_SCL_NAIC2018_UnicareStgTransformationclmexphmcy_1(spark)

    val naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk = oexclmphrmcy.readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_unicare_received_ip_wrk")
    val naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk = oexclmphrmcy.readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_unicare_received_lgp_wrk ")
    val naic2018_mcas_src_eob_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_src_eob_cd_inbnd")
    val naic2018_mcas_eob_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_eob_cd_inbnd")
    val naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd")
    val naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk = oexclmphrmcy.readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_unicare_paid_ip_wrk")
    val mbu_cf_cdvals = dbProperties.getProperty("mbu_Cf_cdVals").split(",").toSeq
    val naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk = oexclmphrmcy.readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_unicare_paid_lgp_wrk")
    val naic2018_mcas_pa_src_eob_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_pa_src_eob_cd_inbnd")
    val naic2018_mcas_pa_eob_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_pa_eob_cd_inbnd")
    val naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd")
    val naic2018_mcas_ce_src_eob_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_ce_src_eob_cd_inbnd")
    val naic2018_mcas_ce_eob_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_ce_eob_cd_inbnd")
    val naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd")
    val naic2018_mcas_ncb_src_eob_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_ncb_src_eob_cd_inbnd")
    val naic2018_mcas_ncb_eob_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_ncb_eob_cd_inbnd")
    val naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd")

    val naic2018_mcas_nmn_src_eob_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_nmn_src_eob_cd_inbnd")

    val naic2018_mcas_nmn_eob_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_nmn_eob_cd_inbnd")
    val naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd")
    val naic2018_mcas_nmnbh_icd_diag_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_nmnbh_icd_diag_cd_inbnd")
   // val naic2018_mcas_nmnbh_icd_proc_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_nmnbh_icd_proc_cd_inbnd")
   // val naic2018_mcas_nmnbh_hlth_srvc_cd_inbnd = oexclmphrmcy.readDataFromHive(dbInbnd + ".naic2018_mcas_nmnbh_hlth_srvc_cd_inbnd")

    var load_log_key = ""

    if (!naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.take(1).isEmpty) {
      load_log_key = naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.select($"load_log_key").first.getString(0)
    }
    
    val tbl1 = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl1(spark)

    val objclmReceivedData = unicare.clmReceivedData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk)
    val objsubInntwkData = unicare.getSubInntwkData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk)
    val objsubOutntwkData = unicare.getSubOutntwkData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk)
    val objDeniedInntwk = unicare.getDeniedInntwk(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk0_30 = unicare.getDeniedInntwkBetweenDates(0, 30, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk31_60 = unicare.getDeniedInntwkBetweenDates(31, 60, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk61_90 = unicare.getDeniedInntwkBetweenDates(61, 90, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk_90 = unicare.getDeniedInntwk_90(end_year, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    var tbl1Data = tbl1.getStageData(objclmReceivedData, objsubInntwkData, objsubOutntwkData, objDeniedInntwk, objDeniedInntwk0_30, objDeniedInntwk31_60,
      objDeniedInntwk61_90, objDeniedInntwk_90)

    tbl1Data = tbl1Data.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
    
    unicare.writeDataToHive(dbwrk + ".naic2018_mcas_hlthoex_clmexphmcy_recDeninColstemp", tbl1Data)
    

    val tbl2 = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl2(spark)
    val objDeniedOutntwk = unicare.getDeniedOutntwk(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk,
      naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedOutntwk0_30 = unicare.getDeniedOutntwkBetweenDates(0, 30, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedOutntwk31_60 = unicare.getDeniedOutntwkBetweenDates(31, 60, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedOutntwk61_90 = unicare.getDeniedOutntwkBetweenDates(61, 90, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedOutntwk_90 = unicare.getDeniedOutntwk_90(end_year, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    var tbl2Data = tbl2.getStageData(objDeniedOutntwk,
      objDeniedOutntwk0_30, objDeniedOutntwk31_60, objDeniedOutntwk61_90, objDeniedOutntwk_90)
    tbl2Data = tbl2Data.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
    unicare.writeDataToHive(dbwrk + ".naic2018_mcas_hlthoex_clmexphmcy_DenoutColstemp", tbl2Data)
    
    val tbl3 = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl3(spark)

    val objPaidInntwk = unicare1.getPaidInntwk(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val objPaidInntwk0_30 = unicare1.getPaidInntwkBetweenDays(0, 30, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val objPaidInntwk31_60 = unicare1.getPaidInntwkBetweenDays(31, 60, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val objPaidInntwk61_90 = unicare1.getPaidInntwkBetweenDays(61, 90, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val objPaidInntwk_90 = unicare1.getPaidInntwk_90(end_year, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)

    var tbl3Data = tbl3.getStageData(objPaidInntwk, objPaidInntwk0_30, objPaidInntwk31_60, objPaidInntwk61_90, objPaidInntwk_90)

    tbl3Data = tbl3Data.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
    unicare.writeDataToHive(dbwrk + ".naic2018_mcas_hlthoex_clmexphmcy_paidInColstemp", tbl3Data)
    
    val tbl4 = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl4(spark)
    val objPaidOutntwk = unicare1.getPaidOutntwk(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val objPaidOutntwk0_30 = unicare1.getPaidOutntwkBetweenDays(0, 30, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val objPaidOutntwk31_60 = unicare1.getPaidOutntwkBetweenDays(31, 60, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val objPaidOutntwk61_90 = unicare1.getPaidOutntwkBetweenDays(61, 90, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val objPaidOutntwk_90 = unicare1.getPaidOutntwk_90(end_year, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    var tbl4Data = tbl4.getStageData(objPaidOutntwk, objPaidOutntwk0_30, objPaidOutntwk31_60, objPaidOutntwk61_90, objPaidOutntwk_90)

    tbl4Data = tbl4Data.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
    unicare.writeDataToHive(dbwrk + ".naic2018_mcas_hlthoex_clmexphmcy_paidOutColstemp", tbl4Data)
    
    val tbl5 = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl5(spark)
    val clm_paidamt = unicare1.getamtData("PAID_AMT", "paid", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val clm_cpayamt = unicare1.getamtData("CPAY_AMT", "copay", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val clm_coinsrnamt = unicare1.getamtData("COINSRN_AMT", "coinsrn", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val clm_ddctblamt = unicare1.getamtData("DDCTBL_AMT", "ddctbl", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)

    var tbl5Data = tbl5.getStageData(clm_paidamt, clm_cpayamt, clm_coinsrnamt, clm_ddctblamt)
    tbl5Data = tbl5Data.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
    unicare.writeDataToHive(dbwrk + ".naic2018_mcas_hlthoex_clmexphmcy_amtColstemp", tbl5Data)
    
    val objdeniedceInntwk = unicare.getdeniedPAInntwk("ce", naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)
    val objdeniedPAInntwk1 = unicare.getdeniedPAInntwk("pa", naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)
    val objdeniedncbInntwk2 = unicare.getdeniedPAInntwk("ncb", naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)
    val objdeniedbhInntwk2 = unicare.getdeniedbhebhInntwk("bh", naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
    val objdeniedebhInntwk2 = unicare.getdeniedbhebhInntwk("ebh", naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val tbl6 = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl1_1(spark)
   
    var tbl6Data = tbl6.getStageData(objdeniedceInntwk, objdeniedPAInntwk1, objdeniedncbInntwk2, objdeniedebhInntwk2, objdeniedbhInntwk2)

    tbl6Data = tbl6Data.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
    unicare.writeDataToHive(dbwrk + ".naic2018_mcas_hlthoex_clmexphmcy_deniedInntwktemp", tbl6Data)

    val objdeniedceoutnwk = unicare.getdeniedPAoutntwk("ce", naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)
    val objdeniedPAoutnwk1 = unicare.getdeniedPAoutntwk("pa", naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)
    val objdeniedncboutnwk2 = unicare.getdeniedPAoutntwk("ncb", naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)
    val objdeniedbhoutnwk2 = unicare.getdeniedbhebhoutntwk("bh", naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd)
    val objdeniedebhoutnwk2 = unicare.getdeniedbhebhoutntwk("ebh", naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

    val tbl7 = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_tbl2_1(spark)
    
    var tbl7Data = tbl7.getStageData(objdeniedceoutnwk, objdeniedPAoutnwk1, objdeniedncboutnwk2, objdeniedebhoutnwk2, objdeniedbhoutnwk2)
    
    tbl7Data = tbl7Data.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
    
     unicare.writeDataToHive(dbwrk + ".naic2018_mcas_hlthoex_clmexphmcy_deniedOutntwktemp", tbl7Data)
    
     new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_finaltbl().sparkInIt()
     
    spark.close()

  }
}

object PCADX_SCL_NAIC2018_UnicareStgTransformationclmexphmcy_finaltbl {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    new PCADX_SCL_NAIC2018_UnicareStgTransformationclmexphmcy_finaltbl().final_main()
  }
}