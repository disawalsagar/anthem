package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
class PCADX_SCL_NAIC2018_OexStgTransformationPAPHMCY {

	val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
			config("hive.exec.dynamic.partition.mode", "nonstrict").
			config("spark.sql.parquet.compression.codec", "snappy").
			config("hive.warehouse.data.skipTrash", "true").
			config("spark.sql.parquet.writeLegacyFormat", "true").
			enableHiveSupport().getOrCreate()

			import spark.implicits._

			val dbProperties = new Properties
			dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
			var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_OexStgTransformationPAPHMCY])
			val dbsg = dbProperties.getProperty("stage.db")
			val dbwrk = dbProperties.getProperty("work.db")
			val uri: String = dbProperties.getProperty("uri")
			val naic_lob_lgp = Seq("LARGE GROUP CBE EXCLUDING MEDICARE"  , "TOTAL NATIONAL CBE")
			val  mbu_cf_cdvals= dbProperties.getProperty("mbu_Cf_cdVals").split(",").toSeq

			def sparkInIt() {

				val naic2018_mcas_hlthex_paphmcy_reqstd_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_paphmcy_reqstd_wrk")
						val naic2018_mcas_hlthex_paphmcy_apprvd_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_paphmcy_apprvd_wrk")
						val naic2018_mcas_hlthex_paphmcy_denied_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_paphmcy_denied_wrk")
						val stageTblData = populateStageTbl(naic2018_mcas_hlthex_paphmcy_reqstd_wrk, naic2018_mcas_hlthex_paphmcy_apprvd_wrk, naic2018_mcas_hlthex_paphmcy_denied_wrk)
						writeDataToHive(dbsg + ".naic2018_mcas_hlthoex_paphmcy_stg", stageTblData)
						spark.close()

			}

			def writeDataToHive(tblName: String, finalDf: DataFrame) {
				finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
				println("Data added in stage table")
			}

			def readDataFromHive(tble: String): DataFrame = {
					val queryOutputTable = """SELECT * FROM """ + tble
							val tbl_data_df = spark.sql(queryOutputTable)
							logger.info("Read data from hive")
							tbl_data_df
			}


			def populateStageTbl(naic2018_mcas_hlthex_paphmcy_reqstd_wrk: DataFrame, naic2018_mcas_hlthex_paphmcy_apprvd_wrk: DataFrame,
					naic2018_mcas_hlthex_paphmcy_denied_wrk: DataFrame): DataFrame = {

							val final_df = null
									val reqFinalDf = getRequestedData(naic2018_mcas_hlthex_paphmcy_reqstd_wrk)
									val appFinalDf = getApprovededData(naic2018_mcas_hlthex_paphmcy_apprvd_wrk, naic2018_mcas_hlthex_paphmcy_reqstd_wrk)
									val denFinalDf = getDeniedData(naic2018_mcas_hlthex_paphmcy_denied_wrk, naic2018_mcas_hlthex_paphmcy_reqstd_wrk)
									val stageTblData = getFinalData(reqFinalDf,appFinalDf,denFinalDf).toDF()
									var load_log_key = ""
									if(!naic2018_mcas_hlthex_paphmcy_reqstd_wrk.take(1).isEmpty) 
									{
										load_log_key = naic2018_mcas_hlthex_paphmcy_reqstd_wrk.select($"load_log_key").first.getString(0)
									}
							val finalStageTblData =stageTblData.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());

							finalStageTblData
			}

			def getRequestedData(naic2018_mcas_hlthex_paphmcy_reqstd_wrk: DataFrame ): DataFrame = {



					val nbrpa_rqstd_total_ip = naic2018_mcas_hlthex_paphmcy_reqstd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") 
									&& (naic2018_mcas_hlthex_paphmcy_reqstd_wrk("grndfthr_ind_cd").notEqual("YES") ||  naic2018_mcas_hlthex_paphmcy_reqstd_wrk("grndfthr_ind_cd").isNull)
									&& (naic2018_mcas_hlthex_paphmcy_reqstd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paphmcy_reqstd_wrk("src_exchng_certfn_cd").isNull)
									&& naic2018_mcas_hlthex_paphmcy_reqstd_wrk("hcr_cmplynt_cd").equalTo("Y")  
									&& naic2018_mcas_hlthex_paphmcy_reqstd_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r1"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r1"),$"state".alias("state_r1")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_rqstd_total_ip"))

							val nbrpa_rqstd_total_ip_pcols = nbrpa_rqstd_total_ip.select($"health_year_r1",$"cmpny_cf_cd_r1",$"state_r1")





							val nbrpa_rqstd_total_sgp = naic2018_mcas_hlthex_paphmcy_reqstd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") 
									&& (naic2018_mcas_hlthex_paphmcy_reqstd_wrk("grndfthr_ind_cd").notEqual("YES") ||  naic2018_mcas_hlthex_paphmcy_reqstd_wrk("grndfthr_ind_cd").isNull)
									&& (naic2018_mcas_hlthex_paphmcy_reqstd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paphmcy_reqstd_wrk("src_exchng_certfn_cd").isNull)
									&& naic2018_mcas_hlthex_paphmcy_reqstd_wrk("hcr_cmplynt_cd").equalTo("Y") 
									&& naic2018_mcas_hlthex_paphmcy_reqstd_wrk("in_exchange").isNull)
							.groupBy($"health_year".alias("health_year_r2"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r2"),$"state".alias("state_r2")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_rqstd_total_sgp"))


							val nbrpa_rqstd_total_sgp_pcols = nbrpa_rqstd_total_sgp.select($"health_year_r2",$"cmpny_cf_cd_r2",$"state_r2")




							val nbrpa_rqstd_gtlgp = naic2018_mcas_hlthex_paphmcy_reqstd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_reqstd_wrk("naic_lob").isin(naic_lob_lgp:_*) 
									&& naic2018_mcas_hlthex_paphmcy_reqstd_wrk("grndfthr_ind_cd").equalTo("YES")
									&& naic2018_mcas_hlthex_paphmcy_reqstd_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r6"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r6"),$"state".alias("state_r6")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_rqstd_gtlgp"))


							val nbrpa_rqstd_gtlgpcols = nbrpa_rqstd_gtlgp.select($"health_year_r6",$"cmpny_cf_cd_r6",$"state_r6") 

							val nbrpa_rqstd_gtsgp = naic2018_mcas_hlthex_paphmcy_reqstd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")  
									&& (naic2018_mcas_hlthex_paphmcy_reqstd_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paphmcy_reqstd_wrk("hcr_cmplynt_cd").notEqual("Y")  || naic2018_mcas_hlthex_paphmcy_reqstd_wrk("hcr_cmplynt_cd").isNull)  
									&& naic2018_mcas_hlthex_paphmcy_reqstd_wrk("in_exchange").isNull)
							.groupBy($"health_year".alias("health_year_r7"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r7"),$"state".alias("state_r7")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_rqstd_gtsgp"))

							val nbrpa_rqstd_gtsgpcols = nbrpa_rqstd_gtsgp.select($"health_year_r7",$"cmpny_cf_cd_r7",$"state_r7")


							val nbrpa_rqstd_gtip = naic2018_mcas_hlthex_paphmcy_reqstd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_reqstd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")  
									&& (naic2018_mcas_hlthex_paphmcy_reqstd_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paphmcy_reqstd_wrk("hcr_cmplynt_cd").notEqual("Y") || naic2018_mcas_hlthex_paphmcy_reqstd_wrk("hcr_cmplynt_cd").isNull )    
									&& naic2018_mcas_hlthex_paphmcy_reqstd_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r8"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r8"),$"state".alias("state_r8")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_rqstd_gtip"))

							val nbrpa_rqstd_gtipcols = nbrpa_rqstd_gtip.select($"health_year_r8",$"cmpny_cf_cd_r8",$"state_r8")

							val getTotal_ip =  nbrpa_rqstd_gtlgp.union(nbrpa_rqstd_gtsgp.union(nbrpa_rqstd_gtip))
							.select($"health_year_r6".alias("health_year_r11"), $"cmpny_cf_cd_r6".alias("cmpny_cf_cd_r11"), $"state_r6".alias("state_r11"), $"nbrpa_rqstd_gtlgp")

							val nbrpa_rqstd_total_gtip = getTotal_ip.groupBy("health_year_r11","cmpny_cf_cd_r11", "state_r11").agg(sum($"nbrpa_rqstd_gtlgp").alias("nbrpa_rqstd_total_gtip"))


							val nbrpa_rqstd_total_gtipcols =   nbrpa_rqstd_total_gtip.select($"health_year_r11",$"cmpny_cf_cd_r11",$"state_r11")


							val nbrpa_rqstd_catastrophic  = naic2018_mcas_hlthex_paphmcy_reqstd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_reqstd_wrk("naic_prod_desc").like("%CATASTROPHIC%")
									&& naic2018_mcas_hlthex_paphmcy_reqstd_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r3"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r3"),$"state".alias("state_r3")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_rqstd_catastrophic"))

							val nbrpa_rqstd_catastrophic_pcols = nbrpa_rqstd_catastrophic.select($"health_year_r3",$"cmpny_cf_cd_r3",$"state_r3")


							val nbrpa_rqstd_lgp_mmcare = naic2018_mcas_hlthex_paphmcy_reqstd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_reqstd_wrk("naic_lob").isin(naic_lob_lgp:_*)
									&& (naic2018_mcas_hlthex_paphmcy_reqstd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paphmcy_reqstd_wrk("grndfthr_ind_cd").isNull)
									&& (!naic2018_mcas_hlthex_paphmcy_reqstd_wrk("mbu_cf_cd").isin(mbu_cf_cdvals:_*)) 
									&& naic2018_mcas_hlthex_paphmcy_reqstd_wrk("in_exchange").isNull)
							.groupBy($"health_year".alias("health_year_r9"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r9"),$"state".alias("state_r9")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_rqstd_lgp_mmcare"))

							val nbrpa_rqstd_lgp_mmcarepcols = nbrpa_rqstd_lgp_mmcare.select($"health_year_r9",$"cmpny_cf_cd_r9",$"state_r9")


							val nbrpa_rqstd_stucvg = naic2018_mcas_hlthex_paphmcy_reqstd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_reqstd_wrk("naic_lob").isin(naic_lob_lgp:_*) 
									&& naic2018_mcas_hlthex_paphmcy_reqstd_wrk("mbu_cf_cd").isin(mbu_cf_cdvals:_*) 
									&& naic2018_mcas_hlthex_paphmcy_reqstd_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r10"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r10"),$"state".alias("state_r10")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_rqstd_stucvg"))
							val nbrpa_rqstd_stucvgcols = nbrpa_rqstd_stucvg.select($"health_year_r10",$"cmpny_cf_cd_r10",$"state_r10") 

							val reqmaster = (nbrpa_rqstd_total_ip_pcols.union(nbrpa_rqstd_total_sgp_pcols.union(nbrpa_rqstd_gtlgpcols.union(nbrpa_rqstd_gtsgpcols
									.union(nbrpa_rqstd_gtipcols.union(nbrpa_rqstd_total_gtipcols.union(nbrpa_rqstd_catastrophic_pcols.union(nbrpa_rqstd_lgp_mmcarepcols.union(nbrpa_rqstd_stucvgcols)))))))))
							.select($"health_year_r1".alias("health_year"),$"cmpny_cf_cd_r1".alias("cmpny_cf_cd"),$"state_r1".alias("state")).distinct
							//val reqmaster_1 = (nbrpa_rqstd_total_ms_sgp_pcols.union(nbrpa_rqstd_total_ms_ip_pcols.union(nbrpa_rqstd_catastrophic_pcols.union(nbrpa_rqstd_total_ip_pcols.union(nbrpa_rqstd_total_sgp_pcols))))).select($"health_year_r5".alias("health_year"),$"cmpny_cf_cd_r5".alias("cmpny_cf_cd"),$"state_r5".alias("state")).distinct


							val reqjoin1 = reqmaster.join(nbrpa_rqstd_total_ip,reqmaster("health_year")===nbrpa_rqstd_total_ip("health_year_r1") &&
							reqmaster("cmpny_cf_cd")===nbrpa_rqstd_total_ip("cmpny_cf_cd_r1") && reqmaster("state")===nbrpa_rqstd_total_ip("state_r1") ,"left_outer").select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_rqstd_total_ip")

							val reqjoin2 = reqjoin1.join(nbrpa_rqstd_total_sgp,reqjoin1("health_year")===nbrpa_rqstd_total_sgp("health_year_r2") &&
							reqjoin1("cmpny_cf_cd")===nbrpa_rqstd_total_sgp("cmpny_cf_cd_r2") && reqjoin1("state")===nbrpa_rqstd_total_sgp("state_r2")  ,"left_outer").select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_rqstd_total_ip",$"nbrpa_rqstd_total_sgp")



							val reqjoin3 = reqjoin2.join(nbrpa_rqstd_gtlgp,reqjoin2("health_year")===nbrpa_rqstd_gtlgp("health_year_r6") &&
							reqjoin2("cmpny_cf_cd")===nbrpa_rqstd_gtlgp("cmpny_cf_cd_r6") && reqjoin2("state")===nbrpa_rqstd_gtlgp("state_r6")  ,"left_outer").select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_rqstd_total_ip",$"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp")


							val reqjoin4 = reqjoin3.join(nbrpa_rqstd_gtsgp,reqjoin3("health_year")===nbrpa_rqstd_gtsgp("health_year_r7") &&
							reqjoin3("cmpny_cf_cd")===nbrpa_rqstd_gtsgp("cmpny_cf_cd_r7") && reqjoin3("state")===nbrpa_rqstd_gtsgp("state_r7") ,"left_outer").select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_rqstd_total_ip",$"nbrpa_rqstd_total_sgp", $"nbrpa_rqstd_gtlgp",$"nbrpa_rqstd_gtsgp")

							val reqjoin5 = reqjoin4.join(nbrpa_rqstd_gtip,reqjoin4("health_year")===nbrpa_rqstd_gtip("health_year_r8") &&
							reqjoin4("cmpny_cf_cd")===nbrpa_rqstd_gtip("cmpny_cf_cd_r8") && reqjoin4("state")===nbrpa_rqstd_gtip("state_r8")  ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_rqstd_total_ip",$"nbrpa_rqstd_total_sgp", 
									$"nbrpa_rqstd_gtlgp",$"nbrpa_rqstd_gtsgp",$"nbrpa_rqstd_gtip")




							val reqjoin6 = reqjoin5.join(nbrpa_rqstd_total_gtip,reqjoin5("health_year")===nbrpa_rqstd_total_gtip("health_year_r11") &&
							reqjoin5("cmpny_cf_cd")===nbrpa_rqstd_total_gtip("cmpny_cf_cd_r11") && reqjoin5("state")===nbrpa_rqstd_total_gtip("state_r11")  ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_rqstd_total_ip",$"nbrpa_rqstd_total_sgp", 
									$"nbrpa_rqstd_gtlgp",$"nbrpa_rqstd_gtsgp",$"nbrpa_rqstd_gtip",$"nbrpa_rqstd_total_gtip")

							val reqjoin7 = reqjoin6.join(nbrpa_rqstd_catastrophic,reqjoin6("health_year")===nbrpa_rqstd_catastrophic("health_year_r3") &&
							reqjoin6("cmpny_cf_cd")===nbrpa_rqstd_catastrophic("cmpny_cf_cd_r3") && reqjoin6("state")===nbrpa_rqstd_catastrophic("state_r3")  ,"left_outer").select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_rqstd_total_ip",$"nbrpa_rqstd_total_sgp",
									$"nbrpa_rqstd_gtlgp",$"nbrpa_rqstd_gtsgp",$"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic")

							val reqjoin8 = reqjoin7.join(nbrpa_rqstd_lgp_mmcare,reqjoin7("health_year")===nbrpa_rqstd_lgp_mmcare("health_year_r9") &&
							reqjoin7("cmpny_cf_cd")===nbrpa_rqstd_lgp_mmcare("cmpny_cf_cd_r9") && reqjoin7("state")===nbrpa_rqstd_lgp_mmcare("state_r9")  ,"left_outer").select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_rqstd_total_ip",$"nbrpa_rqstd_total_sgp",
									$"nbrpa_rqstd_gtlgp",$"nbrpa_rqstd_gtsgp",$"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_lgp_mmcare")


							val reqFinalDf = reqjoin8.join(nbrpa_rqstd_stucvg,reqjoin8("health_year")===nbrpa_rqstd_stucvg("health_year_r10") &&
							reqjoin8("cmpny_cf_cd")===nbrpa_rqstd_stucvg("cmpny_cf_cd_r10") && reqjoin8("state")===nbrpa_rqstd_stucvg("state_r10") ,"left_outer").select($"health_year".alias("health_year_requested"),$"cmpny_cf_cd".alias("cmpny_cf_cd_requested"),$"state".alias("state_requested"),$"nbrpa_rqstd_total_ip",$"nbrpa_rqstd_total_sgp",
									$"nbrpa_rqstd_gtlgp",$"nbrpa_rqstd_gtsgp",$"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg")


							reqFinalDf

			}

			def getApprovededData(naic2018_mcas_hlthex_paphmcy_apprvd_wrk: DataFrame, naic2018_mcas_hlthex_paphmcy_reqstd_wrk: DataFrame): DataFrame = {

					val nbrpa_aprvd_total_ip = naic2018_mcas_hlthex_paphmcy_apprvd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") 
									&&( naic2018_mcas_hlthex_paphmcy_apprvd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paphmcy_apprvd_wrk("grndfthr_ind_cd").isNull ) 
									&& (naic2018_mcas_hlthex_paphmcy_apprvd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paphmcy_apprvd_wrk("src_exchng_certfn_cd").isNull)
									&& naic2018_mcas_hlthex_paphmcy_apprvd_wrk("hcr_cmplynt_cd").equalTo("Y")  
									&& naic2018_mcas_hlthex_paphmcy_apprvd_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r1"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r1"),$"state".alias("state_r1")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_aprvd_total_ip"))

							val nbrpa_aprvd_total_ip_pcols = nbrpa_aprvd_total_ip.select($"health_year_r1",$"cmpny_cf_cd_r1",$"state_r1")



							val nbrpa_aprvd_total_sgp = naic2018_mcas_hlthex_paphmcy_apprvd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") 
									&&( naic2018_mcas_hlthex_paphmcy_apprvd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paphmcy_apprvd_wrk("grndfthr_ind_cd").isNull ) 
									&& (naic2018_mcas_hlthex_paphmcy_apprvd_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paphmcy_apprvd_wrk("src_exchng_certfn_cd").isNull)
									&& naic2018_mcas_hlthex_paphmcy_apprvd_wrk("hcr_cmplynt_cd").equalTo("Y") 
									&& naic2018_mcas_hlthex_paphmcy_apprvd_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r2"),
									$"cmpny_cf_cd".alias("cmpny_cf_cd_r2"),
									$"state".alias("state_r2")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_aprvd_total_sgp"))


							val nbrpa_aprvd_total_sgp_pcols = nbrpa_aprvd_total_sgp.select($"health_year_r2",$"cmpny_cf_cd_r2",$"state_r2")

							val nbrpa_aprvd_gtlgp = naic2018_mcas_hlthex_paphmcy_apprvd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_apprvd_wrk("naic_lob").isin(naic_lob_lgp:_*)  
									&& naic2018_mcas_hlthex_paphmcy_apprvd_wrk("grndfthr_ind_cd").equalTo("YES")
									&& naic2018_mcas_hlthex_paphmcy_apprvd_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r6"),
									$"cmpny_cf_cd".alias("cmpny_cf_cd_r6"),
									$"state".alias("state_r6")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_aprvd_gtlgp"))


							val nbrpa_aprvd_gtlgpcols =  nbrpa_aprvd_gtlgp.select($"health_year_r6",$"cmpny_cf_cd_r6",$"state_r6")  

							val nbrpa_aprvd_gtsgp = naic2018_mcas_hlthex_paphmcy_apprvd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")  
									&& (naic2018_mcas_hlthex_paphmcy_apprvd_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paphmcy_apprvd_wrk("hcr_cmplynt_cd").notEqual("Y")   || naic2018_mcas_hlthex_paphmcy_apprvd_wrk("hcr_cmplynt_cd").isNull) 
									&& naic2018_mcas_hlthex_paphmcy_apprvd_wrk("in_exchange").isNull)
							.groupBy($"health_year".alias("health_year_r7"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r7"),$"state".alias("state_r7")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_aprvd_gtsgp"))

							val nbrpa_aprvd_gtsgpcols =  nbrpa_aprvd_gtsgp.select($"health_year_r7",$"cmpny_cf_cd_r7",$"state_r7")


							val nbrpa_aprvd_gtip = naic2018_mcas_hlthex_paphmcy_apprvd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_apprvd_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")  
									&& (naic2018_mcas_hlthex_paphmcy_apprvd_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paphmcy_apprvd_wrk("hcr_cmplynt_cd").notEqual("Y")  || naic2018_mcas_hlthex_paphmcy_apprvd_wrk("hcr_cmplynt_cd").isNull) 
									&& naic2018_mcas_hlthex_paphmcy_apprvd_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r8"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r8"),$"state".alias("state_r8")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_aprvd_gtip"))

							val nbrpa_aprvd_gtipcols = nbrpa_aprvd_gtip.select($"health_year_r8",$"cmpny_cf_cd_r8",$"state_r8")


							val getTotal_ip = nbrpa_aprvd_gtlgp.union(nbrpa_aprvd_gtsgp.union(nbrpa_aprvd_gtip)).select($"health_year_r6".alias("health_year_r11"),
									$"cmpny_cf_cd_r6".alias("cmpny_cf_cd_r11"), 
									$"state_r6".alias("state_r11"),
									$"nbrpa_aprvd_gtlgp")

							val nbrpa_aprvd_total_gtip = getTotal_ip.groupBy("health_year_r11","cmpny_cf_cd_r11", "state_r11").agg(sum($"nbrpa_aprvd_gtlgp").alias("nbrpa_aprvd_total_gtip"))

							val nbrpa_aprvd_total_gtipcols =     nbrpa_aprvd_total_gtip.select($"health_year_r11",$"cmpny_cf_cd_r11",$"state_r11")

							val nbrpa_aprvd_catastrophic  = naic2018_mcas_hlthex_paphmcy_apprvd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_apprvd_wrk("naic_prod_desc").like("%CATASTROPHIC%")
									&& naic2018_mcas_hlthex_paphmcy_apprvd_wrk("in_exchange").isNull)
							.groupBy($"health_year".alias("health_year_r3"),
									$"cmpny_cf_cd".alias("cmpny_cf_cd_r3"),
									$"state".alias("state_r3")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_aprvd_catastrophic"))

							val nbrpa_aprvd_catastrophic_pcols = nbrpa_aprvd_catastrophic.select($"health_year_r3",$"cmpny_cf_cd_r3",$"state_r3")

							val nbrpa_aprvd_lgp_mmcare = naic2018_mcas_hlthex_paphmcy_apprvd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_apprvd_wrk("naic_lob").isin(naic_lob_lgp:_*) 
									&& (naic2018_mcas_hlthex_paphmcy_apprvd_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paphmcy_apprvd_wrk("grndfthr_ind_cd").isNull)
									&& (!naic2018_mcas_hlthex_paphmcy_apprvd_wrk("mbu_cf_cd").isin(mbu_cf_cdvals:_*)) 
									&& naic2018_mcas_hlthex_paphmcy_apprvd_wrk("in_exchange").isNull)
							.groupBy($"health_year".alias("health_year_r9"),
									$"cmpny_cf_cd".alias("cmpny_cf_cd_r9"),
									$"state".alias("state_r9")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_aprvd_lgp_mmcare"))


							val nbrpa_aprvd_lgp_mmcarepcols = nbrpa_aprvd_lgp_mmcare.select($"health_year_r9",$"cmpny_cf_cd_r9",$"state_r9")


							val nbrpa_aprvd_stucvg = naic2018_mcas_hlthex_paphmcy_apprvd_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_apprvd_wrk("naic_lob").isin(naic_lob_lgp:_*) 
									&& naic2018_mcas_hlthex_paphmcy_apprvd_wrk("mbu_cf_cd").isin(mbu_cf_cdvals:_*) 
									&& naic2018_mcas_hlthex_paphmcy_apprvd_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r10"),
									$"cmpny_cf_cd".alias("cmpny_cf_cd_r10"),
									$"state".alias("state_r10")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_aprvd_stucvg"))
							val nbrpa_aprvd_stucvgcols = nbrpa_aprvd_stucvg.select($"health_year_r10",$"cmpny_cf_cd_r10",$"state_r10") 

							val aprvmaster = (nbrpa_aprvd_total_ip_pcols.union(nbrpa_aprvd_total_sgp_pcols.union(nbrpa_aprvd_gtlgpcols.union(nbrpa_aprvd_gtsgpcols
									.union(nbrpa_aprvd_gtipcols.union(nbrpa_aprvd_total_gtipcols.union(nbrpa_aprvd_catastrophic_pcols
											.union(nbrpa_aprvd_lgp_mmcarepcols.union(nbrpa_aprvd_stucvgcols)))))))))
							.select($"health_year_r1".alias("health_year"),
									$"cmpny_cf_cd_r1".alias("cmpny_cf_cd"),
									$"state_r1".alias("state")).distinct

							val aprvjoin1 = aprvmaster.join(nbrpa_aprvd_total_ip,aprvmaster("health_year")===nbrpa_aprvd_total_ip("health_year_r1") &&
							aprvmaster("cmpny_cf_cd")===nbrpa_aprvd_total_ip("cmpny_cf_cd_r1") && 
							aprvmaster("state")===nbrpa_aprvd_total_ip("state_r1") 
							,"left_outer").select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_aprvd_total_ip")

							val aprvjoin2 = aprvjoin1.join(nbrpa_aprvd_total_sgp,aprvjoin1("health_year")===nbrpa_aprvd_total_sgp("health_year_r2") &&
							aprvjoin1("cmpny_cf_cd")===nbrpa_aprvd_total_sgp("cmpny_cf_cd_r2") &&
							aprvjoin1("state")===nbrpa_aprvd_total_sgp("state_r2") ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_aprvd_total_ip",$"nbrpa_aprvd_total_sgp")

							val aprvjoin3 = aprvjoin2.join(nbrpa_aprvd_gtlgp,aprvjoin2("health_year")===nbrpa_aprvd_gtlgp("health_year_r6") &&
							aprvjoin2("cmpny_cf_cd")===nbrpa_aprvd_gtlgp("cmpny_cf_cd_r6") &&
							aprvjoin2("state")===nbrpa_aprvd_gtlgp("state_r6")  ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_aprvd_total_ip",
									$"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp")


							val aprvjoin4 = aprvjoin3.join(nbrpa_aprvd_gtsgp,aprvjoin3("health_year")===nbrpa_aprvd_gtsgp("health_year_r7") &&
							aprvjoin3("cmpny_cf_cd")===nbrpa_aprvd_gtsgp("cmpny_cf_cd_r7") && 
							aprvjoin3("state")===nbrpa_aprvd_gtsgp("state_r7") ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_aprvd_total_ip",
									$"nbrpa_aprvd_total_sgp", $"nbrpa_aprvd_gtlgp",$"nbrpa_aprvd_gtsgp")

							val aprvjoin5 = aprvjoin4.join(nbrpa_aprvd_gtip,aprvjoin4("health_year")===nbrpa_aprvd_gtip("health_year_r8") &&
							aprvjoin4("cmpny_cf_cd")===nbrpa_aprvd_gtip("cmpny_cf_cd_r8") && 
							aprvjoin4("state")===nbrpa_aprvd_gtip("state_r8")  ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_aprvd_total_ip",$"nbrpa_aprvd_total_sgp", 
									$"nbrpa_aprvd_gtlgp",$"nbrpa_aprvd_gtsgp",$"nbrpa_aprvd_gtip")



							val aprvjoin6 = aprvjoin5.join(nbrpa_aprvd_total_gtip,aprvjoin5("health_year")===nbrpa_aprvd_total_gtip("health_year_r11") &&
							aprvjoin5("cmpny_cf_cd")===nbrpa_aprvd_total_gtip("cmpny_cf_cd_r11") && 
							aprvjoin5("state")===nbrpa_aprvd_total_gtip("state_r11") ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_aprvd_total_ip",$"nbrpa_aprvd_total_sgp", 
									$"nbrpa_aprvd_gtlgp",$"nbrpa_aprvd_gtsgp",$"nbrpa_aprvd_gtip",$"nbrpa_aprvd_total_gtip")

							val aprvjoin7 = aprvjoin6.join(nbrpa_aprvd_catastrophic,aprvjoin6("health_year")===nbrpa_aprvd_catastrophic("health_year_r3") &&
							aprvjoin6("cmpny_cf_cd")===nbrpa_aprvd_catastrophic("cmpny_cf_cd_r3") && 
							aprvjoin6("state")===nbrpa_aprvd_catastrophic("state_r3")  ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_aprvd_total_ip",$"nbrpa_aprvd_total_sgp",
									$"nbrpa_aprvd_gtlgp",$"nbrpa_aprvd_gtsgp",$"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic")

							val aprvjoin8 = aprvjoin7.join(nbrpa_aprvd_lgp_mmcare,aprvjoin7("health_year")===nbrpa_aprvd_lgp_mmcare("health_year_r9") &&
							aprvjoin7("cmpny_cf_cd")===nbrpa_aprvd_lgp_mmcare("cmpny_cf_cd_r9") && 
							aprvjoin7("state")===nbrpa_aprvd_lgp_mmcare("state_r9")  ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_aprvd_total_ip",$"nbrpa_aprvd_total_sgp",
									$"nbrpa_aprvd_gtlgp",$"nbrpa_aprvd_gtsgp",$"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip",
									$"nbrpa_aprvd_catastrophic", $"nbrpa_aprvd_lgp_mmcare")


							val aprvFinalDf = aprvjoin8.join(nbrpa_aprvd_stucvg,aprvjoin8("health_year")===nbrpa_aprvd_stucvg("health_year_r10") &&
							aprvjoin8("cmpny_cf_cd")===nbrpa_aprvd_stucvg("cmpny_cf_cd_r10") && 
							aprvjoin8("state")===nbrpa_aprvd_stucvg("state_r10")  ,"left_outer")
							.select($"health_year".alias("health_year_approved"),$"cmpny_cf_cd".alias("cmpny_cf_cd_approved"),
									$"state".alias("state_approved"),
									$"nbrpa_aprvd_total_ip",$"nbrpa_aprvd_total_sgp",
									$"nbrpa_aprvd_gtlgp",$"nbrpa_aprvd_gtsgp",$"nbrpa_aprvd_gtip", $"nbrpa_aprvd_total_gtip", 
									$"nbrpa_aprvd_catastrophic", $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg")



							aprvFinalDf


			}

			def getDeniedData(naic2018_mcas_hlthex_paphmcy_denied_wrk: DataFrame, naic2018_mcas_hlthex_pa_reqstd_wrk: DataFrame): DataFrame = {

					val nbrpa_denied_total_ip = naic2018_mcas_hlthex_paphmcy_denied_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_denied_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") 
									&& (naic2018_mcas_hlthex_paphmcy_denied_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paphmcy_denied_wrk("grndfthr_ind_cd").isNull )
									&&( naic2018_mcas_hlthex_paphmcy_denied_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paphmcy_denied_wrk("src_exchng_certfn_cd").isNull) 
									&& naic2018_mcas_hlthex_paphmcy_denied_wrk("hcr_cmplynt_cd").equalTo("Y")  
									&& naic2018_mcas_hlthex_paphmcy_denied_wrk("in_exchange").isNull)
							.groupBy($"health_year".alias("health_year_r1"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r1"),$"state".alias("state_r1")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_denied_total_ip"))

							val nbrpa_denied_total_ip_pcols = nbrpa_denied_total_ip
							.select($"health_year_r1",$"cmpny_cf_cd_r1",$"state_r1")



							val nbrpa_denied_total_sgp = naic2018_mcas_hlthex_paphmcy_denied_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_denied_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") 
									&& (naic2018_mcas_hlthex_paphmcy_denied_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paphmcy_denied_wrk("grndfthr_ind_cd").isNull )
									&&( naic2018_mcas_hlthex_paphmcy_denied_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_paphmcy_denied_wrk("src_exchng_certfn_cd").isNull) 
									&& naic2018_mcas_hlthex_paphmcy_denied_wrk("hcr_cmplynt_cd").equalTo("Y") 
									&& naic2018_mcas_hlthex_paphmcy_denied_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r2"),
									$"cmpny_cf_cd".alias("cmpny_cf_cd_r2"),
									$"state".alias("state_r2")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_denied_total_sgp"))


							val nbrpa_denied_total_sgp_pcols = nbrpa_denied_total_sgp
							.select($"health_year_r2",$"cmpny_cf_cd_r2",$"state_r2")

							val nbrpa_denied_gtlgp = naic2018_mcas_hlthex_paphmcy_denied_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_denied_wrk("naic_lob").isin(naic_lob_lgp:_*) 
									// on 0108 && (naic2018_mcas_hlthex_paphmcy_denied_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paphmcy_denied_wrk("hcr_cmplynt_cd").notEqual("Y")  || naic2018_mcas_hlthex_paphmcy_denied_wrk("hcr_cmplynt_cd").isNull)
									&& naic2018_mcas_hlthex_paphmcy_denied_wrk("grndfthr_ind_cd").equalTo("YES") 
									&& naic2018_mcas_hlthex_paphmcy_denied_wrk("in_exchange").isNull)
							.groupBy($"health_year".alias("health_year_r6"),
									$"cmpny_cf_cd".alias("cmpny_cf_cd_r6"),
									$"state".alias("state_r6")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_denied_gtlgp"))


							val nbrpa_denied_gtlgpcols =     nbrpa_denied_gtlgp.select($"health_year_r6",$"cmpny_cf_cd_r6",$"state_r6")    

							val nbrpa_denied_gtsgp = naic2018_mcas_hlthex_paphmcy_denied_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_denied_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE")  
									&& (naic2018_mcas_hlthex_paphmcy_denied_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paphmcy_denied_wrk("hcr_cmplynt_cd").notEqual("Y")  || naic2018_mcas_hlthex_paphmcy_denied_wrk("hcr_cmplynt_cd").isNull) 
									&& naic2018_mcas_hlthex_paphmcy_denied_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r7"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r7"),$"state".alias("state_r7")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_denied_gtsgp"))

							val nbrpa_denied_gtsgpcols =     nbrpa_denied_gtsgp.select($"health_year_r7",$"cmpny_cf_cd_r7",$"state_r7")


							val nbrpa_denied_gtip = naic2018_mcas_hlthex_paphmcy_denied_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_denied_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE")  
									&& (naic2018_mcas_hlthex_paphmcy_denied_wrk("grndfthr_ind_cd").equalTo("YES") || naic2018_mcas_hlthex_paphmcy_denied_wrk("hcr_cmplynt_cd").notEqual("Y")   || naic2018_mcas_hlthex_paphmcy_denied_wrk("hcr_cmplynt_cd").isNull)
									&& naic2018_mcas_hlthex_paphmcy_denied_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r8"),$"cmpny_cf_cd".alias("cmpny_cf_cd_r8"),$"state".alias("state_r8")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_denied_gtip"))

							val nbrpa_denied_gtipcols =     nbrpa_denied_gtip.select($"health_year_r8",$"cmpny_cf_cd_r8",$"state_r8")




							val getTotal_ip =  nbrpa_denied_gtlgp.union(nbrpa_denied_gtsgp.union(nbrpa_denied_gtip))
							.select($"health_year_r6".alias("health_year_r11"),
									$"cmpny_cf_cd_r6".alias("cmpny_cf_cd_r11"), 
									$"state_r6".alias("state_r11"), $"nbrpa_denied_gtlgp")

							val nbrpa_denied_total_gtip = getTotal_ip
							.groupBy("health_year_r11","cmpny_cf_cd_r11", "state_r11").agg(sum($"nbrpa_denied_gtlgp").alias("nbrpa_denied_total_gtip"))
							val nbrpa_denied_total_gtipcols =nbrpa_denied_total_gtip.select($"health_year_r11",$"cmpny_cf_cd_r11",$"state_r11")
							//nbrpa_denied_total_gtip.show()
							val nbrpa_denied_catastrophic  = naic2018_mcas_hlthex_paphmcy_denied_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_denied_wrk("naic_prod_desc").like("%CATASTROPHIC%") 
									&& naic2018_mcas_hlthex_paphmcy_denied_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r3"),
									$"cmpny_cf_cd".alias("cmpny_cf_cd_r3"),
									$"state".alias("state_r3")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_denied_catastrophic"))

							val nbrpa_denied_catastrophic_pcols = nbrpa_denied_catastrophic.select($"health_year_r3",$"cmpny_cf_cd_r3",$"state_r3")


							val nbrpa_denied_lgp_mmcare = naic2018_mcas_hlthex_paphmcy_denied_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_denied_wrk("naic_lob").isin(naic_lob_lgp:_*) 
									&& (naic2018_mcas_hlthex_paphmcy_denied_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_paphmcy_denied_wrk("grndfthr_ind_cd").isNull)
									&& (!naic2018_mcas_hlthex_paphmcy_denied_wrk("mbu_cf_cd").isin(mbu_cf_cdvals:_*)) 
									&& naic2018_mcas_hlthex_paphmcy_denied_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r9"),
									$"cmpny_cf_cd".alias("cmpny_cf_cd_r9"),
									$"state".alias("state_r9")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_denied_lgp_mmcare"))

							val nbrpa_denied_lgp_mmcarepcols = nbrpa_denied_lgp_mmcare.select($"health_year_r9",$"cmpny_cf_cd_r9",$"state_r9")


							val nbrpa_denied_stucvg = naic2018_mcas_hlthex_paphmcy_denied_wrk
							.filter(naic2018_mcas_hlthex_paphmcy_denied_wrk("naic_lob").isin(naic_lob_lgp:_*)  
									&& naic2018_mcas_hlthex_paphmcy_denied_wrk("mbu_cf_cd").isin(mbu_cf_cdvals:_*) 
									&& naic2018_mcas_hlthex_paphmcy_denied_wrk("in_exchange").isNull )
							.groupBy($"health_year".alias("health_year_r10"),
									$"cmpny_cf_cd".alias("cmpny_cf_cd_r10"),
									$"state".alias("state_r10")).agg(countDistinct($"rfrnc_nbr").alias("nbrpa_denied_stucvg"))
							val nbrpa_denied_stucvgcols = nbrpa_denied_stucvg.select($"health_year_r10",$"cmpny_cf_cd_r10",$"state_r10") 

							val denimaster = (nbrpa_denied_total_ip_pcols.union(nbrpa_denied_total_sgp_pcols.union(nbrpa_denied_gtlgpcols.union(nbrpa_denied_gtsgpcols
									.union(nbrpa_denied_gtipcols.union(nbrpa_denied_total_gtipcols.union(nbrpa_denied_catastrophic_pcols
											.union(nbrpa_denied_lgp_mmcarepcols.union(nbrpa_denied_stucvgcols)))))))))
							.select($"health_year_r1".alias("health_year"),
									$"cmpny_cf_cd_r1".alias("cmpny_cf_cd"),
									$"state_r1".alias("state")).distinct

							val denijoin1 = denimaster.join(nbrpa_denied_total_ip,denimaster("health_year")===nbrpa_denied_total_ip("health_year_r1") &&
							denimaster("cmpny_cf_cd")===nbrpa_denied_total_ip("cmpny_cf_cd_r1") && 
							denimaster("state")===nbrpa_denied_total_ip("state_r1") ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_denied_total_ip")

							val denijoin2 = denijoin1.join(nbrpa_denied_total_sgp,denijoin1("health_year")===nbrpa_denied_total_sgp("health_year_r2") &&
							denijoin1("cmpny_cf_cd")===nbrpa_denied_total_sgp("cmpny_cf_cd_r2") &&
							denijoin1("state")===nbrpa_denied_total_sgp("state_r2")  ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_denied_total_ip",$"nbrpa_denied_total_sgp")

							/* val denijoin3 = denijoin2.join(nbrpa_denied_catastrophic,denijoin2("health_year")===nbrpa_denied_catastrophic("health_year_r3") &&
					denijoin2("cmpny_cf_cd")===nbrpa_denied_catastrophic("cmpny_cf_cd_r3") &&
					denijoin2("state")===nbrpa_denied_catastrophic("state_r3")  ,"left_outer")
					.select($"health_year",$"cmpny_cf_cd",$"state" ,$"nbrpa_denied_total_ip",$"nbrpa_denied_total_sgp",$"nbrpa_denied_catastrophic")*/


							val denijoin3 = denijoin2.join(nbrpa_denied_gtlgp,denijoin2("health_year")===nbrpa_denied_gtlgp("health_year_r6") &&
							denijoin2("cmpny_cf_cd")===nbrpa_denied_gtlgp("cmpny_cf_cd_r6") &&
							denijoin2("state")===nbrpa_denied_gtlgp("state_r6") ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_denied_total_ip",
									$"nbrpa_denied_total_sgp", $"nbrpa_denied_gtlgp")


							val denijoin4 = denijoin3.join(nbrpa_denied_gtsgp,denijoin3("health_year")===nbrpa_denied_gtsgp("health_year_r7") &&
							denijoin3("cmpny_cf_cd")===nbrpa_denied_gtsgp("cmpny_cf_cd_r7") && 
							denijoin3("state")===nbrpa_denied_gtsgp("state_r7") ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_denied_total_ip",
									$"nbrpa_denied_total_sgp", $"nbrpa_denied_gtlgp",$"nbrpa_denied_gtsgp")

							val denijoin5 = denijoin4.join(nbrpa_denied_gtip,denijoin4("health_year")===nbrpa_denied_gtip("health_year_r8") &&
							denijoin4("cmpny_cf_cd")===nbrpa_denied_gtip("cmpny_cf_cd_r8") && 
							denijoin4("state")===nbrpa_denied_gtip("state_r8")  ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_denied_total_ip",$"nbrpa_denied_total_sgp", 
									$"nbrpa_denied_gtlgp",$"nbrpa_denied_gtsgp",$"nbrpa_denied_gtip")
							//denijoin5.show()


							val denijoin6 = denijoin5.join(nbrpa_denied_total_gtip,denijoin5("health_year")===nbrpa_denied_total_gtip("health_year_r11") &&
							denijoin5("cmpny_cf_cd")===nbrpa_denied_total_gtip("cmpny_cf_cd_r11") && 
							denijoin5("state")===nbrpa_denied_total_gtip("state_r11") ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_denied_total_ip",$"nbrpa_denied_total_sgp", 
									$"nbrpa_denied_gtlgp",$"nbrpa_denied_gtsgp",$"nbrpa_denied_gtip",$"nbrpa_denied_total_gtip")

							val denijoin7 = denijoin6.join(nbrpa_denied_catastrophic,denijoin6("health_year")===nbrpa_denied_catastrophic("health_year_r3") &&
							denijoin6("cmpny_cf_cd")===nbrpa_denied_catastrophic("cmpny_cf_cd_r3") && 
							denijoin6("state")===nbrpa_denied_catastrophic("state_r3") ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_denied_total_ip",$"nbrpa_denied_total_sgp",
									$"nbrpa_denied_gtlgp",$"nbrpa_denied_gtsgp",$"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip", $"nbrpa_denied_catastrophic")

							val denijoin8 = denijoin7.join(nbrpa_denied_lgp_mmcare,denijoin7("health_year")===nbrpa_denied_lgp_mmcare("health_year_r9") &&
							denijoin7("cmpny_cf_cd")===nbrpa_denied_lgp_mmcare("cmpny_cf_cd_r9") && 
							denijoin7("state")===nbrpa_denied_lgp_mmcare("state_r9")  ,"left_outer")
							.select($"health_year",$"cmpny_cf_cd",$"state",$"nbrpa_denied_total_ip",$"nbrpa_denied_total_sgp",
									$"nbrpa_denied_gtlgp",$"nbrpa_denied_gtsgp",$"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip",
									$"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare")


							val deniFinalDf = denijoin8.join(nbrpa_denied_stucvg,denijoin8("health_year")===nbrpa_denied_stucvg("health_year_r10") &&
							denijoin8("cmpny_cf_cd")===nbrpa_denied_stucvg("cmpny_cf_cd_r10") && 
							denijoin8("state")===nbrpa_denied_stucvg("state_r10")  ,"left_outer")
							.select($"health_year".alias("health_year_denied"),$"cmpny_cf_cd".alias("cmpny_cf_cd_denied"),
									$"state".alias("state_denied"),
									$"nbrpa_denied_total_ip",$"nbrpa_denied_total_sgp",
									$"nbrpa_denied_gtlgp",$"nbrpa_denied_gtsgp",$"nbrpa_denied_gtip", $"nbrpa_denied_total_gtip", 
									$"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare", $"nbrpa_denied_stucvg")


							deniFinalDf



			}

			def getFinalData(reqDf:DataFrame,appDf:DataFrame, denDf:DataFrame):DataFrame={


					val request = reqDf.select($"health_year_requested",$"cmpny_cf_cd_requested",$"state_requested")  
							val approve = appDf.select($"health_year_approved",$"cmpny_cf_cd_approved",$"state_approved")  
							val deny = denDf.select($"health_year_denied",$"cmpny_cf_cd_denied",$"state_denied")  


							val finalmaster = deny.union(request.union(approve)).select($"health_year_denied".alias("health_year"),$"cmpny_cf_cd_denied".alias("cmpny_cf_cd"),$"state_denied".alias("state")).distinct

							val fjoin1 = finalmaster.join(reqDf,finalmaster("health_year")===reqDf("health_year_requested") &&
							finalmaster("cmpny_cf_cd")===reqDf("cmpny_cf_cd_requested") && finalmaster("state")===reqDf("state_requested") , "left_outer").select($"health_year",$"cmpny_cf_cd",$"state",
									$"nbrpa_rqstd_total_ip",$"nbrpa_rqstd_total_sgp",$"nbrpa_rqstd_gtlgp",$"nbrpa_rqstd_gtsgp",$"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg")

							val fjoin2 = fjoin1.join(appDf,fjoin1("health_year")===appDf("health_year_approved") &&
							fjoin1("cmpny_cf_cd")===appDf("cmpny_cf_cd_approved") && fjoin1("state")===appDf("state_approved")  ,"left_outer").select($"health_year",$"cmpny_cf_cd",$"state",
									$"nbrpa_rqstd_total_ip",$"nbrpa_rqstd_total_sgp",$"nbrpa_rqstd_gtlgp",$"nbrpa_rqstd_gtsgp",$"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg",
									$"nbrpa_aprvd_total_ip",$"nbrpa_aprvd_total_sgp",$"nbrpa_aprvd_gtlgp",$"nbrpa_aprvd_gtsgp",$"nbrpa_aprvd_gtip",$"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic", $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg")                                  


							val naicMcasHltOexPa =  fjoin2.join(denDf,fjoin2("health_year")===denDf("health_year_denied") &&
							fjoin2("cmpny_cf_cd")===denDf("cmpny_cf_cd_denied") && fjoin2("state")===denDf("state_denied") ,"left_outer")
							.withColumn("outoff_exchange", lit("OUTOFF"))
							.select($"outoff_exchange",$"health_year",$"cmpny_cf_cd".alias("naic_cmpny_cd"),$"state",
									$"nbrpa_rqstd_total_ip",$"nbrpa_rqstd_total_sgp",$"nbrpa_rqstd_gtlgp",$"nbrpa_rqstd_gtsgp",$"nbrpa_rqstd_gtip", $"nbrpa_rqstd_total_gtip", $"nbrpa_rqstd_catastrophic", $"nbrpa_rqstd_lgp_mmcare", $"nbrpa_rqstd_stucvg",
									$"nbrpa_aprvd_total_ip",$"nbrpa_aprvd_total_sgp",$"nbrpa_aprvd_gtlgp",$"nbrpa_aprvd_gtsgp",$"nbrpa_aprvd_gtip",$"nbrpa_aprvd_total_gtip", $"nbrpa_aprvd_catastrophic", $"nbrpa_aprvd_lgp_mmcare", $"nbrpa_aprvd_stucvg",
									$"nbrpa_denied_total_ip",$"nbrpa_denied_total_sgp",$"nbrpa_denied_gtlgp",$"nbrpa_denied_gtsgp",$"nbrpa_denied_gtip",$"nbrpa_denied_total_gtip", $"nbrpa_denied_catastrophic", $"nbrpa_denied_lgp_mmcare", $"nbrpa_denied_stucvg")  
							//.fill.na(0)
							//val naicMcasHltOexPa = naicMcasHltOexPa
							val finalMaicMcasHltOexPa = naicMcasHltOexPa.na.fill(0)
							finalMaicMcasHltOexPa
			}


}

object PCADX_SCL_NAIC2018_OexStgTransformationPAPHMCY {
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		new PCADX_SCL_NAIC2018_OexStgTransformationPAPHMCY().sparkInIt()
	}
}