package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit
class PCADX_SCL_NAIC2018_UnicareStgTransformationclmexphmcy(val spark: SparkSession) {

  val dbProperties = new Properties

  import spark.implicits._
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_UnicareStgTransformationclmexphmcy])
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clmex")
  val end_year = dbProperties.getProperty("end_year_clmex")
  var naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame = null

  var naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame = null
  var naic2018_mcas_src_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame = null

  var naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame = null
  val mbu_cf_cdvals = dbProperties.getProperty("mbu_Cf_cdVals").split(",").toSeq
  /*def sparkInIt(){
      				naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_clmexphmcy_unicare_received_ip_wrk")
  
      						naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_clmexphmcy_unicare_received_lgp_wrk ")
      						naic2018_mcas_src_eob_cd_inbnd =  readDataFromHive(dbInbnd+".naic2018_mcas_src_eob_cd_inbnd")
      						naic2018_mcas_eob_cd_inbnd =  readDataFromHive(dbInbnd+".naic2018_mcas_eob_cd_inbnd")
      						naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd =  readDataFromHive(dbInbnd+".naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd")
  
  
      						naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_clmexphmcy_unicare_paid_ip_wrk")
  
  
  
      						naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk = readDataFromHive(dbwrk+".naic2018_mcas_hlthex_clmexphmcy_unicare_paid_lgp_wrk")
  
      						spark.close()
      			}*/

  def truncateTbl(tblName: String) {
    spark.sql("TRUNCATE TABLE " + tblName)
  }
  def writeDataToHive(tblName: String, finalDf: DataFrame) {
    finalDf.write.mode(SaveMode.Append).insertInto(tblName)
    println("Data added in stage table")
  }
  def readDataFromHive(tble: String): DataFrame = {
    val queryOutputTable = """SELECT * FROM """ + tble
    val tbl_data_df = spark.sql(queryOutputTable)
    logger.info("Read data from hive")
    tbl_data_df
  }

  def getIpSgpPlan(wrk_df: DataFrame, lob_type: String): DataFrame = {
    val metl_cd = Seq("01", "02", "03", "04")
    val ip_df = wrk_df.filter($"naic_lob".equalTo(lob_type) &&
      ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"hcr_cmplynt_cd".equalTo("Y") &&
      ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull) &&
      $"exchng_metl_type_cd".isin(metl_cd: _*) &&
      $"in_exchange".isNull)

    ip_df
  }
  def getGtData(wrk_df: DataFrame, lob_type: String, islgp: Boolean): DataFrame = {
    var gt_df: DataFrame = null
    if (islgp) {
      gt_df = wrk_df.filter($"grndfthr_ind_cd".equalTo("YES") || $"hcr_cmplynt_cd".notEqual("Y") &&
        $"in_exchange".isNull)
    } else {
      gt_df = wrk_df.filter($"naic_lob".equalTo(lob_type) &&
        $"grndfthr_ind_cd".equalTo("YES") || $"hcr_cmplynt_cd".notEqual("Y") &&
        $"in_exchange".isNull)
    }
    gt_df
  }

  def joinedDf(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_src_eob_cd_inbnd: DataFrame, naic2018_mcas_eob_cd_inbnd: DataFrame,
    naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    val joined_df = naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.alias("received_wrk").join(naic2018_mcas_src_eob_cd_inbnd.alias("sec"),
      $"received_wrk.src_eob_cd" === $"sec.src_eob_cd" &&
        $"received_wrk.clm_sor_cd" === $"sec.clm_sor_cd", "left_outer")
      .join(naic2018_mcas_eob_cd_inbnd.alias("chip"),
        $"received_wrk.eob_cd" === $"chip.eob_cd" &&
          $"received_wrk.clm_sor_cd" === $"chip.clm_sor_cd", "left_outer")
      .join(naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd.alias("aces"),
        $"received_wrk.src_clm_line_disp_rsn_cd" === $"aces.src_clm_line_disp_rsn_cd" &&
          $"received_wrk.clm_sor_cd" === $"aces.clm_sor_cd", "left_outer")
      .filter(($"sec.src_eob_cd".isNull && $"sec.clm_sor_cd".isNull) and
        ($"chip.eob_cd".isNull && $"chip.clm_sor_cd".isNull) and
        ($"aces.src_clm_line_disp_rsn_cd".isNull && $"aces.clm_sor_cd".isNull))

    //chip.src_eob_cd
    joined_df

  }
  
    def joinedDf_new(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_src_eob_cd_inbnd: DataFrame, naic2018_mcas_eob_cd_inbnd: DataFrame,
    naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    val joined_df = naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.alias("received_wrk").join(naic2018_mcas_src_eob_cd_inbnd.alias("sec"),
      $"received_wrk.src_eob_cd" === $"sec.src_eob_cd" &&
        $"received_wrk.clm_sor_cd" === $"sec.clm_sor_cd", "left_outer")
      .join(naic2018_mcas_eob_cd_inbnd.alias("chip"),
        $"received_wrk.eob_cd" === $"chip.eob_cd" &&
          $"received_wrk.clm_sor_cd" === $"chip.clm_sor_cd", "left_outer")
      .join(naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd.alias("aces"),
        $"received_wrk.src_clm_line_disp_rsn_cd" === $"aces.src_clm_line_disp_rsn_cd" &&
          $"received_wrk.clm_sor_cd" === $"aces.clm_sor_cd", "left_outer")
      .filter((!$"sec.src_eob_cd".isNull && !$"sec.clm_sor_cd".isNull) ||
        (!$"chip.eob_cd".isNull && !$"chip.clm_sor_cd".isNull) ||
        (!$"aces.src_clm_line_disp_rsn_cd".isNull && !$"aces.clm_sor_cd".isNull))

    //chip.src_eob_cd
    joined_df

  }

  def joinedDf1(colvalue: String, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame, naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame): DataFrame = {

    val joined_df = naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.alias("received_wrk").join(naic2018_mcas_nmn_src_eob_cd_inbnd.alias("sec"),
      $"received_wrk.src_eob_cd" === $"sec.src_eob_cd" &&
        $"received_wrk.clm_sor_cd" === $"sec.clm_sor_cd", "leftouter")
      .join(naic2018_mcas_nmn_eob_cd_inbnd.alias("chip"),
        $"received_wrk.eob_cd" === $"chip.eob_cd" &&
          $"received_wrk.clm_sor_cd" === $"chip.clm_sor_cd", "leftouter")
      .join(naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd.alias("aces"),
        $"received_wrk.src_clm_line_disp_rsn_cd" === $"aces.src_clm_line_disp_rsn_cd" &&
          $"received_wrk.clm_sor_cd" === $"aces.clm_sor_cd", "leftouter")
      .join(naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc1"),
        $"received_wrk.diag_1_cd" === $"idc1.icd_diag_cd", "leftouter")
    /*  .join(naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc2"),
        $"received_wrk.diag_2_cd" === $"idc2.icd_diag_cd", "leftouter")
      .join(naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc3"),
        $"received_wrk.diag_3_cd" === $"idc3.icd_diag_cd", "leftouter")
      .join(naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc4"),
        $"received_wrk.diag_4_cd" === $"idc4.icd_diag_cd", "leftouter")
      .join(naic2018_mcas_nmnbh_icd_proc_cd_inbnd.alias("ipc"),
        $"received_wrk.icd_proc_cd" === $"ipc.icd_proc_cd", "leftouter")
      .join(naic2018_mcas_nmnbh_hlth_srvc_cd_inbnd.alias("hsc"),
        $"received_wrk.hlth_srvc_cd" === $"hsc.hlth_srvc_cd", "leftouter") commented as on 15th feb*/

    var filteredjoineddf: DataFrame = null

    if (colvalue == "ebh") {

      filteredjoineddf = joined_df.filter(((!$"sec.src_eob_cd".isNull && !$"sec.clm_sor_cd".isNull) || (!$"chip.eob_cd".isNull && !$"chip.clm_sor_cd".isNull) || (!$"aces.src_clm_line_disp_rsn_cd".isNull && !$"aces.clm_sor_cd".isNull)) && $"idc1.icd_diag_cd".isNull)
   
    } else {

      filteredjoineddf = joined_df.filter(((!$"sec.src_eob_cd".isNull && !$"sec.clm_sor_cd".isNull) || (!$"chip.eob_cd".isNull && !$"chip.clm_sor_cd".isNull) || (!$"aces.src_clm_line_disp_rsn_cd".isNull && !$"aces.clm_sor_cd".isNull)) && !$"idc1.icd_diag_cd".isNull)
    }

    filteredjoineddf

  }

  def clmReceivedData(naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame): DataFrame = {
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val ip_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val nbrclm_received_bronze_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_received_bronze_ip"))

    val nbrclm_received_silver_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_received_silver_ip"))

    val brSil = nbrclm_received_bronze_ip.alias("parent").join(nbrclm_received_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip")

    val nbrclm_received_gold_ip = ip_df.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_received_gold_ip"))

    val bsGld = brSilData.alias("parent").join(nbrclm_received_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"))

    val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip")
    val nbrclm_received_platinum_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_received_platinum_ip"))

    val bsgchild = bsGldData.alias("parent").join(nbrclm_received_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"))

    val bsgchildData = bsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip")
    val total_ip = nbrclm_received_bronze_ip.union(nbrclm_received_silver_ip.union(nbrclm_received_gold_ip.union(nbrclm_received_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_received_bronze_ip")

    val nbrclm_received_total_ip = total_ip.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_received_bronze_ip").alias("nbrclm_received_total_ip"))
    val ip = bsgchildData.alias("parent").join(nbrclm_received_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"))

    val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_received_bronze_sgp", lit(0))
      .withColumn("nbrclm_received_silver_sgp", lit(0))
      .withColumn("nbrclm_received_gold_sgp", lit(0))
      .withColumn("nbrclm_received_platinum_sgp", lit(0))
      .withColumn("nbrclm_received_total_sgp", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp", "nbrclm_received_total_sgp")

    val nbrclm_received_gtlgp = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") && $"state".equalTo("IL") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_gtlgp"))

    val gtLgp = ipData.alias("parent").join(nbrclm_received_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"))

    val gtLgpData = gtLgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_received_gtsgp", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_gtlgp", "nbrclm_received_gtsgp")

    lob_type = "TOTAL INDIVIDUAL CBE"
    //val gt_ip_df = getGtData(naic_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp) 

    val nbrclm_received_gtip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      $"state".equalTo("DC")).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_gtip"))

    val gtIp = gtLgpData.alias("parent").join(nbrclm_received_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"))

    val gtIpData = gtIp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_gtlgp", "nbrclm_received_gtsgp", "nbrclm_received_gtip")

    val tot_gt = nbrclm_received_gtip.union(nbrclm_received_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_received_gtip")

    val nbrclm_received_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_received_gtip").alias("nbrclm_received_total_gtip"))

    val gttot = gtIpData.alias("parent").join(nbrclm_received_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"))

    val gttotData = gttot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_gtlgp", "nbrclm_received_gtsgp", "nbrclm_received_gtip", "nbrclm_received_total_gtip")

    val nbrclm_received_lgp_mmcare = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      $"state".equalTo("MA")).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_lgp_mmcare"))

    val lgpmmcare = gttotData.alias("parent").join(nbrclm_received_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"), col("nbrclm_received_lgp_mmcare"))

    val lgpmmcareData = lgpmmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_gtlgp", "nbrclm_received_gtsgp", "nbrclm_received_gtip", "nbrclm_received_total_gtip", "nbrclm_received_lgp_mmcare")

    val nbrclm_received_stucvg = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_received_stucvg"))

    val stuvg = lgpmmcareData.alias("parent").join(nbrclm_received_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"), col("nbrclm_received_lgp_mmcare"), col("nbrclm_received_stucvg"))

    val stuvgData = stuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_received_catastrophic", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_gtlgp", "nbrclm_received_gtsgp", "nbrclm_received_gtip", "nbrclm_received_total_gtip", "nbrclm_received_lgp_mmcare", "nbrclm_received_stucvg", "nbrclm_received_catastrophic")

    stuvgData

  }

  def getSubInntwkData(naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame): DataFrame = {
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    //val ip_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val nbrclm_sub_inntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_sub_inntwk_bronze_ip"))

    val nbrclm_sub_inntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_sub_inntwk_silver_ip"))

    val brzSil = nbrclm_sub_inntwk_bronze_ip.alias("parent").join(nbrclm_sub_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"))

    val brzSilData = brzSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip")

    val nbrclm_sub_inntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_sub_inntwk_gold_ip"))

    val bsGld = brzSilData.alias("parent").join(nbrclm_sub_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"))

    val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip")

    val nbrclm_sub_inntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_sub_inntwk_platinum_ip"))

    val bsgchild = bsGldData.alias("parent").join(nbrclm_sub_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"))

    val bsgchildData = bsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip")

    val tot_ip = nbrclm_sub_inntwk_bronze_ip.union(nbrclm_sub_inntwk_silver_ip.union(nbrclm_sub_inntwk_gold_ip.union(nbrclm_sub_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_sub_inntwk_bronze_ip")

    val nbrclm_sub_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_sub_inntwk_bronze_ip").alias("nbrclm_sub_inntwk_total_ip"))

    val ip = bsgchildData.alias("parent").join(nbrclm_sub_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"))

    val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_sub_inntwk_bronze_sgp", lit(0))
      .withColumn("nbrclm_sub_inntwk_silver_sgp", lit(0))
      .withColumn("nbrclm_sub_inntwk_gold_sgp", lit(0))
      .withColumn("nbrclm_sub_inntwk_platinum_sgp", lit(0))
      .withColumn("nbrclm_sub_inntwk_total_sgp", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp")

    lob_type = ""
    var islgp = true
    val gt_lgp_df = getGtData(naic_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp)

    val nbrclm_sub_inntwk_gtlgp = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) && $"inn_cd".isin(clminn_cd: _*)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_gtlgp"))

    val gtlgp = ipData.alias("parent").join(nbrclm_sub_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_gtlgp"))

    val gtlgpData = gtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_sub_inntwk_gtsgp", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp", "nbrclm_sub_inntwk_gtsgp")

    val nbrclm_sub_inntwk_gtip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) && $"inn_cd".isin(clminn_cd: _*)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_gtip"))

    val gtip = gtlgpData.alias("parent").join(nbrclm_sub_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_gtlgp"), col("nbrclm_sub_inntwk_gtsgp"), col("nbrclm_sub_inntwk_gtip"))

    val gtipData = gtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_gtsgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp", "nbrclm_sub_inntwk_gtsgp", "nbrclm_sub_inntwk_gtip")
    val tot_gt = nbrclm_sub_inntwk_gtip.union(nbrclm_sub_inntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_sub_inntwk_gtip")

    val nbrclm_sub_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_sub_inntwk_gtip").alias("nbrclm_sub_inntwk_total_gtip"))

    val gttot = gtipData.alias("parent").join(nbrclm_sub_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_gtlgp"), col("nbrclm_sub_inntwk_gtsgp"), col("nbrclm_sub_inntwk_gtip"), col("nbrclm_sub_inntwk_total_gtip"))
    //nbrclm_sub_inntwk_platinum_sgp
    val gttotData = gttot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_sub_inntwk_catastrophic", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp", "nbrclm_sub_inntwk_gtsgp", "nbrclm_sub_inntwk_gtip", "nbrclm_sub_inntwk_total_gtip", "nbrclm_sub_inntwk_catastrophic")

    val nbrclm_sub_inntwk_lgp_mmcare = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) && $"inn_cd".isin(clminn_cd: _*)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_lgp_mmcare"))

    val lgp = gttotData.alias("parent").join(nbrclm_sub_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"), col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"),
        col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_gtlgp"), col("nbrclm_sub_inntwk_gtsgp"), col("nbrclm_sub_inntwk_gtip"), col("nbrclm_sub_inntwk_total_gtip"), col("nbrclm_sub_inntwk_catastrophic"), col("nbrclm_sub_inntwk_lgp_mmcare"))

    val lgpData = lgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp", "nbrclm_sub_inntwk_gtsgp", "nbrclm_sub_inntwk_gtip", "nbrclm_sub_inntwk_total_gtip",
        "nbrclm_sub_inntwk_catastrophic", "nbrclm_sub_inntwk_lgp_mmcare")

    val nbrclm_sub_inntwk_stucvg = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_sub_inntwk_stucvg"))

    val stuvg = lgpData.alias("parent").join(nbrclm_sub_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"), col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"),
        col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_gtlgp"), col("nbrclm_sub_inntwk_gtsgp"), col("nbrclm_sub_inntwk_gtip"), col("nbrclm_sub_inntwk_total_gtip"), col("nbrclm_sub_inntwk_catastrophic"), col("nbrclm_sub_inntwk_lgp_mmcare"), col("nbrclm_sub_inntwk_stucvg"))

    val stuvgData = stuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp", "nbrclm_sub_inntwk_gtsgp", "nbrclm_sub_inntwk_gtip", "nbrclm_sub_inntwk_total_gtip",
        "nbrclm_sub_inntwk_catastrophic", "nbrclm_sub_inntwk_lgp_mmcare", "nbrclm_sub_inntwk_stucvg")

    stuvgData
  }
  def getSubOutntwkData(naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame): DataFrame = {
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    //val ip_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val nbrclm_sub_outntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_sub_outntwk_bronze_ip"))

    val nbrclm_sub_outntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_sub_outntwk_silver_ip"))

    val brzSil = nbrclm_sub_outntwk_bronze_ip.alias("parent").join(nbrclm_sub_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"))

    val brzSilData = brzSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip")

    val nbrclm_sub_outntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_sub_outntwk_gold_ip"))

    val bsGld = brzSilData.alias("parent").join(nbrclm_sub_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"))

    val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip")

    val nbrclm_sub_outntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_sub_outntwk_platinum_ip"))

    val bsgchild = bsGldData.alias("parent").join(nbrclm_sub_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"))

    val bsgchildData = bsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip")

    val tot_ip = nbrclm_sub_outntwk_bronze_ip.union(nbrclm_sub_outntwk_silver_ip.union(nbrclm_sub_outntwk_gold_ip.union(nbrclm_sub_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_sub_outntwk_bronze_ip")

    val nbrclm_sub_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_sub_outntwk_bronze_ip").alias("nbrclm_sub_outntwk_total_ip"))

    val ip = bsgchildData.alias("parent").join(nbrclm_sub_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"))

    val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_sub_outntwk_bronze_sgp", lit(0))
      .withColumn("nbrclm_sub_outntwk_silver_sgp", lit(0))
      .withColumn("nbrclm_sub_outntwk_gold_sgp", lit(0))
      .withColumn("nbrclm_sub_outntwk_platinum_sgp", lit(0))
      .withColumn("nbrclm_sub_outntwk_total_sgp", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp")

    lob_type = ""
    var islgp = true

    val nbrclm_sub_outntwk_gtlgp = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) && (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_gtlgp"))

    val gtlgp = ipData.alias("parent").join(nbrclm_sub_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_gtlgp"))

    val gtlgpData = gtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_sub_outntwk_gtsgp", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_gtlgp", "nbrclm_sub_outntwk_gtsgp")

    val nbrclm_sub_outntwk_gtip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) && (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_gtip"))

    val gtip = gtlgpData.alias("parent").join(nbrclm_sub_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_gtlgp"), col("nbrclm_sub_outntwk_gtsgp"), col("nbrclm_sub_outntwk_gtip"))

    val gtipData = gtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_gtlgp", "nbrclm_sub_outntwk_gtsgp", "nbrclm_sub_outntwk_gtip")
    val tot_gt = nbrclm_sub_outntwk_gtip.union(nbrclm_sub_outntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_sub_outntwk_gtip")

    val nbrclm_sub_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_sub_outntwk_gtip").alias("nbrclm_sub_outntwk_total_gtip"))

    val gttot = gtipData.alias("parent").join(nbrclm_sub_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_gtlgp"), col("nbrclm_sub_outntwk_gtsgp"), col("nbrclm_sub_outntwk_gtip"), col("nbrclm_sub_outntwk_total_gtip"))

    val gttotData = gttot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_sub_outntwk_catastrophic", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_gtlgp", "nbrclm_sub_outntwk_gtsgp", "nbrclm_sub_outntwk_gtip", "nbrclm_sub_outntwk_total_gtip", "nbrclm_sub_outntwk_catastrophic")

    val nbrclm_sub_outntwk_lgp_mmcare = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) && ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_lgp_mmcare"))

    val lgp = gttotData.alias("parent").join(nbrclm_sub_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"), col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"),
        col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_gtlgp"), col("nbrclm_sub_outntwk_gtsgp"), col("nbrclm_sub_outntwk_gtip"), col("nbrclm_sub_outntwk_total_gtip"), col("nbrclm_sub_outntwk_catastrophic"), col("nbrclm_sub_outntwk_lgp_mmcare"))

    val lgpData = lgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_gtlgp", "nbrclm_sub_outntwk_gtsgp", "nbrclm_sub_outntwk_gtip", "nbrclm_sub_outntwk_total_gtip",
        "nbrclm_sub_outntwk_catastrophic", "nbrclm_sub_outntwk_lgp_mmcare")

    val nbrclm_sub_outntwk_stucvg = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_sub_outntwk_stucvg"))

    val stuvg = lgpData.alias("parent").join(nbrclm_sub_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"), col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"),
        col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_gtlgp"), col("nbrclm_sub_outntwk_gtsgp"), col("nbrclm_sub_outntwk_gtip"), col("nbrclm_sub_outntwk_total_gtip"), col("nbrclm_sub_outntwk_catastrophic"), col("nbrclm_sub_outntwk_lgp_mmcare"), col("nbrclm_sub_outntwk_stucvg"))

    val stuvgData = stuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_gtlgp", "nbrclm_sub_outntwk_gtsgp", "nbrclm_sub_outntwk_gtip", "nbrclm_sub_outntwk_total_gtip",
        "nbrclm_sub_outntwk_catastrophic", "nbrclm_sub_outntwk_lgp_mmcare", "nbrclm_sub_outntwk_stucvg")

    stuvgData
  }

  def getDeniedInntwk(naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
    naic_mcas_src_eob_cd_inbnd: DataFrame, naic_mcas_eob_cd_inbnd: DataFrame,
    naic_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")

    val nbrclm_denied_inntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_bronze_ip"))

    val nbrclm_denied_inntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip")

    val nbrclm_denied_inntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip")

    val nbrclm_denied_inntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_bronze_ip.union(nbrclm_denied_inntwk_silver_ip.union(nbrclm_denied_inntwk_gold_ip.union(nbrclm_denied_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_denied_inntwk_bronze_ip")

    val nbrclm_denied_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_bronze_ip").alias("nbrclm_denied_inntwk_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"),
        col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_inntwk_bronze_sgp", lit(0))
      .withColumn("nbrclm_denied_inntwk_silver_sgp", lit(0))
      .withColumn("nbrclm_denied_inntwk_gold_sgp", lit(0))
      .withColumn("nbrclm_denied_inntwk_platinum_sgp", lit(0))
      .withColumn("nbrclm_denied_inntwk_total_sgp", col("nbrclm_denied_inntwk_bronze_sgp") + col("nbrclm_denied_inntwk_silver_sgp") + col("nbrclm_denied_inntwk_gold_sgp") + col("nbrclm_denied_inntwk_platinum_sgp"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp")

    lob_type = ""
    var islgp = true

    val received_gtlgp = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gtlgp = joinedDf(received_gtlgp, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gtlgp"))
    val gtlgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_inntwk_gtsgp", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp")

    val received_gtip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gtip = joinedDf(received_gtip, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gtip"))

    val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp", "nbrclm_denied_inntwk_gtip")
    val tot_gt = nbrclm_denied_inntwk_gtip.union(nbrclm_denied_inntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_denied_inntwk_gtip")

    val nbrclm_denied_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_denied_inntwk_gtip").alias("nbrclm_denied_inntwk_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"), col("nbrclm_denied_inntwk_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_inntwk_catastrophic", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp", "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic")

    val received_lgpmmcare = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_lgpmmcare = joinedDf(received_lgpmmcare, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_lgp_mmcare"))

    val lgpmmcareMaster = gttotMasterData.alias("parent").join(nbrclm_denied_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"), col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp", "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare")

    val nbrclm_denied_inntwk_stucvg = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"), col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"), col("nbrclm_denied_inntwk_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp", "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare", "nbrclm_denied_inntwk_stucvg")
    stucvgMasterData
  }

  def getDeniedInntwkBetweenDates(start_day: Int, end_day: Int, naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
    naic_mcas_src_eob_cd_inbnd: DataFrame, naic_mcas_eob_cd_inbnd: DataFrame,
    naic_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = start_day.toString + "to" + end_day
    val fend_day = end_day + 1

    val nbrclm_denied_inntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_inntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip")

    val nbrclm_denied_inntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip")

    val nbrclm_denied_inntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_bronze_ip.union(nbrclm_denied_inntwk_silver_ip.union(nbrclm_denied_inntwk_gold_ip.union(nbrclm_denied_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_ip").alias("nbrclm_denied_inntwk_" + colVal + "_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", lit(0))
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_silver_sgp", lit(0))
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_gold_sgp", lit(0))
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", lit(0)) //nbrclm_denied_inntwk_0to30_total_sgp
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_total_sgp", col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp") + col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp") + col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp") + col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp") //, "nbrclm_denied_inntwk_"+colVal+"_gtlgp", "nbrclm_denied_inntwk_"+colVal+"_gtsgp")

    val received_gtlgp = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_gtlgp = joinedDf(received_gtlgp, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gtlgp"))
    val gtlgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"), //nbrclm_denied_inntwk_0to30_total_sgp 
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_gtsgp", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp")

    val received_gtip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_gtip = joinedDf(received_gtip, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gtip"))

    val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip")
    val tot_gt = nbrclm_denied_inntwk_gtip.union(nbrclm_denied_inntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colVal + "_gtip"))

    val nbrclm_denied_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col("nbrclm_denied_inntwk_" + colVal + "_gtip")).alias("nbrclm_denied_inntwk_" + colVal + "_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_catastrophic", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip", "nbrclm_denied_inntwk_" + colVal + "_catastrophic")

        
    val received_lgpmmcare = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
    val denied_in_lgpmmcare = joinedDf(received_lgpmmcare, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare"))
    val lgpmmcareMaster = gttotMasterData.alias("parent").join(nbrclm_denied_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip", "nbrclm_denied_inntwk_" + colVal + "_catastrophic", "nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare")

    val nbrclm_denied_inntwk_stucvg = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colVal + "_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_denied_inntwk_" + colVal + "_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip", "nbrclm_denied_inntwk_" + colVal + "_catastrophic", "nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare", "nbrclm_denied_inntwk_" + colVal + "_stucvg")
    stucvgMasterData
  }

  def getDeniedInntwk_90(end_year: String, naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
    naic_mcas_src_eob_cd_inbnd: DataFrame, naic_mcas_eob_cd_inbnd: DataFrame,
    naic_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = "90"
    val strt_day: Int = 91

    val nbrclm_denied_inntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_inntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip")

    val nbrclm_denied_inntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip")

    val nbrclm_denied_inntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_bronze_ip.union(nbrclm_denied_inntwk_silver_ip.union(nbrclm_denied_inntwk_gold_ip.union(nbrclm_denied_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_ip").alias("nbrclm_denied_inntwk_" + colVal + "_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", lit(0))
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_silver_sgp", lit(0))
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_gold_sgp", lit(0)) //nbrclm_denied_90_inntwk_platinum_sgp
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", lit(0))
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_total_sgp", col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp") + col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp") + col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp") + col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp")

    val received_gtlgp = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.withColumn("constant_date", lit(end_year)).filter($"naic_lob".equalTo("LARGE GROUP GRAND") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_gtlgp = joinedDf(received_gtlgp, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gtlgp"))
    val gtlgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_gtsgp", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp")

    val received_gtip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.withColumn("constant_date", lit(end_year)).filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
    val denied_in_gtip = joinedDf(received_gtip, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gtip"))

    val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip")
    val tot_gt = nbrclm_denied_inntwk_gtip.union(nbrclm_denied_inntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colVal + "_gtip"))

    val nbrclm_denied_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("nbrclm_denied_inntwk_" + colVal + "_gtip").alias("nbrclm_denied_inntwk_" + colVal + "_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_inntwk_" + colVal + "_catastrophic", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip", "nbrclm_denied_inntwk_" + colVal + "_catastrophic")

    val received_lgpmmcare = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.withColumn("constant_date", lit(end_year))
      .filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
        $"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year) &&
        $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_lgpmmcare = joinedDf(received_lgpmmcare, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMaster = gttotMasterData.withColumn("constant_date", lit(end_year)).alias("parent").join(nbrclm_denied_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip", "nbrclm_denied_inntwk_" + colVal + "_catastrophic", "nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare")

    val nbrclm_denied_inntwk_stucvg = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colVal + "_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_denied_inntwk_" + colVal + "_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip", "nbrclm_denied_inntwk_" + colVal + "_catastrophic", "nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare", "nbrclm_denied_inntwk_" + colVal + "_stucvg")
    stucvgMasterData
  }
  def getDeniedOutntwk_90(end_year: String, naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
    naic_mcas_src_eob_cd_inbnd: DataFrame, naic_mcas_eob_cd_inbnd: DataFrame,
    naic_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = "90"
    val strt_day: Int = 91

    val nbrclm_denied_outntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_outntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip")

    val nbrclm_denied_outntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip")

    val nbrclm_denied_outntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_bronze_ip.union(nbrclm_denied_outntwk_silver_ip.union(nbrclm_denied_outntwk_gold_ip.union(nbrclm_denied_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_ip").alias("nbrclm_denied_outntwk_" + colVal + "_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", lit(0))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_silver_sgp", lit(0))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_gold_sgp", lit(0))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", lit(0))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_total_sgp", col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp") + col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp") + col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp") + col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp")

    lob_type = ""
    var islgp = true
    val lgp_df = getGtData(naic_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val received_gtlgp = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.withColumn("constant_date", lit(end_year)).filter($"naic_lob".equalTo("LARGE GROUP GRAND") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_gtlgp = joinedDf(received_gtlgp, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gtlgp"))
    val gtlgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_gtsgp", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val gtip_df = getGtData(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val received_gtip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.withColumn("constant_date", lit(end_year)).filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_gtip = joinedDf(received_gtip, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gtip"))

    val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip")
    val tot_gt = nbrclm_denied_outntwk_gtip.union(nbrclm_denied_outntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colVal + "_gtip"))

    val nbrclm_denied_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("nbrclm_denied_outntwk_" + colVal + "_gtip").alias("nbrclm_denied_outntwk_" + colVal + "_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_catastrophic", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip", "nbrclm_denied_outntwk_" + colVal + "_catastrophic")

    val received_lgpmmcare = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.withColumn("constant_date", lit(end_year))
      .filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
        (!$"inn_cd".isin(clminn_cd: _*)) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year) &&
        $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_lgpmmcare = joinedDf(received_lgpmmcare, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMaster = gttotMasterData.withColumn("constant_date", lit(end_year)).alias("parent").join(nbrclm_denied_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip", "nbrclm_denied_outntwk_" + colVal + "_catastrophic", "nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare")

    val nbrclm_denied_outntwk_stucvg = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colVal + "_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_denied_outntwk_" + colVal + "_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip", "nbrclm_denied_outntwk_" + colVal + "_catastrophic", "nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare", "nbrclm_denied_outntwk_" + colVal + "_stucvg")
    stucvgMasterData
  }
  def getDeniedOutntwk(naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
    naic_mcas_src_eob_cd_inbnd: DataFrame, naic_mcas_eob_cd_inbnd: DataFrame,
    naic_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")

    val nbrclm_denied_outntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_bronze_ip"))

    val nbrclm_denied_outntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip")

    val nbrclm_denied_outntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip")

    val nbrclm_denied_outntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_bronze_ip.union(nbrclm_denied_outntwk_silver_ip.union(nbrclm_denied_outntwk_gold_ip.union(nbrclm_denied_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_denied_outntwk_bronze_ip")

    val nbrclm_denied_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_bronze_ip").alias("nbrclm_denied_outntwk_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"),
        col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_outntwk_bronze_sgp", lit(0))
      .withColumn("nbrclm_denied_outntwk_silver_sgp", lit(0))
      .withColumn("nbrclm_denied_outntwk_gold_sgp", lit(0))
      .withColumn("nbrclm_denied_outntwk_platinum_sgp", lit(0))
      .withColumn("nbrclm_denied_outntwk_total_sgp", col("nbrclm_denied_outntwk_bronze_sgp") + col("nbrclm_denied_outntwk_silver_sgp") + col("nbrclm_denied_outntwk_gold_sgp") + col("nbrclm_denied_outntwk_platinum_sgp"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp")

    val received_gtlgp = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gtlgp = joinedDf(received_gtlgp, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gtlgp"))
    val gtlgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_outntwk_gtsgp", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp")

    val received_gtip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))
    val denied_in_gtip = joinedDf(received_gtip, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gtip"))

    val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp", "nbrclm_denied_outntwk_gtip")
    val tot_gt = nbrclm_denied_outntwk_gtip.union(nbrclm_denied_outntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_denied_outntwk_gtip")

    val nbrclm_denied_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_denied_outntwk_gtip").alias("nbrclm_denied_outntwk_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"), col("nbrclm_denied_outntwk_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_outntwk_catastrophic", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp", "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic")

    val received_lgpmmcare = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_lgpmmcare = joinedDf(received_lgpmmcare, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_lgp_mmcare"))

    val lgpmmcareMaster = gttotMasterData.alias("parent").join(nbrclm_denied_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"), col("nbrclm_denied_outntwk_total_gtip"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp", "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare")

    val nbrclm_denied_outntwk_stucvg = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"), col("nbrclm_denied_outntwk_total_gtip"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_lgp_mmcare"), col("nbrclm_denied_outntwk_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp", "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare", "nbrclm_denied_outntwk_stucvg")
    stucvgMasterData
  }
  def getDeniedOutntwkBetweenDates(start_day: Int, end_day: Int, naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
    naic_mcas_src_eob_cd_inbnd: DataFrame, naic_mcas_eob_cd_inbnd: DataFrame,
    naic_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = start_day.toString + "to" + end_day
    val fend_day = end_day + 1

    val nbrclm_denied_outntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_outntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip")

    val nbrclm_denied_outntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip")

    val nbrclm_denied_outntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_bronze_ip.union(nbrclm_denied_outntwk_silver_ip.union(nbrclm_denied_outntwk_gold_ip.union(nbrclm_denied_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_ip").alias("nbrclm_denied_outntwk_" + colVal + "_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", lit(0))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_silver_sgp", lit(0))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_gold_sgp", lit(0))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", lit(0))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_total_sgp", col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp") + col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp") + col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp") + col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp")

    val received_gtlgp = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_gtlgp = joinedDf(received_gtlgp, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gtlgp"))
    val gtlgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_gtsgp", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp")

    val received_gtip = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
    val denied_in_gtip = joinedDf(received_gtip, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gtip"))

    val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip")
    val tot_gt = nbrclm_denied_outntwk_gtip.union(nbrclm_denied_outntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colVal + "_gtip"))

    val nbrclm_denied_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col("nbrclm_denied_outntwk_" + colVal + "_gtip")).alias("nbrclm_denied_outntwk_" + colVal + "_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("nbrclm_denied_outntwk_" + colVal + "_catastrophic", lit(0))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip", "nbrclm_denied_outntwk_" + colVal + "_catastrophic")

    val received_lgpmmcare = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_lgpmmcare = joinedDf(received_lgpmmcare, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare"))
 
      
    val lgpmmcareMaster = gttotMasterData.alias("parent").join(nbrclm_denied_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip", "nbrclm_denied_outntwk_" + colVal + "_catastrophic", "nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare")

    val nbrclm_denied_outntwk_stucvg = naic_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colVal + "_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_denied_outntwk_" + colVal + "_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip", "nbrclm_denied_outntwk_" + colVal + "_catastrophic", "nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare", "nbrclm_denied_outntwk_" + colVal + "_stucvg")
    stucvgMasterData
  }

  def getdeniedPAInntwk(colvalue: String, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_src_eob_cd_inbnd: DataFrame, naic2018_mcas_eob_cd_inbnd: DataFrame, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame =

    {

      val clminn_cd = Seq("IN", "PAR")
      val clmLineAdjdctn = Seq("DND", "DNDZB")

      val nbrclm_denied_inntwk_bronze_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"))

      val nbrclm_denied_inntwk_silver_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"))

      val brSil = nbrclm_denied_inntwk_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"))

      val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip")

      val nbrclm_denied_inntwk_gold_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"))

      val bsGld = brSilData.alias("parent").join(nbrclm_denied_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"))

      val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip")

      val nbrclm_denied_inntwk_platinum_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"))

      val bsgchild = bsGldData.alias("parent").join(nbrclm_denied_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"))

      val bsgchildData = bsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip")

      val tot_ip = nbrclm_denied_inntwk_bronze_ip.union(nbrclm_denied_inntwk_silver_ip.union(nbrclm_denied_inntwk_gold_ip.union(nbrclm_denied_inntwk_platinum_ip)))
        .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"))

      val nbrclm_denied_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip").alias("nbrclm_denied_inntwk_" + colvalue + "_total_ip"))

      val ip = bsgchildData.alias("parent").join(nbrclm_denied_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_ip"))

      val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp", lit(0))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", lit(0))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", lit(0))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", lit(0))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_total_sgp", lit(0))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip",
          "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_inntwk_" + colvalue + "_total_ip", "nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp",
          "nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_inntwk_" + colvalue + "_total_sgp")

      var denied_gtlgp = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") &&
        $"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

      val denied_in_gtlgp = joinedDf_new(denied_gtlgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

      val nbrclm_denied_inntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colvalue + "_gtlgp"))

      val gtlgpMaster = ipData.alias("parent").join(nbrclm_denied_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtlgp"))

      val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_gtsgp", lit(0))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_inntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_inntwk_" + colvalue + "_total_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gtlgp", "nbrclm_denied_inntwk_" + colvalue + "_gtsgp")

      var received_gtip = naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
        $"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

      val denied_in_gtip = joinedDf_new(received_gtip, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

      val nbrclm_denied_inntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colvalue + "_gtip"))

      val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtip"))

      val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_inntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_inntwk_" + colvalue + "_total_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gtlgp", "nbrclm_denied_inntwk_" + colvalue + "_gtsgp", "nbrclm_denied_inntwk_" + colvalue + "_gtip")

      val tot_gt = nbrclm_denied_inntwk_gtip.union(nbrclm_denied_inntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colvalue + "_gtip"))

      val nbrclm_denied_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col("nbrclm_denied_inntwk_" + colvalue + "_gtip")).alias("nbrclm_denied_inntwk_" + colvalue + "_total_gtip"))

      val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_gtip"))

      val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_catastrophic", lit(0))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_inntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_inntwk_" + colvalue + "_total_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gtlgp", "nbrclm_denied_inntwk_" + colvalue + "_gtsgp", "nbrclm_denied_inntwk_" + colvalue + "_gtip", "nbrclm_denied_inntwk_" + colvalue + "_total_gtip", "nbrclm_denied_inntwk_" + colvalue + "_catastrophic")

      var denied_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
        $"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

      val denied_in_lgpmmcare = joinedDf_new(denied_lgpmmcare, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

      val nbrclm_denied_inntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colvalue + "_lgp_mmcare"))

      val lgpmmcareMaster = gttotMasterData.alias("parent").join(nbrclm_denied_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_gtip"), col("nbrclm_denied_inntwk_" + colvalue + "_catastrophic"), col("nbrclm_denied_inntwk_" + colvalue + "_lgp_mmcare"))

      val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_inntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_inntwk_" + colvalue + "_total_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gtlgp", "nbrclm_denied_inntwk_" + colvalue + "_gtsgp", "nbrclm_denied_inntwk_" + colvalue + "_gtip", "nbrclm_denied_inntwk_" + colvalue + "_total_gtip", "nbrclm_denied_inntwk_" + colvalue + "_catastrophic", "nbrclm_denied_inntwk_" + colvalue + "_lgp_mmcare")

      val nbrclm_denied_inntwk_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colvalue + "_stucvg"))

      val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_gtip"), col("nbrclm_denied_inntwk_" + colvalue + "_catastrophic"), col("nbrclm_denied_inntwk_" + colvalue + "_lgp_mmcare"), col("nbrclm_denied_inntwk_" + colvalue + "_stucvg"))

      val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_inntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_inntwk_" + colvalue + "_total_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gtlgp", "nbrclm_denied_inntwk_" + colvalue + "_gtsgp", "nbrclm_denied_inntwk_" + colvalue + "_gtip", "nbrclm_denied_inntwk_" + colvalue + "_total_gtip", "nbrclm_denied_inntwk_" + colvalue + "_catastrophic", "nbrclm_denied_inntwk_" + colvalue + "_lgp_mmcare", "nbrclm_denied_inntwk_" + colvalue + "_stucvg")
     
      stucvgMasterData
    }

  def getdeniedbhebhInntwk(colvalue: String, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
    naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame): DataFrame =

    {

      val clminn_cd = Seq("IN", "PAR")
      val clmLineAdjdctn = Seq("DND", "DNDZB")

      val nbrclm_denied_inntwk_bronze_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"))

      val nbrclm_denied_inntwk_silver_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"))

      val brSil = nbrclm_denied_inntwk_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"))

      val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip")

      val nbrclm_denied_inntwk_gold_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"))

      val bsGld = brSilData.alias("parent").join(nbrclm_denied_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"))

      val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip")

      val nbrclm_denied_inntwk_platinum_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"))

      val bsgchild = bsGldData.alias("parent").join(nbrclm_denied_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"))

      val bsgchildData = bsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip")

      val tot_ip = nbrclm_denied_inntwk_bronze_ip.union(nbrclm_denied_inntwk_silver_ip.union(nbrclm_denied_inntwk_gold_ip.union(nbrclm_denied_inntwk_platinum_ip)))
        .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"))

      val nbrclm_denied_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip").alias("nbrclm_denied_inntwk_" + colvalue + "_total_ip"))

      val ip = bsgchildData.alias("parent").join(nbrclm_denied_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_ip"))

      val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp", lit(0))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", lit(0))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", lit(0))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", lit(0))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_total_sgp", lit(0))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip",
          "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_inntwk_" + colvalue + "_total_ip", "nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp",
          "nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_inntwk_" + colvalue + "_total_sgp")

      var denied_gtlgp = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") &&
        $"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

      val denied_in_gtlgp = joinedDf1(colvalue, denied_gtlgp, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

      val nbrclm_denied_inntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colvalue + "_gtlgp"))

      val gtlgpMaster = ipData.alias("parent").join(nbrclm_denied_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtlgp"))

      val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_gtsgp", lit(0))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_inntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_inntwk_" + colvalue + "_total_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gtlgp", "nbrclm_denied_inntwk_" + colvalue + "_gtsgp")

      var received_gtip = naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
        $"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

      val denied_in_gtip = joinedDf1(colvalue, received_gtip, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

      val nbrclm_denied_inntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colvalue + "_gtip"))

      val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtip"))

      val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_inntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_inntwk_" + colvalue + "_total_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gtlgp", "nbrclm_denied_inntwk_" + colvalue + "_gtsgp", "nbrclm_denied_inntwk_" + colvalue + "_gtip")

      val tot_gt = nbrclm_denied_inntwk_gtip.union(nbrclm_denied_inntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colvalue + "_gtip"))

      val nbrclm_denied_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col("nbrclm_denied_inntwk_" + colvalue + "_gtip")).alias("nbrclm_denied_inntwk_" + colvalue + "_total_gtip"))

      val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_gtip"))

      val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .withColumn("nbrclm_denied_inntwk_" + colvalue + "_catastrophic", lit(0))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_inntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_inntwk_" + colvalue + "_total_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gtlgp", "nbrclm_denied_inntwk_" + colvalue + "_gtsgp", "nbrclm_denied_inntwk_" + colvalue + "_gtip", "nbrclm_denied_inntwk_" + colvalue + "_total_gtip", "nbrclm_denied_inntwk_" + colvalue + "_catastrophic")
      var denied_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
        $"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

      val denied_in_lgpmmcare = joinedDf1(colvalue, denied_lgpmmcare, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

      val nbrclm_denied_inntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colvalue + "_lgp_mmcare"))

      val lgpmmcareMaster = gttotMasterData.alias("parent").join(nbrclm_denied_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_gtip"), col("nbrclm_denied_inntwk_" + colvalue + "_catastrophic"), col("nbrclm_denied_inntwk_" + colvalue + "_lgp_mmcare"))

      val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_inntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_inntwk_" + colvalue + "_total_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gtlgp", "nbrclm_denied_inntwk_" + colvalue + "_gtsgp", "nbrclm_denied_inntwk_" + colvalue + "_gtip", "nbrclm_denied_inntwk_" + colvalue + "_total_gtip", "nbrclm_denied_inntwk_" + colvalue + "_catastrophic", "nbrclm_denied_inntwk_" + colvalue + "_lgp_mmcare")

      val nbrclm_denied_inntwk_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_inntwk_" + colvalue + "_stucvg"))

      val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_inntwk_" + colvalue + "_gtip"), col("nbrclm_denied_inntwk_" + colvalue + "_total_gtip"), col("nbrclm_denied_inntwk_" + colvalue + "_catastrophic"), col("nbrclm_denied_inntwk_" + colvalue + "_lgp_mmcare"), col("nbrclm_denied_inntwk_" + colvalue + "_stucvg"))

      val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_inntwk_" + colvalue + "_silver_ip", "nbrclm_denied_inntwk_" + colvalue + "_gold_ip", "nbrclm_denied_inntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_inntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_inntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_inntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_inntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_inntwk_" + colvalue + "_total_sgp", "nbrclm_denied_inntwk_" + colvalue + "_gtlgp", "nbrclm_denied_inntwk_" + colvalue + "_gtsgp", "nbrclm_denied_inntwk_" + colvalue + "_gtip", "nbrclm_denied_inntwk_" + colvalue + "_total_gtip", "nbrclm_denied_inntwk_" + colvalue + "_catastrophic", "nbrclm_denied_inntwk_" + colvalue + "_lgp_mmcare", "nbrclm_denied_inntwk_" + colvalue + "_stucvg")

      stucvgMasterData

    }

  def getdeniedPAoutntwk(colvalue: String, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_src_eob_cd_inbnd: DataFrame, naic2018_mcas_eob_cd_inbnd: DataFrame, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame =

    {

      val clminn_cd = Seq("IN", "PAR")
      val clmLineAdjdctn = Seq("DND", "DNDZB")

      val nbrclm_denied_outntwk_bronze_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"))

      val nbrclm_denied_outntwk_silver_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"))

      val brSil = nbrclm_denied_outntwk_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"))

      val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip")

      val nbrclm_denied_outntwk_gold_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"))

      val bsGld = brSilData.alias("parent").join(nbrclm_denied_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"))

      val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip")

      val nbrclm_denied_outntwk_platinum_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"))

      val bsgchild = bsGldData.alias("parent").join(nbrclm_denied_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"))

      val bsgchildData = bsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip")

      val tot_ip = nbrclm_denied_outntwk_bronze_ip.union(nbrclm_denied_outntwk_silver_ip.union(nbrclm_denied_outntwk_gold_ip.union(nbrclm_denied_outntwk_platinum_ip)))
        .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"))

      val nbrclm_denied_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip").alias("nbrclm_denied_outntwk_" + colvalue + "_total_ip"))

      val ip = bsgchildData.alias("parent").join(nbrclm_denied_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_ip"))

      val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp", lit(0))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", lit(0))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", lit(0))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", lit(0))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_total_sgp", lit(0))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip",
          "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_outntwk_" + colvalue + "_total_ip", "nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp",
          "nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_outntwk_" + colvalue + "_total_sgp")

      var denied_gtlgp = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") &&
        !$"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

      val denied_in_gtlgp = joinedDf_new(denied_gtlgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

      val nbrclm_denied_outntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colvalue + "_gtlgp"))

      val gtlgpMaster = ipData.alias("parent").join(nbrclm_denied_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtlgp"))

      val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_gtsgp", lit(0))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_outntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_outntwk_" + colvalue + "_total_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gtlgp", "nbrclm_denied_outntwk_" + colvalue + "_gtsgp")

      var received_gtip = naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
        !$"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

      val denied_in_gtip = joinedDf_new(received_gtip, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

      val nbrclm_denied_outntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colvalue + "_gtip"))

      val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtip"))

      val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_outntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_outntwk_" + colvalue + "_total_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gtlgp", "nbrclm_denied_outntwk_" + colvalue + "_gtsgp", "nbrclm_denied_outntwk_" + colvalue + "_gtip")

      val tot_gt = nbrclm_denied_outntwk_gtip.union(nbrclm_denied_outntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colvalue + "_gtip"))

      val nbrclm_denied_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col("nbrclm_denied_outntwk_" + colvalue + "_gtip")).alias("nbrclm_denied_outntwk_" + colvalue + "_total_gtip"))

      val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_gtip"))

      val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_catastrophic", lit(0))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_outntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_outntwk_" + colvalue + "_total_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gtlgp", "nbrclm_denied_outntwk_" + colvalue + "_gtsgp", "nbrclm_denied_outntwk_" + colvalue + "_gtip", "nbrclm_denied_outntwk_" + colvalue + "_total_gtip", "nbrclm_denied_outntwk_" + colvalue + "_catastrophic")

      var denied_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
        !$"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

      val denied_in_lgpmmcare = joinedDf_new(denied_lgpmmcare, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

      val nbrclm_denied_outntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colvalue + "_lgp_mmcare"))

      val lgpmmcareMaster = gttotMasterData.alias("parent").join(nbrclm_denied_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_gtip"), col("nbrclm_denied_outntwk_" + colvalue + "_catastrophic"), col("nbrclm_denied_outntwk_" + colvalue + "_lgp_mmcare"))

      val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_outntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_outntwk_" + colvalue + "_total_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gtlgp", "nbrclm_denied_outntwk_" + colvalue + "_gtsgp", "nbrclm_denied_outntwk_" + colvalue + "_gtip", "nbrclm_denied_outntwk_" + colvalue + "_total_gtip", "nbrclm_denied_outntwk_" + colvalue + "_catastrophic", "nbrclm_denied_outntwk_" + colvalue + "_lgp_mmcare")

      val nbrclm_denied_outntwk_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colvalue + "_stucvg"))

      val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_gtip"), col("nbrclm_denied_outntwk_" + colvalue + "_catastrophic"), col("nbrclm_denied_outntwk_" + colvalue + "_lgp_mmcare"), col("nbrclm_denied_outntwk_" + colvalue + "_stucvg"))

      val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_outntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_outntwk_" + colvalue + "_total_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gtlgp", "nbrclm_denied_outntwk_" + colvalue + "_gtsgp", "nbrclm_denied_outntwk_" + colvalue + "_gtip", "nbrclm_denied_outntwk_" + colvalue + "_total_gtip", "nbrclm_denied_outntwk_" + colvalue + "_catastrophic", "nbrclm_denied_outntwk_" + colvalue + "_lgp_mmcare", "nbrclm_denied_outntwk_" + colvalue + "_stucvg")

      stucvgMasterData
    }

  def getdeniedbhebhoutntwk(colvalue: String, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame,
    naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame): DataFrame =

    {

      val clmLineAdjdctn = Seq("DND", "DNDZB")
      val clminn_cd = Seq("IN", "PAR")
      val nbrclm_denied_outntwk_bronze_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"))

      val nbrclm_denied_outntwk_silver_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"))

      val brSil = nbrclm_denied_outntwk_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"))

      val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip")

      val nbrclm_denied_outntwk_gold_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"))

      val bsGld = brSilData.alias("parent").join(nbrclm_denied_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"))

      val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip")

      val nbrclm_denied_outntwk_platinum_ip = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"))

      val bsgchild = bsGldData.alias("parent").join(nbrclm_denied_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"))

      val bsgchildData = bsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip")

      val tot_ip = nbrclm_denied_outntwk_bronze_ip.union(nbrclm_denied_outntwk_silver_ip.union(nbrclm_denied_outntwk_gold_ip.union(nbrclm_denied_outntwk_platinum_ip)))
        .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"))

      val nbrclm_denied_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip").alias("nbrclm_denied_outntwk_" + colvalue + "_total_ip"))

      val ip = bsgchildData.alias("parent").join(nbrclm_denied_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_ip"))

      val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp", lit(0))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", lit(0))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", lit(0))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", lit(0))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_total_sgp", lit(0))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip",
          "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_outntwk_" + colvalue + "_total_ip", "nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp",
          "nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_outntwk_" + colvalue + "_total_sgp")

      var denied_gtlgp = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") &&
        !$"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

      val denied_in_gtlgp = joinedDf1(colvalue, denied_gtlgp, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

      val nbrclm_denied_outntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colvalue + "_gtlgp"))


      val gtlgpMaster = ipData.alias("parent").join(nbrclm_denied_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtlgp"))

      val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_gtsgp", lit(0))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_outntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_outntwk_" + colvalue + "_total_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gtlgp", "nbrclm_denied_outntwk_" + colvalue + "_gtsgp")

      var received_gtip = naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
        !$"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

      val denied_in_gtip = joinedDf1(colvalue, received_gtip, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

      val nbrclm_denied_outntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colvalue + "_gtip"))

      val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtip"))

      val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_outntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_outntwk_" + colvalue + "_total_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gtlgp", "nbrclm_denied_outntwk_" + colvalue + "_gtsgp", "nbrclm_denied_outntwk_" + colvalue + "_gtip")

      val tot_gt = nbrclm_denied_outntwk_gtip.union(nbrclm_denied_outntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colvalue + "_gtip"))

      val nbrclm_denied_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col("nbrclm_denied_outntwk_" + colvalue + "_gtip")).alias("nbrclm_denied_outntwk_" + colvalue + "_total_gtip"))

      val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_gtip"))

      val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .withColumn("nbrclm_denied_outntwk_" + colvalue + "_catastrophic", lit(0))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_outntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_outntwk_" + colvalue + "_total_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gtlgp", "nbrclm_denied_outntwk_" + colvalue + "_gtsgp", "nbrclm_denied_outntwk_" + colvalue + "_gtip", "nbrclm_denied_outntwk_" + colvalue + "_total_gtip", "nbrclm_denied_outntwk_" + colvalue + "_catastrophic")
      var denied_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
        !$"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

      val denied_in_lgpmmcare = joinedDf1(colvalue, denied_lgpmmcare, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd)

      val nbrclm_denied_outntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
        .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colvalue + "_lgp_mmcare"))

      val lgpmmcareMaster = gttotMasterData.alias("parent").join(nbrclm_denied_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_gtip"), col("nbrclm_denied_outntwk_" + colvalue + "_catastrophic"), col("nbrclm_denied_outntwk_" + colvalue + "_lgp_mmcare"))

      val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_outntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_outntwk_" + colvalue + "_total_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gtlgp", "nbrclm_denied_outntwk_" + colvalue + "_gtsgp", "nbrclm_denied_outntwk_" + colvalue + "_gtip", "nbrclm_denied_outntwk_" + colvalue + "_total_gtip", "nbrclm_denied_outntwk_" + colvalue + "_catastrophic", "nbrclm_denied_outntwk_" + colvalue + "_lgp_mmcare")

      val nbrclm_denied_outntwk_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_denied_outntwk_" + colvalue + "_stucvg"))

      val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
        && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
        .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
          $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
          $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colvalue + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_ip"),
          col("nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_total_sgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtlgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtsgp"), col("nbrclm_denied_outntwk_" + colvalue + "_gtip"), col("nbrclm_denied_outntwk_" + colvalue + "_total_gtip"), col("nbrclm_denied_outntwk_" + colvalue + "_catastrophic"), col("nbrclm_denied_outntwk_" + colvalue + "_lgp_mmcare"), col("nbrclm_denied_outntwk_" + colvalue + "_stucvg"))

      val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
        .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
        .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
        .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colvalue + "_bronze_ip", "nbrclm_denied_outntwk_" + colvalue + "_silver_ip", "nbrclm_denied_outntwk_" + colvalue + "_gold_ip", "nbrclm_denied_outntwk_" + colvalue + "_platinum_ip", "nbrclm_denied_outntwk_" + colvalue + "_total_ip",
          "nbrclm_denied_outntwk_" + colvalue + "_bronze_sgp", "nbrclm_denied_outntwk_" + colvalue + "_silver_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gold_sgp", "nbrclm_denied_outntwk_" + colvalue + "_platinum_sgp", "nbrclm_denied_outntwk_" + colvalue + "_total_sgp", "nbrclm_denied_outntwk_" + colvalue + "_gtlgp", "nbrclm_denied_outntwk_" + colvalue + "_gtsgp", "nbrclm_denied_outntwk_" + colvalue + "_gtip", "nbrclm_denied_outntwk_" + colvalue + "_total_gtip", "nbrclm_denied_outntwk_" + colvalue + "_catastrophic", "nbrclm_denied_outntwk_" + colvalue + "_lgp_mmcare", "nbrclm_denied_outntwk_" + colvalue + "_stucvg")
 
      stucvgMasterData
    }
  
  
  

}

object PCADX_SCL_NAIC_UnicareStgTransformationclmexphmcy {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
  }
}