package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate

class PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_tbl1_1(val spark: SparkSession) {

  /* val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()*/

  import spark.implicits._

  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_tbl1_1])

  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))

  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clmex")
  val end_year = dbProperties.getProperty("end_year_clmex")
  var naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame = null
  var naic2018_mcas_src_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame = null
  def sparkInIt(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic2018_mcas_src_eob_cd_inbnd: DataFrame, naic2018_mcas_eob_cd_inbnd: DataFrame, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame, load_log_key: String) {

    val oexclmphrmcy = new PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy(spark)

    /* naic_mcas_hlthex_clmexphmcy_received_ip_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic_mcas_hlthex_clmexphmcy_received_ip_wrk")

     naic_mcas_hlthex_clmexphmcy_received_sgp_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic_mcas_hlthex_clmexphmcy_received_sgp_wrk")
      naic_mcas_hlthex_clmexphmcy_received_cat_wrk = oexclmphrmcy.readDataFromHive(dbwrk+".naic_mcas_hlthex_clmexphmcy_received_cat_wrk")
     naic_mcas_src_eob_cd_inbnd =  oexclmphrmcy.readDataFromHive(dbInbnd+".naic_mcas_src_eob_cd_inbnd")
     naic_mcas_eob_cd_inbnd =  oexclmphrmcy.readDataFromHive(dbInbnd+".naic_mcas_eob_cd_inbnd")
     naic_mcas_src_clm_line_disp_rsn_cd_inbnd =  oexclmphrmcy.readDataFromHive(dbInbnd+".naic_mcas_src_clm_line_disp_rsn_cd_inbnd")

     */
    val objclmReceivedData = oexclmphrmcy.clmReceivedData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk)
    val objsubInntwkData = oexclmphrmcy.getSubInntwkData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk)
    val objsubOutntwkData = oexclmphrmcy.getSubOutntwkData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk)
    val objDeniedInntwk = oexclmphrmcy.getDeniedInntwk(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk0_30 = oexclmphrmcy.getDeniedInntwkBetweenDates(0, 30, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk31_60 = oexclmphrmcy.getDeniedInntwkBetweenDates(31, 60, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk61_90 = oexclmphrmcy.getDeniedInntwkBetweenDates(61, 90, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk_90 = oexclmphrmcy.getDeniedInntwk_90(end_year, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val StgData_1 = getStageData(objclmReceivedData, objsubInntwkData, objsubOutntwkData,
      objDeniedInntwk: DataFrame, objDeniedInntwk0_30: DataFrame, objDeniedInntwk31_60,
      objDeniedInntwk61_90, objDeniedInntwk_90)
    /* var load_log_key = ""
    if(!naic_mcas_hlthex_clmexphmcy_received_ip_wrk.take(1).isEmpty){
     load_log_key = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.select($"load_log_key").first.getString(0)
    }*/
    val f_stgData = StgData_1.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
    oexclmphrmcy.writeDataToHive(dbwrk + ".naic2018_mcas_hlthiex_clmexphmcy_recSubColstemp", f_stgData)
    //spark.close()\
    //f_stgData.repartition(1)
    //Thread.sleep(2000)
    //spark.close()
    println("After spark close")
  }

  def getStageData(objclmReceivedData: DataFrame, objsubInntwkData: DataFrame, objsubOutntwkData: DataFrame,
                   objDeniedInntwk: DataFrame, objDeniedInntwk0_30: DataFrame, objDeniedInntwk31_60: DataFrame,
                   objDeniedInntwk61_90: DataFrame, objDeniedInntwk_90: DataFrame): DataFrame = {

    println("first")
    val rec_subIn = objclmReceivedData.alias("parent").join(objsubInntwkData.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"), $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"), $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"), col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"), col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_bronze_ms_ip"), col("nbrclm_received_silver_ms_ip"), col("nbrclm_received_gold_ms_ip"), col("nbrclm_received_platinum_ms_ip"), col("nbrclm_received_total_ms_ip"), col("nbrclm_received_bronze_ms_sgp"), col("nbrclm_received_silver_ms_sgp"), col("nbrclm_received_gold_ms_sgp"), col("nbrclm_received_platinum_ms_sgp"), col("nbrclm_received_total_ms_sgp"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"), col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_catastrophic"), col("nbrclm_sub_inntwk_bronze_ms_ip"), col("nbrclm_sub_inntwk_silver_ms_ip"), col("nbrclm_sub_inntwk_gold_ms_ip"), col("nbrclm_sub_inntwk_platinum_ms_ip"), col("nbrclm_sub_inntwk_total_ms_ip"), col("nbrclm_sub_inntwk_bronze_ms_sgp"), col("nbrclm_sub_inntwk_silver_ms_sgp"), col("nbrclm_sub_inntwk_gold_ms_sgp"), col("nbrclm_sub_inntwk_platinum_ms_sgp"), col("nbrclm_sub_inntwk_total_ms_sgp"))

    val rec_subInData = rec_subIn.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year")).withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny")).withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state")).withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("in_exchange", "health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip", "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp", "nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_bronze_ms_ip", "nbrclm_received_silver_ms_ip", "nbrclm_received_gold_ms_ip", "nbrclm_received_platinum_ms_ip", "nbrclm_received_total_ms_ip", "nbrclm_received_bronze_ms_sgp", "nbrclm_received_silver_ms_sgp", "nbrclm_received_gold_ms_sgp", "nbrclm_received_platinum_ms_sgp", "nbrclm_received_total_ms_sgp", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_catastrophic", "nbrclm_sub_inntwk_bronze_ms_ip", "nbrclm_sub_inntwk_silver_ms_ip", "nbrclm_sub_inntwk_gold_ms_ip", "nbrclm_sub_inntwk_platinum_ms_ip", "nbrclm_sub_inntwk_total_ms_ip", "nbrclm_sub_inntwk_bronze_ms_sgp", "nbrclm_sub_inntwk_silver_ms_sgp", "nbrclm_sub_inntwk_gold_ms_sgp", "nbrclm_sub_inntwk_platinum_ms_sgp", "nbrclm_sub_inntwk_total_ms_sgp")

    val sub_out = rec_subInData.alias("parent").join(objsubOutntwkData.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"), $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"), $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"), col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"), col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_bronze_ms_ip"), col("nbrclm_received_silver_ms_ip"), col("nbrclm_received_gold_ms_ip"), col("nbrclm_received_platinum_ms_ip"), col("nbrclm_received_total_ms_ip"), col("nbrclm_received_bronze_ms_sgp"), col("nbrclm_received_silver_ms_sgp"), col("nbrclm_received_gold_ms_sgp"), col("nbrclm_received_platinum_ms_sgp"), col("nbrclm_received_total_ms_sgp"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"), col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_catastrophic"), col("nbrclm_sub_inntwk_bronze_ms_ip"), col("nbrclm_sub_inntwk_silver_ms_ip"), col("nbrclm_sub_inntwk_gold_ms_ip"), col("nbrclm_sub_inntwk_platinum_ms_ip"), col("nbrclm_sub_inntwk_total_ms_ip"), col("nbrclm_sub_inntwk_bronze_ms_sgp"), col("nbrclm_sub_inntwk_silver_ms_sgp"), col("nbrclm_sub_inntwk_gold_ms_sgp"), col("nbrclm_sub_inntwk_platinum_ms_sgp"), col("nbrclm_sub_inntwk_total_ms_sgp"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"), col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_catastrophic"), col("nbrclm_sub_outntwk_bronze_ms_ip"), col("nbrclm_sub_outntwk_silver_ms_ip"), col("nbrclm_sub_outntwk_gold_ms_ip"), col("nbrclm_sub_outntwk_platinum_ms_ip"), col("nbrclm_sub_outntwk_total_ms_ip"), col("nbrclm_sub_outntwk_bronze_ms_sgp"), col("nbrclm_sub_outntwk_silver_ms_sgp"), col("nbrclm_sub_outntwk_gold_ms_sgp"), col("nbrclm_sub_outntwk_platinum_ms_sgp"), col("nbrclm_sub_outntwk_total_ms_sgp"))
    val sub_outData = sub_out.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year")).withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny")).withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state")).withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("in_exchange", "health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip", "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp", "nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_bronze_ms_ip", "nbrclm_received_silver_ms_ip", "nbrclm_received_gold_ms_ip", "nbrclm_received_platinum_ms_ip", "nbrclm_received_total_ms_ip", "nbrclm_received_bronze_ms_sgp", "nbrclm_received_silver_ms_sgp", "nbrclm_received_gold_ms_sgp", "nbrclm_received_platinum_ms_sgp", "nbrclm_received_total_ms_sgp", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_catastrophic", "nbrclm_sub_inntwk_bronze_ms_ip", "nbrclm_sub_inntwk_silver_ms_ip", "nbrclm_sub_inntwk_gold_ms_ip", "nbrclm_sub_inntwk_platinum_ms_ip", "nbrclm_sub_inntwk_total_ms_ip", "nbrclm_sub_inntwk_bronze_ms_sgp", "nbrclm_sub_inntwk_silver_ms_sgp", "nbrclm_sub_inntwk_gold_ms_sgp", "nbrclm_sub_inntwk_platinum_ms_sgp", "nbrclm_sub_inntwk_total_ms_sgp", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_catastrophic", "nbrclm_sub_outntwk_bronze_ms_ip", "nbrclm_sub_outntwk_silver_ms_ip", "nbrclm_sub_outntwk_gold_ms_ip", "nbrclm_sub_outntwk_platinum_ms_ip", "nbrclm_sub_outntwk_total_ms_ip", "nbrclm_sub_outntwk_bronze_ms_sgp", "nbrclm_sub_outntwk_silver_ms_sgp", "nbrclm_sub_outntwk_gold_ms_sgp", "nbrclm_sub_outntwk_platinum_ms_sgp", "nbrclm_sub_outntwk_total_ms_sgp")

    sub_outData
  }
}
object PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_tbl1_1 {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    // new PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_tbl1_1().sparkInIt()
  }
}