package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy(val spark: SparkSession) {
  var year = ""
  val dbProperties = new Properties

  /*val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()*/

  import spark.implicits._
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy])
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clmex")
  val end_year = dbProperties.getProperty("end_year_clmex")

  var naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame = null
  var naic2018_mcas_src_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame = null

  // New Looked up Tables-2018 @12/21/2018
  var naic2018_mcas_ce_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd: DataFrame = null
  var naic2018_mcas_ce_src_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_ncb_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd: DataFrame = null
  var naic2018_mcas_ncb_src_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_nmn_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame = null
  var naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_nmnbh_hlth_srvc_cd_inbnd: DataFrame = null
  var naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame = null
  var naic2018_mcas_nmnbh_icd_proc_cd_inbnd: DataFrame = null
  var naic2018_mcas_pa_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd: DataFrame = null
  var naic2018_mcas_pa_src_eob_cd_inbnd: DataFrame = null

  def sparkInIt() {

    naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk")
    naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk")
    naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk")
    naic2018_mcas_src_eob_cd_inbnd = readDataFromHive(dbInbnd + ".naic2018_mcas_src_eob_cd_inbnd")
    naic2018_mcas_eob_cd_inbnd = readDataFromHive(dbInbnd + ".naic2018_mcas_eob_cd_inbnd")
    naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd = readDataFromHive(dbInbnd + ".naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd")
    naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk")
    naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk")
    naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk")

    naic2018_mcas_ce_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_ce_eob_cd_inbnd")
    naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd")
    naic2018_mcas_ce_src_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_ce_src_eob_cd_inbnd")
    naic2018_mcas_ncb_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_ncb_eob_cd_inbnd")
    naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd")
    naic2018_mcas_ncb_src_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_ncb_src_eob_cd_inbnd")
    naic2018_mcas_nmn_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_nmn_eob_cd_inbnd")
    naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd")
    naic2018_mcas_nmn_src_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_nmn_src_eob_cd_inbnd")
    naic2018_mcas_nmnbh_hlth_srvc_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_nmnbh_hlth_srvc_cd_inbnd")
    naic2018_mcas_nmnbh_icd_diag_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_nmnbh_icd_diag_cd_inbnd")
    naic2018_mcas_nmnbh_icd_proc_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_nmnbh_icd_proc_cd_inbnd")
    naic2018_mcas_pa_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_pa_eob_cd_inbnd")
    naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd")
    naic2018_mcas_pa_src_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_pa_src_eob_cd_inbnd")

    // populateStgTbl()
    //val load_log_key = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.select($"load_log_key").first.getString(0)
    spark.close()
  }

  /*def populateStgTbl(){

     truncateTbl(dbsg+".naic_mcas_hlthiex_clmexphmcy_stg")
    val obj_clmsExPhrmcy = new PCADX_SCL_NAIC_IEXStgTransformationclmexphmcy_part2()
    val oex_pat3 = new PCADX_SCL_NAIC_IEXStgTransformationclmexphmcy_part3()
    val objclmReceivedData= clmReceivedData(naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk)
    val objsubInntwkData = getSubInntwkData(naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk)
    val objsubOutntwkData = getSubOutntwkData(naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk)
    val objDeniedInntwk =getDeniedInntwk(naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk,
        naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd,naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk0_30 = getDeniedInntwkBetweenDates(0, 30,naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk,naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd,naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk31_60 = getDeniedInntwkBetweenDates(31, 60,naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk,naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd,naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk61_90 = getDeniedInntwkBetweenDates(61, 90,naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk,naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd,naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    //objDeniedInntwk61_90.show
    val objDeniedInntwk_90 = getDeniedInntwk_90(end_year,naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk,naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd,naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val objDeniedOutntwk =getDeniedOutntwk(naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk,naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd,naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedOutntwk0_30 = getDeniedOutntwkBetweenDates(0, 30,naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk,naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd,naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedOutntwk31_60 = getDeniedOutntwkBetweenDates(31, 60,naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk,naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd,naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedOutntwk61_90 = getDeniedOutntwkBetweenDates(61, 90,naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk,naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd,naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
     val objDeniedOutnwk_90 = getDeniedOutntwk_90(end_year,naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk,naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd,naic_mcas_src_clm_line_disp_rsn_cd_inbnd)
     val objPaidInntwk = obj_clmsExPhrmcy.getPaidInntwk(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk,naic_mcas_hlthex_clmexphmcy_paid_cat_wrk,  naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
     val objPaidInntwk0_30 = obj_clmsExPhrmcy.getpaidInntwkBetweenDates(0, 30, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
     val objPaidInntwk31_60 = obj_clmsExPhrmcy.getpaidInntwkBetweenDates(31, 60, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
     val objPaidInntwk61_90 = obj_clmsExPhrmcy.getpaidInntwkBetweenDates(61, 90, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
     val objPaidInntwk_90 = obj_clmsExPhrmcy.getpaidInntwk_90(end_year, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)

     val objPaidOutntwk = obj_clmsExPhrmcy.getPaidOutntwk(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk,naic_mcas_hlthex_clmexphmcy_paid_cat_wrk,  naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
     val objPaidOutntwk0_30 = obj_clmsExPhrmcy.getpaidOutntwkBetweenDates(0, 30, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
     val objPaidOutntwk31_60 = obj_clmsExPhrmcy.getpaidOutntwkBetweenDates(31, 60, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
     val objPaidOutntwk61_90 = obj_clmsExPhrmcy.getpaidOutntwkBetweenDates(61, 90, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
     val objPaidOutntwk_90 = obj_clmsExPhrmcy.getpaidOutntwk_90(end_year, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
     val clm_paidamt = obj_clmsExPhrmcy.getamtData("PAID_AMT","paid",naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
     val clm_cpayamt = obj_clmsExPhrmcy.getamtData("CPAY_AMT","copay",naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
     val clm_coinsrnamt = obj_clmsExPhrmcy.getamtData("COINSRN_AMT","coinsrn",naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
     val clm_ddctblamt = obj_clmsExPhrmcy.getamtData("DDCTBL_AMT","ddctbl",naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic_mcas_hlthex_clmexphmcy_paid_sgp_wrk)
     println("Done ")
     val StgData = oex_pat3.getStageData(objclmReceivedData,objsubInntwkData,objsubOutntwkData,
      objDeniedInntwk:DataFrame,objDeniedInntwk0_30:DataFrame,objDeniedInntwk31_60,
      objDeniedInntwk61_90,objDeniedInntwk_90 ,objDeniedOutntwk,
      objDeniedOutntwk0_30,objDeniedOutntwk31_60,objDeniedOutntwk61_90,
      objDeniedOutnwk_90, objPaidInntwk, objPaidInntwk0_30,
      objPaidInntwk31_60, objPaidInntwk61_90, objPaidInntwk_90,
      objPaidOutntwk, objPaidOutntwk0_30, objPaidOutntwk31_60,
      objPaidOutntwk61_90, objPaidOutntwk_90,clm_paidamt, clm_cpayamt,clm_coinsrnamt, clm_ddctblamt)


      val finalStgData = StgData.withColumn("load_log_key", lit(null)).withColumn("load_dt", current_timestamp())

      //writeDataToHive(dbsg+".naic_mcas_hlthiex_clmexphmcy_stg", finalStgData)

  }*/
  def truncateTbl(tblName: String) {
    spark.sql("TRUNCATE TABLE " + tblName)
  }
  def writeDataToHive(tblName: String, finalDf: DataFrame) {
    finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
    println("Data added in stage table")
  }
  def readDataFromHive(tble: String): DataFrame = {
    val queryOutputTable = """SELECT * FROM """ + tble
    val tbl_data_df = spark.sql(queryOutputTable) //.na.fill("")
    logger.info("Read data from hive")
    tbl_data_df
  }

  def getIpSgpPlan(wrk_df: DataFrame, lob_type: String): DataFrame = {
    val metl_cd = Seq("01", "02", "03", "04")
    val ip_df = wrk_df.filter($"naic_lob".equalTo(lob_type) &&
      ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"hcr_cmplynt_cd".equalTo("Y") &&
      ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull) &&
      $"exchng_metl_type_cd".isin(metl_cd: _*) &&
      $"in_exchange".equalTo("IN"))

    ip_df
  }
  def getMSPlan(wrk_df: DataFrame, lob_type: String): DataFrame = {
    val metl_cd = Seq("01", "02", "03", "04")
    val msip_df = wrk_df.filter($"naic_lob".equalTo(lob_type) &&
      $"src_exchng_certfn_cd".equalTo("M") &&
      $"exchng_metl_type_cd".isin(metl_cd: _*) && //263
      $"in_exchange".equalTo("IN"))
    msip_df
  }
  def clmReceivedData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame): DataFrame = {
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val nbrclm_received_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_bronze_ip"))

    val nbrclm_received_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_silver_ip"))

    val brSil = nbrclm_received_bronze_ip.alias("parent").join(nbrclm_received_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip")

    val nbrclm_received_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_gold_ip"))

    val bsGld = brSilData.alias("parent").join(nbrclm_received_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"))

    val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip")
    val nbrclm_received_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_platinum_ip"))

    val bsgchild = bsGldData.alias("parent").join(nbrclm_received_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"))

    val bsgchildData = bsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip")

    val total_ip = nbrclm_received_bronze_ip.union(nbrclm_received_silver_ip.union(nbrclm_received_gold_ip.union(nbrclm_received_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_received_bronze_ip")

    val nbrclm_received_total_ip = total_ip.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum($"nbrclm_received_bronze_ip").alias("nbrclm_received_total_ip"))
    val ip = bsgchildData.alias("parent").join(nbrclm_received_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"))

    val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)
    val nbrclm_received_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_bronze_sgp"))
    val ipBrz = ipData.alias("parent").join(nbrclm_received_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"))

    val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp")

    val nbrclm_received_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_silver_sgp"))
    val ipbSil = ipBrzData.alias("parent").join(nbrclm_received_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"))

    val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp")
    val nbrclm_received_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_gold_sgp"))
    val ipbsGld = ipbSilData.alias("parent").join(nbrclm_received_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"))

    val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp")
    val nbrclm_received_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_platinum_sgp"))
    val ipbsgchild = ipbsGldData.alias("parent").join(nbrclm_received_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"))

    val ipbsgchildData = ipbsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp")
    val total_sgp = nbrclm_received_bronze_sgp.union(nbrclm_received_silver_sgp.union(nbrclm_received_gold_sgp.union(nbrclm_received_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_received_bronze_sgp")

    val nbrclm_received_total_sgp = total_sgp.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum($"nbrclm_received_bronze_sgp").alias("nbrclm_received_total_sgp"))
    val ipsgp = ipbsgchildData.alias("parent").join(nbrclm_received_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"))

    val ipsgpData = ipsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp")

    val nbrclm_received_catastrophic = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_exchange".equalTo("IN") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_catastrophic"))

    val ipsgpCat = ipsgpData.alias("parent").join(nbrclm_received_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"))

    val ipsgpCatData = ipsgpCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val nbrclm_received_bronze_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_bronze_ms_ip"))
    val ipsgpBrz = ipsgpCatData.alias("parent").join(nbrclm_received_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_bronze_ms_ip"))

    val ipsgpBrzData = ipsgpBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_bronze_ms_ip")
    val nbrclm_received_silver_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_silver_ms_ip"))
    val ipsgpbSil = ipsgpBrzData.alias("parent").join(nbrclm_received_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_bronze_ms_ip"), col("nbrclm_received_silver_ms_ip"))

    val ipsgpbSilData = ipsgpbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_bronze_ms_ip", "nbrclm_received_silver_ms_ip")
    val nbrclm_received_gold_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_gold_ms_ip"))
    val ipsgpbsGld = ipsgpbSilData.alias("parent").join(nbrclm_received_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_bronze_ms_ip"), col("nbrclm_received_silver_ms_ip"), col("nbrclm_received_gold_ms_ip"))

    val ipsgpbsGldData = ipsgpbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_bronze_ms_ip", "nbrclm_received_silver_ms_ip", "nbrclm_received_gold_ms_ip")
    val nbrclm_received_platinum_ms_ip = msip_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_platinum_ms_ip"))

    val ipsgpbsgchild = ipsgpbsGldData.alias("parent").join(nbrclm_received_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_bronze_ms_ip"), col("nbrclm_received_silver_ms_ip"), col("nbrclm_received_gold_ms_ip"), col("nbrclm_received_platinum_ms_ip"))

    val ipsgpbsgchildData = ipsgpbsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_bronze_ms_ip", "nbrclm_received_silver_ms_ip", "nbrclm_received_gold_ms_ip", "nbrclm_received_platinum_ms_ip")

    val total_ms_ip = nbrclm_received_bronze_ms_ip.union(nbrclm_received_silver_ms_ip.union(nbrclm_received_gold_ms_ip.union(nbrclm_received_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_received_bronze_ms_ip")

    val nbrclm_received_total_ms_ip = total_ms_ip.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum($"nbrclm_received_bronze_ms_ip").alias("nbrclm_received_total_ms_ip"))

    val ipsgpmsip = ipsgpbsgchildData.alias("parent").join(nbrclm_received_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_bronze_ms_ip"), col("nbrclm_received_silver_ms_ip"), col("nbrclm_received_gold_ms_ip"), col("nbrclm_received_platinum_ms_ip"),
        col("nbrclm_received_total_ms_ip"))

    val ipsgpmsipData = ipsgpmsip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_bronze_ms_ip", "nbrclm_received_silver_ms_ip", "nbrclm_received_gold_ms_ip", "nbrclm_received_platinum_ms_ip",
        "nbrclm_received_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val ms_sgp_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)
    val nbrclm_received_bronze_ms_sgp = ms_sgp_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_bronze_ms_sgp"))

    val ipsgpmsipBrz = ipsgpmsipData.alias("parent").join(nbrclm_received_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_bronze_ms_ip"), col("nbrclm_received_silver_ms_ip"), col("nbrclm_received_gold_ms_ip"), col("nbrclm_received_platinum_ms_ip"),
        col("nbrclm_received_total_ms_ip"), col("nbrclm_received_bronze_ms_sgp"))

    val ipsgpmsipBrzData = ipsgpmsipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_bronze_ms_ip", "nbrclm_received_silver_ms_ip", "nbrclm_received_gold_ms_ip", "nbrclm_received_platinum_ms_ip",
        "nbrclm_received_total_ms_ip", "nbrclm_received_bronze_ms_sgp")
    val nbrclm_received_silver_ms_sgp = ms_sgp_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_silver_ms_sgp"))

    val ipsgpmsipbSil = ipsgpmsipBrzData.alias("parent").join(nbrclm_received_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_bronze_ms_ip"), col("nbrclm_received_silver_ms_ip"), col("nbrclm_received_gold_ms_ip"), col("nbrclm_received_platinum_ms_ip"),
        col("nbrclm_received_total_ms_ip"), col("nbrclm_received_bronze_ms_sgp"), col("nbrclm_received_silver_ms_sgp"))

    val ipsgpmsipbSilData = ipsgpmsipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_bronze_ms_ip", "nbrclm_received_silver_ms_ip", "nbrclm_received_gold_ms_ip", "nbrclm_received_platinum_ms_ip",
        "nbrclm_received_total_ms_ip", "nbrclm_received_bronze_ms_sgp", "nbrclm_received_silver_ms_sgp")

    val nbrclm_received_gold_ms_sgp = ms_sgp_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_gold_ms_sgp"))

    val ipsgpmsipbsGld = ipsgpmsipbSilData.alias("parent").join(nbrclm_received_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_bronze_ms_ip"), col("nbrclm_received_silver_ms_ip"), col("nbrclm_received_gold_ms_ip"), col("nbrclm_received_platinum_ms_ip"),
        col("nbrclm_received_total_ms_ip"), col("nbrclm_received_bronze_ms_sgp"), col("nbrclm_received_silver_ms_sgp"), col("nbrclm_received_gold_ms_sgp"))

    val ipsgpmsipbsGldData = ipsgpmsipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_bronze_ms_ip", "nbrclm_received_silver_ms_ip", "nbrclm_received_gold_ms_ip", "nbrclm_received_platinum_ms_ip",
        "nbrclm_received_total_ms_ip", "nbrclm_received_bronze_ms_sgp", "nbrclm_received_silver_ms_sgp", "nbrclm_received_gold_ms_sgp")

    val nbrclm_received_platinum_ms_sgp = ms_sgp_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_received_platinum_ms_sgp"))
    val ipsgpmsipbsgchild = ipsgpmsipbsGldData.alias("parent").join(nbrclm_received_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_bronze_ms_ip"), col("nbrclm_received_silver_ms_ip"), col("nbrclm_received_gold_ms_ip"), col("nbrclm_received_platinum_ms_ip"),
        col("nbrclm_received_total_ms_ip"), col("nbrclm_received_bronze_ms_sgp"), col("nbrclm_received_silver_ms_sgp"), col("nbrclm_received_gold_ms_sgp"), col("nbrclm_received_platinum_ms_sgp"))

    val ipsgpmsipbsgchildData = ipsgpmsipbsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_bronze_ms_ip", "nbrclm_received_silver_ms_ip", "nbrclm_received_gold_ms_ip", "nbrclm_received_platinum_ms_ip",
        "nbrclm_received_total_ms_ip", "nbrclm_received_bronze_ms_sgp", "nbrclm_received_silver_ms_sgp", "nbrclm_received_gold_ms_sgp", "nbrclm_received_platinum_ms_sgp")

    val total_ms_sgp = nbrclm_received_bronze_ms_sgp.union(nbrclm_received_silver_ms_sgp.union(nbrclm_received_gold_ms_sgp.union(nbrclm_received_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_received_bronze_ms_sgp")

    val nbrclm_received_total_ms_sgp = total_ms_sgp.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum($"nbrclm_received_bronze_ms_sgp").alias("nbrclm_received_total_ms_sgp"))

    val ipsgpmsipmssgp = ipsgpmsipbsgchildData.alias("parent").join(nbrclm_received_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_catastrophic"), col("nbrclm_received_bronze_ms_ip"), col("nbrclm_received_silver_ms_ip"), col("nbrclm_received_gold_ms_ip"), col("nbrclm_received_platinum_ms_ip"),
        col("nbrclm_received_total_ms_ip"), col("nbrclm_received_bronze_ms_sgp"), col("nbrclm_received_silver_ms_sgp"), col("nbrclm_received_gold_ms_sgp"), col("nbrclm_received_platinum_ms_sgp"),
        col("nbrclm_received_total_ms_sgp"))

    val receivedData = ipsgpmsipmssgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_catastrophic", "nbrclm_received_bronze_ms_ip", "nbrclm_received_silver_ms_ip", "nbrclm_received_gold_ms_ip", "nbrclm_received_platinum_ms_ip",
        "nbrclm_received_total_ms_ip", "nbrclm_received_bronze_ms_sgp", "nbrclm_received_silver_ms_sgp", "nbrclm_received_gold_ms_sgp", "nbrclm_received_platinum_ms_sgp",
        "nbrclm_received_total_ms_sgp")

    receivedData

  }
  def getSubInntwkData(naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame): DataFrame = {
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val ip_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val nbrclm_sub_inntwk_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_bronze_ip"))

    val nbrclm_sub_inntwk_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_silver_ip"))

    val brzSil = nbrclm_sub_inntwk_bronze_ip.alias("parent").join(nbrclm_sub_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"))

    val brzSilData = brzSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip")

    val nbrclm_sub_inntwk_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_gold_ip"))

    val bsGld = brzSilData.alias("parent").join(nbrclm_sub_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"))

    val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip")

    val nbrclm_sub_inntwk_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_platinum_ip"))

    val bsgchild = bsGldData.alias("parent").join(nbrclm_sub_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"))

    val bsgchildData = bsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip")

    val tot_ip = nbrclm_sub_inntwk_bronze_ip.union(nbrclm_sub_inntwk_silver_ip.union(nbrclm_sub_inntwk_gold_ip.union(nbrclm_sub_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_sub_inntwk_bronze_ip")

    val nbrclm_sub_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_sub_inntwk_bronze_ip").alias("nbrclm_sub_inntwk_total_ip"))

    val ip = bsgchildData.alias("parent").join(nbrclm_sub_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"))

    val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val nbrclm_sub_inntwk_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_bronze_sgp"))
    val ipBrz = ipData.alias("parent").join(nbrclm_sub_inntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"))

    val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp")

    val nbrclm_sub_inntwk_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_silver_sgp"))
    val ipbSil = ipBrzData.alias("parent").join(nbrclm_sub_inntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"))

    val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp")

    val nbrclm_sub_inntwk_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_gold_sgp"))
    val ipbsGld = ipbSilData.alias("parent").join(nbrclm_sub_inntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"))

    val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp")

    val nbrclm_sub_inntwk_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_platinum_sgp"))
    val ipbsgchild = ipbsGldData.alias("parent").join(nbrclm_sub_inntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"))

    val ipbsgchildData = ipbsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp")

    val tot_sgp = nbrclm_sub_inntwk_bronze_sgp.union(nbrclm_sub_inntwk_silver_sgp.union(nbrclm_sub_inntwk_gold_sgp.union(nbrclm_sub_inntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_sub_inntwk_bronze_sgp")

    val nbrclm_sub_inntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_sub_inntwk_bronze_sgp").alias("nbrclm_sub_inntwk_total_sgp"))

    val ipsgp = ipbsgchildData.alias("parent").join(nbrclm_sub_inntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"))

    val ipsgpData = ipsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp")

    val nbrclm_sub_inntwk_catastrophic = naic_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_exchange".equalTo("IN") && $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_catastrophic"))

    val ipsgpcat = ipsgpData.alias("parent").join(nbrclm_sub_inntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_catastrophic"))

    val ipsgpcatData = ipsgpcat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val ms_ip_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)
    val nbrclm_sub_inntwk_bronze_ms_ip = ms_ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_bronze_ms_ip"))

    val ipsgpbrz = ipsgpcatData.alias("parent").join(nbrclm_sub_inntwk_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_catastrophic"),
        col("nbrclm_sub_inntwk_bronze_ms_ip"))

    val ipsgpbrzData = ipsgpbrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_catastrophic",
        "nbrclm_sub_inntwk_bronze_ms_ip")

    val nbrclm_sub_inntwk_silver_ms_ip = ms_ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_silver_ms_ip"))

    val ipsgpbSil = ipsgpbrzData.alias("parent").join(nbrclm_sub_inntwk_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_catastrophic"),
        col("nbrclm_sub_inntwk_bronze_ms_ip"), col("nbrclm_sub_inntwk_silver_ms_ip"))

    val ipsgpbSilData = ipsgpbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_catastrophic",
        "nbrclm_sub_inntwk_bronze_ms_ip", "nbrclm_sub_inntwk_silver_ms_ip")

    val nbrclm_sub_inntwk_gold_ms_ip = ms_ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_gold_ms_ip"))

    val ipsgpbsGld = ipsgpbSilData.alias("parent").join(nbrclm_sub_inntwk_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_catastrophic"),
        col("nbrclm_sub_inntwk_bronze_ms_ip"), col("nbrclm_sub_inntwk_silver_ms_ip"), col("nbrclm_sub_inntwk_gold_ms_ip"))

    val ipsgpbsGldData = ipsgpbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_catastrophic",
        "nbrclm_sub_inntwk_bronze_ms_ip", "nbrclm_sub_inntwk_silver_ms_ip", "nbrclm_sub_inntwk_gold_ms_ip")
    val nbrclm_sub_inntwk_platinum_ms_ip = ms_ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_platinum_ms_ip"))

    val ipsgpbsgchild = ipsgpbsGldData.alias("parent").join(nbrclm_sub_inntwk_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_catastrophic"),
        col("nbrclm_sub_inntwk_bronze_ms_ip"), col("nbrclm_sub_inntwk_silver_ms_ip"), col("nbrclm_sub_inntwk_gold_ms_ip"), col("nbrclm_sub_inntwk_platinum_ms_ip"))

    val ipsgpbsgchildData = ipsgpbsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_catastrophic",
        "nbrclm_sub_inntwk_bronze_ms_ip", "nbrclm_sub_inntwk_silver_ms_ip", "nbrclm_sub_inntwk_gold_ms_ip", "nbrclm_sub_inntwk_platinum_ms_ip")

    val tot_msip = nbrclm_sub_inntwk_bronze_ms_ip.union(nbrclm_sub_inntwk_silver_ms_ip.union(nbrclm_sub_inntwk_gold_ms_ip.union(nbrclm_sub_inntwk_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_sub_inntwk_bronze_ms_ip")

    val nbrclm_sub_inntwk_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_sub_inntwk_bronze_ms_ip").alias("nbrclm_sub_inntwk_total_ms_ip"))

    val ipsgpmsip = ipsgpbsgchildData.alias("parent").join(nbrclm_sub_inntwk_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_catastrophic"),
        col("nbrclm_sub_inntwk_bronze_ms_ip"), col("nbrclm_sub_inntwk_silver_ms_ip"), col("nbrclm_sub_inntwk_gold_ms_ip"), col("nbrclm_sub_inntwk_platinum_ms_ip"), col("nbrclm_sub_inntwk_total_ms_ip"))

    val ipsgpmsipData = ipsgpmsip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_catastrophic",
        "nbrclm_sub_inntwk_bronze_ms_ip", "nbrclm_sub_inntwk_silver_ms_ip", "nbrclm_sub_inntwk_gold_ms_ip", "nbrclm_sub_inntwk_platinum_ms_ip", "nbrclm_sub_inntwk_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val ms_sgp_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)
    val nbrclm_sub_inntwk_bronze_ms_sgp = ms_sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_bronze_ms_sgp"))

    val ipsgpmsipBrz = ipsgpmsipData.alias("parent").join(nbrclm_sub_inntwk_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_catastrophic"),
        col("nbrclm_sub_inntwk_bronze_ms_ip"), col("nbrclm_sub_inntwk_silver_ms_ip"), col("nbrclm_sub_inntwk_gold_ms_ip"), col("nbrclm_sub_inntwk_platinum_ms_ip"), col("nbrclm_sub_inntwk_total_ms_ip"),
        col("nbrclm_sub_inntwk_bronze_ms_sgp"))

    val ipsgpmsipBrzData = ipsgpmsipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_catastrophic",
        "nbrclm_sub_inntwk_bronze_ms_ip", "nbrclm_sub_inntwk_silver_ms_ip", "nbrclm_sub_inntwk_gold_ms_ip", "nbrclm_sub_inntwk_platinum_ms_ip", "nbrclm_sub_inntwk_total_ms_ip",
        "nbrclm_sub_inntwk_bronze_ms_sgp")

    val nbrclm_sub_inntwk_silver_ms_sgp = ms_sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_silver_ms_sgp"))

    val ipsgpmsipbSil = ipsgpmsipBrzData.alias("parent").join(nbrclm_sub_inntwk_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_catastrophic"),
        col("nbrclm_sub_inntwk_bronze_ms_ip"), col("nbrclm_sub_inntwk_silver_ms_ip"), col("nbrclm_sub_inntwk_gold_ms_ip"), col("nbrclm_sub_inntwk_platinum_ms_ip"), col("nbrclm_sub_inntwk_total_ms_ip"),
        col("nbrclm_sub_inntwk_bronze_ms_sgp"), col("nbrclm_sub_inntwk_silver_ms_sgp"))

    val ipsgpmsipbSilData = ipsgpmsipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_catastrophic",
        "nbrclm_sub_inntwk_bronze_ms_ip", "nbrclm_sub_inntwk_silver_ms_ip", "nbrclm_sub_inntwk_gold_ms_ip", "nbrclm_sub_inntwk_platinum_ms_ip", "nbrclm_sub_inntwk_total_ms_ip",
        "nbrclm_sub_inntwk_bronze_ms_sgp", "nbrclm_sub_inntwk_silver_ms_sgp")

    val nbrclm_sub_inntwk_gold_ms_sgp = ms_sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_gold_ms_sgp"))

    val ipsgpmsipbsGld = ipsgpmsipbSilData.alias("parent").join(nbrclm_sub_inntwk_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_catastrophic"),
        col("nbrclm_sub_inntwk_bronze_ms_ip"), col("nbrclm_sub_inntwk_silver_ms_ip"), col("nbrclm_sub_inntwk_gold_ms_ip"), col("nbrclm_sub_inntwk_platinum_ms_ip"), col("nbrclm_sub_inntwk_total_ms_ip"),
        col("nbrclm_sub_inntwk_bronze_ms_sgp"), col("nbrclm_sub_inntwk_silver_ms_sgp"), col("nbrclm_sub_inntwk_gold_ms_sgp"))

    val ipsgpmsipbsGldData = ipsgpmsipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_catastrophic",
        "nbrclm_sub_inntwk_bronze_ms_ip", "nbrclm_sub_inntwk_silver_ms_ip", "nbrclm_sub_inntwk_gold_ms_ip", "nbrclm_sub_inntwk_platinum_ms_ip", "nbrclm_sub_inntwk_total_ms_ip",
        "nbrclm_sub_inntwk_bronze_ms_sgp", "nbrclm_sub_inntwk_silver_ms_sgp", "nbrclm_sub_inntwk_gold_ms_sgp")
    val nbrclm_sub_inntwk_platinum_ms_sgp = ms_sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_inntwk_platinum_ms_sgp"))

    val ipsgpmsipbsgchild = ipsgpmsipbsGldData.alias("parent").join(nbrclm_sub_inntwk_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_catastrophic"),
        col("nbrclm_sub_inntwk_bronze_ms_ip"), col("nbrclm_sub_inntwk_silver_ms_ip"), col("nbrclm_sub_inntwk_gold_ms_ip"), col("nbrclm_sub_inntwk_platinum_ms_ip"), col("nbrclm_sub_inntwk_total_ms_ip"),
        col("nbrclm_sub_inntwk_bronze_ms_sgp"), col("nbrclm_sub_inntwk_silver_ms_sgp"), col("nbrclm_sub_inntwk_gold_ms_sgp"), col("nbrclm_sub_inntwk_platinum_ms_sgp"))

    val ipsgpmsipbsgchildData = ipsgpmsipbsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_catastrophic",
        "nbrclm_sub_inntwk_bronze_ms_ip", "nbrclm_sub_inntwk_silver_ms_ip", "nbrclm_sub_inntwk_gold_ms_ip", "nbrclm_sub_inntwk_platinum_ms_ip", "nbrclm_sub_inntwk_total_ms_ip",
        "nbrclm_sub_inntwk_bronze_ms_sgp", "nbrclm_sub_inntwk_silver_ms_sgp", "nbrclm_sub_inntwk_gold_ms_sgp", "nbrclm_sub_inntwk_platinum_ms_sgp")

    val tot_mssgp = nbrclm_sub_inntwk_bronze_ms_sgp.union(nbrclm_sub_inntwk_silver_ms_sgp.union(nbrclm_sub_inntwk_gold_ms_sgp.union(nbrclm_sub_inntwk_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_sub_inntwk_bronze_ms_sgp")

    val nbrclm_sub_inntwk_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_sub_inntwk_bronze_ms_sgp").alias("nbrclm_sub_inntwk_total_ms_sgp"))

    val subInnwtk = ipsgpmsipbsgchildData.alias("parent").join(nbrclm_sub_inntwk_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_catastrophic"),
        col("nbrclm_sub_inntwk_bronze_ms_ip"), col("nbrclm_sub_inntwk_silver_ms_ip"), col("nbrclm_sub_inntwk_gold_ms_ip"), col("nbrclm_sub_inntwk_platinum_ms_ip"), col("nbrclm_sub_inntwk_total_ms_ip"),
        col("nbrclm_sub_inntwk_bronze_ms_sgp"), col("nbrclm_sub_inntwk_silver_ms_sgp"), col("nbrclm_sub_inntwk_gold_ms_sgp"), col("nbrclm_sub_inntwk_platinum_ms_sgp"), col("nbrclm_sub_inntwk_total_ms_sgp"))

    val subInnwtkData = subInnwtk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_catastrophic",
        "nbrclm_sub_inntwk_bronze_ms_ip", "nbrclm_sub_inntwk_silver_ms_ip", "nbrclm_sub_inntwk_gold_ms_ip", "nbrclm_sub_inntwk_platinum_ms_ip", "nbrclm_sub_inntwk_total_ms_ip",
        "nbrclm_sub_inntwk_bronze_ms_sgp", "nbrclm_sub_inntwk_silver_ms_sgp", "nbrclm_sub_inntwk_gold_ms_sgp", "nbrclm_sub_inntwk_platinum_ms_sgp", "nbrclm_sub_inntwk_total_ms_sgp")

    subInnwtkData
  }
  def getSubOutntwkData(naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame): DataFrame = {
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val ip_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val nbrclm_sub_outntwk_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_bronze_ip"))

    val nbrclm_sub_outntwk_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_silver_ip"))

    val brzSil = nbrclm_sub_outntwk_bronze_ip.alias("parent").join(nbrclm_sub_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"))

    val brzSilData = brzSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip")

    val nbrclm_sub_outntwk_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_gold_ip"))

    val bsGld = brzSilData.alias("parent").join(nbrclm_sub_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"))

    val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip")

    val nbrclm_sub_outntwk_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_platinum_ip"))

    val bsgchild = bsGldData.alias("parent").join(nbrclm_sub_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"))

    val bsgchildData = bsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip")

    val tot_ip = nbrclm_sub_outntwk_bronze_ip.union(nbrclm_sub_outntwk_silver_ip.union(nbrclm_sub_outntwk_gold_ip.union(nbrclm_sub_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_sub_outntwk_bronze_ip")

    val nbrclm_sub_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_sub_outntwk_bronze_ip").alias("nbrclm_sub_outntwk_total_ip"))

    val ip = bsgchildData.alias("parent").join(nbrclm_sub_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"))

    val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val nbrclm_sub_outntwk_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_bronze_sgp"))
    val ipBrz = ipData.alias("parent").join(nbrclm_sub_outntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"))

    val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp")

    val nbrclm_sub_outntwk_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_silver_sgp"))
    val ipbSil = ipBrzData.alias("parent").join(nbrclm_sub_outntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"))

    val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp")

    val nbrclm_sub_outntwk_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_gold_sgp"))
    val ipbsGld = ipbSilData.alias("parent").join(nbrclm_sub_outntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"))

    val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp")

    val nbrclm_sub_outntwk_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_platinum_sgp"))
    val ipbsgchild = ipbsGldData.alias("parent").join(nbrclm_sub_outntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"))

    val ipbsgchildData = ipbsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp")

    val tot_sgp = nbrclm_sub_outntwk_bronze_sgp.union(nbrclm_sub_outntwk_silver_sgp.union(nbrclm_sub_outntwk_gold_sgp.union(nbrclm_sub_outntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_sub_outntwk_bronze_sgp")

    val nbrclm_sub_outntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_sub_outntwk_bronze_sgp").alias("nbrclm_sub_outntwk_total_sgp"))

    val ipsgp = ipbsgchildData.alias("parent").join(nbrclm_sub_outntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"))

    val ipsgpData = ipsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp")

    val nbrclm_sub_outntwk_catastrophic = naic_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      $"in_exchange".equalTo("IN") && (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_catastrophic"))

    val ipsgpcat = ipsgpData.alias("parent").join(nbrclm_sub_outntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_catastrophic"))

    val ipsgpcatData = ipsgpcat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val ms_ip_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)
    val nbrclm_sub_outntwk_bronze_ms_ip = ms_ip_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_bronze_ms_ip"))

    val ipsgpbrz = ipsgpcatData.alias("parent").join(nbrclm_sub_outntwk_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_catastrophic"),
        col("nbrclm_sub_outntwk_bronze_ms_ip"))

    val ipsgpbrzData = ipsgpbrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_catastrophic",
        "nbrclm_sub_outntwk_bronze_ms_ip")

    val nbrclm_sub_outntwk_silver_ms_ip = ms_ip_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_silver_ms_ip"))

    val ipsgpbSil = ipsgpbrzData.alias("parent").join(nbrclm_sub_outntwk_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_catastrophic"),
        col("nbrclm_sub_outntwk_bronze_ms_ip"), col("nbrclm_sub_outntwk_silver_ms_ip"))

    val ipsgpbSilData = ipsgpbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_catastrophic",
        "nbrclm_sub_outntwk_bronze_ms_ip", "nbrclm_sub_outntwk_silver_ms_ip")

    val nbrclm_sub_outntwk_gold_ms_ip = ms_ip_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_gold_ms_ip"))

    val ipsgpbsGld = ipsgpbSilData.alias("parent").join(nbrclm_sub_outntwk_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_catastrophic"),
        col("nbrclm_sub_outntwk_bronze_ms_ip"), col("nbrclm_sub_outntwk_silver_ms_ip"), col("nbrclm_sub_outntwk_gold_ms_ip"))

    val ipsgpbsGldData = ipsgpbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_catastrophic",
        "nbrclm_sub_outntwk_bronze_ms_ip", "nbrclm_sub_outntwk_silver_ms_ip", "nbrclm_sub_outntwk_gold_ms_ip")
    val nbrclm_sub_outntwk_platinum_ms_ip = ms_ip_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_platinum_ms_ip"))

    val ipsgpbsgchild = ipsgpbsGldData.alias("parent").join(nbrclm_sub_outntwk_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_catastrophic"),
        col("nbrclm_sub_outntwk_bronze_ms_ip"), col("nbrclm_sub_outntwk_silver_ms_ip"), col("nbrclm_sub_outntwk_gold_ms_ip"), col("nbrclm_sub_outntwk_platinum_ms_ip"))

    val ipsgpbsgchildData = ipsgpbsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_catastrophic",
        "nbrclm_sub_outntwk_bronze_ms_ip", "nbrclm_sub_outntwk_silver_ms_ip", "nbrclm_sub_outntwk_gold_ms_ip", "nbrclm_sub_outntwk_platinum_ms_ip")

    val tot_msip = nbrclm_sub_outntwk_bronze_ms_ip.union(nbrclm_sub_outntwk_silver_ms_ip.union(nbrclm_sub_outntwk_gold_ms_ip.union(nbrclm_sub_outntwk_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_sub_outntwk_bronze_ms_ip")

    val nbrclm_sub_outntwk_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_sub_outntwk_bronze_ms_ip").alias("nbrclm_sub_outntwk_total_ms_ip"))

    val ipsgpmsip = ipsgpbsgchildData.alias("parent").join(nbrclm_sub_outntwk_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_catastrophic"),
        col("nbrclm_sub_outntwk_bronze_ms_ip"), col("nbrclm_sub_outntwk_silver_ms_ip"), col("nbrclm_sub_outntwk_gold_ms_ip"), col("nbrclm_sub_outntwk_platinum_ms_ip"), col("nbrclm_sub_outntwk_total_ms_ip"))

    val ipsgpmsipData = ipsgpmsip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_catastrophic",
        "nbrclm_sub_outntwk_bronze_ms_ip", "nbrclm_sub_outntwk_silver_ms_ip", "nbrclm_sub_outntwk_gold_ms_ip", "nbrclm_sub_outntwk_platinum_ms_ip", "nbrclm_sub_outntwk_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val ms_sgp_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)
    val nbrclm_sub_outntwk_bronze_ms_sgp = ms_sgp_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_bronze_ms_sgp"))

    val ipsgpmsipBrz = ipsgpmsipData.alias("parent").join(nbrclm_sub_outntwk_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_catastrophic"),
        col("nbrclm_sub_outntwk_bronze_ms_ip"), col("nbrclm_sub_outntwk_silver_ms_ip"), col("nbrclm_sub_outntwk_gold_ms_ip"), col("nbrclm_sub_outntwk_platinum_ms_ip"), col("nbrclm_sub_outntwk_total_ms_ip"),
        col("nbrclm_sub_outntwk_bronze_ms_sgp"))

    val ipsgpmsipBrzData = ipsgpmsipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_catastrophic",
        "nbrclm_sub_outntwk_bronze_ms_ip", "nbrclm_sub_outntwk_silver_ms_ip", "nbrclm_sub_outntwk_gold_ms_ip", "nbrclm_sub_outntwk_platinum_ms_ip", "nbrclm_sub_outntwk_total_ms_ip",
        "nbrclm_sub_outntwk_bronze_ms_sgp")

    val nbrclm_sub_outntwk_silver_ms_sgp = ms_sgp_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_silver_ms_sgp"))

    val ipsgpmsipbSil = ipsgpmsipBrzData.alias("parent").join(nbrclm_sub_outntwk_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_catastrophic"),
        col("nbrclm_sub_outntwk_bronze_ms_ip"), col("nbrclm_sub_outntwk_silver_ms_ip"), col("nbrclm_sub_outntwk_gold_ms_ip"), col("nbrclm_sub_outntwk_platinum_ms_ip"), col("nbrclm_sub_outntwk_total_ms_ip"),
        col("nbrclm_sub_outntwk_bronze_ms_sgp"), col("nbrclm_sub_outntwk_silver_ms_sgp"))

    val ipsgpmsipbSilData = ipsgpmsipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_catastrophic",
        "nbrclm_sub_outntwk_bronze_ms_ip", "nbrclm_sub_outntwk_silver_ms_ip", "nbrclm_sub_outntwk_gold_ms_ip", "nbrclm_sub_outntwk_platinum_ms_ip", "nbrclm_sub_outntwk_total_ms_ip",
        "nbrclm_sub_outntwk_bronze_ms_sgp", "nbrclm_sub_outntwk_silver_ms_sgp")

    val nbrclm_sub_outntwk_gold_ms_sgp = ms_sgp_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_gold_ms_sgp"))

    val ipsgpmsipbsGld = ipsgpmsipbSilData.alias("parent").join(nbrclm_sub_outntwk_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_catastrophic"),
        col("nbrclm_sub_outntwk_bronze_ms_ip"), col("nbrclm_sub_outntwk_silver_ms_ip"), col("nbrclm_sub_outntwk_gold_ms_ip"), col("nbrclm_sub_outntwk_platinum_ms_ip"), col("nbrclm_sub_outntwk_total_ms_ip"),
        col("nbrclm_sub_outntwk_bronze_ms_sgp"), col("nbrclm_sub_outntwk_silver_ms_sgp"), col("nbrclm_sub_outntwk_gold_ms_sgp"))

    val ipsgpmsipbsGldData = ipsgpmsipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_catastrophic",
        "nbrclm_sub_outntwk_bronze_ms_ip", "nbrclm_sub_outntwk_silver_ms_ip", "nbrclm_sub_outntwk_gold_ms_ip", "nbrclm_sub_outntwk_platinum_ms_ip", "nbrclm_sub_outntwk_total_ms_ip",
        "nbrclm_sub_outntwk_bronze_ms_sgp", "nbrclm_sub_outntwk_silver_ms_sgp", "nbrclm_sub_outntwk_gold_ms_sgp")
    val nbrclm_sub_outntwk_platinum_ms_sgp = ms_sgp_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_sub_outntwk_platinum_ms_sgp"))

    val ipsgpmsipbsgchild = ipsgpmsipbsGldData.alias("parent").join(nbrclm_sub_outntwk_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_catastrophic"),
        col("nbrclm_sub_outntwk_bronze_ms_ip"), col("nbrclm_sub_outntwk_silver_ms_ip"), col("nbrclm_sub_outntwk_gold_ms_ip"), col("nbrclm_sub_outntwk_platinum_ms_ip"), col("nbrclm_sub_outntwk_total_ms_ip"),
        col("nbrclm_sub_outntwk_bronze_ms_sgp"), col("nbrclm_sub_outntwk_silver_ms_sgp"), col("nbrclm_sub_outntwk_gold_ms_sgp"), col("nbrclm_sub_outntwk_platinum_ms_sgp"))

    val ipsgpmsipbsgchildData = ipsgpmsipbsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_catastrophic",
        "nbrclm_sub_outntwk_bronze_ms_ip", "nbrclm_sub_outntwk_silver_ms_ip", "nbrclm_sub_outntwk_gold_ms_ip", "nbrclm_sub_outntwk_platinum_ms_ip", "nbrclm_sub_outntwk_total_ms_ip",
        "nbrclm_sub_outntwk_bronze_ms_sgp", "nbrclm_sub_outntwk_silver_ms_sgp", "nbrclm_sub_outntwk_gold_ms_sgp", "nbrclm_sub_outntwk_platinum_ms_sgp")

    val tot_mssgp = nbrclm_sub_outntwk_bronze_ms_sgp.union(nbrclm_sub_outntwk_silver_ms_sgp.union(nbrclm_sub_outntwk_gold_ms_sgp.union(nbrclm_sub_outntwk_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_sub_outntwk_bronze_ms_sgp")

    val nbrclm_sub_outntwk_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_sub_outntwk_bronze_ms_sgp").alias("nbrclm_sub_outntwk_total_ms_sgp"))

    val subOutnwtk = ipsgpmsipbsgchildData.alias("parent").join(nbrclm_sub_outntwk_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_catastrophic"),
        col("nbrclm_sub_outntwk_bronze_ms_ip"), col("nbrclm_sub_outntwk_silver_ms_ip"), col("nbrclm_sub_outntwk_gold_ms_ip"), col("nbrclm_sub_outntwk_platinum_ms_ip"), col("nbrclm_sub_outntwk_total_ms_ip"),
        col("nbrclm_sub_outntwk_bronze_ms_sgp"), col("nbrclm_sub_outntwk_silver_ms_sgp"), col("nbrclm_sub_outntwk_gold_ms_sgp"), col("nbrclm_sub_outntwk_platinum_ms_sgp"), col("nbrclm_sub_outntwk_total_ms_sgp"))

    val subOutnwtkData = subOutnwtk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_catastrophic",
        "nbrclm_sub_outntwk_bronze_ms_ip", "nbrclm_sub_outntwk_silver_ms_ip", "nbrclm_sub_outntwk_gold_ms_ip", "nbrclm_sub_outntwk_platinum_ms_ip", "nbrclm_sub_outntwk_total_ms_ip",
        "nbrclm_sub_outntwk_bronze_ms_sgp", "nbrclm_sub_outntwk_silver_ms_sgp", "nbrclm_sub_outntwk_gold_ms_sgp", "nbrclm_sub_outntwk_platinum_ms_sgp", "nbrclm_sub_outntwk_total_ms_sgp")

    subOutnwtkData
  }

  def joinedDf(naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_src_eob_cd_inbnd: DataFrame, naic_mcas_eob_cd_inbnd: DataFrame,
               naic_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    val joined_df = naic_mcas_hlthex_clmexphmcy_received_ip_wrk.alias("received_wrk").join(
      naic_mcas_src_eob_cd_inbnd.alias("sec"),
      $"received_wrk.src_eob_cd" === $"sec.src_eob_cd" &&
        $"received_wrk.clm_sor_cd" === $"sec.clm_sor_cd", "left_outer")
      .join(
        naic_mcas_eob_cd_inbnd.alias("chip"),
        $"received_wrk.eob_cd" === $"chip.eob_cd" &&
          $"received_wrk.clm_sor_cd" === $"chip.clm_sor_cd", "left_outer")
      .join(
        naic_mcas_src_clm_line_disp_rsn_cd_inbnd.alias("aces"),
        $"received_wrk.src_clm_line_disp_rsn_cd" === $"aces.src_clm_line_disp_rsn_cd" &&
          $"received_wrk.clm_sor_cd" === $"aces.clm_sor_cd", "left_outer")
      .filter($"sec.src_eob_cd".isNull && $"sec.clm_sor_cd".isNull &&
        $"chip.eob_cd".isNull && $"chip.clm_sor_cd".isNull &&
        $"aces.src_clm_line_disp_rsn_cd".isNull && $"aces.clm_sor_cd".isNull)
    //chip.src_eob_cd
    joined_df

  }

  def getDeniedInntwk(naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame,
                      naic_mcas_src_eob_cd_inbnd: DataFrame, naic_mcas_eob_cd_inbnd: DataFrame,
                      naic_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_brz = joinedDf(received_brnz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sil = joinedDf(received_silver, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip")
    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gld = joinedDf(received_gold, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_plt = joinedDf(received_platinum, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_bronze_ip.union(nbrclm_denied_inntwk_silver_ip.union(nbrclm_denied_inntwk_gold_ip.union(nbrclm_denied_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_bronze_ip")

    val nbrclm_denied_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_bronze_ip").alias("nbrclm_denied_inntwk_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_brz = joinedDf(received_sgp_bronze, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_sil = joinedDf(received_sgp_silver, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_gld = joinedDf(received_sgp_gold, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_plt = joinedDf(received_sgp_plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp")

    val tot_sgp = nbrclm_denied_inntwk_bronze_sgp.union(nbrclm_denied_inntwk_silver_sgp.union(nbrclm_denied_inntwk_gold_sgp.union(nbrclm_denied_inntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_bronze_sgp")

    val nbrclm_denied_inntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_bronze_sgp").alias("nbrclm_denied_inntwk_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp")

    val receivedCatFilters = naic_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_cat = joinedDf(receivedCatFilters, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_brz = joinedDf(received_msip_Brz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_bronze_ms_ip = denied_in_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_inntwk_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"),
        col("nbrclm_denied_inntwk_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic",
        "nbrclm_denied_inntwk_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_sil = joinedDf(received_msip_Sil, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_silver_ms_ip = denied_in_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"),
        col("nbrclm_denied_inntwk_bronze_ms_ip"), col("nbrclm_denied_inntwk_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic",
        "nbrclm_denied_inntwk_bronze_ms_ip", "nbrclm_denied_inntwk_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_gld = joinedDf(received_msip_Gld, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gold_ms_ip = denied_in_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"),
        col("nbrclm_denied_inntwk_bronze_ms_ip"), col("nbrclm_denied_inntwk_silver_ms_ip"), col("nbrclm_denied_inntwk_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic",
        "nbrclm_denied_inntwk_bronze_ms_ip", "nbrclm_denied_inntwk_silver_ms_ip", "nbrclm_denied_inntwk_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_plt = joinedDf(received_msip_Plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_platinum_ms_ip = denied_in_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"),
        col("nbrclm_denied_inntwk_bronze_ms_ip"), col("nbrclm_denied_inntwk_silver_ms_ip"), col("nbrclm_denied_inntwk_gold_ms_ip"), col("nbrclm_denied_inntwk_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic",
        "nbrclm_denied_inntwk_bronze_ms_ip", "nbrclm_denied_inntwk_silver_ms_ip", "nbrclm_denied_inntwk_gold_ms_ip", "nbrclm_denied_inntwk_platinum_ms_ip")
    val tot_msip = nbrclm_denied_inntwk_bronze_ms_ip.union(nbrclm_denied_inntwk_silver_ms_ip.union(nbrclm_denied_inntwk_gold_ms_ip.union(nbrclm_denied_inntwk_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_bronze_ms_ip")

    val nbrclm_denied_inntwk_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_bronze_ms_ip").alias("nbrclm_denied_inntwk_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_inntwk_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"),
        col("nbrclm_denied_inntwk_bronze_ms_ip"), col("nbrclm_denied_inntwk_silver_ms_ip"), col("nbrclm_denied_inntwk_gold_ms_ip"), col("nbrclm_denied_inntwk_platinum_ms_ip"), col("nbrclm_denied_inntwk_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic",
        "nbrclm_denied_inntwk_bronze_ms_ip", "nbrclm_denied_inntwk_silver_ms_ip", "nbrclm_denied_inntwk_gold_ms_ip", "nbrclm_denied_inntwk_platinum_ms_ip", "nbrclm_denied_inntwk_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_brz = joinedDf(received_mssgp_Brz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_bronze_ms_sgp = denied_in_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_inntwk_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"),
        col("nbrclm_denied_inntwk_bronze_ms_ip"), col("nbrclm_denied_inntwk_silver_ms_ip"), col("nbrclm_denied_inntwk_gold_ms_ip"), col("nbrclm_denied_inntwk_platinum_ms_ip"), col("nbrclm_denied_inntwk_total_ms_ip"), col("nbrclm_denied_inntwk_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic",
        "nbrclm_denied_inntwk_bronze_ms_ip", "nbrclm_denied_inntwk_silver_ms_ip", "nbrclm_denied_inntwk_gold_ms_ip", "nbrclm_denied_inntwk_platinum_ms_ip", "nbrclm_denied_inntwk_total_ms_ip",
        "nbrclm_denied_inntwk_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_sil = joinedDf(received_mssgp_Sil, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_silver_ms_sgp = denied_in_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"),
        col("nbrclm_denied_inntwk_bronze_ms_ip"), col("nbrclm_denied_inntwk_silver_ms_ip"), col("nbrclm_denied_inntwk_gold_ms_ip"), col("nbrclm_denied_inntwk_platinum_ms_ip"), col("nbrclm_denied_inntwk_total_ms_ip"),
        col("nbrclm_denied_inntwk_bronze_ms_sgp"), col("nbrclm_denied_inntwk_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic",
        "nbrclm_denied_inntwk_bronze_ms_ip", "nbrclm_denied_inntwk_silver_ms_ip", "nbrclm_denied_inntwk_gold_ms_ip", "nbrclm_denied_inntwk_platinum_ms_ip", "nbrclm_denied_inntwk_total_ms_ip",
        "nbrclm_denied_inntwk_bronze_ms_sgp", "nbrclm_denied_inntwk_silver_ms_sgp")
    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_gld = joinedDf(received_mssgp_Gld, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gold_ms_sgp = denied_in_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"),
        col("nbrclm_denied_inntwk_bronze_ms_ip"), col("nbrclm_denied_inntwk_silver_ms_ip"), col("nbrclm_denied_inntwk_gold_ms_ip"), col("nbrclm_denied_inntwk_platinum_ms_ip"), col("nbrclm_denied_inntwk_total_ms_ip"),
        col("nbrclm_denied_inntwk_bronze_ms_sgp"), col("nbrclm_denied_inntwk_silver_ms_sgp"), col("nbrclm_denied_inntwk_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic",
        "nbrclm_denied_inntwk_bronze_ms_ip", "nbrclm_denied_inntwk_silver_ms_ip", "nbrclm_denied_inntwk_gold_ms_ip", "nbrclm_denied_inntwk_platinum_ms_ip", "nbrclm_denied_inntwk_total_ms_ip",
        "nbrclm_denied_inntwk_bronze_ms_sgp", "nbrclm_denied_inntwk_silver_ms_sgp", "nbrclm_denied_inntwk_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_plt = joinedDf(received_mssgp_Plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_platinum_ms_sgp = denied_in_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"),
        col("nbrclm_denied_inntwk_bronze_ms_ip"), col("nbrclm_denied_inntwk_silver_ms_ip"), col("nbrclm_denied_inntwk_gold_ms_ip"), col("nbrclm_denied_inntwk_platinum_ms_ip"), col("nbrclm_denied_inntwk_total_ms_ip"),
        col("nbrclm_denied_inntwk_bronze_ms_sgp"), col("nbrclm_denied_inntwk_silver_ms_sgp"), col("nbrclm_denied_inntwk_gold_ms_sgp"), col("nbrclm_denied_inntwk_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic",
        "nbrclm_denied_inntwk_bronze_ms_ip", "nbrclm_denied_inntwk_silver_ms_ip", "nbrclm_denied_inntwk_gold_ms_ip", "nbrclm_denied_inntwk_platinum_ms_ip", "nbrclm_denied_inntwk_total_ms_ip",
        "nbrclm_denied_inntwk_bronze_ms_sgp", "nbrclm_denied_inntwk_silver_ms_sgp", "nbrclm_denied_inntwk_gold_ms_sgp", "nbrclm_denied_inntwk_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_inntwk_bronze_ms_sgp.union(nbrclm_denied_inntwk_silver_ms_sgp.union(nbrclm_denied_inntwk_gold_ms_sgp.union(nbrclm_denied_inntwk_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_bronze_ms_sgp")

    val nbrclm_denied_inntwk_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_bronze_ms_sgp").alias("nbrclm_denied_inntwk_total_ms_sgp"))

    val denied_inntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_inntwk_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"), //nbrclm_denied_inntwk_total_ms_ip
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_catastrophic"),
        col("nbrclm_denied_inntwk_bronze_ms_ip"), col("nbrclm_denied_inntwk_silver_ms_ip"), col("nbrclm_denied_inntwk_gold_ms_ip"), col("nbrclm_denied_inntwk_platinum_ms_ip"), col("nbrclm_denied_inntwk_total_ms_ip"),
        col("nbrclm_denied_inntwk_bronze_ms_sgp"), col("nbrclm_denied_inntwk_silver_ms_sgp"), col("nbrclm_denied_inntwk_gold_ms_sgp"), col("nbrclm_denied_inntwk_platinum_ms_sgp"), col("nbrclm_denied_inntwk_total_ms_sgp"))

    val denied_inntwkData = denied_inntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_catastrophic",
        "nbrclm_denied_inntwk_bronze_ms_ip", "nbrclm_denied_inntwk_silver_ms_ip", "nbrclm_denied_inntwk_gold_ms_ip", "nbrclm_denied_inntwk_platinum_ms_ip", "nbrclm_denied_inntwk_total_ms_ip",
        "nbrclm_denied_inntwk_bronze_ms_sgp", "nbrclm_denied_inntwk_silver_ms_sgp", "nbrclm_denied_inntwk_gold_ms_sgp", "nbrclm_denied_inntwk_platinum_ms_sgp", "nbrclm_denied_inntwk_total_ms_sgp")
    denied_inntwkData
  }

  def getDeniedInntwkBetweenDates(start_day: Int, end_day: Int, naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame,
                                  naic_mcas_src_eob_cd_inbnd: DataFrame, naic_mcas_eob_cd_inbnd: DataFrame,
                                  naic_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = { // change the var name start_day n end_day

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = start_day.toString + "to" + end_day
    val fend_day = end_day + 1
    /* val ip_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

   val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
                                    $"inn_cd".isin(clminn_cd:_*) &&
                                    $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                                     $"ADJDCTN_DT".between(strt_year,end_year) &&
									 $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT",start_day) , date_add($"PRMPT_PAY_CLM_RCVD_DT",fend_day)))//propmt_pay update *********
                 */

    val denied_in_brz = joinedDf(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    var ip_df = getIpSgpPlan(denied_in_brz, lob_type)
    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day))) //propmt_pay update *********

    val nbrclm_denied_inntwk_colVal_bronze_ip = received_brnz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"))
    ip_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)
    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sil = joinedDf(received_silver, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_colVal_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_colVal_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip")
    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_gld = joinedDf(received_gold, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_plt = joinedDf(received_platinum, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_colVal_bronze_ip.union(nbrclm_denied_inntwk_colVal_silver_ip.union(nbrclm_denied_inntwk_colVal_gold_ip.union(nbrclm_denied_inntwk_colVal_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_inntwk_colVal_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_ip").alias("nbrclm_denied_inntwk_" + colVal + "_total_ip"))
    //********************
    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_brz = joinedDf(received_sgp_bronze, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_sil = joinedDf(received_sgp_silver, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_gld = joinedDf(received_sgp_gold, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_plt = joinedDf(received_sgp_plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp")

    val tot_sgp = nbrclm_denied_inntwk_colVal_bronze_sgp.union(nbrclm_denied_inntwk_colVal_silver_sgp.union(nbrclm_denied_inntwk_colVal_gold_sgp.union(nbrclm_denied_inntwk_colVal_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_denied_inntwk_colVal_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp").alias("nbrclm_denied_inntwk_" + colVal + "_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp")

    val receivedCatFilters = naic_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_cat = joinedDf(receivedCatFilters, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_msip_brz = joinedDf(received_msip_Brz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_bronze_ms_ip = denied_in_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_msip_sil = joinedDf(received_msip_Sil, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_silver_ms_ip = denied_in_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_msip_gld = joinedDf(received_msip_Gld, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_gold_ms_ip = denied_in_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_msip_plt = joinedDf(received_msip_Plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_platinum_ms_ip = denied_in_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip")
    val tot_msip = nbrclm_denied_inntwk_colVal_bronze_ms_ip.union(nbrclm_denied_inntwk_colVal_silver_ms_ip.union(nbrclm_denied_inntwk_colVal_gold_ms_ip.union(nbrclm_denied_inntwk_colVal_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"))

    val nbrclm_denied_inntwk_colVal_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip").alias("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_mssgp_brz = joinedDf(received_mssgp_Brz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_bronze_ms_sgp = denied_in_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_mssgp_sil = joinedDf(received_mssgp_Sil, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_silver_ms_sgp = denied_in_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp")
    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_mssgp_gld = joinedDf(received_mssgp_Gld, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_gold_ms_sgp = denied_in_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_mssgp_plt = joinedDf(received_mssgp_Plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_platinum_ms_sgp = denied_in_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_inntwk_colVal_bronze_ms_sgp.union(nbrclm_denied_inntwk_colVal_silver_ms_sgp.union(nbrclm_denied_inntwk_colVal_gold_ms_sgp.union(nbrclm_denied_inntwk_colVal_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"))

    val nbrclm_denied_inntwk_colVal_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp").alias("nbrclm_denied_inntwk_" + colVal + "_total_ms_sgp"))

    val denied_inntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_sgp"))

    val denied_inntwkData = denied_inntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_ms_sgp")
    denied_inntwkData
  }
  def getDeniedInntwk_90(end_year: String, naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame,
                         naic_mcas_src_eob_cd_inbnd: DataFrame, naic_mcas_eob_cd_inbnd: DataFrame,
                         naic_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = "90"
    val strt_day: Int = 91
    val ip_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date")) //prompt_date *******************

    val denied_in_brz = joinedDf(received_brnz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sil = joinedDf(received_silver, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_colVal_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_colVal_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip")
    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_gld = joinedDf(received_gold, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_plt = joinedDf(received_platinum, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_colVal_bronze_ip.union(nbrclm_denied_inntwk_colVal_silver_ip.union(nbrclm_denied_inntwk_colVal_gold_ip.union(nbrclm_denied_inntwk_colVal_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_inntwk_colVal_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_ip").alias("nbrclm_denied_inntwk_" + colVal + "_total_ip"))
    //********************
    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_brz = joinedDf(received_sgp_bronze, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_sil = joinedDf(received_sgp_silver, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_gld = joinedDf(received_sgp_gold, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_plt = joinedDf(received_sgp_plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp")

    val tot_sgp = nbrclm_denied_inntwk_colVal_bronze_sgp.union(nbrclm_denied_inntwk_colVal_silver_sgp.union(nbrclm_denied_inntwk_colVal_gold_sgp.union(nbrclm_denied_inntwk_colVal_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_denied_inntwk_colVal_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp").alias("nbrclm_denied_inntwk_" + colVal + "_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp")

    val receivedCatFilters = naic_mcas_hlthex_clmexphmcy_received_cat_wrk
      .withColumn("constant_date", lit(end_year))
      .filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
        $"in_Exchange".equalTo("IN") &&
        $"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year) &&
        $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_cat = joinedDf(receivedCatFilters, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_msip_brz = joinedDf(received_msip_Brz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_bronze_ms_ip = denied_in_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_msip_sil = joinedDf(received_msip_Sil, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_silver_ms_ip = denied_in_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_msip_gld = joinedDf(received_msip_Gld, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_gold_ms_ip = denied_in_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_msip_plt = joinedDf(received_msip_Plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_platinum_ms_ip = denied_in_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip")
    val tot_msip = nbrclm_denied_inntwk_colVal_bronze_ms_ip.union(nbrclm_denied_inntwk_colVal_silver_ms_ip.union(nbrclm_denied_inntwk_colVal_gold_ms_ip.union(nbrclm_denied_inntwk_colVal_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"))

    val nbrclm_denied_inntwk_colVal_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip").alias("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_mssgp_brz = joinedDf(received_mssgp_Brz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_bronze_ms_sgp = denied_in_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_mssgp_sil = joinedDf(received_mssgp_Sil, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_silver_ms_sgp = denied_in_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp")

    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_mssgp_gld = joinedDf(received_mssgp_Gld, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_gold_ms_sgp = denied_in_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_mssgp_plt = joinedDf(received_mssgp_Plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_colVal_platinum_ms_sgp = denied_in_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_inntwk_colVal_bronze_ms_sgp.union(nbrclm_denied_inntwk_colVal_silver_ms_sgp.union(nbrclm_denied_inntwk_colVal_gold_ms_sgp.union(nbrclm_denied_inntwk_colVal_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"))

    val nbrclm_denied_inntwk_colVal_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp").alias("nbrclm_denied_inntwk_" + colVal + "_total_ms_sgp"))

    val denied_inntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_inntwk_colVal_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ms_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_ms_sgp"))

    val denied_inntwkData = denied_inntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_ms_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_ms_sgp")
    denied_inntwkData
  }

  def getDeniedOutntwk(naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame,
                       naic_mcas_src_eob_cd_inbnd: DataFrame, naic_mcas_eob_cd_inbnd: DataFrame,
                       naic_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_brz = joinedDf(received_brnz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sil = joinedDf(received_silver, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip")
    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gld = joinedDf(received_gold, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_plt = joinedDf(received_platinum, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_bronze_ip.union(nbrclm_denied_outntwk_silver_ip.union(nbrclm_denied_outntwk_gold_ip.union(nbrclm_denied_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_bronze_ip")

    val nbrclm_denied_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_bronze_ip").alias("nbrclm_denied_outntwk_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_brz = joinedDf(received_sgp_bronze, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_sil = joinedDf(received_sgp_silver, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_gld = joinedDf(received_sgp_gold, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_plt = joinedDf(received_sgp_plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp")

    val tot_sgp = nbrclm_denied_outntwk_bronze_sgp.union(nbrclm_denied_outntwk_silver_sgp.union(nbrclm_denied_outntwk_gold_sgp.union(nbrclm_denied_outntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_bronze_sgp")

    val nbrclm_denied_outntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_bronze_sgp").alias("nbrclm_denied_outntwk_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp")

    val receivedCatFilters = naic_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_cat = joinedDf(receivedCatFilters, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_brz = joinedDf(received_msip_Brz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_bronze_ms_ip = denied_in_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_outntwk_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"),
        col("nbrclm_denied_outntwk_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic",
        "nbrclm_denied_outntwk_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_sil = joinedDf(received_msip_Sil, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_silver_ms_ip = denied_in_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"),
        col("nbrclm_denied_outntwk_bronze_ms_ip"), col("nbrclm_denied_outntwk_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic",
        "nbrclm_denied_outntwk_bronze_ms_ip", "nbrclm_denied_outntwk_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_gld = joinedDf(received_msip_Gld, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gold_ms_ip = denied_in_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"),
        col("nbrclm_denied_outntwk_bronze_ms_ip"), col("nbrclm_denied_outntwk_silver_ms_ip"), col("nbrclm_denied_outntwk_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic",
        "nbrclm_denied_outntwk_bronze_ms_ip", "nbrclm_denied_outntwk_silver_ms_ip", "nbrclm_denied_outntwk_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_plt = joinedDf(received_msip_Plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_platinum_ms_ip = denied_in_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"),
        col("nbrclm_denied_outntwk_bronze_ms_ip"), col("nbrclm_denied_outntwk_silver_ms_ip"), col("nbrclm_denied_outntwk_gold_ms_ip"), col("nbrclm_denied_outntwk_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic",
        "nbrclm_denied_outntwk_bronze_ms_ip", "nbrclm_denied_outntwk_silver_ms_ip", "nbrclm_denied_outntwk_gold_ms_ip", "nbrclm_denied_outntwk_platinum_ms_ip")
    val tot_msip = nbrclm_denied_outntwk_bronze_ms_ip.union(nbrclm_denied_outntwk_silver_ms_ip.union(nbrclm_denied_outntwk_gold_ms_ip.union(nbrclm_denied_outntwk_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_bronze_ms_ip")

    val nbrclm_denied_outntwk_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_bronze_ms_ip").alias("nbrclm_denied_outntwk_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_outntwk_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"),
        col("nbrclm_denied_outntwk_bronze_ms_ip"), col("nbrclm_denied_outntwk_silver_ms_ip"), col("nbrclm_denied_outntwk_gold_ms_ip"), col("nbrclm_denied_outntwk_platinum_ms_ip"), col("nbrclm_denied_outntwk_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic",
        "nbrclm_denied_outntwk_bronze_ms_ip", "nbrclm_denied_outntwk_silver_ms_ip", "nbrclm_denied_outntwk_gold_ms_ip", "nbrclm_denied_outntwk_platinum_ms_ip", "nbrclm_denied_outntwk_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_brz = joinedDf(received_mssgp_Brz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_bronze_ms_sgp = denied_in_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_outntwk_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"),
        col("nbrclm_denied_outntwk_bronze_ms_ip"), col("nbrclm_denied_outntwk_silver_ms_ip"), col("nbrclm_denied_outntwk_gold_ms_ip"), col("nbrclm_denied_outntwk_platinum_ms_ip"), col("nbrclm_denied_outntwk_total_ms_ip"), col("nbrclm_denied_outntwk_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic",
        "nbrclm_denied_outntwk_bronze_ms_ip", "nbrclm_denied_outntwk_silver_ms_ip", "nbrclm_denied_outntwk_gold_ms_ip", "nbrclm_denied_outntwk_platinum_ms_ip", "nbrclm_denied_outntwk_total_ms_ip",
        "nbrclm_denied_outntwk_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_sil = joinedDf(received_mssgp_Sil, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_silver_ms_sgp = denied_in_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"),
        col("nbrclm_denied_outntwk_bronze_ms_ip"), col("nbrclm_denied_outntwk_silver_ms_ip"), col("nbrclm_denied_outntwk_gold_ms_ip"), col("nbrclm_denied_outntwk_platinum_ms_ip"), col("nbrclm_denied_outntwk_total_ms_ip"),
        col("nbrclm_denied_outntwk_bronze_ms_sgp"), col("nbrclm_denied_outntwk_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic",
        "nbrclm_denied_outntwk_bronze_ms_ip", "nbrclm_denied_outntwk_silver_ms_ip", "nbrclm_denied_outntwk_gold_ms_ip", "nbrclm_denied_outntwk_platinum_ms_ip", "nbrclm_denied_outntwk_total_ms_ip",
        "nbrclm_denied_outntwk_bronze_ms_sgp", "nbrclm_denied_outntwk_silver_ms_sgp")
    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_gld = joinedDf(received_mssgp_Gld, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gold_ms_sgp = denied_in_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"),
        col("nbrclm_denied_outntwk_bronze_ms_ip"), col("nbrclm_denied_outntwk_silver_ms_ip"), col("nbrclm_denied_outntwk_gold_ms_ip"), col("nbrclm_denied_outntwk_platinum_ms_ip"), col("nbrclm_denied_outntwk_total_ms_ip"),
        col("nbrclm_denied_outntwk_bronze_ms_sgp"), col("nbrclm_denied_outntwk_silver_ms_sgp"), col("nbrclm_denied_outntwk_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic",
        "nbrclm_denied_outntwk_bronze_ms_ip", "nbrclm_denied_outntwk_silver_ms_ip", "nbrclm_denied_outntwk_gold_ms_ip", "nbrclm_denied_outntwk_platinum_ms_ip", "nbrclm_denied_outntwk_total_ms_ip",
        "nbrclm_denied_outntwk_bronze_ms_sgp", "nbrclm_denied_outntwk_silver_ms_sgp", "nbrclm_denied_outntwk_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_plt = joinedDf(received_mssgp_Plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_platinum_ms_sgp = denied_in_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"),
        col("nbrclm_denied_outntwk_bronze_ms_ip"), col("nbrclm_denied_outntwk_silver_ms_ip"), col("nbrclm_denied_outntwk_gold_ms_ip"), col("nbrclm_denied_outntwk_platinum_ms_ip"), col("nbrclm_denied_outntwk_total_ms_ip"),
        col("nbrclm_denied_outntwk_bronze_ms_sgp"), col("nbrclm_denied_outntwk_silver_ms_sgp"), col("nbrclm_denied_outntwk_gold_ms_sgp"), col("nbrclm_denied_outntwk_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic",
        "nbrclm_denied_outntwk_bronze_ms_ip", "nbrclm_denied_outntwk_silver_ms_ip", "nbrclm_denied_outntwk_gold_ms_ip", "nbrclm_denied_outntwk_platinum_ms_ip", "nbrclm_denied_outntwk_total_ms_ip",
        "nbrclm_denied_outntwk_bronze_ms_sgp", "nbrclm_denied_outntwk_silver_ms_sgp", "nbrclm_denied_outntwk_gold_ms_sgp", "nbrclm_denied_outntwk_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_outntwk_bronze_ms_sgp.union(nbrclm_denied_outntwk_silver_ms_sgp.union(nbrclm_denied_outntwk_gold_ms_sgp.union(nbrclm_denied_outntwk_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_bronze_ms_sgp")

    val nbrclm_denied_outntwk_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_bronze_ms_sgp").alias("nbrclm_denied_outntwk_total_ms_sgp"))

    val denied_outntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_outntwk_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"), //nbrclm_denied_outntwk_total_ms_ip
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_catastrophic"),
        col("nbrclm_denied_outntwk_bronze_ms_ip"), col("nbrclm_denied_outntwk_silver_ms_ip"), col("nbrclm_denied_outntwk_gold_ms_ip"), col("nbrclm_denied_outntwk_platinum_ms_ip"), col("nbrclm_denied_outntwk_total_ms_ip"),
        col("nbrclm_denied_outntwk_bronze_ms_sgp"), col("nbrclm_denied_outntwk_silver_ms_sgp"), col("nbrclm_denied_outntwk_gold_ms_sgp"), col("nbrclm_denied_outntwk_platinum_ms_sgp"), col("nbrclm_denied_outntwk_total_ms_sgp"))

    val denied_outntwkData = denied_outntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_catastrophic",
        "nbrclm_denied_outntwk_bronze_ms_ip", "nbrclm_denied_outntwk_silver_ms_ip", "nbrclm_denied_outntwk_gold_ms_ip", "nbrclm_denied_outntwk_platinum_ms_ip", "nbrclm_denied_outntwk_total_ms_ip",
        "nbrclm_denied_outntwk_bronze_ms_sgp", "nbrclm_denied_outntwk_silver_ms_sgp", "nbrclm_denied_outntwk_gold_ms_sgp", "nbrclm_denied_outntwk_platinum_ms_sgp", "nbrclm_denied_outntwk_total_ms_sgp")
    denied_outntwkData
  }
  def getDeniedOutntwkBetweenDates(start_day: Int, end_day: Int, naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame,
                                   naic_mcas_src_eob_cd_inbnd: DataFrame, naic_mcas_eob_cd_inbnd: DataFrame,
                                   naic_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = start_day.toString + "to" + end_day
    val ip_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)
    val fend_day = end_day + 1
    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_brz = joinedDf(received_brnz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sil = joinedDf(received_silver, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_colVal_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_colVal_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip")
    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_gld = joinedDf(received_gold, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_plt = joinedDf(received_platinum, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_colVal_bronze_ip.union(nbrclm_denied_outntwk_colVal_silver_ip.union(nbrclm_denied_outntwk_colVal_gold_ip.union(nbrclm_denied_outntwk_colVal_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_outntwk_colVal_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_ip").alias("nbrclm_denied_outntwk_" + colVal + "_total_ip"))
    //********************
    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_brz = joinedDf(received_sgp_bronze, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_sil = joinedDf(received_sgp_silver, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_gld = joinedDf(received_sgp_gold, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_plt = joinedDf(received_sgp_plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp")

    val tot_sgp = nbrclm_denied_outntwk_colVal_bronze_sgp.union(nbrclm_denied_outntwk_colVal_silver_sgp.union(nbrclm_denied_outntwk_colVal_gold_sgp.union(nbrclm_denied_outntwk_colVal_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_denied_outntwk_colVal_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp").alias("nbrclm_denied_outntwk_" + colVal + "_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp")

    val receivedCatFilters = naic_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_cat = joinedDf(receivedCatFilters, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_msip_brz = joinedDf(received_msip_Brz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_bronze_ms_ip = denied_in_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_msip_sil = joinedDf(received_msip_Sil, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_silver_ms_ip = denied_in_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_msip_gld = joinedDf(received_msip_Gld, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_gold_ms_ip = denied_in_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_msip_plt = joinedDf(received_msip_Plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_platinum_ms_ip = denied_in_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip")
    val tot_msip = nbrclm_denied_outntwk_colVal_bronze_ms_ip.union(nbrclm_denied_outntwk_colVal_silver_ms_ip.union(nbrclm_denied_outntwk_colVal_gold_ms_ip.union(nbrclm_denied_outntwk_colVal_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"))

    val nbrclm_denied_outntwk_colVal_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip").alias("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_mssgp_brz = joinedDf(received_mssgp_Brz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_bronze_ms_sgp = denied_in_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_mssgp_sil = joinedDf(received_mssgp_Sil, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_silver_ms_sgp = denied_in_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp")
    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_mssgp_gld = joinedDf(received_mssgp_Gld, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_gold_ms_sgp = denied_in_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_mssgp_plt = joinedDf(received_mssgp_Plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_platinum_ms_sgp = denied_in_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_outntwk_colVal_bronze_ms_sgp.union(nbrclm_denied_outntwk_colVal_silver_ms_sgp.union(nbrclm_denied_outntwk_colVal_gold_ms_sgp.union(nbrclm_denied_outntwk_colVal_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"))

    val nbrclm_denied_outntwk_colVal_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp").alias("nbrclm_denied_outntwk_" + colVal + "_total_ms_sgp"))

    val denied_outntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_sgp"))

    val denied_outntwkData = denied_outntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_ms_sgp")
    denied_outntwkData
  }
  def getDeniedOutntwk_90(end_year: String, naic_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame,
                          naic_mcas_src_eob_cd_inbnd: DataFrame, naic_mcas_eob_cd_inbnd: DataFrame,
                          naic_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = "90"
    val strt_day: Int = 91
    val ip_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_brz = joinedDf(received_brnz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sil = joinedDf(received_silver, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_colVal_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_colVal_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip")
    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_gld = joinedDf(received_gold, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_plt = joinedDf(received_platinum, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_colVal_bronze_ip.union(nbrclm_denied_outntwk_colVal_silver_ip.union(nbrclm_denied_outntwk_colVal_gold_ip.union(nbrclm_denied_outntwk_colVal_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_outntwk_colVal_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_ip").alias("nbrclm_denied_outntwk_" + colVal + "_total_ip"))
    //********************
    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_brz = joinedDf(received_sgp_bronze, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_sil = joinedDf(received_sgp_silver, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_gld = joinedDf(received_sgp_gold, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_plt = joinedDf(received_sgp_plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp")

    val tot_sgp = nbrclm_denied_outntwk_colVal_bronze_sgp.union(nbrclm_denied_outntwk_colVal_silver_sgp.union(nbrclm_denied_outntwk_colVal_gold_sgp.union(nbrclm_denied_outntwk_colVal_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_denied_outntwk_colVal_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp").alias("nbrclm_denied_outntwk_" + colVal + "_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp")

    val receivedCatFilters = naic_mcas_hlthex_clmexphmcy_received_cat_wrk
      .withColumn("constant_date", lit(end_year))
      .filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
        $"in_Exchange".equalTo("IN") &&
        (!$"inn_cd".isin(clminn_cd: _*)) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year) &&
        $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_cat = joinedDf(receivedCatFilters, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_msip_brz = joinedDf(received_msip_Brz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_bronze_ms_ip = denied_in_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_msip_sil = joinedDf(received_msip_Sil, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_silver_ms_ip = denied_in_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_msip_gld = joinedDf(received_msip_Gld, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_gold_ms_ip = denied_in_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_msip_plt = joinedDf(received_msip_Plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_platinum_ms_ip = denied_in_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip")
    val tot_msip = nbrclm_denied_outntwk_colVal_bronze_ms_ip.union(nbrclm_denied_outntwk_colVal_silver_ms_ip.union(nbrclm_denied_outntwk_colVal_gold_ms_ip.union(nbrclm_denied_outntwk_colVal_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"))

    val nbrclm_denied_outntwk_colVal_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip").alias("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_mssgp_brz = joinedDf(received_mssgp_Brz, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_bronze_ms_sgp = denied_in_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_mssgp_sil = joinedDf(received_mssgp_Sil, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_silver_ms_sgp = denied_in_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp")
    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_mssgp_gld = joinedDf(received_mssgp_Gld, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_gold_ms_sgp = denied_in_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_mssgp_plt = joinedDf(received_mssgp_Plt, naic_mcas_src_eob_cd_inbnd, naic_mcas_eob_cd_inbnd, naic_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_colVal_platinum_ms_sgp = denied_in_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_outntwk_colVal_bronze_ms_sgp.union(nbrclm_denied_outntwk_colVal_silver_ms_sgp.union(nbrclm_denied_outntwk_colVal_gold_ms_sgp.union(nbrclm_denied_outntwk_colVal_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"))

    val nbrclm_denied_outntwk_colVal_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp").alias("nbrclm_denied_outntwk_" + colVal + "_total_ms_sgp"))

    val denied_outntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_outntwk_colVal_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ms_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_ms_sgp"))

    val denied_outntwkData = denied_outntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_catastrophic",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ms_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_ms_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_ms_sgp")
    denied_outntwkData
  }

}

object PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    // new PCADX_SCL_NAIC_IEXStgTransformationclmexphmcy().sparkInIt()
  }
}
