package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator

import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit

import org.apache.hadoop.fs._;
class PCADX_SCL_NAIC2018_CLMEXPHRMCY_ReceivedSGP{
  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()
    import spark.implicits._
  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_CLMEXPHRMCY_ReceivedSGP])
     val dbWrk = dbProperties.getProperty("work.db")
     val dbInbnd = dbProperties.getProperty("inbound.db")
	 val wrhDb = dbProperties.getProperty("warehouse.db")
	 val audit_log_df = spark.sql("select * from "+wrhDb+".audt_load_log") 
    val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString() 
    println("load_log_key : "+load_log_key)
     val reportYear =dbProperties.getProperty("report.year")
      val clmexRcvdStrtDt = dbProperties.getProperty("CLM_EX_RCVD_DT_STRT")
	    val clmexRcvdEndDt = dbProperties.getProperty("CLM_EX_RCVD_DT_END")
     
  def sgpTemp()="""
   insert overwrite table """+dbWrk+""".clmexphmcy_sgpinter_wrk
   select 
   distinct
   CB.GL_LVL_DESC ,
   CB.CF_CD as CB_CF_CD,
 MED.GL_CF_DESC  ,
 MED.CF_CD as MED_CF_CD,
 BRD.CF_CD as BRD_CF_CD,
 BRD.State AS  State,
 FC.CF_CD as FC_CF_CD ,
  """+load_log_key+""",
 current_timestamp()
  from 
  """+dbWrk+""".clm_inter cl
inner join (
select CF_CD, GL_LVL_DESC 
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
WHERE GL_CF_TYPE_DESC = 'CBE'
AND GL_LVL_DESC in ('TOTAL SMALL GROUP CBE') 
group by 1,2
) as CB
on CB.CF_CD =cl.MBU_CF_CD
 inner join (
select CF_CD,  GL_CF_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where GL_CF_TYPE_DESC = 'PRODUCT' 
group by 1,2
) as MED
on MED.CF_CD = cl.PROD_CF_CD
inner join
(
select
gl.CF_CD
,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY gl
where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
and ((gl.GL_LVL_DESC like  ('NON BLUE%') or gl.GL_LVL_DESC like  ('BLUE%')) and gl.GL_LVL_DESC not like  ('%TOTAL') )
group by 1,2
) BRD
on BRD.CF_CD= cl.MBU_CF_CD 
and BRD.State <> 'LT'
inner join
(
select DISTINCT CF_CD
from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
where  GL_CF_TYPE_DESC = 'FUND_CODE'
and CF_CD NOT IN ( select  DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY  
          WHERE    GL_CF_TYPE_DESC = 'FUND_CODE' AND  
        ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
       )
) FC
ON FC.CF_CD = cl.FUNDG_CF_CD
  WHERE  
  BRD.State not in ('IL','DC','MA')

   """
     def naic_mcas_hlthex_clmexphmcy_received_sgp_wrk() = """Insert overwrite table """+dbWrk+""".naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk"""+"""
    select * from              
( 
SELECT 
"""+reportYear+"""  as health_year,
 mclm_wrk.CLM_ADJSTMNT_KEY  AS CLM_ADJSTMNT_KEY,
 mclm_wrk.CLM_LINE_NBR AS CLM_LINE_NBR ,
 mclm_wrk.CLM_SOR_CD   AS CLM_SOR_CD ,
 mclm_wrk.INN_CD     AS INN_CD ,
 cl.MBR_KEY AS MBR_KEY ,
 cl.MBRSHP_SOR_CD AS MBRSHP_SOR_CD, 
 cl.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
  cl.MBU_CF_CD AS MBU_CF_CD ,
 cl.PROD_CF_CD AS PROD_CF_CD,
 cl.CMPNY_CF_CD AS CMPNY_CF_CD,
 cl.FUNDG_CF_CD AS FUNDG_CF_CD,
 BPA.EXCHNG_IND_CD AS EXCHNG_IND_CD,
 BPA.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
 BPA.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD , 
 BPA.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
 BPA.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
 MHE.HIX_CD AS HIX_CD,
 l.State AS  State,
 CASE WHEN substr (cl.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    and cl.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
     WHEN BPA.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN' 
     WHEN SUBSTR(cl.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( BPA.EXCHNG_IND_CD IS NULL OR BPA.EXCHNG_IND_CD ='UNK' )AND MHE.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
             END AS IN_Exchange ,
 CASE WHEN substr (cl.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and cl.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
     WHEN BPA.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
      WHEN SUBSTR(cl.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( BPA.EXCHNG_IND_CD IS NULL OR BPA.EXCHNG_IND_CD ='UNK' )AND MHE.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
     END AS OUTOFF_Exchange, 
  l.GL_LVL_DESC AS naic_lob,
 l.GL_CF_DESC  as  naic_prod_desc,
 mclm_wrk.src_eob_cd    AS    src_eob_cd ,
 mclm_wrk.eob_cd   AS  eob_cd,
 mclm_wrk.src_clm_line_disp_rsn_cd  AS  src_clm_line_disp_rsn_cd ,
 mclm_wrk.rptg_clm_line_adjdctn_stts_cd AS rptg_clm_line_adjdctn_stts_cd ,
 mclm_wrk.prmpt_pay_clm_rcvd_dt  AS prmpt_pay_clm_rcvd_dt ,
 mclm_wrk.clm_rcvd_dt  AS clm_rcvd_dt ,
 mclm_wrk.adjdctn_dt          AS    adjdctn_dt ,
 cl.src_grp_nbr,
 cl.src_subgrp_nbr,
 mclm_wrk.diag_1_cd      AS  diag_1_cd   ,
mclm_wrk.diag_2_cd      AS  diag_2_cd  ,
mclm_wrk.diag_3_cd      AS  diag_3_cd  ,
mclm_wrk.diag_4_cd      AS  diag_4_cd   ,
mclm_wrk.hlth_srvc_cd  AS  hlth_srvc_cd  ,
mclm_wrk.hlth_srvc_type_cd  AS  hlth_srvc_type_cd  ,
mclm_wrk.icd_proc_cd  AS icd_proc_cd ,
mclm_wrk.icd_vrsn_cd  AS icd_vrsn_cd ,
 """+load_log_key+""",
 current_timestamp()
 
    FROM   """+dbWrk+""".naic2018_mcas_mclm_wrk  mclm_wrk
  inner join """+dbWrk+""".clm_inter cl
  on mclm_wrk.MBR_KEY = cl.MBR_KEY
inner join 
"""+dbWrk+""".clmexphmcy_sgpinter_wrk l
on
l.CB_CF_CD =cl.MBU_CF_CD
and l.MED_CF_CD = cl.PROD_CF_CD
and l.FC_CF_CD = cl.FUNDG_CF_CD
 LEFT OUTER JOIN """+dbInbnd+""".MBR_HIX_ENRLMNT MHE
 ON cl.MBR_KEY = MHE.MBR_KEY
 AND cl.PROD_OFRG_KEY = MHE.PROD_OFRG_KEY
 AND cl.MBR_PROD_ENRLMNT_EFCTV_DT = MHE.MBR_PROD_ENRLMNT_EFCTV_DT
 AND MHE.RCRD_STTS_CD <> 'DEL'
 LEFT OUTER JOIN """+dbInbnd+""".BNFT_PKG_ADDNL BPA
 ON cl.BNFT_PKG_KEY = BPA.BNFT_PKG_KEY 
 AND BPA.RCRD_STTS_CD <> 'DEL'
  
WHERE 
 ((mclm_wrk.prmpt_pay_clm_rcvd_dt  between cl.mbr_prod_enrlmnt_efctv_dt and cl.mbr_prod_enrlmnt_trmntn_dt) 
   or (mclm_wrk.clm_line_srvc_strt_dt  between cl.mbr_prod_enrlmnt_efctv_dt and cl.mbr_prod_enrlmnt_trmntn_dt)) 
  and ( mclm_wrk.PRMPT_PAY_CLM_RCVD_DT  BETWEEN  """+clmexRcvdStrtDt+"""  AND """+clmexRcvdEndDt+""" 
or  mclm_wrk.ADJDCTN_DT   BETWEEN  """+clmexRcvdStrtDt+"""  AND """+clmexRcvdEndDt+"""  )
 GROUP BY 
 mclm_wrk.CLM_ADJSTMNT_KEY  ,
 mclm_wrk.CLM_LINE_NBR  ,
 mclm_wrk.CLM_SOR_CD   ,
 mclm_wrk.INN_CD      ,
 mclm_wrk.src_eob_cd     ,
 mclm_wrk.eob_cd   ,
 mclm_wrk.src_clm_line_disp_rsn_cd ,
 mclm_wrk.rptg_clm_line_adjdctn_stts_cd  ,
 mclm_wrk.prmpt_pay_clm_rcvd_dt   ,
 mclm_wrk.clm_rcvd_dt   ,
 mclm_wrk.adjdctn_dt         ,
  cl.MBR_KEY ,
 cl.MBRSHP_SOR_CD , 
 cl.GRNDFTHR_IND_CD  ,
 MHE.HIX_CD ,
 BPA.GRNDFTHRG_STTS_CD , 
 BPA.hcr_cmplynt_cd ,
 BPA.EXCHNG_IND_CD ,
 BPA.EXCHNG_METL_TYPE_CD ,
 BPA.SRC_EXCHNG_CERTFN_CD ,
 cl.MBU_CF_CD  ,
 cl.PROD_CF_CD ,
 cl.CMPNY_CF_CD ,
 cl.FUNDG_CF_CD ,
 l.State ,
 l.GL_LVL_DESC,
 l.GL_CF_DESC,
 cl.src_grp_nbr,
 cl.src_subgrp_nbr,
  mclm_wrk.diag_1_cd  ,
mclm_wrk.diag_2_cd  ,
mclm_wrk.diag_3_cd ,
mclm_wrk.diag_4_cd ,
mclm_wrk.hlth_srvc_cd  ,
mclm_wrk.hlth_srvc_type_cd   ,
mclm_wrk.icd_proc_cd  ,
mclm_wrk.icd_vrsn_cd 
)x
--where x.IN_Exchange = 'IN' OR x.OUTOFF_Exchange = 'OUTOFF'

    """
  
  
   def sparkInIt(){
    spark.sql(sgpTemp())
    spark.sql(naic_mcas_hlthex_clmexphmcy_received_sgp_wrk())
    spark.close
  }
}
object PCADX_SCL_NAIC2018_CLMEXPHRMCY_ReceivedSGP{
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val clmPhmy = new PCADX_SCL_NAIC2018_CLMEXPHRMCY_ReceivedSGP()
		//OEX.setYear(args(1))
		clmPhmy.sparkInIt()
	}


}