package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._
import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row
import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import org.apache.hadoop.fs.Options.Rename

class PCADX_SCL_NAIC2018_OEXStgTransformationPOA {
	val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
			config("hive.exec.dynamic.partition.mode", "nonstrict").
			config("spark.sql.parquet.compression.codec", "snappy").
			config("hive.warehouse.data.skipTrash", "true").
			config("spark.sql.parquet.writeLegacyFormat", "true").
			enableHiveSupport().getOrCreate()
			import org.apache.spark.sql.types._
			import spark.implicits._


			val dbProperties = new Properties
			dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
			var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_OEXStgTransformationPOA])
			val dbsg = dbProperties.getProperty("stage.db")
			val dbwrk = dbProperties.getProperty("work.db")
			val tblIssued = dbProperties.getProperty("issued_poa")
			val tblRenewed = dbProperties.getProperty("renewed_poa")
			val tblMmissued = dbProperties.getProperty("mmissued_poa")
			val tblMmrenewed = dbProperties.getProperty("mmrenewed_poa")
			val tblTermed = dbProperties.getProperty("termed_poa")
			val tblTermed_nonpay = dbProperties.getProperty("termed_nonpay_poa")
			val tblTermed_lives = dbProperties.getProperty("termed_lives_poa")
			val tblTermed_nonpay_lives = dbProperties.getProperty("termed_nonpay_lives_poa")
			val uri: String = dbProperties.getProperty("uri")
			val mbu_cf_cdvals_sql = dbProperties.getProperty("mbu_Cf_cdVals_sql")
			val mbu_cf_cdvals = dbProperties.getProperty("mbu_Cf_cdVals").split(",").toSeq
			val strt_year = dbProperties.getProperty("strt_year_poa")
			val end_year = dbProperties.getProperty("end_year_poa")
			val date1 = LocalDate.parse(end_year)
			val date2 = LocalDate.parse(strt_year)
			val strt_year_sql = dbProperties.getProperty("strt_year_poa_sql")
			val end_year_sql = dbProperties.getProperty("end_year_poa_sql")
			val naic_lob_lgp = Seq("LARGE GROUP CBE EXCLUDING MEDICARE"  , "TOTAL NATIONAL CBE")
			val mmissue_const_date = dbProperties.getProperty("const_date_mmissued")

			def sparkInIt() {

				truncateTbl(dbsg + "." + "naic2018_mcas_hlthoex_poa_stg")
				val naic2018_mcas_hlthex_poa_issued_wrk = readDataFromHive(dbwrk + "." + tblIssued)
				val naic2018_mcas_hlthex_poa_renewed_wrk = readDataFromHive(dbwrk + "." + tblRenewed)
				val naic2018_mcas_hlthex_poa_mmissued_wrk = readDataFromHive(dbwrk + "." + tblMmissued)
				val naic2018_mcas_hlthex_poa_mmrenewed_wrk = readDataFromHive(dbwrk + "." + tblMmrenewed)
				val naic2018_mcas_hlthex_poa_termed_wrk = readDataFromHive(dbwrk + "." + tblTermed)
				val naic2018_mcas_hlthex_poa_termed_nonpay_wrk = readDataFromHive(dbwrk + "." + tblTermed_nonpay)
				val naic2018_mcas_hlthex_poa_termed_lives_wrk = readDataFromHive(dbwrk + "." + tblTermed_lives)
				val naic2018_mcas_hlthex_poa_termed_nonpay_lives_wrk = readDataFromHive(dbwrk + "." + tblTermed_nonpay_lives)
				val naic2018_mcas_hlthex_poag_issued_wrk = readDataFromHive(dbwrk + ". naic2018_mcas_hlthex_poag_issued_wrk")
				val naic2018_mcas_hlthex_poag_renewed_wrk = readDataFromHive(dbwrk + ". naic2018_mcas_hlthex_poag_renewed_wrk")
				val naic2018_mcas_hlthex_poag_mmissued_wrk = readDataFromHive(dbwrk + ". naic2018_mcas_hlthex_poag_mmissued_wrk ")
				val naic2018_mcas_hlthex_poag_mmrenewed_wrk = readDataFromHive(dbwrk + ". naic2018_mcas_hlthex_poag_mmrenewed_wrk")
				val naic2018_mcas_hlthex_poag_termed_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_poag_termed_wrk")
				val naic2018_mcas_hlthex_poag_termed_nonpay_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_poag_termed_nonpay_wrk ")
				val naic2018_mcas_hlthex_poag_termed_lives_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_poag_termed_lives_wrk")
				val naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk ")
				val naic2018_mcas_hlthoex_poa_facets_stg = readDataFromHive(dbsg + ".naic2018_mcas_hlthoex_poa_facets_stg")


				val stgData = populateStageTbl(naic2018_mcas_hlthex_poa_issued_wrk, naic2018_mcas_hlthex_poa_renewed_wrk, 
						naic2018_mcas_hlthex_poa_mmissued_wrk, naic2018_mcas_hlthex_poa_mmrenewed_wrk,
						naic2018_mcas_hlthex_poa_termed_wrk, naic2018_mcas_hlthex_poa_termed_nonpay_wrk, 
						naic2018_mcas_hlthex_poa_termed_lives_wrk, naic2018_mcas_hlthex_poa_termed_nonpay_lives_wrk,naic2018_mcas_hlthex_poag_issued_wrk ,
						naic2018_mcas_hlthex_poag_renewed_wrk,naic2018_mcas_hlthex_poag_mmissued_wrk ,naic2018_mcas_hlthex_poag_mmrenewed_wrk,
						naic2018_mcas_hlthex_poag_termed_wrk,naic2018_mcas_hlthex_poag_termed_nonpay_wrk ,
						naic2018_mcas_hlthex_poag_termed_lives_wrk,naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk,naic2018_mcas_hlthoex_poa_facets_stg )
				stgData.repartition(50)
				println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
				writeDataToHive(dbsg + "." + "naic2018_mcas_hlthoex_poa_stg", stgData)
				println("Done writing")
				spark.close()
			}

			def truncateTbl(tblName: String) {
				spark.sql("TRUNCATE TABLE " + tblName)
			}

			def readDataFromHive(tble: String): DataFrame = {
					val queryOutputTable = """SELECT * FROM """ + tble
							val tbl_data_df = spark.sql(queryOutputTable) //.na.fill("")
							logger.info("Read data from hive")
							tbl_data_df
			}

			def writeDataToHive(tblName: String, finalDf: DataFrame) {
				finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)

				println("Data added in stage table")
			}





			def populateStageTbl(naic2018_mcas_hlthex_poa_issued_wrk: DataFrame, naic2018_mcas_hlthex_poa_renewed_wrk: DataFrame, naic2018_mcas_hlthex_poa_mmissued_wrk: DataFrame,
					naic2018_mcas_hlthex_poa_mmrenewed_wrk: DataFrame, naic2018_mcas_hlthex_poa_termed_wrk: DataFrame, naic2018_mcas_hlthex_poa_termed_nonpay_wrk: DataFrame,
					naic2018_mcas_hlthex_poa_termed_lives_wrk: DataFrame, naic2018_mcas_hlthex_poa_termed_nonpay_lives_wrk: DataFrame,naic2018_mcas_hlthex_poag_issued_wrk : DataFrame ,naic2018_mcas_hlthex_poag_renewed_wrk : DataFrame,naic2018_mcas_hlthex_poag_mmissued_wrk : DataFrame ,naic2018_mcas_hlthex_poag_mmrenewed_wrk : DataFrame,naic2018_mcas_hlthex_poag_termed_wrk : DataFrame,naic2018_mcas_hlthex_poag_termed_nonpay_wrk : DataFrame   ,naic2018_mcas_hlthex_poag_termed_lives_wrk : DataFrame,naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk : DataFrame,naic2018_mcas_hlthoex_poa_facets_stg:DataFrame ): DataFrame = {

							val issueFinalDf = getInitialData(naic2018_mcas_hlthex_poa_issued_wrk,naic2018_mcas_hlthex_poag_issued_wrk,"issued") 
							val rennewedFinalDf = getInitialData(naic2018_mcas_hlthex_poa_renewed_wrk,naic2018_mcas_hlthex_poag_renewed_wrk, "renewed")
							val mmissuedFinalDf = getMemberIssuedData(naic2018_mcas_hlthex_poa_mmissued_wrk,naic2018_mcas_hlthex_poag_mmissued_wrk)
							val mmrenewedFinalDf = getMemberRenewedData(naic2018_mcas_hlthex_poa_mmrenewed_wrk,naic2018_mcas_hlthex_poag_mmrenewed_wrk)
							val termedFinalDf = getInitialtermedData(naic2018_mcas_hlthex_poa_termed_wrk,naic2018_mcas_hlthoex_poa_facets_stg,naic2018_mcas_hlthex_poag_termed_wrk, "termed")
						  val termed_nonpayFinalDf = getInitialtermedData(naic2018_mcas_hlthex_poa_termed_nonpay_wrk,naic2018_mcas_hlthoex_poa_facets_stg,naic2018_mcas_hlthex_poag_termed_nonpay_wrk,"termed_nonpay")
						  val termed_livesFinalDf = getTermedLivesData(naic2018_mcas_hlthex_poa_termed_lives_wrk,naic2018_mcas_hlthoex_poa_facets_stg,naic2018_mcas_hlthex_poag_termed_lives_wrk, "termed_lives")
							val termed_nonpay_livesFinalDf = getTermedLivesData(naic2018_mcas_hlthex_poa_termed_nonpay_lives_wrk,naic2018_mcas_hlthoex_poa_facets_stg ,naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk,"termed_nonpay_lives")

									

						val stgData = getStageData(issueFinalDf, rennewedFinalDf, mmissuedFinalDf, mmrenewedFinalDf, termedFinalDf, termed_nonpayFinalDf,
										termed_livesFinalDf, termed_nonpay_livesFinalDf)
									var load_log_key = ""

										if (!naic2018_mcas_hlthex_poa_issued_wrk.take(1).isEmpty) {
										load_log_key = naic2018_mcas_hlthex_poa_issued_wrk.select($"load_log_key").first.getString(0)
									}
							val finalStgdata = stgData.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
					
									finalStgdata

			}


			def getInitialtermedData(naic_mcas_hlthex_poa_wrk:DataFrame,naic_mcas_hlthex_poag_facets_wrk: DataFrame,naic_mcas_hlthex_poag_wrk:DataFrame, typeOfData: String): DataFrame = {


					naic_mcas_hlthex_poag_facets_wrk.createOrReplaceTempView("facets_stg")
					naic_mcas_hlthex_poag_wrk.createOrReplaceTempView("termedPOAG_wrk")
					naic_mcas_hlthex_poa_wrk.createOrReplaceTempView("termedPOA_wrk")

					val nbrpoa_bronze_ip = "nbrpoa_" + typeOfData + "_bronze_ip"  
					val nbrpoa_issued_bronze_ip = naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
							(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("04") &&
							naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_bronze_ip))



					val nbrpoa_silver_ip = "nbrpoa_" + typeOfData + "_silver_ip"
					val nbrpoa_issued_silver_ip = naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
							(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("03") &&
							naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_silver_ip))


					val brSil = nbrpoa_issued_bronze_ip.alias("bronze").join(nbrpoa_issued_silver_ip.alias("silver"), $"bronze.health_year" === $"silver.health_year"
					&& $"bronze.cmpny_cf_cd" === $"silver.cmpny_cf_cd" && $"bronze.state" === $"silver.state", "outer")
					.select($"bronze.health_year".alias("b_year"), $"silver.health_year".alias("s_year"),
							$"bronze.cmpny_cf_cd".alias("b_cmpny"), $"silver.cmpny_cf_cd".alias("s_cmpny"), $"bronze.state".alias("b_state"),
							$"silver.state".alias("s_state"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip))


					val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip)


					val nbrpoa_gold_ip = "nbrpoa_" + typeOfData + "_gold_ip"
					val nbrpoa_issued_gold_ip = naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
							(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("02") &&
							naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_gold_ip))


					val bsGold = brSilData.alias("brsil").join(nbrpoa_issued_gold_ip.alias("gold"), $"brsil.health_year" === $"gold.health_year"
					&& $"brsil.cmpny_cf_cd" === $"gold.cmpny_cf_cd" && $"brsil.state" === $"gold.state", "outer")
					.select($"brsil.health_year".alias("b_year"), $"gold.health_year".alias("s_year"),
							$"brsil.cmpny_cf_cd".alias("b_cmpny"), $"gold.cmpny_cf_cd".alias("s_cmpny"), $"brsil.state".alias("b_state"),
							$"gold.state".alias("s_state"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip))


					val bsGoldData = bsGold.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip)



					val nbrpoa_platinum_ip = "nbrpoa_" + typeOfData + "_platinum_ip"
					val nbrpoa_issued_platinum_ip = naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
							(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("01") &&
							naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_platinum_ip))

					val bsgPlt = bsGoldData.alias("bsg").join(nbrpoa_issued_platinum_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip))

					val bsgPltinumData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip)

					val nbrpoa_total_ip = "nbrpoa_" + typeOfData + "_total_ip"
					val getTotal_ip = nbrpoa_issued_bronze_ip.union(nbrpoa_issued_silver_ip.union(nbrpoa_issued_gold_ip.union(nbrpoa_issued_platinum_ip)))
					.select($"health_year", $"cmpny_cf_cd", $"state", col(nbrpoa_bronze_ip))

					val nbrpoa_issued_total_ip = getTotal_ip.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col(nbrpoa_bronze_ip)).alias(nbrpoa_total_ip))

					val bsgpTot = bsgPltinumData.alias("bsg").join(nbrpoa_issued_total_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip))

					val bsgPTotData = bsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,nbrpoa_total_ip)

					val nbrpoa_gtlgp = "nbrpoa_" + typeOfData + "_gtlgp" 

					val nbrpoa_issued_gtlgp = spark.sql("""

							select 


   case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.health_year
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.health_year
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.health_year
        end as  health_year ,      
         
   case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.anthem_cmpny_cd 
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.cmpny_cf_cd 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.cmpny_cf_cd
        end as  cmpny_cf_cd ,
        
    case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.state
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.state 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.state
        end as  state ,  
        
    CASE
           WHEN stg.anthem_cmpny_cd IS NULL AND stg.state IS NULL THEN 
                cast(count(DISTINCT wrk1.mbrshp_sor_cd, wrk1.src_grp_nbr) as int)
           WHEN stg.anthem_cmpny_cd IS NOT NULL AND stg.state IS NOT NULL  and
           wrk1.cmpny_cf_cd is not null and wrk1.state is not null
           THEN cast((count(DISTINCT wrk1.mbrshp_sor_cd, wrk1.src_grp_nbr) + stg."""+nbrpoa_gtlgp+""" ) as int)
            WHEN wrk1.cmpny_cf_cd IS NULL
                AND wrk1.state IS NULL THEN stg."""+nbrpoa_gtlgp+"""
       END AS """+nbrpoa_gtlgp+"""
       

from 
( select wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.mbrshp_sor_cd, wrk.src_grp_nbr
from termedPOAG_wrk wrk
where wrk.naic_lob in ('LARGE GROUP CBE EXCLUDING MEDICARE'  , 'TOTAL NATIONAL CBE' ) 
and   wrk.grndfthr_ind_cd = 'YES' 
and wrk.in_exchange is null
group by wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.mbrshp_sor_cd, wrk.src_grp_nbr
)wrk1
full outer join facets_stg stg
on wrk1.cmpny_cf_cd = stg.anthem_cmpny_cd
and wrk1.state = stg.state

group by wrk1.cmpny_cf_cd ,wrk1.state, stg.anthem_cmpny_cd,   stg.state,
         stg."""+nbrpoa_gtlgp+""", wrk1.health_year, stg.health_year 
""")
							
	

					val ipgtlgp = bsgPTotData.alias("bsg").join(nbrpoa_issued_gtlgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_gtlgp)) 



					val ipgtlgpData = ipgtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,nbrpoa_total_ip,nbrpoa_gtlgp)


					val nbrpoa_gtip = "nbrpoa_" + typeOfData + "_gtip" 

					val nbrpoa_issued_gtip = spark.sql("""
		
							select 
               case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.health_year
                    when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.health_year
                when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
                and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.health_year
            end as  health_year ,      
         
         case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.anthem_cmpny_cd 
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.cmpny_cf_cd 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.cmpny_cf_cd
        end as  cmpny_cf_cd ,
        
        case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.state
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.state 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.state
        end as  state , 
        
							CASE WHEN stg.anthem_cmpny_cd is null and stg.state is null THEN cast(count(distinct wrk1.sbscrbr_id) as int)
							when stg.anthem_cmpny_cd is not null and stg.state is not null and
							wrk1.cmpny_cf_cd is not null and wrk1.state is not null
							THEN cast((count(distinct wrk1.sbscrbr_id) + stg."""+nbrpoa_gtip+""") as int)
							WHEN wrk1.cmpny_cf_cd IS NULL  AND wrk1.state IS NULL THEN stg."""+nbrpoa_gtip+"""
							end as  """+nbrpoa_gtip+"""
							  
							from 
							( select wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.sbscrbr_id
							from termedPOA_wrk wrk
							where wrk.naic_lob = 'TOTAL INDIVIDUAL CBE'
							and ( wrk.grndfthr_ind_cd = 'YES'   or  wrk.hcr_cmplynt_cd <> 'Y'  or  wrk.hcr_cmplynt_cd is null  )
							and  wrk.in_exchange is null
							group by wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.sbscrbr_id
							)wrk1
							full outer join facets_stg stg
							on wrk1.cmpny_cf_cd = stg.anthem_cmpny_cd
							and wrk1.state = stg.state
							
							group by  
							wrk1.health_year ,
							wrk1.cmpny_cf_cd ,
							wrk1.state,
							stg.anthem_cmpny_cd,
							stg.state,
							stg."""+nbrpoa_gtip+""",
							stg.health_year 
"""
							)



					val ipgtlgpip = ipgtlgpData.alias("bsg").join(nbrpoa_issued_gtip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_gtlgp),col(nbrpoa_gtip))



					val ipgtlgpipData = ipgtlgpip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, 
							nbrpoa_platinum_ip,nbrpoa_total_ip,nbrpoa_gtlgp, nbrpoa_gtip)

					val nbrpoa_catastrophic = "nbrpoa_" + typeOfData + "_catastrophic"
					val nbrpoa_issued_catastrophic = naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_prod_desc").like("%CATASTROPHIC%") &&
							naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_catastrophic))

					val bsgptCat = ipgtlgpipData.alias("bsg").join(nbrpoa_issued_catastrophic.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_gtlgp),col(nbrpoa_gtip), col(nbrpoa_catastrophic))

					val bsgptCatData = bsgptCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip,nbrpoa_gtlgp, nbrpoa_gtip,nbrpoa_catastrophic)
							
					

					val nbrpoa_lgp_mmcare = "nbrpoa_" + typeOfData + "_lgp_mmcare"

					val nbrpoa_termed_lgp_mmcare = spark.sql("""
	            select 
   case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.health_year
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.health_year
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.health_year
        end as  health_year ,      
         
   case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.anthem_cmpny_cd 
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.cmpny_cf_cd 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.cmpny_cf_cd
        end as  cmpny_cf_cd ,
        
    case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.state
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.state 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.state
        end as  state , 
        
        
							CASE WHEN stg.anthem_cmpny_cd is null and stg.state is null THEN cast(count(distinct wrk1.mbrshp_sor_cd, wrk1.src_grp_nbr) as int)
							when stg.anthem_cmpny_cd is not null and stg.state is not null 
							and wrk1.cmpny_cf_cd is not null and wrk1.state is not null
							THEN cast((count(distinct wrk1.mbrshp_sor_cd, wrk1.src_grp_nbr) + stg."""+nbrpoa_lgp_mmcare+""") as int) 
							WHEN wrk1.cmpny_cf_cd IS NULL AND wrk1.state IS NULL THEN stg."""+nbrpoa_lgp_mmcare+"""							
							end as """+nbrpoa_lgp_mmcare+"""
							  
							from 
							(
							select wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.mbrshp_sor_cd, wrk.src_grp_nbr
							from termedPOAG_wrk wrk
							where wrk.naic_lob in ('LARGE GROUP CBE EXCLUDING MEDICARE'  , 'TOTAL NATIONAL CBE' ) 
							and ( wrk.grndfthr_ind_cd <> 'YES'  or wrk.grndfthr_ind_cd is null )
							and wrk.mbu_cf_cd not in ("""+mbu_cf_cdvals_sql+""")
							and in_exchange is null
							group by wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.mbrshp_sor_cd, wrk.src_grp_nbr
							)wrk1
							full outer join facets_stg stg
							on wrk1.cmpny_cf_cd = stg.anthem_cmpny_cd
							and wrk1.state = stg.state


							group by  
							wrk1.health_year ,
							wrk1.cmpny_cf_cd ,
							wrk1.state,
							stg.anthem_cmpny_cd,
							stg.state,
							stg."""+nbrpoa_lgp_mmcare+""",
							stg.health_year 

							"""
							)
						


					val bsgptcMmcare = bsgptCatData.alias("bsg").join(nbrpoa_termed_lgp_mmcare.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_gtlgp),col(nbrpoa_gtip), col(nbrpoa_catastrophic),col(nbrpoa_lgp_mmcare))

					val bsgptcMmcareData = bsgptcMmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip,nbrpoa_gtlgp, nbrpoa_gtip,nbrpoa_catastrophic,nbrpoa_lgp_mmcare)



					val nbrpoa_stucvg = "nbrpoa_" + typeOfData + "_stucvg"

							val nbrpoa_issued_stucvg = naic_mcas_hlthex_poag_wrk.filter(naic_mcas_hlthex_poag_wrk("naic_lob").isin(naic_lob_lgp:_*) &&
									naic_mcas_hlthex_poag_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*) &&
									naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state",$"mbrshp_sor_cd",$"src_grp_nbr").agg((lit(1)).alias("count_Val")).groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias(nbrpoa_stucvg))

							
							
							
							val bsgptcmmcStuvg = bsgptcMmcareData.alias("bsg").join(nbrpoa_issued_stucvg.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp), col(nbrpoa_gtip), col(nbrpoa_catastrophic), col(nbrpoa_lgp_mmcare), col(nbrpoa_stucvg))

							val finalData = bsgptcmmcStuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_gtlgp, nbrpoa_gtip, nbrpoa_catastrophic, nbrpoa_lgp_mmcare, nbrpoa_stucvg)
 
									
							finalData
						

			}

			def getMemberIssuedData(naic_mcas_hlthex_poa_wrk: DataFrame,naic_mcas_hlthex_poag_mmissued_wrk:DataFrame): DataFrame = {


					var mmissued_wrk = naic_mcas_hlthex_poa_wrk.withColumn("Const_date", lit(mmissue_const_date))
							mmissued_wrk.withColumn("Const_date", to_date($"Const_date"))

							var mmissued_wrk1 = naic_mcas_hlthex_poag_mmissued_wrk.withColumn("Const_date", lit(mmissue_const_date))
							mmissued_wrk.withColumn("Const_date", to_date($"Const_date"))


							val mbrmpoa_issued_bronze_ip = mmissued_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
									(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("04") &&
									naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(
									when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_bronze_ip_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_bronze_ip_1").alias("mbrmpoa_issued_bronze_ip")).withColumn("mbrmpoa_issued_bronze_ip", round($"mbrmpoa_issued_bronze_ip", 0).cast(IntegerType))

							val mbrmpoa_issued_silver_ip = mmissued_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
									(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("03") &&
									naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_silver_ip_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_silver_ip_1").alias("mbrmpoa_issued_silver_ip")).withColumn("mbrmpoa_issued_silver_ip", round($"mbrmpoa_issued_silver_ip", 0).cast(IntegerType))

							val brSil = mbrmpoa_issued_bronze_ip.alias("bsg").join(mbrmpoa_issued_silver_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"))

							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip")

							val mbrmpoa_issued_gold_ip = mmissued_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
									(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("02") &&
									naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_gold_ip_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_gold_ip_1").alias("mbrmpoa_issued_gold_ip")).withColumn("mbrmpoa_issued_gold_ip", round($"mbrmpoa_issued_gold_ip", 0).cast(IntegerType))
							val bsGld = brSilData.alias("bsg").join(mbrmpoa_issued_gold_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"))

							val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip",
									"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip")

							val mbrmpoa_issued_platinum_ip = mmissued_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
									(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("01") &&
									naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"MBR_RLTNSHP_CD", $"Const_date",
									$"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_platinum_ip_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_platinum_ip_1").alias("mbrmpoa_issued_platinum_ip")).withColumn("mbrmpoa_issued_platinum_ip", round($"mbrmpoa_issued_platinum_ip", 0).cast(IntegerType))

							val bsgPlt = bsGldData.alias("bsg").join(mbrmpoa_issued_platinum_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"),
									col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"))

							val bsgPltData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip")

							val getTotal_ip = mbrmpoa_issued_bronze_ip.union(mbrmpoa_issued_silver_ip.union(mbrmpoa_issued_gold_ip.union(mbrmpoa_issued_platinum_ip)))
							.select($"health_year", $"cmpny_cf_cd", $"state", $"mbrmpoa_issued_bronze_ip")

							val mbrmpoa_issued_total_ip = getTotal_ip.groupBy("health_year", "cmpny_cf_cd", "state")
							.agg(sum($"mbrmpoa_issued_bronze_ip").alias("mbrmpoa_issued_total_ip"))

							val ip = bsgPltData.alias("bsg").join(mbrmpoa_issued_total_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"))

							val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip",
									"mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip")

							val mbrmpoa_issued_bronze_sgp = mmissued_wrk1.filter(naic_mcas_hlthex_poag_mmissued_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").isNull) &&
									naic_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").isNull) &&
									naic_mcas_hlthex_poag_mmissued_wrk("exchng_metl_type_cd").equalTo("04") &&
									naic_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"MBR_RLTNSHP_CD", $"Const_date",
									$"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_bronze_sgp_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_bronze_sgp_1").alias("mbrmpoa_issued_bronze_sgp")).withColumn("mbrmpoa_issued_bronze_sgp", round($"mbrmpoa_issued_bronze_sgp", 0).cast(IntegerType))

							val ipBrz = ipData.alias("bsg").join(mbrmpoa_issued_bronze_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"),
									col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"))

							val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip",
									"mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp")

							val mbrmpoa_issued_silver_sgp = mmissued_wrk1.filter(naic_mcas_hlthex_poag_mmissued_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").isNull) &&
									naic_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").isNull) &&
									naic_mcas_hlthex_poag_mmissued_wrk("exchng_metl_type_cd").equalTo("03") &&
									naic_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"Const_date",
									$"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_silver_sgp_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_silver_sgp_1").alias("mbrmpoa_issued_silver_sgp")).withColumn("mbrmpoa_issued_silver_sgp", round($"mbrmpoa_issued_silver_sgp", 0).cast(IntegerType))

							val ipbSil = ipBrzData.alias("bsg").join(mbrmpoa_issued_silver_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"))

							val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip",
									"mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp")

							val mbrmpoa_issued_gold_sgp = mmissued_wrk1.filter(naic_mcas_hlthex_poag_mmissued_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").isNull) &&
									naic_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").isNull) &&
									naic_mcas_hlthex_poag_mmissued_wrk("exchng_metl_type_cd").equalTo("02") &&
									naic_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"MBR_RLTNSHP_CD", $"Const_date",
									$"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_gold_sgp_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_gold_sgp_1").alias("mbrmpoa_issued_gold_sgp")).withColumn("mbrmpoa_issued_gold_sgp", round($"mbrmpoa_issued_gold_sgp", 0).cast(IntegerType))

							val ipbsGld = ipbSilData.alias("bsg").join(mbrmpoa_issued_gold_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state",
									"outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"),
									col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"),
									col("mbrmpoa_issued_gold_sgp"))

							val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip",
									"mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp")


							val mbrmpoa_issued_platinum_sgp = mmissued_wrk1.filter(naic_mcas_hlthex_poag_mmissued_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").isNull) &&
									naic_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poag_mmissued_wrk("src_exchng_certfn_cd").isNull) &&
									naic_mcas_hlthex_poag_mmissued_wrk("exchng_metl_type_cd").equalTo("01") &&
									naic_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull) //naic_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"MBR_RLTNSHP_CD", $"Const_date",
									$"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_platinum_sgp_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_platinum_sgp_1").alias("mbrmpoa_issued_platinum_sgp")).withColumn("mbrmpoa_issued_platinum_sgp", round($"mbrmpoa_issued_platinum_sgp", 0).cast(IntegerType))

							val ipbsgPlt = ipbsGldData.alias("bsg").join(mbrmpoa_issued_platinum_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"))

							val ipbsgPltData = ipbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp",
									"mbrmpoa_issued_platinum_sgp")

							val getTotal_sgp = mbrmpoa_issued_bronze_sgp.union(mbrmpoa_issued_silver_sgp.union(mbrmpoa_issued_gold_sgp.union(mbrmpoa_issued_platinum_sgp)))
							.select($"health_year", $"cmpny_cf_cd", $"state", $"mbrmpoa_issued_bronze_sgp")

							val mbrmpoa_issued_total_sgp = getTotal_sgp.groupBy("health_year", "cmpny_cf_cd", "state")
							.agg(sum($"mbrmpoa_issued_bronze_sgp").alias("mbrmpoa_issued_total_sgp"))

							val ipsgp = ipbsgPltData.alias("bsg").join(mbrmpoa_issued_total_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"))

							val ipsgpData = ipsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp")

							val mbrmpoa_issued_gtlgp = mmissued_wrk1.filter(naic_mcas_hlthex_poag_mmissued_wrk("naic_lob").isin(naic_lob_lgp:_*) &&
									//(naic_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").equalTo("YES") || naic_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").notEqual("Y") || naic_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").isNull) &&
									naic_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").equalTo("YES") &&
									naic_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"MBR_RLTNSHP_CD", $"Const_date",
									$"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_gtlgp_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_gtlgp_1").alias("mbrmpoa_issued_gtlgp")).withColumn("mbrmpoa_issued_gtlgp", round($"mbrmpoa_issued_gtlgp", 0).cast(IntegerType))

							val ipbsgtlgp = ipsgpData.alias("bsg").join(mbrmpoa_issued_gtlgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state",
									"outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"),
									col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"),
									col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_gtlgp"))

							val ipbsgtlgpData = ipbsgtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp")
							val mbrmpoa_issued_gtsgp = mmissued_wrk1.filter(naic_mcas_hlthex_poag_mmissued_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").equalTo("YES") || naic_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").notEqual("Y")|| naic_mcas_hlthex_poag_mmissued_wrk("hcr_cmplynt_cd").isNull) &&
									naic_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"MBR_RLTNSHP_CD", $"Const_date",
									$"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_gtsgp_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_gtsgp_1").alias("mbrmpoa_issued_gtsgp")).withColumn("mbrmpoa_issued_gtsgp", round($"mbrmpoa_issued_gtsgp", 0).cast(IntegerType))

							val ipbsgtsgp = ipbsgtlgpData.alias("bsg").join(mbrmpoa_issued_gtsgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state",
									"outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"),
									col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"),
									col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_gtlgp"), col("mbrmpoa_issued_gtsgp"))

							val ipbsgtsgpData = ipbsgtsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp", "mbrmpoa_issued_gtsgp")

							val mbrmpoa_issued_gtip = mmissued_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
									(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").equalTo("YES") || naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").notEqual("Y")|| naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"MBR_RLTNSHP_CD", $"Const_date",
									$"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_gtip_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_gtip_1").alias("mbrmpoa_issued_gtip")).withColumn("mbrmpoa_issued_gtip", round($"mbrmpoa_issued_gtip", 0).cast(IntegerType))
							val ipbsgtip = ipbsgtsgpData.alias("bsg").join(mbrmpoa_issued_gtip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state",
									"outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"),
									col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"),
									col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_gtlgp"), col("mbrmpoa_issued_gtsgp"), col("mbrmpoa_issued_gtip"))

							val ipbsgtipData = ipbsgtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp", "mbrmpoa_issued_gtsgp", "mbrmpoa_issued_gtip")

							val get_total_gtip = mbrmpoa_issued_gtlgp.union(mbrmpoa_issued_gtsgp.union(mbrmpoa_issued_gtip))
							.select($"health_year", $"cmpny_cf_cd", $"state", $"mbrmpoa_issued_gtlgp")

							val mbrmpoa_issued_total_gtip = get_total_gtip.groupBy("health_year", "cmpny_cf_cd", "state")
							.agg(sum($"mbrmpoa_issued_gtlgp").alias("mbrmpoa_issued_total_gtip"))

							val gtlp = ipbsgtipData.alias("bsg").join(mbrmpoa_issued_total_gtip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_gtlgp"), col("mbrmpoa_issued_gtsgp"), col("mbrmpoa_issued_gtip"),
									col("mbrmpoa_issued_total_gtip"))

							val ipgtlpData = gtlp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp", "mbrmpoa_issued_gtsgp", "mbrmpoa_issued_gtip", "mbrmpoa_issued_total_gtip")

							val mbrmpoa_issued_catastrophic = mmissued_wrk
							.filter(naic_mcas_hlthex_poa_wrk("naic_prod_desc").like("%CATASTROPHIC%") &&
									naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"MBR_RLTNSHP_CD", $"Const_date",
									$"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_catastrophic_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_catastrophic_1").alias("mbrmpoa_issued_catastrophic")).withColumn("mbrmpoa_issued_catastrophic", round($"mbrmpoa_issued_catastrophic", 0).cast(IntegerType))
							val ipCat = ipgtlpData.alias("bsg").join(mbrmpoa_issued_catastrophic.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_gtlgp"), col("mbrmpoa_issued_gtsgp"), col("mbrmpoa_issued_gtip"),
									col("mbrmpoa_issued_total_gtip"), col("mbrmpoa_issued_catastrophic"))

							val ipCatData = ipCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp", "mbrmpoa_issued_gtsgp", "mbrmpoa_issued_gtip",
									"mbrmpoa_issued_total_gtip", "mbrmpoa_issued_catastrophic")

							val mbrmpoa_issued_lgp_mmcare = mmissued_wrk1.filter(naic_mcas_hlthex_poag_mmissued_wrk("naic_lob").isin(naic_lob_lgp:_*) &&
									(!naic_mcas_hlthex_poag_mmissued_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*)) &&
									(naic_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_mmissued_wrk("grndfthr_ind_cd").isNull) &&
									naic_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"MBR_RLTNSHP_CD", $"Const_date",
									$"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_lgp_mmcare_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_lgp_mmcare_1").alias("mbrmpoa_issued_lgp_mmcare")).withColumn("mbrmpoa_issued_lgp_mmcare", round($"mbrmpoa_issued_lgp_mmcare", 0).cast(IntegerType))

							val ipLgpmm = ipCatData.alias("bsg").join(mbrmpoa_issued_lgp_mmcare.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_gtlgp"), col("mbrmpoa_issued_gtsgp"), col("mbrmpoa_issued_gtip"),
									col("mbrmpoa_issued_total_gtip"), col("mbrmpoa_issued_catastrophic"), col("mbrmpoa_issued_lgp_mmcare"))

							val ipLgpmmData = ipLgpmm.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp", "mbrmpoa_issued_gtsgp", "mbrmpoa_issued_gtip",
									"mbrmpoa_issued_total_gtip", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_lgp_mmcare")

							val mbrmpoa_issued_stucvg = mmissued_wrk1.filter(naic_mcas_hlthex_poag_mmissued_wrk("naic_lob").isin(naic_lob_lgp:_*) &&
									naic_mcas_hlthex_poag_mmissued_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*) &&
									naic_mcas_hlthex_poag_mmissued_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD",
									$"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT")
							.agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_stucvg_1"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("mbrmpoa_issued_stucvg_1").alias("mbrmpoa_issued_stucvg")).withColumn("mbrmpoa_issued_stucvg", round($"mbrmpoa_issued_stucvg", 0).cast(IntegerType))

							val ipStu = ipLgpmmData.alias("bsg").join(mbrmpoa_issued_stucvg.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
									col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
									col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_gtlgp"), col("mbrmpoa_issued_gtsgp"), col("mbrmpoa_issued_gtip"),
									col("mbrmpoa_issued_total_gtip"), col("mbrmpoa_issued_catastrophic"), col("mbrmpoa_issued_lgp_mmcare"), col("mbrmpoa_issued_stucvg"))

							val finalData = ipStu.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_oux").isNull, $"s_oux").otherwise($"b_oux"))
							.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
									"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
									"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp", "mbrmpoa_issued_gtsgp", "mbrmpoa_issued_gtip",
									"mbrmpoa_issued_total_gtip", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_lgp_mmcare", "mbrmpoa_issued_stucvg")

							
							finalData

			}


			def getMemberRenewedData(naic_mcas_hlthex_poa_wrk: DataFrame,naic_mcas_hlthex_poag_mmrenewed_wrk:DataFrame): DataFrame = {
					//val year ="2016"

					naic_mcas_hlthex_poa_wrk.createOrReplaceTempView("mmrenewed_wrk")
					naic_mcas_hlthex_poag_mmrenewed_wrk.createOrReplaceTempView("mmrenewedpoag")


					val mbrmpoa_renewed_bronze_ip = spark.sql("""              
							SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_bronze_ip FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'TOTAL INDIVIDUAL CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '04' 
							and in_exchange is NULL
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val mbrmpoa_renewed_silver_ip = spark.sql(""" SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_silver_ip 
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'TOTAL INDIVIDUAL CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '03' 
							and in_exchange is NULL
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val mbrmpoa_renewed_gold_ip = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_gold_ip
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'TOTAL INDIVIDUAL CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '02' 
							and in_exchange is NULL
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val mbrmpoa_renewed_platinum_ip = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_platinum_ip
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'TOTAL INDIVIDUAL CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '01' 
							and in_exchange is NULL
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val mbrmpoa_renewed_bronze_sgp = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_bronze_sgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewedpoag
							where naic_lob = 'TOTAL SMALL GROUP CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '04' 
							and in_exchange is NULL
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val mbrmpoa_renewed_silver_sgp = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_silver_sgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewedpoag
							where naic_lob = 'TOTAL SMALL GROUP CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '03' 
							and in_exchange is NULL
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val mbrmpoa_renewed_gold_sgp = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_gold_sgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewedpoag
							where naic_lob = 'TOTAL SMALL GROUP CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '02' 
							and in_exchange is NULL
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val mbrmpoa_renewed_platinum_sgp = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_platinum_sgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewedpoag
							where naic_lob = 'TOTAL SMALL GROUP CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '01' 
							and in_exchange is NULL
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val mbrmpoa_renewed_gtlgp = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_gtlgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewedpoag
							where naic_lob in ('LARGE GROUP CBE EXCLUDING MEDICARE',  'TOTAL NATIONAL CBE')
							-- on 0108 and ( grndfthr_ind_cd = 'YES'   or  hcr_cmplynt_cd <> 'Y' or hcr_cmplynt_cd is null )
							and ( grndfthr_ind_cd = 'YES')	
							and in_exchange is NULL	
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val mbrmpoa_renewed_gtsgp = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_gtsgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewedpoag
							where naic_lob = 'TOTAL SMALL GROUP CBE'
							and ( grndfthr_ind_cd = 'YES'   or   hcr_cmplynt_cd <> 'Y' or hcr_cmplynt_cd is null  )	
							and in_exchange is NULL	
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val mbrmpoa_renewed_gtip = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_gtip
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'TOTAL INDIVIDUAL CBE'
							and ( grndfthr_ind_cd = 'YES'   or   hcr_cmplynt_cd <> 'Y' or hcr_cmplynt_cd is null  )
							and in_exchange is NULL	
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val mbrmpoa_renewed_catastrophic = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_catastrophic
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_prod_desc  LIKE  '%CATASTROPHIC%'
							and in_exchange is NULL
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val mbrmpoa_renewed_lgp_mmcare = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_lgp_mmcare
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewedpoag
							where naic_lob in ('LARGE GROUP CBE EXCLUDING MEDICARE',  'TOTAL NATIONAL CBE')
							and (grndfthr_ind_cd <>  'YES' OR grndfthr_ind_cd is NULL) 
							and mbu_cf_cd not in ("""+mbu_cf_cdvals_sql+""")
							and in_exchange is NULL	
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val mbrmpoa_renewed_stucvg = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state, cast(round(SUM( Member_Months ),0)  as int) as mbrmpoa_renewed_stucvg
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewedpoag
							where naic_lob in ('LARGE GROUP CBE EXCLUDING MEDICARE',  'TOTAL NATIONAL CBE')
							and mbu_cf_cd in ("""+mbu_cf_cdvals_sql+""")
							and in_exchange is NULL	
							GROUP BY health_year,cmpny_cf_cd,state,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state""")

					val brSil = mbrmpoa_renewed_bronze_ip.alias("bsg").join(mbrmpoa_renewed_silver_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"))

					val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip")

					val bsGld = brSilData.alias("bsg").join(mbrmpoa_renewed_gold_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"))

					val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip")

					val bsgPlt = bsGldData.alias("bsg").join(mbrmpoa_renewed_platinum_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"))

					val bsgPltData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip")

					//"mbrmpoa_renewed_bronze_ip + mbrmpoa_renewed_silver_ip + mbrmpoa_renewed_gold_ip + mbrmpoa_renewed_platinum_ip"

					val getTotal_ip = mbrmpoa_renewed_bronze_ip.union(mbrmpoa_renewed_silver_ip.union(mbrmpoa_renewed_gold_ip.union(mbrmpoa_renewed_platinum_ip)))
					.select($"health_year", $"cmpny_cf_cd", $"state", $"mbrmpoa_renewed_bronze_ip")

					val mbrmpoa_renewed_total_ip = getTotal_ip.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"mbrmpoa_renewed_bronze_ip").alias("mbrmpoa_renewed_total_ip"))

					val ip = bsgPltData.alias("bsg").join(mbrmpoa_renewed_total_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"))

					val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip")

					val ipBrz = ipData.alias("bsg").join(mbrmpoa_renewed_bronze_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"))

					val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp")

					val ipbSil = ipBrzData.alias("bsg").join(mbrmpoa_renewed_silver_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"))

					val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp")

					val ipbsGld = ipbSilData.alias("bsg").join(mbrmpoa_renewed_gold_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"))

					val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp")

					val ipbsgPlt = ipbsGldData.alias("bsg").join(mbrmpoa_renewed_platinum_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"))

					val ipbsgPltData = ipbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp")

					val getTotal_sgp = mbrmpoa_renewed_bronze_sgp.union(mbrmpoa_renewed_silver_sgp.union(mbrmpoa_renewed_gold_sgp.union(mbrmpoa_renewed_platinum_sgp)))
					.select($"health_year", $"cmpny_cf_cd", $"state", $"mbrmpoa_renewed_bronze_sgp")

					val mbrmpoa_renewed_total_sgp = getTotal_sgp.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"mbrmpoa_renewed_bronze_sgp").alias("mbrmpoa_renewed_total_sgp"))

					val ipSgp = ipbsgPltData.alias("bsg").join(mbrmpoa_renewed_total_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"))

					val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp")

					val ipSgpgtLgp = ipSgpData.alias("bsg").join(mbrmpoa_renewed_gtlgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"))

					val ipSgpgtLgpData = ipSgpgtLgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp",
							"mbrmpoa_renewed_gtlgp")

					val ipSgpgtLgpgtSgp = ipSgpgtLgpData.alias("bsg").join(mbrmpoa_renewed_gtsgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"), col("mbrmpoa_renewed_gtsgp"))

					val ipSgpgtLgpgtSgpData = ipSgpgtLgpgtSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp",
							"mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp")

					val ipSgpgtLgpgtSgpip = ipSgpgtLgpgtSgpData.alias("bsg").join(mbrmpoa_renewed_gtip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"), col("mbrmpoa_renewed_gtsgp"), col("mbrmpoa_renewed_gtip"))

					val ipSgpgtLgpgtSgpipData = ipSgpgtLgpgtSgpip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp",
							"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip")

					val getTotal_gtip = mbrmpoa_renewed_gtlgp.union(mbrmpoa_renewed_gtsgp.union(mbrmpoa_renewed_gtip))
					.select($"health_year", $"cmpny_cf_cd", $"state", $"mbrmpoa_renewed_gtlgp")

					val mbrmpoa_renewed_total_gtip = getTotal_gtip.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"mbrmpoa_renewed_gtlgp").alias("mbrmpoa_renewed_total_gtip")).withColumn("mbrmpoa_renewed_total_gtip", $"mbrmpoa_renewed_total_gtip".cast(IntegerType))

					val ipSgpgtLgpgtSgpipgtTot = ipSgpgtLgpgtSgpipData.alias("bsg").join(mbrmpoa_renewed_total_gtip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"), col("mbrmpoa_renewed_gtsgp"), col("mbrmpoa_renewed_gtip"), col("mbrmpoa_renewed_total_gtip"))

					val ipSgpgtLgpgtSgpipgtTotData = ipSgpgtLgpgtSgpipgtTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp",
							"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip", "mbrmpoa_renewed_total_gtip")

					val ipSgpgtLgpgtSgpipgtTotCat = ipSgpgtLgpgtSgpipgtTotData.alias("bsg").join(mbrmpoa_renewed_catastrophic.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"), col("mbrmpoa_renewed_gtsgp"), col("mbrmpoa_renewed_gtip"), col("mbrmpoa_renewed_total_gtip"),
							col("mbrmpoa_renewed_catastrophic"))

					val ipSgpgtLgpgtSgpipgtTotCatData = ipSgpgtLgpgtSgpipgtTotCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp",
							"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip", "mbrmpoa_renewed_total_gtip", "mbrmpoa_renewed_catastrophic")

					val ipSgpgtLgpgtSgpipgtTotCatmm = ipSgpgtLgpgtSgpipgtTotCatData.alias("bsg").join(mbrmpoa_renewed_lgp_mmcare.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"), col("mbrmpoa_renewed_gtsgp"), col("mbrmpoa_renewed_gtip"), col("mbrmpoa_renewed_total_gtip"),
							col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_lgp_mmcare"))

					val ipSgpgtLgpgtSgpipgtTotCatmmData = ipSgpgtLgpgtSgpipgtTotCatmm.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp",
							"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip", "mbrmpoa_renewed_total_gtip", "mbrmpoa_renewed_catastrophic",
							"mbrmpoa_renewed_lgp_mmcare")

					val ipSgpgtLgpgtSgpipgtTotCatmmSt = ipSgpgtLgpgtSgpipgtTotCatmmData.alias("bsg").join(mbrmpoa_renewed_stucvg.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
							col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
							col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_gtlgp"), col("mbrmpoa_renewed_gtsgp"), col("mbrmpoa_renewed_gtip"), col("mbrmpoa_renewed_total_gtip"),
							col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_lgp_mmcare"), col("mbrmpoa_renewed_stucvg"))

					val finalData = ipSgpgtLgpgtSgpipgtTotCatmmSt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp",
							"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip", "mbrmpoa_renewed_total_gtip", "mbrmpoa_renewed_catastrophic",
							"mbrmpoa_renewed_lgp_mmcare", "mbrmpoa_renewed_stucvg")

					
					finalData

			}
			def getTermedLivesData(naic_mcas_hlthex_poa_wrk: DataFrame,naic2018_mcas_hlthoex_poa_facets_stg:DataFrame,naic_mcas_hlthex_poag_wrk:DataFrame,typeOfData: String): DataFrame = {

					naic_mcas_hlthex_poa_wrk.createOrReplaceTempView("termedlivesPOA_wrk")
					naic2018_mcas_hlthoex_poa_facets_stg.createOrReplaceTempView("facets_stg")
					naic_mcas_hlthex_poag_wrk.createOrReplaceTempView("termedlivesPOAG_wrk")




					val nbrpoa_bronze_ip = "nbrpoa_" + typeOfData + "_bronze_ip"
					val nbrpoa_termed_nonpay_lives_bronze_ip = naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
							(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("04") &&
							naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"mbr_rltnshp_cd").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_bronze_ip))

					val nbrpoa_silver_ip = "nbrpoa_" + typeOfData + "_silver_ip"
					val nbrpoa_termed_nonpay_lives_silver_ip = naic_mcas_hlthex_poa_wrk
					.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
							(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("03") &&
							naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"mbr_rltnshp_cd").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_silver_ip))

					val brSil = nbrpoa_termed_nonpay_lives_bronze_ip.alias("bronze").join(nbrpoa_termed_nonpay_lives_silver_ip.alias("silver"), $"bronze.health_year" === $"silver.health_year"
					&& $"bronze.cmpny_cf_cd" === $"silver.cmpny_cf_cd" && $"bronze.state" === $"silver.state", "outer")
					.select($"bronze.health_year".alias("b_year"), $"silver.health_year".alias("s_year"),
							$"bronze.cmpny_cf_cd".alias("b_cmpny"), $"silver.cmpny_cf_cd".alias("s_cmpny"), $"bronze.state".alias("b_state"),
							$"silver.state".alias("s_state"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip))

					val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip)
					val nbrpoa_gold_ip = "nbrpoa_" + typeOfData + "_gold_ip"
					val nbrpoa_termed_nonpay_lives_gold_ip = naic_mcas_hlthex_poa_wrk
					.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
							(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("02") &&
							naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"mbr_rltnshp_cd").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_gold_ip))

					val bsGold = brSilData.alias("brsil").join(nbrpoa_termed_nonpay_lives_gold_ip.alias("gold"), $"brsil.health_year" === $"gold.health_year"
					&& $"brsil.cmpny_cf_cd" === $"gold.cmpny_cf_cd" && $"brsil.state" === $"gold.state", "outer")
					.select($"brsil.health_year".alias("b_year"), $"gold.health_year".alias("s_year"),
							$"brsil.cmpny_cf_cd".alias("b_cmpny"), $"gold.cmpny_cf_cd".alias("s_cmpny"), $"brsil.state".alias("b_state"),
							$"gold.state".alias("s_state"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip))

					val bsGoldData = bsGold.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip)

					val nbrpoa_platinum_ip = "nbrpoa_" + typeOfData + "_platinum_ip"
					val nbrpoa_termed_nonpay_lives_platinum_ip = naic_mcas_hlthex_poa_wrk
					.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
							(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("01") &&
							naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"mbr_rltnshp_cd").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_platinum_ip))

					val bsgPlt = bsGoldData.alias("bsg").join(nbrpoa_termed_nonpay_lives_platinum_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip))

					val bsgPltinumData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip)

					val nbrpoa_total_ip = "nbrpoa_" + typeOfData + "_total_ip"
					val getTotal_ip = nbrpoa_termed_nonpay_lives_bronze_ip.union(nbrpoa_termed_nonpay_lives_silver_ip.union(nbrpoa_termed_nonpay_lives_gold_ip.union(nbrpoa_termed_nonpay_lives_platinum_ip)))
					.select($"health_year", $"cmpny_cf_cd", $"state", col(nbrpoa_bronze_ip))

					val nbrpoa_termed_nonpay_lives_total_ip = getTotal_ip.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col(nbrpoa_bronze_ip)).alias(nbrpoa_total_ip))

					val bsgpTot = bsgPltinumData.alias("bsg").join(nbrpoa_termed_nonpay_lives_total_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip))

					val ipTotData = bsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip)



					val nbrpoa_bronze_sgp = "nbrpoa_" + typeOfData + "_bronze_sgp"
					val nbrpoa_termed_nonpay_lives_bronze_sgp = naic_mcas_hlthex_poag_wrk
					.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
							(naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("04") &&
							naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"mbr_rltnshp_cd").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_bronze_sgp))

					val ipBrz = ipTotData.alias("bsg").join(nbrpoa_termed_nonpay_lives_bronze_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp))

					val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip, nbrpoa_bronze_sgp)

					val nbrpoa_silver_sgp = "nbrpoa_" + typeOfData + "_silver_sgp"
					val nbrpoa_termed_nonpay_lives_silver_sgp = naic_mcas_hlthex_poag_wrk
					.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
							(naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("03") &&
							naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"mbr_rltnshp_cd").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_silver_sgp))

					val ipbSil = ipBrzData.alias("bsg").join(nbrpoa_termed_nonpay_lives_silver_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp))

					val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp)

					val nbrpoa_gold_sgp = "nbrpoa_" + typeOfData + "_gold_sgp"
					val nbrpoa_termed_nonpay_lives_gold_sgp = naic_mcas_hlthex_poag_wrk
					.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
							(naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("02") &&
							naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"mbr_rltnshp_cd").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_gold_sgp))

					val ipbsGld = ipbSilData.alias("bsg").join(nbrpoa_termed_nonpay_lives_gold_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp))

					val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp)

					val nbrpoa_platinum_sgp = "nbrpoa_" + typeOfData + "_platinum_sgp"
					val nbrpoa_termed_nonpay_lives_platimun_sgp = naic_mcas_hlthex_poag_wrk
					.filter(naic_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
							(naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
							(naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
							naic_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("01") &&
							naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"mbr_rltnshp_cd").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_platinum_sgp))

					val ipbsgPlt = ipbsGldData.alias("bsg").join(nbrpoa_termed_nonpay_lives_platimun_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp))

					val ipbsgPltData = ipbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp)

					val nbrpoa_total_sgp = "nbrpoa_" + typeOfData + "_total_sgp"
					val getTotal_sgp = nbrpoa_termed_nonpay_lives_bronze_sgp.union(nbrpoa_termed_nonpay_lives_silver_sgp.union(nbrpoa_termed_nonpay_lives_gold_sgp.union(nbrpoa_termed_nonpay_lives_platimun_sgp)))
					.select($"health_year", $"cmpny_cf_cd", $"state", col(nbrpoa_bronze_sgp))

					val nbrpoa_termed_nonpay_lives_total_sgp = getTotal_sgp.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col(nbrpoa_bronze_sgp)).alias(nbrpoa_total_sgp))

					val ipbsgpTot = ipbsgPltData.alias("bsg").join(nbrpoa_termed_nonpay_lives_total_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp))

					val ipsgpData = ipbsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp)

					val nbrpoa_gtlgb = "nbrpoa_" + typeOfData + "_gtlgp"

					val nbrpoa_termed_lives_gtlgp = spark.sql(""" 
              select 
               case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.health_year
                    when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.health_year
                when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
                and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.health_year
            end as  health_year ,      
         
         case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.anthem_cmpny_cd 
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.cmpny_cf_cd 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.cmpny_cf_cd
        end as  cmpny_cf_cd ,
        
        case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.state
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.state 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.state
        end as  state , 
        
							CASE WHEN stg.anthem_cmpny_cd is null and stg.state is null THEN 
							cast((count(distinct wrk1.sbscrbr_id, wrk1.mbr_rltnshp_cd)) as  int)
							when stg.anthem_cmpny_cd is not null and stg.state is not null 
							and wrk1.cmpny_cf_cd is not null and wrk1.state is not null
							THEN cast((count(distinct wrk1.sbscrbr_id, wrk1.mbr_rltnshp_cd) + stg."""+nbrpoa_gtlgb+""") as  int)
							WHEN wrk1.cmpny_cf_cd IS NULL AND wrk1.state IS NULL THEN stg."""+nbrpoa_gtlgb+"""
							end as """+nbrpoa_gtlgb+"""
							  
							from 
							( select wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.sbscrbr_id, wrk.mbr_rltnshp_cd
							from termedlivesPOAG_wrk wrk
							where wrk.naic_lob in ('LARGE GROUP CBE EXCLUDING MEDICARE'  , 'TOTAL NATIONAL CBE' ) 
							and   wrk.grndfthr_ind_cd = 'YES' 
							and wrk.in_exchange is null
							group by wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.sbscrbr_id, wrk.mbr_rltnshp_cd
							)wrk1
							full outer join facets_stg stg
							on wrk1.cmpny_cf_cd = stg.anthem_cmpny_cd
							and wrk1.state = stg.state

							group by  
							wrk1.health_year ,
							wrk1.cmpny_cf_cd ,
							wrk1.state,
							stg.anthem_cmpny_cd,
							stg.state,
							stg."""+nbrpoa_gtlgb+""",
							stg.health_year
"""
							)



					val ipbsgpTotgtLgp = ipsgpData.alias("bsg").join(nbrpoa_termed_lives_gtlgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
							col(nbrpoa_gtlgb))

					val ipbsgpTotgtLgpData = ipbsgpTotgtLgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_gtlgb)

					val nbrpoa_gtsgp = "nbrpoa_" + typeOfData + "_gtsgp"

					val nbrpoa_termed_lives_gtsgp = spark.sql("""
              select 

   case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.health_year
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.health_year
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.health_year
        end as  health_year ,      
         
   case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.anthem_cmpny_cd 
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.cmpny_cf_cd 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.cmpny_cf_cd
        end as  cmpny_cf_cd ,
        
    case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.state
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.state 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.state
        end as  state , 
        
							CASE WHEN stg.anthem_cmpny_cd is null and stg.state is null THEN cast((count(distinct wrk1.sbscrbr_id, wrk1.mbr_rltnshp_cd)) as int)
							when stg.anthem_cmpny_cd is not null and stg.state is not null and
           wrk1.cmpny_cf_cd is not null and wrk1.state is not null							
							THEN cast((count(distinct wrk1.sbscrbr_id , wrk1.mbr_rltnshp_cd) + stg."""+nbrpoa_gtsgp+""") as int)
							WHEN wrk1.cmpny_cf_cd IS NULL AND wrk1.state IS NULL THEN stg."""+nbrpoa_gtsgp+"""
							end as  """+nbrpoa_gtsgp+"""
							  
							  
							from 
							( select wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.sbscrbr_id, wrk.mbr_rltnshp_cd
							from termedlivesPOAG_wrk wrk
							where  wrk.naic_lob = 'TOTAL SMALL GROUP CBE'
							and (  wrk.grndfthr_ind_cd = 'YES'   or   wrk.hcr_cmplynt_cd <> 'Y' or  wrk.hcr_cmplynt_cd is null   )  
							and  wrk.in_exchange is null
							group by wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.sbscrbr_id, wrk.mbr_rltnshp_cd
							)wrk1
							full outer join facets_stg stg
							on wrk1.cmpny_cf_cd = stg.anthem_cmpny_cd
							and wrk1.state = stg.state


							group by  
							wrk1.health_year ,
							wrk1.cmpny_cf_cd ,
							wrk1.state,
							stg.anthem_cmpny_cd,
							stg.state,
							stg."""+nbrpoa_gtsgp+""",
							stg.health_year

							"""
							)


					val ipbsgpTotgtLgpgtsgp = ipbsgpTotgtLgpData.alias("bsg").join(nbrpoa_termed_lives_gtsgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
							col(nbrpoa_gtlgb), col(nbrpoa_gtsgp))

					val ipbsgpTotgtLgpgtsgpData = ipbsgpTotgtLgpgtsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_gtlgb, nbrpoa_gtsgp)

					val nbrpoa_gtip = "nbrpoa_" + typeOfData + "_gtip"


					val nbrpoa_termed_lives_gtip = spark.sql("""
					  
              select 

   case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.health_year
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.health_year
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.health_year
        end as  health_year ,      
         
   case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.anthem_cmpny_cd 
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.cmpny_cf_cd 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.cmpny_cf_cd
        end as  cmpny_cf_cd ,
        
    case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.state
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.state 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.state
        end as  state ,  
        
							CASE WHEN stg.anthem_cmpny_cd is null and stg.state is null THEN cast((count(distinct wrk1.sbscrbr_id, wrk1.mbr_rltnshp_cd)) as int)
							when stg.anthem_cmpny_cd is not null and stg.state is not null and
           wrk1.cmpny_cf_cd is not null and wrk1.state is not null
							THEN cast((count(distinct wrk1.sbscrbr_id , wrk1.mbr_rltnshp_cd) + stg."""+nbrpoa_gtip+""") as int)
							WHEN wrk1.cmpny_cf_cd IS NULL
                AND wrk1.state IS NULL THEN stg."""+nbrpoa_gtip+"""
							end as  """+nbrpoa_gtip+"""
							  
							from 
							( select wrk.health_year, wrk.cmpny_cf_cd , wrk.state,wrk.sbscrbr_id, wrk.mbr_rltnshp_cd
							from termedlivesPOA_wrk wrk
							where  wrk.naic_lob = 'TOTAL INDIVIDUAL CBE'
							and (  wrk.grndfthr_ind_cd = 'YES'   or   wrk.hcr_cmplynt_cd <> 'Y'  or  wrk.hcr_cmplynt_cd is null    )
							and  wrk.in_exchange is null
							group by wrk.health_year, wrk.cmpny_cf_cd , wrk.state,wrk.sbscrbr_id, wrk.mbr_rltnshp_cd
							)wrk1
							full outer join facets_stg stg
							on wrk1.cmpny_cf_cd = stg.anthem_cmpny_cd
							and wrk1.state = stg.state
							
							group by  wrk1.health_year ,wrk1.cmpny_cf_cd ,wrk1.state,
							stg.anthem_cmpny_cd,
							stg.state,
							stg."""+nbrpoa_gtip+""",
							stg.health_year 

							"""
							)
					val ipbsgpTotgtLgpgtsgpip = ipbsgpTotgtLgpgtsgpData.alias("bsg").join(nbrpoa_termed_lives_gtip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
							col(nbrpoa_gtlgb), col(nbrpoa_gtsgp), col(nbrpoa_gtip))

					val ipbsgpTotgtLgpgtsgpipData = ipbsgpTotgtLgpgtsgpip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_gtlgb, nbrpoa_gtsgp,
							nbrpoa_gtip)
					val nbrpoa_total_gtip = "nbrpoa_" + typeOfData + "_total_gtip"
					val getTotal_gtip = nbrpoa_termed_lives_gtlgp.union(nbrpoa_termed_lives_gtsgp.union(nbrpoa_termed_lives_gtip))
					.select($"health_year", $"cmpny_cf_cd", $"state", col(nbrpoa_gtlgb))

					val mbrmpoa_renewed_total_ip = getTotal_gtip.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(nbrpoa_gtlgb).alias(nbrpoa_total_gtip))

					val ipbsgpTotgtLgpgtsgpipTot = ipbsgpTotgtLgpgtsgpipData.alias("bsg").join(mbrmpoa_renewed_total_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
							col(nbrpoa_gtlgb), col(nbrpoa_gtsgp), col(nbrpoa_gtip), col(nbrpoa_total_gtip))

					val ipbsgpTotgtLgpgtsgpipTotData = ipbsgpTotgtLgpgtsgpipTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_gtlgb, nbrpoa_gtsgp,
							nbrpoa_gtip, nbrpoa_total_gtip)

					val nbrpoa_catastrophic = "nbrpoa_" + typeOfData + "_catastrophic"
					val nbrpoa_termed_nonpay_lives_catastrophic = naic_mcas_hlthex_poa_wrk
					.filter(naic_mcas_hlthex_poa_wrk("naic_prod_desc").like("%CATASTROPHIC%") &&
							naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"mbr_rltnshp_cd").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_catastrophic))

					val ipbsgpCat = ipbsgpTotgtLgpgtsgpipTotData.alias("bsg").join(nbrpoa_termed_nonpay_lives_catastrophic.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
							col(nbrpoa_gtlgb), col(nbrpoa_gtsgp), col(nbrpoa_gtip), col(nbrpoa_total_gtip), col(nbrpoa_catastrophic))

					val ipbsgpCatData = ipbsgpCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp,
							nbrpoa_gtlgb, nbrpoa_gtsgp,
							nbrpoa_gtip, nbrpoa_total_gtip, nbrpoa_catastrophic)

					val nbrpoa_mmcare = "nbrpoa_" + typeOfData + "_lgp_mmcare"


					val nbrpoa_termed_nonpay_lives_mmcare = spark.sql("""
               select 
     
              case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.health_year
                   when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.health_year
                   when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
                   and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.health_year
                   end as  health_year ,      
         
             case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.anthem_cmpny_cd 
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.cmpny_cf_cd 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.cmpny_cf_cd
        end as  cmpny_cf_cd ,
    
                case when wrk1.cmpny_cf_cd is null and wrk1.state is null then stg.state
        when stg.anthem_cmpny_cd is null and stg.state is null then wrk1.state 
        when wrk1.cmpny_cf_cd is not null and wrk1.state is not null
            and stg.anthem_cmpny_cd is not null and stg.state is not null then wrk1.state
       end as  state ,     
        
       CASE
           WHEN stg.anthem_cmpny_cd IS NULL
                AND stg.state IS NULL 
      THEN cast((count(DISTINCT wrk1.sbscrbr_id, wrk1.mbr_rltnshp_cd)) as int)
           WHEN stg.anthem_cmpny_cd IS NOT NULL AND stg.state IS NOT NULL  and
           wrk1.cmpny_cf_cd is not null and wrk1.state is not null
      THEN cast((count(DISTINCT wrk1.sbscrbr_id, wrk1.mbr_rltnshp_cd) + stg."""+nbrpoa_mmcare+""") as int) 
            WHEN wrk1.cmpny_cf_cd IS NULL
                AND wrk1.state IS NULL THEN stg."""+nbrpoa_mmcare+"""
       END AS """+nbrpoa_mmcare+""" 
from 
( select 
  wrk.health_year,
   wrk.cmpny_cf_cd ,
    wrk.state, 
    wrk.sbscrbr_id,
     wrk.mbr_rltnshp_cd
from 
termedlivesPOAG_wrk wrk
where  
wrk.naic_lob in ('LARGE GROUP CBE EXCLUDING MEDICARE'  , 'TOTAL NATIONAL CBE' ) 
and (  wrk.grndfthr_ind_cd <> 'YES'  or  wrk.grndfthr_ind_cd is null )
and  wrk.mbu_cf_cd not in ("""+mbu_cf_cdvals_sql+""")
and  wrk.in_exchange is null
group by wrk.health_year, wrk.cmpny_cf_cd , wrk.state, wrk.sbscrbr_id, wrk.mbr_rltnshp_cd
) wrk1
full outer join facets_stg stg
on wrk1.cmpny_cf_cd = stg.anthem_cmpny_cd
and wrk1.state = stg.state

group by wrk1.cmpny_cf_cd ,wrk1.state, stg.anthem_cmpny_cd,   stg.state,
         stg."""+nbrpoa_mmcare+""", wrk1.health_year, stg.health_year


							"""
							)
							println ("############ nbrpoa_" + typeOfData + "_lgp_mmcare")
							nbrpoa_termed_nonpay_lives_mmcare.collect()
							nbrpoa_termed_nonpay_lives_mmcare.show()
							
					val ipbsgpcMmcare = ipbsgpCatData.alias("bsg").join(nbrpoa_termed_nonpay_lives_mmcare.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
							col(nbrpoa_gtlgb), col(nbrpoa_gtsgp), col(nbrpoa_gtip), col(nbrpoa_total_gtip), col(nbrpoa_catastrophic),
							col(nbrpoa_mmcare))

					val ipbsgpcMmcareData = ipbsgpcMmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp,
							nbrpoa_gtlgb, nbrpoa_gtsgp,
							nbrpoa_gtip, nbrpoa_total_gtip, nbrpoa_catastrophic,
							nbrpoa_mmcare)

					val nbrpoa_stucvg = "nbrpoa_" + typeOfData + "_stucvg"
					val nbrpoa_termed_nonpay_stucvg = naic_mcas_hlthex_poag_wrk.filter(naic_mcas_hlthex_poag_wrk("naic_lob").isin(naic_lob_lgp:_*) &&
							naic_mcas_hlthex_poag_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*) &&
							naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
					.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"SBSCRBR_ID", $"mbr_rltnshp_cd").agg((lit(1)).alias("Count_vl"))
					.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum($"Count_vl").alias(nbrpoa_stucvg))

					val ipbsgpcMmcStucvg = ipbsgpcMmcareData.alias("bsg").join(nbrpoa_termed_nonpay_stucvg.alias("plt"), $"bsg.health_year" === $"plt.health_year"
					&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
					.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
							$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
							$"plt.state".alias("s_state"),
							col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
							col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp),
							col(nbrpoa_gtlgb), col(nbrpoa_gtsgp), col(nbrpoa_gtip), col(nbrpoa_total_gtip), col(nbrpoa_catastrophic),
							col(nbrpoa_mmcare), col(nbrpoa_stucvg))

					val finalData = ipbsgpcMmcStucvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
					.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
					.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
					//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
					.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
							nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_gtlgb, nbrpoa_gtsgp,
							nbrpoa_gtip, nbrpoa_total_gtip, nbrpoa_catastrophic,
							nbrpoa_mmcare, nbrpoa_stucvg)


				
					finalData
			}


			def getInitialData(naic_mcas_hlthex_poa_wrk: DataFrame,naic_mcas_hlthex_poag_wrk:DataFrame, typeOfData: String): DataFrame = {

					val nbrpoa_bronze_ip = "nbrpoa_" + typeOfData + "_bronze_ip"  
							val nbrpoa_issued_bronze_ip = naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
									(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("04") &&
									naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_bronze_ip))



							val nbrpoa_silver_ip = "nbrpoa_" + typeOfData + "_silver_ip"
							val nbrpoa_issued_silver_ip = naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
									(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("03") &&
									naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_silver_ip))


							val brSil = nbrpoa_issued_bronze_ip.alias("bronze").join(nbrpoa_issued_silver_ip.alias("silver"), $"bronze.health_year" === $"silver.health_year"
							&& $"bronze.cmpny_cf_cd" === $"silver.cmpny_cf_cd" && $"bronze.state" === $"silver.state", "outer")
							.select($"bronze.health_year".alias("b_year"), $"silver.health_year".alias("s_year"),
									$"bronze.cmpny_cf_cd".alias("b_cmpny"), $"silver.cmpny_cf_cd".alias("s_cmpny"), $"bronze.state".alias("b_state"),
									$"silver.state".alias("s_state"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip))

							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip)


							val nbrpoa_gold_ip = "nbrpoa_" + typeOfData + "_gold_ip"
							val nbrpoa_issued_gold_ip = naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
									(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("02") &&
									naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_gold_ip))


							val bsGold = brSilData.alias("brsil").join(nbrpoa_issued_gold_ip.alias("gold"), $"brsil.health_year" === $"gold.health_year"
							&& $"brsil.cmpny_cf_cd" === $"gold.cmpny_cf_cd" && $"brsil.state" === $"gold.state", "outer")
							.select($"brsil.health_year".alias("b_year"), $"gold.health_year".alias("s_year"),
									$"brsil.cmpny_cf_cd".alias("b_cmpny"), $"gold.cmpny_cf_cd".alias("s_cmpny"), $"brsil.state".alias("b_state"),
									$"gold.state".alias("s_state"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip))


							val bsGoldData = bsGold.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip)



							val nbrpoa_platinum_ip = "nbrpoa_" + typeOfData + "_platinum_ip"
							val nbrpoa_issued_platinum_ip = naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
									(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("01") &&
									naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_platinum_ip))

							val bsgPlt = bsGoldData.alias("bsg").join(nbrpoa_issued_platinum_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip))

							val bsgPltinumData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip)

							val nbrpoa_total_ip = "nbrpoa_" + typeOfData + "_total_ip"
							val getTotal_ip = nbrpoa_issued_bronze_ip.union(nbrpoa_issued_silver_ip.union(nbrpoa_issued_gold_ip.union(nbrpoa_issued_platinum_ip)))
							.select($"health_year", $"cmpny_cf_cd", $"state", col(nbrpoa_bronze_ip))

							val nbrpoa_issued_total_ip = getTotal_ip.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col(nbrpoa_bronze_ip)).alias(nbrpoa_total_ip))

							val bsgpTot = bsgPltinumData.alias("bsg").join(nbrpoa_issued_total_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip))

							val bsgPTotData = bsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip)

							val nbrpoa_gtlgp = "nbrpoa_" + typeOfData + "_gtlgp"

							val nbrpoa_issued_gtlgp = naic_mcas_hlthex_poag_wrk.filter(naic_mcas_hlthex_poag_wrk("naic_lob").isin(naic_lob_lgp:_*) &&
									naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").equalTo("YES") &&
									naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state",$"mbrshp_sor_cd",$"src_grp_nbr").agg((lit(1)).alias("count_Val")).groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias(nbrpoa_gtlgp))

							val ipgtlgp = bsgPTotData.alias("bsg").join(nbrpoa_issued_gtlgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp))

							val ipgtlgpData = ipgtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_gtlgp)

							val nbrpoa_gtip = "nbrpoa_" + typeOfData + "_gtip"
							val nbrpoa_issued_gtip = naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
									(naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").equalTo("YES") || naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").notEqual("Y")|| naic_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").isNull) &&
									naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_gtip))

							val ipgtlgpip = ipgtlgpData.alias("bsg").join(nbrpoa_issued_gtip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp), col(nbrpoa_gtip))

							val ipgtlgpipData = ipgtlgpip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_gtlgp, nbrpoa_gtip)

							val nbrpoa_catastrophic = "nbrpoa_" + typeOfData + "_catastrophic"
							val nbrpoa_issued_catastrophic = naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_prod_desc").like("%CATASTROPHIC%") &&
									naic_mcas_hlthex_poa_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_catastrophic))

							val bsgptCat = ipgtlgpipData.alias("bsg").join(nbrpoa_issued_catastrophic.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp), col(nbrpoa_gtip), col(nbrpoa_catastrophic))

							val bsgptCatData = bsgptCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_gtlgp, nbrpoa_gtip, nbrpoa_catastrophic)

							val nbrpoa_lgp_mmcare = "nbrpoa_" + typeOfData + "_lgp_mmcare"

							val nbrpoa_issued_lgp_mmcare = naic_mcas_hlthex_poag_wrk.filter(naic_mcas_hlthex_poag_wrk("naic_lob").isin(naic_lob_lgp:_*) &&
									(naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
									(!naic_mcas_hlthex_poag_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*)) &&
									naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state",$"mbrshp_sor_cd",$"src_grp_nbr").agg((lit(1)).alias("count_Val")).groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias(nbrpoa_lgp_mmcare))

							val bsgptcMmcare = bsgptCatData.alias("bsg").join(nbrpoa_issued_lgp_mmcare.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp), col(nbrpoa_gtip), col(nbrpoa_catastrophic), col(nbrpoa_lgp_mmcare))

							val bsgptcMmcareData = bsgptcMmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_gtlgp, nbrpoa_gtip, nbrpoa_catastrophic, nbrpoa_lgp_mmcare)

							val nbrpoa_stucvg = "nbrpoa_" + typeOfData + "_stucvg"

							val nbrpoa_issued_stucvg = naic_mcas_hlthex_poag_wrk.filter(naic_mcas_hlthex_poag_wrk("naic_lob").isin(naic_lob_lgp:_*) &&
									naic_mcas_hlthex_poag_wrk("mbu_cf_cd").isin(mbu_cf_cdvals: _*) &&
									naic_mcas_hlthex_poag_wrk("in_exchange").isNull)
							.groupBy($"health_year", $"cmpny_cf_cd", $"state",$"mbrshp_sor_cd",$"src_grp_nbr").agg((lit(1)).alias("count_Val")).groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias(nbrpoa_stucvg))

							val bsgptcmmcStuvg = bsgptcMmcareData.alias("bsg").join(nbrpoa_issued_stucvg.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"),
									col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
									col(nbrpoa_total_ip), col(nbrpoa_gtlgp), col(nbrpoa_gtip), col(nbrpoa_catastrophic), col(nbrpoa_lgp_mmcare), col(nbrpoa_stucvg))

							val finalData = bsgptcmmcStuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
									nbrpoa_total_ip, nbrpoa_gtlgp, nbrpoa_gtip, nbrpoa_catastrophic, nbrpoa_lgp_mmcare, nbrpoa_stucvg)

							finalData

			}

			def getStageData(issueFinalDf: DataFrame, renewedFinalDf: DataFrame, mmissuedFinalDf: DataFrame, mmrenewedFinalDf: DataFrame, termedFinalDf: DataFrame, termed_nonpayFinalDf: DataFrame,
					termed_livesFinalDf: DataFrame, termed_nonpay_livesFinalDf: DataFrame): DataFrame = {

							// var master_tbl = readDataFromHive(dbsg+"."+"naic_mcas_hlthoex_poa_stg_temp").repartition(1)

							val issued_renewed = issueFinalDf.alias("parent").join(renewedFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
											$"child.state".alias("s_state"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
											$"nbrpoa_issued_total_ip", $"nbrpoa_issued_gtlgp", $"nbrpoa_issued_gtip", $"nbrpoa_issued_catastrophic",
											$"nbrpoa_issued_lgp_mmcare", $"nbrpoa_issued_stucvg",
											$"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
											$"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_gtlgp", $"nbrpoa_renewed_gtip", $"nbrpoa_renewed_catastrophic",
											$"nbrpoa_renewed_lgp_mmcare", $"nbrpoa_renewed_stucvg")

									val issued_RennewedData = issued_renewed.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
									//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
									.select("health_year", "cmpny_cf_cd", "state", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
											"nbrpoa_issued_total_ip", "nbrpoa_issued_gtlgp", "nbrpoa_issued_gtip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_lgp_mmcare",
											"nbrpoa_issued_stucvg",
											"nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
											"nbrpoa_renewed_total_ip", "nbrpoa_renewed_gtlgp", "nbrpoa_renewed_gtip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_lgp_mmcare",
											"nbrpoa_renewed_stucvg")

									val mmissued_master = issued_RennewedData.alias("parent").join(mmissuedFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
											$"child.state".alias("s_state"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
											$"nbrpoa_issued_total_ip", $"nbrpoa_issued_gtlgp", $"nbrpoa_issued_gtip", $"nbrpoa_issued_catastrophic",
											$"nbrpoa_issued_lgp_mmcare", $"nbrpoa_issued_stucvg",
											$"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
											$"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_gtlgp", $"nbrpoa_renewed_gtip", $"nbrpoa_renewed_catastrophic",
											$"nbrpoa_renewed_lgp_mmcare", $"nbrpoa_renewed_stucvg", //24
											$"mbrmpoa_issued_bronze_ip", $"mbrmpoa_issued_silver_ip", $"mbrmpoa_issued_gold_ip",
											$"mbrmpoa_issued_platinum_ip", $"mbrmpoa_issued_total_ip",
											$"mbrmpoa_issued_bronze_sgp", $"mbrmpoa_issued_silver_sgp", $"mbrmpoa_issued_gold_sgp", $"mbrmpoa_issued_platinum_sgp",
											$"mbrmpoa_issued_total_sgp", $"mbrmpoa_issued_gtlgp", $"mbrmpoa_issued_gtsgp", $"mbrmpoa_issued_gtip", $"mbrmpoa_issued_total_gtip",
											$"mbrmpoa_issued_catastrophic", $"mbrmpoa_issued_lgp_mmcare", $"mbrmpoa_issued_stucvg")

									val irmmi = mmissued_master.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
									//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
									.select("health_year", "cmpny_cf_cd", "state", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
											"nbrpoa_issued_total_ip", "nbrpoa_issued_gtlgp", "nbrpoa_issued_gtip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_lgp_mmcare",
											"nbrpoa_issued_stucvg",
											"nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
											"nbrpoa_renewed_total_ip", "nbrpoa_renewed_gtlgp", "nbrpoa_renewed_gtip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_lgp_mmcare",
											"nbrpoa_renewed_stucvg", //24
											"mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
											"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
											"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp", "mbrmpoa_issued_gtsgp", "mbrmpoa_issued_gtip", "mbrmpoa_issued_total_gtip",
											"mbrmpoa_issued_catastrophic", "mbrmpoa_issued_lgp_mmcare", "mbrmpoa_issued_stucvg") //41

									val mmrenewed_master = irmmi.alias("parent").join(mmrenewedFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
											$"child.state".alias("s_state"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
											$"nbrpoa_issued_total_ip", $"nbrpoa_issued_gtlgp", $"nbrpoa_issued_gtip", $"nbrpoa_issued_catastrophic",
											$"nbrpoa_issued_lgp_mmcare", $"nbrpoa_issued_stucvg",
											$"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
											$"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_gtlgp", $"nbrpoa_renewed_gtip", $"nbrpoa_renewed_catastrophic",
											$"nbrpoa_renewed_lgp_mmcare", $"nbrpoa_renewed_stucvg", //24
											$"mbrmpoa_issued_bronze_ip", $"mbrmpoa_issued_silver_ip", $"mbrmpoa_issued_gold_ip",
											$"mbrmpoa_issued_platinum_ip", $"mbrmpoa_issued_total_ip",
											$"mbrmpoa_issued_bronze_sgp", $"mbrmpoa_issued_silver_sgp", $"mbrmpoa_issued_gold_sgp", $"mbrmpoa_issued_platinum_sgp",
											$"mbrmpoa_issued_total_sgp", $"mbrmpoa_issued_gtlgp", $"mbrmpoa_issued_gtsgp", $"mbrmpoa_issued_gtip", $"mbrmpoa_issued_total_gtip",
											$"mbrmpoa_issued_catastrophic", $"mbrmpoa_issued_lgp_mmcare", $"mbrmpoa_issued_stucvg",
											$"mbrmpoa_renewed_bronze_ip", $"mbrmpoa_renewed_silver_ip", $"mbrmpoa_renewed_gold_ip",
											$"mbrmpoa_renewed_platinum_ip", $"mbrmpoa_renewed_total_ip", $"mbrmpoa_renewed_bronze_sgp", $"mbrmpoa_renewed_silver_sgp", $"mbrmpoa_renewed_gold_sgp", $"mbrmpoa_renewed_platinum_sgp",
											$"mbrmpoa_renewed_total_sgp", $"mbrmpoa_renewed_gtlgp", $"mbrmpoa_renewed_gtsgp", $"mbrmpoa_renewed_gtip", $"mbrmpoa_renewed_total_gtip",
											$"mbrmpoa_renewed_catastrophic", $"mbrmpoa_renewed_lgp_mmcare", $"mbrmpoa_renewed_stucvg")

									val irmmimmr = mmrenewed_master.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
									//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
									.select("health_year", "cmpny_cf_cd", "state", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
											"nbrpoa_issued_total_ip", "nbrpoa_issued_gtlgp", "nbrpoa_issued_gtip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_lgp_mmcare",
											"nbrpoa_issued_stucvg",
											"nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
											"nbrpoa_renewed_total_ip", "nbrpoa_renewed_gtlgp", "nbrpoa_renewed_gtip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_lgp_mmcare",
											"nbrpoa_renewed_stucvg", //24
											"mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
											"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
											"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp", "mbrmpoa_issued_gtsgp", "mbrmpoa_issued_gtip", "mbrmpoa_issued_total_gtip",
											"mbrmpoa_issued_catastrophic", "mbrmpoa_issued_lgp_mmcare", "mbrmpoa_issued_stucvg", //41
											"mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp",
											"mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp",
											"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip", "mbrmpoa_renewed_total_gtip",
											"mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_lgp_mmcare", "mbrmpoa_renewed_stucvg") //58
									val termed_master = irmmimmr.alias("parent").join(termedFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
											$"child.state".alias("s_state"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
											$"nbrpoa_issued_total_ip", $"nbrpoa_issued_gtlgp", $"nbrpoa_issued_gtip", $"nbrpoa_issued_catastrophic",
											$"nbrpoa_issued_lgp_mmcare", $"nbrpoa_issued_stucvg",
											$"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
											$"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_gtlgp", $"nbrpoa_renewed_gtip", $"nbrpoa_renewed_catastrophic",
											$"nbrpoa_renewed_lgp_mmcare", $"nbrpoa_renewed_stucvg", //24
											$"mbrmpoa_issued_bronze_ip", $"mbrmpoa_issued_silver_ip", $"mbrmpoa_issued_gold_ip",
											$"mbrmpoa_issued_platinum_ip", $"mbrmpoa_issued_total_ip",
											$"mbrmpoa_issued_bronze_sgp", $"mbrmpoa_issued_silver_sgp", $"mbrmpoa_issued_gold_sgp", $"mbrmpoa_issued_platinum_sgp",
											$"mbrmpoa_issued_total_sgp", $"mbrmpoa_issued_gtlgp", $"mbrmpoa_issued_gtsgp", $"mbrmpoa_issued_gtip", $"mbrmpoa_issued_total_gtip",
											$"mbrmpoa_issued_catastrophic", $"mbrmpoa_issued_lgp_mmcare", $"mbrmpoa_issued_stucvg",
											$"mbrmpoa_renewed_bronze_ip", $"mbrmpoa_renewed_silver_ip", $"mbrmpoa_renewed_gold_ip",
											$"mbrmpoa_renewed_platinum_ip", $"mbrmpoa_renewed_total_ip", $"mbrmpoa_renewed_bronze_sgp", $"mbrmpoa_renewed_silver_sgp", $"mbrmpoa_renewed_gold_sgp", $"mbrmpoa_renewed_platinum_sgp",
											$"mbrmpoa_renewed_total_sgp", $"mbrmpoa_renewed_gtlgp", $"mbrmpoa_renewed_gtsgp", $"mbrmpoa_renewed_gtip", $"mbrmpoa_renewed_total_gtip",
											$"mbrmpoa_renewed_catastrophic", $"mbrmpoa_renewed_lgp_mmcare", $"mbrmpoa_renewed_stucvg",
											$"nbrpoa_termed_bronze_ip", $"nbrpoa_termed_silver_ip", $"nbrpoa_termed_gold_ip", $"nbrpoa_termed_platinum_ip",
											$"nbrpoa_termed_total_ip", $"nbrpoa_termed_gtlgp", $"nbrpoa_termed_gtip", $"nbrpoa_termed_catastrophic",
											$"nbrpoa_termed_lgp_mmcare", $"nbrpoa_termed_stucvg") //68

									val irmmimmrterm = termed_master.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
									//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
									.select("health_year", "cmpny_cf_cd", "state", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
											"nbrpoa_issued_total_ip", "nbrpoa_issued_gtlgp", "nbrpoa_issued_gtip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_lgp_mmcare",
											"nbrpoa_issued_stucvg",
											"nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
											"nbrpoa_renewed_total_ip", "nbrpoa_renewed_gtlgp", "nbrpoa_renewed_gtip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_lgp_mmcare",
											"nbrpoa_renewed_stucvg", //24
											"mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
											"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
											"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp", "mbrmpoa_issued_gtsgp", "mbrmpoa_issued_gtip", "mbrmpoa_issued_total_gtip",
											"mbrmpoa_issued_catastrophic", "mbrmpoa_issued_lgp_mmcare", "mbrmpoa_issued_stucvg", //41
											"mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp",
											"mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp",
											"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip", "mbrmpoa_renewed_total_gtip",
											"mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_lgp_mmcare", "mbrmpoa_renewed_stucvg", //58
											"nbrpoa_termed_bronze_ip", "nbrpoa_termed_silver_ip", "nbrpoa_termed_gold_ip", "nbrpoa_termed_platinum_ip",
											"nbrpoa_termed_total_ip", "nbrpoa_termed_gtlgp", "nbrpoa_termed_gtip", "nbrpoa_termed_catastrophic",
											"nbrpoa_termed_lgp_mmcare", "nbrpoa_termed_stucvg") //68
									val termednonpay_master = irmmimmrterm.alias("parent").join(termed_nonpayFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
											$"child.state".alias("s_state"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
											$"nbrpoa_issued_total_ip", $"nbrpoa_issued_gtlgp", $"nbrpoa_issued_gtip", $"nbrpoa_issued_catastrophic",
											$"nbrpoa_issued_lgp_mmcare", $"nbrpoa_issued_stucvg",
											$"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
											$"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_gtlgp", $"nbrpoa_renewed_gtip", $"nbrpoa_renewed_catastrophic",
											$"nbrpoa_renewed_lgp_mmcare", $"nbrpoa_renewed_stucvg", //24
											$"mbrmpoa_issued_bronze_ip", $"mbrmpoa_issued_silver_ip", $"mbrmpoa_issued_gold_ip",
											$"mbrmpoa_issued_platinum_ip", $"mbrmpoa_issued_total_ip",
											$"mbrmpoa_issued_bronze_sgp", $"mbrmpoa_issued_silver_sgp", $"mbrmpoa_issued_gold_sgp", $"mbrmpoa_issued_platinum_sgp",
											$"mbrmpoa_issued_total_sgp", $"mbrmpoa_issued_gtlgp", $"mbrmpoa_issued_gtsgp", $"mbrmpoa_issued_gtip", $"mbrmpoa_issued_total_gtip",
											$"mbrmpoa_issued_catastrophic", $"mbrmpoa_issued_lgp_mmcare", $"mbrmpoa_issued_stucvg",
											$"mbrmpoa_renewed_bronze_ip", $"mbrmpoa_renewed_silver_ip", $"mbrmpoa_renewed_gold_ip",
											$"mbrmpoa_renewed_platinum_ip", $"mbrmpoa_renewed_total_ip", $"mbrmpoa_renewed_bronze_sgp", $"mbrmpoa_renewed_silver_sgp", $"mbrmpoa_renewed_gold_sgp", $"mbrmpoa_renewed_platinum_sgp",
											$"mbrmpoa_renewed_total_sgp", $"mbrmpoa_renewed_gtlgp", $"mbrmpoa_renewed_gtsgp", $"mbrmpoa_renewed_gtip", $"mbrmpoa_renewed_total_gtip",
											$"mbrmpoa_renewed_catastrophic", $"mbrmpoa_renewed_lgp_mmcare", $"mbrmpoa_renewed_stucvg",
											$"nbrpoa_termed_bronze_ip", $"nbrpoa_termed_silver_ip", $"nbrpoa_termed_gold_ip", $"nbrpoa_termed_platinum_ip",
											$"nbrpoa_termed_total_ip", $"nbrpoa_termed_gtlgp", $"nbrpoa_termed_gtip", $"nbrpoa_termed_catastrophic",
											$"nbrpoa_termed_lgp_mmcare", $"nbrpoa_termed_stucvg", //68
											$"nbrpoa_termed_nonpay_bronze_ip", $"nbrpoa_termed_nonpay_silver_ip", $"nbrpoa_termed_nonpay_gold_ip", $"nbrpoa_termed_nonpay_platinum_ip",
											$"nbrpoa_termed_nonpay_total_ip",
											$"nbrpoa_termed_nonpay_gtlgp", $"nbrpoa_termed_nonpay_gtip", $"nbrpoa_termed_nonpay_catastrophic",
											$"nbrpoa_termed_nonpay_lgp_mmcare", $"nbrpoa_termed_nonpay_stucvg") //78

									val term_nonpay_Data = termednonpay_master.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
									//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
									.select("health_year", "cmpny_cf_cd", "state", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
											"nbrpoa_issued_total_ip", "nbrpoa_issued_gtlgp", "nbrpoa_issued_gtip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_lgp_mmcare",
											"nbrpoa_issued_stucvg",
											"nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
											"nbrpoa_renewed_total_ip", "nbrpoa_renewed_gtlgp", "nbrpoa_renewed_gtip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_lgp_mmcare",
											"nbrpoa_renewed_stucvg", //24
											"mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
											"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
											"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp", "mbrmpoa_issued_gtsgp", "mbrmpoa_issued_gtip", "mbrmpoa_issued_total_gtip",
											"mbrmpoa_issued_catastrophic", "mbrmpoa_issued_lgp_mmcare", "mbrmpoa_issued_stucvg", //41
											"mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp",
											"mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp",
											"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip", "mbrmpoa_renewed_total_gtip",
											"mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_lgp_mmcare", "mbrmpoa_renewed_stucvg", //58
											"nbrpoa_termed_bronze_ip", "nbrpoa_termed_silver_ip", "nbrpoa_termed_gold_ip", "nbrpoa_termed_platinum_ip",
											"nbrpoa_termed_total_ip", "nbrpoa_termed_gtlgp", "nbrpoa_termed_gtip", "nbrpoa_termed_catastrophic",
											"nbrpoa_termed_lgp_mmcare", "nbrpoa_termed_stucvg",
											"nbrpoa_termed_nonpay_bronze_ip", "nbrpoa_termed_nonpay_silver_ip", "nbrpoa_termed_nonpay_gold_ip", "nbrpoa_termed_nonpay_platinum_ip",
											"nbrpoa_termed_nonpay_total_ip", "nbrpoa_termed_nonpay_gtlgp", "nbrpoa_termed_nonpay_gtip", "nbrpoa_termed_nonpay_catastrophic",
											"nbrpoa_termed_nonpay_lgp_mmcare", "nbrpoa_termed_nonpay_stucvg") //78)//68
									val termedLives_master = term_nonpay_Data.alias("parent").join(termed_livesFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
											$"child.state".alias("s_state"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
											$"nbrpoa_issued_total_ip", $"nbrpoa_issued_gtlgp", $"nbrpoa_issued_gtip", $"nbrpoa_issued_catastrophic",
											$"nbrpoa_issued_lgp_mmcare", $"nbrpoa_issued_stucvg",
											$"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
											$"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_gtlgp", $"nbrpoa_renewed_gtip", $"nbrpoa_renewed_catastrophic",
											$"nbrpoa_renewed_lgp_mmcare", $"nbrpoa_renewed_stucvg", //24
											$"mbrmpoa_issued_bronze_ip", $"mbrmpoa_issued_silver_ip", $"mbrmpoa_issued_gold_ip",
											$"mbrmpoa_issued_platinum_ip", $"mbrmpoa_issued_total_ip",
											$"mbrmpoa_issued_bronze_sgp", $"mbrmpoa_issued_silver_sgp", $"mbrmpoa_issued_gold_sgp", $"mbrmpoa_issued_platinum_sgp",
											$"mbrmpoa_issued_total_sgp", $"mbrmpoa_issued_gtlgp", $"mbrmpoa_issued_gtsgp", $"mbrmpoa_issued_gtip", $"mbrmpoa_issued_total_gtip",
											$"mbrmpoa_issued_catastrophic", $"mbrmpoa_issued_lgp_mmcare", $"mbrmpoa_issued_stucvg",
											$"mbrmpoa_renewed_bronze_ip", $"mbrmpoa_renewed_silver_ip", $"mbrmpoa_renewed_gold_ip",
											$"mbrmpoa_renewed_platinum_ip", $"mbrmpoa_renewed_total_ip", $"mbrmpoa_renewed_bronze_sgp", $"mbrmpoa_renewed_silver_sgp", $"mbrmpoa_renewed_gold_sgp", $"mbrmpoa_renewed_platinum_sgp",
											$"mbrmpoa_renewed_total_sgp", $"mbrmpoa_renewed_gtlgp", $"mbrmpoa_renewed_gtsgp", $"mbrmpoa_renewed_gtip", $"mbrmpoa_renewed_total_gtip",
											$"mbrmpoa_renewed_catastrophic", $"mbrmpoa_renewed_lgp_mmcare", $"mbrmpoa_renewed_stucvg",
											$"nbrpoa_termed_bronze_ip", $"nbrpoa_termed_silver_ip", $"nbrpoa_termed_gold_ip", $"nbrpoa_termed_platinum_ip",
											$"nbrpoa_termed_total_ip", $"nbrpoa_termed_gtlgp", $"nbrpoa_termed_gtip", $"nbrpoa_termed_catastrophic",
											$"nbrpoa_termed_lgp_mmcare", $"nbrpoa_termed_stucvg", //68
											$"nbrpoa_termed_nonpay_bronze_ip", $"nbrpoa_termed_nonpay_silver_ip", $"nbrpoa_termed_nonpay_gold_ip", $"nbrpoa_termed_nonpay_platinum_ip",
											$"nbrpoa_termed_nonpay_total_ip",
											$"nbrpoa_termed_nonpay_gtlgp", $"nbrpoa_termed_nonpay_gtip", $"nbrpoa_termed_nonpay_catastrophic",
											$"nbrpoa_termed_nonpay_lgp_mmcare", $"nbrpoa_termed_nonpay_stucvg", //78
											$"nbrpoa_termed_lives_bronze_ip", $"nbrpoa_termed_lives_silver_ip", $"nbrpoa_termed_lives_gold_ip", $"nbrpoa_termed_lives_platinum_ip",
											$"nbrpoa_termed_lives_total_ip", $"nbrpoa_termed_lives_bronze_sgp", $"nbrpoa_termed_lives_silver_sgp", $"nbrpoa_termed_lives_gold_sgp", $"nbrpoa_termed_lives_platinum_sgp", $"nbrpoa_termed_lives_total_sgp",
											$"nbrpoa_termed_lives_gtlgp", $"nbrpoa_termed_lives_gtsgp", $"nbrpoa_termed_lives_gtip", $"nbrpoa_termed_lives_total_gtip", $"nbrpoa_termed_lives_catastrophic", $"nbrpoa_termed_lives_lgp_mmcare",
											$"nbrpoa_termed_lives_stucvg")

									val termed_lives_Data = termedLives_master.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
									//.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
									.select("health_year", "cmpny_cf_cd", "state", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
											"nbrpoa_issued_total_ip", "nbrpoa_issued_gtlgp", "nbrpoa_issued_gtip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_lgp_mmcare",
											"nbrpoa_issued_stucvg",
											"nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
											"nbrpoa_renewed_total_ip", "nbrpoa_renewed_gtlgp", "nbrpoa_renewed_gtip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_lgp_mmcare",
											"nbrpoa_renewed_stucvg", //24
											"mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
											"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
											"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp", "mbrmpoa_issued_gtsgp", "mbrmpoa_issued_gtip", "mbrmpoa_issued_total_gtip",
											"mbrmpoa_issued_catastrophic", "mbrmpoa_issued_lgp_mmcare", "mbrmpoa_issued_stucvg", //41
											"mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp",
											"mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp",
											"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip", "mbrmpoa_renewed_total_gtip",
											"mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_lgp_mmcare", "mbrmpoa_renewed_stucvg", //58
											"nbrpoa_termed_bronze_ip", "nbrpoa_termed_silver_ip", "nbrpoa_termed_gold_ip", "nbrpoa_termed_platinum_ip",
											"nbrpoa_termed_total_ip", "nbrpoa_termed_gtlgp", "nbrpoa_termed_gtip", "nbrpoa_termed_catastrophic",
											"nbrpoa_termed_lgp_mmcare", "nbrpoa_termed_stucvg", //68
											"nbrpoa_termed_nonpay_bronze_ip", "nbrpoa_termed_nonpay_silver_ip", "nbrpoa_termed_nonpay_gold_ip", "nbrpoa_termed_nonpay_platinum_ip",
											"nbrpoa_termed_nonpay_total_ip", "nbrpoa_termed_nonpay_gtlgp", "nbrpoa_termed_nonpay_gtip", "nbrpoa_termed_nonpay_catastrophic",
											"nbrpoa_termed_nonpay_lgp_mmcare", "nbrpoa_termed_nonpay_stucvg", //78
											"nbrpoa_termed_lives_bronze_ip", "nbrpoa_termed_lives_silver_ip", "nbrpoa_termed_lives_gold_ip", "nbrpoa_termed_lives_platinum_ip",
											"nbrpoa_termed_lives_total_ip", "nbrpoa_termed_lives_bronze_sgp", "nbrpoa_termed_lives_silver_sgp", "nbrpoa_termed_lives_gold_sgp", "nbrpoa_termed_lives_platinum_sgp", "nbrpoa_termed_lives_total_sgp",
											"nbrpoa_termed_lives_gtlgp",
											"nbrpoa_termed_lives_gtsgp", "nbrpoa_termed_lives_gtip", "nbrpoa_termed_lives_total_gtip", "nbrpoa_termed_lives_catastrophic", "nbrpoa_termed_lives_lgp_mmcare",
											"nbrpoa_termed_lives_stucvg") //95
									val termednonpayLives_master = termed_lives_Data.alias("parent").join(termed_nonpay_livesFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
											$"child.state".alias("s_state"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
											$"nbrpoa_issued_total_ip", $"nbrpoa_issued_gtlgp", $"nbrpoa_issued_gtip", $"nbrpoa_issued_catastrophic",
											$"nbrpoa_issued_lgp_mmcare", $"nbrpoa_issued_stucvg",
											$"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
											$"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_gtlgp", $"nbrpoa_renewed_gtip", $"nbrpoa_renewed_catastrophic",
											$"nbrpoa_renewed_lgp_mmcare", $"nbrpoa_renewed_stucvg", //24
											$"mbrmpoa_issued_bronze_ip", $"mbrmpoa_issued_silver_ip", $"mbrmpoa_issued_gold_ip",
											$"mbrmpoa_issued_platinum_ip", $"mbrmpoa_issued_total_ip",
											$"mbrmpoa_issued_bronze_sgp", $"mbrmpoa_issued_silver_sgp", $"mbrmpoa_issued_gold_sgp", $"mbrmpoa_issued_platinum_sgp",
											$"mbrmpoa_issued_total_sgp", $"mbrmpoa_issued_gtlgp", $"mbrmpoa_issued_gtsgp", $"mbrmpoa_issued_gtip", $"mbrmpoa_issued_total_gtip",
											$"mbrmpoa_issued_catastrophic", $"mbrmpoa_issued_lgp_mmcare", $"mbrmpoa_issued_stucvg",
											$"mbrmpoa_renewed_bronze_ip", $"mbrmpoa_renewed_silver_ip", $"mbrmpoa_renewed_gold_ip",
											$"mbrmpoa_renewed_platinum_ip", $"mbrmpoa_renewed_total_ip", $"mbrmpoa_renewed_bronze_sgp", $"mbrmpoa_renewed_silver_sgp", $"mbrmpoa_renewed_gold_sgp", $"mbrmpoa_renewed_platinum_sgp",
											$"mbrmpoa_renewed_total_sgp", $"mbrmpoa_renewed_gtlgp", $"mbrmpoa_renewed_gtsgp", $"mbrmpoa_renewed_gtip", $"mbrmpoa_renewed_total_gtip",
											$"mbrmpoa_renewed_catastrophic", $"mbrmpoa_renewed_lgp_mmcare", $"mbrmpoa_renewed_stucvg",
											$"nbrpoa_termed_bronze_ip", $"nbrpoa_termed_silver_ip", $"nbrpoa_termed_gold_ip", $"nbrpoa_termed_platinum_ip",
											$"nbrpoa_termed_total_ip", $"nbrpoa_termed_gtlgp", $"nbrpoa_termed_gtip", $"nbrpoa_termed_catastrophic",
											$"nbrpoa_termed_lgp_mmcare", $"nbrpoa_termed_stucvg", //68
											$"nbrpoa_termed_nonpay_bronze_ip", $"nbrpoa_termed_nonpay_silver_ip", $"nbrpoa_termed_nonpay_gold_ip", $"nbrpoa_termed_nonpay_platinum_ip",
											$"nbrpoa_termed_nonpay_total_ip",
											$"nbrpoa_termed_nonpay_gtlgp", $"nbrpoa_termed_nonpay_gtip", $"nbrpoa_termed_nonpay_catastrophic",
											$"nbrpoa_termed_nonpay_lgp_mmcare", $"nbrpoa_termed_nonpay_stucvg", //78
											$"nbrpoa_termed_lives_bronze_ip", $"nbrpoa_termed_lives_silver_ip", $"nbrpoa_termed_lives_gold_ip", $"nbrpoa_termed_lives_platinum_ip",
											$"nbrpoa_termed_lives_total_ip", $"nbrpoa_termed_lives_bronze_sgp", $"nbrpoa_termed_lives_silver_sgp", $"nbrpoa_termed_lives_gold_sgp", $"nbrpoa_termed_lives_platinum_sgp", $"nbrpoa_termed_lives_total_sgp",
											$"nbrpoa_termed_lives_gtlgp", $"nbrpoa_termed_lives_gtsgp", $"nbrpoa_termed_lives_gtip", $"nbrpoa_termed_lives_total_gtip", $"nbrpoa_termed_lives_catastrophic", $"nbrpoa_termed_lives_lgp_mmcare",
											$"nbrpoa_termed_lives_stucvg",

											$"nbrpoa_termed_nonpay_lives_bronze_ip", $"nbrpoa_termed_nonpay_lives_silver_ip", $"nbrpoa_termed_nonpay_lives_gold_ip", $"nbrpoa_termed_nonpay_lives_platinum_ip",
											$"nbrpoa_termed_nonpay_lives_total_ip", $"nbrpoa_termed_nonpay_lives_bronze_sgp", $"nbrpoa_termed_nonpay_lives_silver_sgp", $"nbrpoa_termed_nonpay_lives_gold_sgp", $"nbrpoa_termed_nonpay_lives_platinum_sgp", $"nbrpoa_termed_nonpay_lives_total_sgp",
											$"nbrpoa_termed_nonpay_lives_gtlgp", $"nbrpoa_termed_nonpay_lives_gtsgp", $"nbrpoa_termed_nonpay_lives_gtip", $"nbrpoa_termed_nonpay_lives_total_gtip", $"nbrpoa_termed_nonpay_lives_catastrophic", $"nbrpoa_termed_nonpay_lives_lgp_mmcare",
											$"nbrpoa_termed_nonpay_lives_stucvg")

									val final_Data = termednonpayLives_master.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
									.withColumn("outoff_exchange", lit("OUTOFF"))
									.select("outoff_exchange", "health_year", "cmpny_cf_cd", "state", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
											"nbrpoa_issued_total_ip", "nbrpoa_issued_gtlgp", "nbrpoa_issued_gtip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_lgp_mmcare",
											"nbrpoa_issued_stucvg",
											"nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
											"nbrpoa_renewed_total_ip", "nbrpoa_renewed_gtlgp", "nbrpoa_renewed_gtip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_lgp_mmcare",
											"nbrpoa_renewed_stucvg", //24
											"mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
											"mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
											"mbrmpoa_issued_total_sgp", "mbrmpoa_issued_gtlgp", "mbrmpoa_issued_gtsgp", "mbrmpoa_issued_gtip", "mbrmpoa_issued_total_gtip",
											"mbrmpoa_issued_catastrophic", "mbrmpoa_issued_lgp_mmcare", "mbrmpoa_issued_stucvg", //41
											"mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp",
											"mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp",
											"mbrmpoa_renewed_gtlgp", "mbrmpoa_renewed_gtsgp", "mbrmpoa_renewed_gtip", "mbrmpoa_renewed_total_gtip",
											"mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_lgp_mmcare", "mbrmpoa_renewed_stucvg", //58
											"nbrpoa_termed_bronze_ip", "nbrpoa_termed_silver_ip", "nbrpoa_termed_gold_ip", "nbrpoa_termed_platinum_ip",
											"nbrpoa_termed_total_ip", "nbrpoa_termed_gtlgp", "nbrpoa_termed_gtip", "nbrpoa_termed_catastrophic",
											"nbrpoa_termed_lgp_mmcare", "nbrpoa_termed_stucvg", //68
											"nbrpoa_termed_nonpay_bronze_ip", "nbrpoa_termed_nonpay_silver_ip", "nbrpoa_termed_nonpay_gold_ip", "nbrpoa_termed_nonpay_platinum_ip",
											"nbrpoa_termed_nonpay_total_ip", "nbrpoa_termed_nonpay_gtlgp", "nbrpoa_termed_nonpay_gtip", "nbrpoa_termed_nonpay_catastrophic",
											"nbrpoa_termed_nonpay_lgp_mmcare", "nbrpoa_termed_nonpay_stucvg", //78
											"nbrpoa_termed_lives_bronze_ip", "nbrpoa_termed_lives_silver_ip", "nbrpoa_termed_lives_gold_ip", "nbrpoa_termed_lives_platinum_ip",
											"nbrpoa_termed_lives_total_ip", "nbrpoa_termed_lives_bronze_sgp", "nbrpoa_termed_lives_silver_sgp", "nbrpoa_termed_lives_gold_sgp", "nbrpoa_termed_lives_platinum_sgp", "nbrpoa_termed_lives_total_sgp",
											"nbrpoa_termed_lives_gtlgp",
											"nbrpoa_termed_lives_gtsgp", "nbrpoa_termed_lives_gtip", "nbrpoa_termed_lives_total_gtip", "nbrpoa_termed_lives_catastrophic", "nbrpoa_termed_lives_lgp_mmcare",
											"nbrpoa_termed_lives_stucvg", //95
											"nbrpoa_termed_nonpay_lives_bronze_ip", "nbrpoa_termed_nonpay_lives_silver_ip", "nbrpoa_termed_nonpay_lives_gold_ip", "nbrpoa_termed_nonpay_lives_platinum_ip",
											"nbrpoa_termed_nonpay_lives_total_ip", "nbrpoa_termed_nonpay_lives_bronze_sgp", "nbrpoa_termed_nonpay_lives_silver_sgp", "nbrpoa_termed_nonpay_lives_gold_sgp", "nbrpoa_termed_nonpay_lives_platinum_sgp", "nbrpoa_termed_nonpay_lives_total_sgp",
											"nbrpoa_termed_nonpay_lives_gtlgp", "nbrpoa_termed_nonpay_lives_gtsgp", "nbrpoa_termed_nonpay_lives_gtip", "nbrpoa_termed_nonpay_lives_total_gtip", "nbrpoa_termed_nonpay_lives_catastrophic", "nbrpoa_termed_nonpay_lives_lgp_mmcare",
											"nbrpoa_termed_nonpay_lives_stucvg").withColumn("load_log_key", lit(1)).withColumn("load_dt", current_timestamp());



							final_Data
			}
}


/*object PCADX_SCL_NAIC2018_OEXStgTransformationPOA {
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		println("$$$$$$$")
		val OEX = new PCADX_SCL_NAIC2018_OEXStgTransformationPOA()
		OEX.sparkInIt()
		println("$$$$$$$$$$$")
	}
}*/

object PCADX_SCL_NAIC2018_OEXStgTransformationPOA {
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val OEX = new PCADX_SCL_NAIC2018_OEXStgTransformationPOA()
		//OEX.setYear(args(1))
		OEX.sparkInIt()
	}

}

