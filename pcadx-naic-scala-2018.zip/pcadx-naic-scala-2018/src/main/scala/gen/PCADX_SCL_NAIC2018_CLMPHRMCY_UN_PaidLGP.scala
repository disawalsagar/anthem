package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator

import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit

import org.apache.hadoop.fs._;
class PCADX_SCL_NAIC2018_CLMPHRMCY_UN_PaidLGP{
  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()
    import spark.implicits._
  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_DataExtraction])
     val dbWrk = dbProperties.getProperty("work.db")
     val dbInbnd = dbProperties.getProperty("inbound.db")
     val wrhDb = dbProperties.getProperty("warehouse.db")
	 
     val reportYear =dbProperties.getProperty("report.year")
	 val audit_log_df = spark.sql("select * from "+wrhDb+".audt_load_log") 
    val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0) 
    println("load_log_key : "+load_log_key)
	    val clmRcvdStrtDt = dbProperties.getProperty("CLM_RCVD_DT_STRT")
	    val clmRcvdEndDt = dbProperties.getProperty("CLM_RCVD_DT_END")
   
  def naic_mcas_hlthex_clmphmcy_un_il_paid_lgp_wrk() = """Insert overwrite table """+dbWrk+""".naic2018_mcas_hlthex_clmphmcy_unicare_paid_lgp_wrk"""+"""
    select * from              
( 
SELECT  """+reportYear+"""  as health_year,  pclm_paid_wrk.CLM_ADJSTMNT_KEY  AS CLM_ADJSTMNT_KEY,  pclm_paid_wrk.CLM_LINE_NBR AS CLM_LINE_NBR ,  pclm_paid_wrk.CLM_SOR_CD   AS CLM_SOR_CD ,
  pclm_paid_wrk.PRMPT_PAY_CLM_RCVD_DT as  PRMPT_PAY_CLM_RCVD_DT,
  pclm_paid_wrk.CLM_RCVD_DT as CLM_RCVD_DT,
  pclm_paid_wrk.GL_POST_DT as GL_POST_DT,  pclm_paid_wrk.INN_CD     AS INN_CD ,  pclm_paid_wrk.inn_paid AS inn_paid ,  pclm_paid_wrk.outn_paid AS outn_paid ,  pclm_paid_wrk.PAID_AMT            AS    PAID_AMT  ,  pclm_paid_wrk.CPAY_AMT           AS   CPAY_AMT  ,  pclm_paid_wrk.COINSRN_AMT        AS   COINSRN_AMT  ,  pclm_paid_wrk.DDCTBL_AMT         AS  DDCTBL_AMT ,  UNI.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,   UNI.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,  UNI.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,   UNI.hcr_cmplynt_cd AS hcr_cmplynt_cd ,  UNI.EXCHNG_IND_CD AS EXCHNG_IND_CD,  UNI.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,  UNI.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,  UNI.MBU_CF_CD AS MBU_CF_CD ,  UNI.PROD_CF_CD AS PROD_CF_CD,   'G0365'        AS CMPNY_CF_CD,  UNI.FUNDG_CF_CD AS FUNDG_CF_CD,  'IL'  AS  State, NULL   AS IN_Exchange ,  'OUTOFF'  AS OUTOFF_Exchange,  'LARGE GROUP GRAND'  AS naic_lob,  MED.GL_CF_DESC  as  naic_prod_desc,
  UNI.SRC_GRP_NBR ,
  UNI.SRC_SUBGRP_NBR,  """+load_log_key+""" as load_log_key,
 current_timestamp()   FROM   """+dbWrk+""".naic2018_mcas_pclm_paid_wrk  pclm_paid_wrk
INNER JOIN """+dbWrk+""".clm_inter UNI     ON pclm_paid_wrk.MBR_KEY = UNI.MBR_KEY 	 	   inner join ( select CF_CD,  GL_CF_DESC   from """+dbInbnd+""".GL_CF_VRTCL_HRCHY where GL_CF_TYPE_DESC = 'PRODUCT'  group by 1,2 ) as MED on MED.CF_CD = UNI.PROD_CF_CD  inner join ( select DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY where  GL_CF_TYPE_DESC = 'FUND_CODE' and CF_CD NOT IN ( select  DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY                   where  GL_CF_TYPE_DESC = 'FUND_CODE'      AND    ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )        ) ) FC ON FC.CF_CD = UNI.FUNDG_CF_CD      where (UNI.SRC_SUBGRP_NBR in (        '131195M001',        '131196M001',        '141333M001',        '145447M001'        )    or
 UNI.ORG_GRP_SRC_SUBGRP_NBR in (       
'131195M001',       
'131196M001',       
'141333M001',       
'145447M001'       
)  
)    and  ((pclm_paid_wrk.clm_rcvd_dt between UNI.mbr_prod_enrlmnt_efctv_dt and UNI.mbr_prod_enrlmnt_trmntn_dt)
        or
       (pclm_paid_wrk.clm_line_srvc_strt_dt between UNI.mbr_prod_enrlmnt_efctv_dt and UNI.mbr_prod_enrlmnt_trmntn_dt)
      )    
     AND ( ( UNI.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN UNI.prchsr_org_efctv_dt AND UNI.prchsr_org_trmntn_dt) OR UNI.prchsr_org_trmntn_dt IS NULL)
      AND ( UNI.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN UNI.MBR_COA_EFCTV_DT AND UNI.MBR_COA_TRMNTN_DT) 
      AND UNI.DUP_DATA_CD = '00' 
        GROUP BY   pclm_paid_wrk.CLM_ADJSTMNT_KEY  ,  pclm_paid_wrk.CLM_LINE_NBR  ,  pclm_paid_wrk.CLM_SOR_CD   ,
  pclm_paid_wrk.PRMPT_PAY_CLM_RCVD_DT,
  pclm_paid_wrk.CLM_RCVD_DT,
  pclm_paid_wrk.GL_POST_DT,  pclm_paid_wrk.INN_CD      ,  pclm_paid_wrk.inn_paid ,  pclm_paid_wrk.outn_paid ,  pclm_paid_wrk.PAID_AMT             ,  pclm_paid_wrk.CPAY_AMT             ,  pclm_paid_wrk.COINSRN_AMT        ,  pclm_paid_wrk.DDCTBL_AMT         ,  UNI.MBRSHP_SOR_CD ,   UNI.GRNDFTHR_IND_CD  ,  UNI.GRNDFTHRG_STTS_CD ,   UNI.hcr_cmplynt_cd ,  UNI.EXCHNG_IND_CD ,  UNI.EXCHNG_METL_TYPE_CD ,  UNI.SRC_EXCHNG_CERTFN_CD ,  UNI.MBU_CF_CD  ,  UNI.PROD_CF_CD ,  UNI.FUNDG_CF_CD ,  MED.GL_CF_DESC,
  UNI.SRC_GRP_NBR ,
  UNI.SRC_SUBGRP_NBR
  )"""

def naic_mcas_hlthex_clmphmcy_un_ma_paid_lgp_wrk() = """Insert into table """+dbWrk+""".naic2018_mcas_hlthex_clmphmcy_unicare_paid_lgp_wrk"""+"""
    select * from              
( 
SELECT 
 """+reportYear+"""  as health_year,
  pclm_paid_wrk.CLM_ADJSTMNT_KEY  AS CLM_ADJSTMNT_KEY,
  pclm_paid_wrk.CLM_LINE_NBR AS CLM_LINE_NBR ,
  pclm_paid_wrk.CLM_SOR_CD   AS CLM_SOR_CD ,
  pclm_paid_wrk.PRMPT_PAY_CLM_RCVD_DT as  PRMPT_PAY_CLM_RCVD_DT,
  pclm_paid_wrk.CLM_RCVD_DT as CLM_RCVD_DT,
  pclm_paid_wrk.GL_POST_DT as GL_POST_DT,
  pclm_paid_wrk.INN_CD     AS INN_CD ,
  pclm_paid_wrk.inn_paid AS inn_paid ,
  pclm_paid_wrk.outn_paid AS outn_paid ,
  pclm_paid_wrk.PAID_AMT            AS    PAID_AMT  ,
  pclm_paid_wrk.CPAY_AMT           AS   CPAY_AMT  ,
  pclm_paid_wrk.COINSRN_AMT        AS   COINSRN_AMT  ,
  pclm_paid_wrk.DDCTBL_AMT         AS  DDCTBL_AMT ,
  UNI.MBRSHP_SOR_CD AS MBRSHP_SOR_CD, 
  UNI.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD ,
  UNI.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD , 
  UNI.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
  UNI.EXCHNG_IND_CD AS EXCHNG_IND_CD,
  UNI.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
  UNI.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
  UNI.MBU_CF_CD AS MBU_CF_CD ,
  UNI.PROD_CF_CD AS PROD_CF_CD,
   'G0365'        AS CMPNY_CF_CD,
  UNI.FUNDG_CF_CD AS FUNDG_CF_CD,
  'MA'  AS  State,
 NULL   AS IN_Exchange ,
  'OUTOFF'  AS OUTOFF_Exchange, 
 'LARGE GROUP CBE'  AS naic_lob,
   MED.GL_CF_DESC  as  naic_prod_desc,
   UNI.SRC_GRP_NBR ,
   UNI.SRC_SUBGRP_NBR,
  """+load_log_key+""" as load_log_key,
  current_timestamp()
  
 FROM   """+dbWrk+""".naic2018_mcas_pclm_paid_wrk  pclm_paid_wrk
 INNER JOIN """+dbWrk+""".clm_inter UNI
     ON pclm_paid_wrk.MBR_KEY = UNI.MBR_KEY
 	
 	   inner join (
 select CF_CD,  GL_CF_DESC  
 from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
 where GL_CF_TYPE_DESC = 'PRODUCT' 
 group by 1,2
 ) as MED
 on MED.CF_CD = UNI.PROD_CF_CD
 
 inner join
 (
 select DISTINCT CF_CD
 from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
 where  GL_CF_TYPE_DESC = 'FUND_CODE'
 and CF_CD NOT IN ( select  DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY  
             
    where  GL_CF_TYPE_DESC = 'FUND_CODE' 
     AND    ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
        )
 ) FC
 ON FC.CF_CD = UNI.FUNDG_CF_CD
  
 where (UNI.SRC_GRP_NBR = '131192' or UNI.ORG_GRP_SRC_GRP_NBR = '131192')     
   and  ((pclm_paid_wrk.clm_rcvd_dt between UNI.mbr_prod_enrlmnt_efctv_dt and UNI.mbr_prod_enrlmnt_trmntn_dt)
         or
         (pclm_paid_wrk.clm_line_srvc_strt_dt between UNI.mbr_prod_enrlmnt_efctv_dt and UNI.mbr_prod_enrlmnt_trmntn_dt)
         )  
         
  AND ( ( UNI.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN UNI.prchsr_org_efctv_dt AND UNI.prchsr_org_trmntn_dt) OR UNI.prchsr_org_trmntn_dt IS NULL)
      AND ( UNI.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN UNI.MBR_COA_EFCTV_DT AND UNI.MBR_COA_TRMNTN_DT) 
      AND UNI.DUP_DATA_CD = '00' 
        
  GROUP BY 
  pclm_paid_wrk.CLM_ADJSTMNT_KEY  ,
  pclm_paid_wrk.CLM_LINE_NBR  ,
  pclm_paid_wrk.CLM_SOR_CD   ,
  pclm_paid_wrk.PRMPT_PAY_CLM_RCVD_DT,
  pclm_paid_wrk.CLM_RCVD_DT,
  pclm_paid_wrk.GL_POST_DT, 
  pclm_paid_wrk.INN_CD      ,
  pclm_paid_wrk.inn_paid ,
  pclm_paid_wrk.outn_paid ,
  pclm_paid_wrk.PAID_AMT             ,
  pclm_paid_wrk.CPAY_AMT             ,
  pclm_paid_wrk.COINSRN_AMT        ,
  pclm_paid_wrk.DDCTBL_AMT         ,
  UNI.MBRSHP_SOR_CD , 
  UNI.GRNDFTHR_IND_CD  ,
  UNI.GRNDFTHRG_STTS_CD , 
  UNI.hcr_cmplynt_cd ,
  UNI.EXCHNG_IND_CD ,
  UNI.EXCHNG_METL_TYPE_CD ,
  UNI.SRC_EXCHNG_CERTFN_CD ,
  UNI.MBU_CF_CD  ,
  UNI.PROD_CF_CD ,
  UNI.FUNDG_CF_CD ,
  MED.GL_CF_DESC,
  UNI.SRC_GRP_NBR ,
  UNI.SRC_SUBGRP_NBR
)"""

  
   def sparkInIt(){
   var un_il_paid_lgp=naic_mcas_hlthex_clmphmcy_un_il_paid_lgp_wrk()
   var un_ma_paid_lgp=naic_mcas_hlthex_clmphmcy_un_ma_paid_lgp_wrk()
   un_il_paid_lgp=un_il_paid_lgp.replace("$1",String.valueOf(load_log_key))
   un_ma_paid_lgp=un_ma_paid_lgp.replace("$1",String.valueOf(load_log_key))
   
    spark.sql(un_il_paid_lgp)
	spark.sql(un_ma_paid_lgp)
	spark.close()
  }
}
object PCADX_SCL_NAIC2018_CLMPHRMCY_UN_PaidLGP{
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val clmPhmy = new PCADX_SCL_NAIC2018_CLMPHRMCY_UN_PaidLGP()
		
		clmPhmy.sparkInIt()
	}


}