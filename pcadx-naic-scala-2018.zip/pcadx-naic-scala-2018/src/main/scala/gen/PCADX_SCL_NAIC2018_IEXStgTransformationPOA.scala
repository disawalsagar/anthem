package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class PCADX_SCL_NAIC2018_IEXStgTransformationPOA {

  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()

  import org.apache.spark.sql.types._
  import spark.implicits._

  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_IEXStgTransformationPOA])

  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))

  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")

  val tblIssued = dbProperties.getProperty("issued_poa")
  val tblRenewed = dbProperties.getProperty("renewed_poa")
  val tblMmissued = dbProperties.getProperty("mmissued_poa")
  val tblMmrenewed = dbProperties.getProperty("mmrenewed_poa")
  val tblTermed = dbProperties.getProperty("termed_poa")
  val tblTermed_nonpay = dbProperties.getProperty("termed_nonpay_poa")
  val tblTermed_lives = dbProperties.getProperty("termed_lives_poa")
  val tblTermed_nonpay_lives = dbProperties.getProperty("termed_nonpay_lives_poa")

  val tbl_poag_Mmissued = dbProperties.getProperty("mmissued_poag")
  val tbl_poag_Mmrenewed = dbProperties.getProperty("mmrenewed_poag")
  val tbl_poag_Termed_lives = dbProperties.getProperty("termed_lives_poag")
  val tbl_poag_Termed_nonpay_lives = dbProperties.getProperty("termed_nonpay_lives_poag")

  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_poa")
  //val end_year =dbProperties.getProperty("end_year_poa")
  val strt_year_sql = dbProperties.getProperty("strt_year_poa_sql")
  val end_year_sql = dbProperties.getProperty("end_year_poa_sql")
  val mmissue_const_date = dbProperties.getProperty("const_date_mmissued")

  //val mmissue_const_date ="2017-12-31 00:00:00"
  /*def setyear(yr:String){
      year = yr
      }*/

  def sparkInIt() {

    val naic2018_mcas_hlthex_poa_issued_wrk = readDataFromHive(dbwrk + "." + tblIssued)
    val naic2018_mcas_hlthex_poa_renewed_wrk = readDataFromHive(dbwrk + "." + tblRenewed)
    val naic2018_mcas_hlthex_poa_mmissued_wrk = readDataFromHive(dbwrk + "." + tblMmissued)
    val naic2018_mcas_hlthex_poa_mmrenewed_wrk = readDataFromHive(dbwrk + "." + tblMmrenewed)

    val naic2018_mcas_hlthex_poa_termed_wrk = readDataFromHive(dbwrk + "." + tblTermed)
    val naic2018_mcas_hlthex_poa_termed_nonpay_wrk = readDataFromHive(dbwrk + "." + tblTermed_nonpay)
    val naic2018_mcas_hlthex_poa_termed_lives_wrk = readDataFromHive(dbwrk + "." + tblTermed_lives)
    val naic2018_mcas_hlthex_poa_termed_nonpay_lives_wrk = readDataFromHive(dbwrk + "." + tblTermed_nonpay_lives)

    val naic2018_mcas_hlthex_poag_mmissued_wrk = readDataFromHive(dbwrk + "." + tbl_poag_Mmissued)
    val naic2018_mcas_hlthex_poag_mmrenewed_wrk = readDataFromHive(dbwrk + "." + tbl_poag_Mmrenewed)
    val naic2018_mcas_hlthex_poag_termed_lives_wrk = readDataFromHive(dbwrk + "." + tbl_poag_Termed_lives)
    val naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk = readDataFromHive(dbwrk + "." + tbl_poag_Termed_nonpay_lives)

    //truncateTbl(dbsg+"."+"naic_mcas_hlthiex_poa_stg")
    val stgData = populateStageTbl(naic2018_mcas_hlthex_poa_issued_wrk, naic2018_mcas_hlthex_poa_renewed_wrk, naic2018_mcas_hlthex_poa_mmissued_wrk, naic2018_mcas_hlthex_poa_mmrenewed_wrk,
      naic2018_mcas_hlthex_poa_termed_wrk, naic2018_mcas_hlthex_poa_termed_nonpay_wrk, naic2018_mcas_hlthex_poa_termed_lives_wrk, naic2018_mcas_hlthex_poa_termed_nonpay_lives_wrk,
      naic2018_mcas_hlthex_poag_mmissued_wrk, naic2018_mcas_hlthex_poag_mmrenewed_wrk, naic2018_mcas_hlthex_poag_termed_lives_wrk, naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk)
    //println("stgData count :"+stgData.count())
    stgData.repartition(50)
    writeDataToHive(dbsg + "." + "naic2018_mcas_hlthiex_poa_stg", stgData)
    spark.close()
  }

  def truncateTbl(tblName: String) {
    spark.sql("TRUNCATE TABLE " + tblName)
  }

  def writeDataToHive(tblName: String, finalDf: DataFrame) {
    finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
    println("Data added in stage table")
  }

  def readDataFromHive(tble: String): DataFrame = {
    val queryOutputTable = """SELECT * FROM """ + tble
    println(queryOutputTable)
    val tbl_data_df = spark.sql(queryOutputTable) //.na.fill("")
    logger.info("Read data from hive")
    tbl_data_df
  }

  def populateStageTbl(naic2018_mcas_hlthex_poa_issued_wrk: DataFrame, naic2018_mcas_hlthex_poa_renewed_wrk: DataFrame, naic2018_mcas_hlthex_poa_mmissued_wrk: DataFrame,
                       naic2018_mcas_hlthex_poa_mmrenewed_wrk: DataFrame, naic2018_mcas_hlthex_poa_termed_wrk: DataFrame, naic2018_mcas_hlthex_poa_termed_nonpay_wrk: DataFrame,
                       naic2018_mcas_hlthex_poa_termed_lives_wrk: DataFrame, naic2018_mcas_hlthex_poa_termed_nonpay_lives_wrk: DataFrame,
                       naic2018_mcas_hlthex_poag_mmissued_wrk: DataFrame, naic2018_mcas_hlthex_poag_mmrenewed_wrk: DataFrame, naic2018_mcas_hlthex_poag_termed_lives_wrk: DataFrame,
                       naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk: DataFrame): DataFrame = {

    val final_df = null

    //same function
    val issueFinalDf = getIssuedData(naic2018_mcas_hlthex_poa_issued_wrk, "issued")

    val rennewedFinalDf = getIssuedData(naic2018_mcas_hlthex_poa_renewed_wrk, "renewed")

    val termedFinalDf = getIssuedData(naic2018_mcas_hlthex_poa_termed_wrk, "termed")
    val termed_nonpayFinalDf = getIssuedData(naic2018_mcas_hlthex_poa_termed_nonpay_wrk, "termed_nonpay")

    val mmissuedFinalDf = getMemberIssuedData(naic2018_mcas_hlthex_poa_mmissued_wrk, naic2018_mcas_hlthex_poag_mmissued_wrk)
    val mmrenewedFinalDf = getMemberRenewedData(naic2018_mcas_hlthex_poa_mmrenewed_wrk, naic2018_mcas_hlthex_poag_mmrenewed_wrk)

    val termed_livesFinalDf = getTermedLivesData(naic2018_mcas_hlthex_poa_termed_lives_wrk, naic2018_mcas_hlthex_poag_termed_lives_wrk, "termed_lives")
    val termed_nonpay_livesFinalDf = getTermedLivesData(naic2018_mcas_hlthex_poa_termed_nonpay_lives_wrk, naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk, "termed_nonpay_lives")

    val naicIexStgData = getStageData(issueFinalDf, rennewedFinalDf, mmissuedFinalDf, mmrenewedFinalDf, termedFinalDf, termed_nonpayFinalDf, termed_livesFinalDf, termed_nonpay_livesFinalDf)
    var load_log_key = ""

    if (!naic2018_mcas_hlthex_poa_issued_wrk.take(1).isEmpty) {
      load_log_key = naic2018_mcas_hlthex_poa_issued_wrk.select($"load_log_key").first.getString(0)
    }

    val finalStgdata = naicIexStgData.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
    //finalStgdata.filter($"state".equalTo("OH")).show()
    finalStgdata

  }

  def getMemberRenewedData(naic2018_mcas_hlthex_poa_wrk: DataFrame, naic2018_mcas_hlthex_poag_wrk: DataFrame): DataFrame = {

    // val date1 =  LocalDate.parse(strt_year)
    // val date2= LocalDate.parse(end_year)
    // println ("Date 1 : "+date1)
    // println("Date 2 : "+date2)
    // naic_mcas_hlthex_poa_wrk.show(1)

    naic2018_mcas_hlthex_poa_wrk.createOrReplaceTempView("mmrenewed_wrk")
    naic2018_mcas_hlthex_poag_wrk.createOrReplaceTempView("mmrenewed_poag_wrk")

    val mbrmpoa_renewed_bronze_ip = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_bronze_ip
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'TOTAL INDIVIDUAL CBE'
							and (grndfthr_ind_cd <> 'YES'   OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '04' 
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_silver_ip = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_silver_ip FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'TOTAL INDIVIDUAL CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '03' 
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_gold_ip = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_gold_ip
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'TOTAL INDIVIDUAL CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '02' 
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_platinum_ip = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_platinum_ip
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'TOTAL INDIVIDUAL CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '01' 
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_bronze_sgp = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_bronze_sgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewed_poag_wrk
							where naic_lob = 'TOTAL SMALL GROUP CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '04' 
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_silver_sgp = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_silver_sgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewed_poag_wrk
							where naic_lob = 'TOTAL SMALL GROUP CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '03' 
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_gold_sgp = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_gold_sgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewed_poag_wrk
							where naic_lob = 'TOTAL SMALL GROUP CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '02' 
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_platinum_sgp = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_platinum_sgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewed_poag_wrk
							where naic_lob = 'TOTAL SMALL GROUP CBE'
							and (grndfthr_ind_cd <> 'YES' OR grndfthr_ind_cd is NULL)
							and hcr_cmplynt_cd = 'Y'
							and (src_exchng_certfn_cd <> 'M' OR src_exchng_certfn_cd is NULL)
							and exchng_metl_type_cd = '01' 
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_catastrophic = spark.sql("""

							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_catastrophic
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_prod_desc  LIKE  '%CATASTROPHIC%'
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_bronze_ms_ip = spark.sql("""
							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_bronze_ms_ip
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'TOTAL INDIVIDUAL CBE'
							and src_exchng_certfn_cd = 'M'
							and exchng_metl_type_cd = '04'
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_silver_ms_ip = spark.sql("""
							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_silver_ms_ip
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'TOTAL INDIVIDUAL CBE'
							and src_exchng_certfn_cd = 'M'
							and exchng_metl_type_cd = '03'
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_gold_ms_ip = spark.sql("""
							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_gold_ms_ip
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0)  
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'TOTAL INDIVIDUAL CBE'
							and src_exchng_certfn_cd = 'M'
							and exchng_metl_type_cd = '02'
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_platinum_ms_ip = spark.sql("""
							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_platinum_ms_ip
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewed_wrk
							where naic_lob = 'TOTAL INDIVIDUAL CBE'
							and src_exchng_certfn_cd = 'M'
							and exchng_metl_type_cd = '01'
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_bronze_ms_sgp = spark.sql("""
							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_bronze_ms_sgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewed_poag_wrk
							where naic_lob =  'TOTAL SMALL GROUP CBE'
							and src_exchng_certfn_cd = 'M'
							and exchng_metl_type_cd = '04' 
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_silver_ms_sgp = spark.sql("""
							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_silver_ms_sgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewed_poag_wrk
							where naic_lob =  'TOTAL SMALL GROUP CBE'
							and src_exchng_certfn_cd = 'M'
							and exchng_metl_type_cd = '03' 
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_gold_ms_sgp = spark.sql("""
							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_gold_ms_sgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewed_poag_wrk
							where naic_lob =  'TOTAL SMALL GROUP CBE'
							and src_exchng_certfn_cd = 'M'
							and exchng_metl_type_cd = '02' 
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val mbrmpoa_renewed_platinum_ms_sgp = spark.sql("""
							SELECT health_year,cmpny_cf_cd,state,in_exchange, cast(round(SUM( Member_Months ),0) as int) as mbrmpoa_renewed_platinum_ms_sgp
							FROM (
							SELECT SBSCRBR_ID , health_year,cmpny_cf_cd,state,in_exchange, 
							MBR_RLTNSHP_CD , 
							CASE WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ ,  """ + strt_year_sql + """  ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  > """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN ( """ + end_year_sql + """ , MBR_PROD_ENRLMNT_EFCTV_DT  ),0)
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND
							( """ + strt_year_sql + """ BETWEEN MBR_PROD_ENRLMNT_EFCTV_DT AND """ + end_year_sql + """) THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT ,  """ + strt_year_sql + """   ),0) 
							WHEN MBR_PROD_ENRLMNT_TRMNTN_DT  <= """ + end_year_sql + """  AND 
							MBR_PROD_ENRLMNT_EFCTV_DT >  """ + strt_year_sql + """ THEN  round(MONTHS_BETWEEN (  MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT   ),0) 
							END AS Member_Months
							FROM mmrenewed_poag_wrk
							where naic_lob =  'TOTAL SMALL GROUP CBE'
							and src_exchng_certfn_cd = 'M'
							and exchng_metl_type_cd = '01' 
							and in_exchange = 'IN'
							GROUP BY health_year,cmpny_cf_cd,state,in_exchange,SBSCRBR_ID,  MBR_RLTNSHP_CD , MBR_PROD_ENRLMNT_TRMNTN_DT , MBR_PROD_ENRLMNT_EFCTV_DT ) 
							GROUP BY  health_year,cmpny_cf_cd,state,in_exchange""")

    val brSil = mbrmpoa_renewed_bronze_ip.alias("bsg").join(mbrmpoa_renewed_silver_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip")

    val bsGld = brSilData.alias("bsg").join(mbrmpoa_renewed_gold_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"))

    val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip")

    val bsgPlt = bsGldData.alias("bsg").join(mbrmpoa_renewed_platinum_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"))

    val bsgPltData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip")

    //"mbrmpoa_renewed_bronze_ip + mbrmpoa_renewed_silver_ip + mbrmpoa_renewed_gold_ip + mbrmpoa_renewed_platinum_ip"

    val getTotal_ip = mbrmpoa_renewed_bronze_ip.union(mbrmpoa_renewed_silver_ip.union(mbrmpoa_renewed_gold_ip.union(mbrmpoa_renewed_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrmpoa_renewed_bronze_ip")

    val mbrmpoa_renewed_total_ip = getTotal_ip.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum($"mbrmpoa_renewed_bronze_ip").alias("mbrmpoa_renewed_total_ip")).withColumn("mbrmpoa_renewed_total_ip", $"mbrmpoa_renewed_total_ip".cast(IntegerType))

    val ip = bsgPltData.alias("bsg").join(mbrmpoa_renewed_total_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"))

    val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip")

    val ipBrz = ipData.alias("bsg").join(mbrmpoa_renewed_bronze_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"))

    val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp")

    val ipbSil = ipBrzData.alias("bsg").join(mbrmpoa_renewed_silver_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"))

    val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp")

    val ipbsGld = ipbSilData.alias("bsg").join(mbrmpoa_renewed_gold_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"))

    val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp")
    //ipbsGldData.show()

    val ipbsgPlt = ipbsGldData.alias("bsg").join(mbrmpoa_renewed_platinum_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"))

    val ipbsgPltData = ipbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp")

    val getTotal_sgp = mbrmpoa_renewed_bronze_sgp.union(mbrmpoa_renewed_silver_sgp.union(mbrmpoa_renewed_gold_sgp.union(mbrmpoa_renewed_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrmpoa_renewed_bronze_sgp")

    val mbrmpoa_renewed_total_sgp = getTotal_sgp.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum($"mbrmpoa_renewed_bronze_sgp").alias("mbrmpoa_renewed_total_sgp")).withColumn("mbrmpoa_renewed_total_sgp", $"mbrmpoa_renewed_total_sgp".cast(IntegerType))

    val ipSgp = ipbsgPltData.alias("bsg").join(mbrmpoa_renewed_total_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
        col("mbrmpoa_renewed_total_sgp"))

    val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp")

    val ipSgpCat = ipSgpData.alias("bsg").join(mbrmpoa_renewed_catastrophic.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
        col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_catastrophic"))

    val ipSgpCatData = ipSgpCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic")

    val ipSgpCBrz = ipSgpCatData.alias("bsg").join(mbrmpoa_renewed_bronze_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
        col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_bronze_ms_ip"))

    val ipSgpCBrzData = ipSgpCBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip")

    val ipSgpCbSil = ipSgpCBrzData.alias("bsg").join(mbrmpoa_renewed_silver_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
        col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_bronze_ms_ip"), col("mbrmpoa_renewed_silver_ms_ip"))

    val ipSgpCbSilData = ipSgpCbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip")

    val ipSgpCbsGld = ipSgpCbSilData.alias("bsg").join(mbrmpoa_renewed_gold_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
        col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_bronze_ms_ip"), col("mbrmpoa_renewed_silver_ms_ip"), col("mbrmpoa_renewed_gold_ms_ip"))

    val ipSgpCbsGldData = ipSgpCbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip", "mbrmpoa_renewed_gold_ms_ip")

    val ipSgpCbsgPlt = ipSgpCbsGldData.alias("bsg").join(mbrmpoa_renewed_platinum_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
        col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_bronze_ms_ip"), col("mbrmpoa_renewed_silver_ms_ip"), col("mbrmpoa_renewed_gold_ms_ip"),
        col("mbrmpoa_renewed_platinum_ms_ip"))

    val ipSgpCbsgPltData = ipSgpCbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip", "mbrmpoa_renewed_gold_ms_ip",
        "mbrmpoa_renewed_platinum_ms_ip")

    val getTotal_ms_ip = mbrmpoa_renewed_bronze_ms_ip.union(mbrmpoa_renewed_silver_ms_ip.union(mbrmpoa_renewed_gold_ms_ip.union(mbrmpoa_renewed_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrmpoa_renewed_bronze_ms_ip")

    val mbrmpoa_renewed_total_ms_ip = getTotal_ms_ip.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum($"mbrmpoa_renewed_bronze_ms_ip").alias("mbrmpoa_renewed_total_ms_ip")).withColumn("mbrmpoa_renewed_total_ms_ip", $"mbrmpoa_renewed_total_ms_ip".cast(IntegerType))

    val ipSgpCmsip = ipSgpCbsgPltData.alias("bsg").join(mbrmpoa_renewed_total_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
        col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_bronze_ms_ip"), col("mbrmpoa_renewed_silver_ms_ip"), col("mbrmpoa_renewed_gold_ms_ip"),
        col("mbrmpoa_renewed_platinum_ms_ip"), col("mbrmpoa_renewed_total_ms_ip"))

    val ipSgpCmsipData = ipSgpCmsip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip", "mbrmpoa_renewed_gold_ms_ip",
        "mbrmpoa_renewed_platinum_ms_ip", "mbrmpoa_renewed_total_ms_ip")

    val ipSgpCmsipBrz = ipSgpCmsipData.alias("bsg").join(mbrmpoa_renewed_bronze_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
        col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_bronze_ms_ip"), col("mbrmpoa_renewed_silver_ms_ip"), col("mbrmpoa_renewed_gold_ms_ip"),
        col("mbrmpoa_renewed_platinum_ms_ip"), col("mbrmpoa_renewed_total_ms_ip"), col("mbrmpoa_renewed_bronze_ms_sgp"))

    val ipSgpCmsipBrzData = ipSgpCmsipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip", "mbrmpoa_renewed_gold_ms_ip",
        "mbrmpoa_renewed_platinum_ms_ip", "mbrmpoa_renewed_total_ms_ip", "mbrmpoa_renewed_bronze_ms_sgp")

    val ipSgpCmsipbSil = ipSgpCmsipBrzData.alias("bsg").join(mbrmpoa_renewed_silver_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
        col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_bronze_ms_ip"), col("mbrmpoa_renewed_silver_ms_ip"), col("mbrmpoa_renewed_gold_ms_ip"),
        col("mbrmpoa_renewed_platinum_ms_ip"), col("mbrmpoa_renewed_total_ms_ip"), col("mbrmpoa_renewed_bronze_ms_sgp"), col("mbrmpoa_renewed_silver_ms_sgp"))

    val ipSgpCmsipbSilData = ipSgpCmsipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip", "mbrmpoa_renewed_gold_ms_ip",
        "mbrmpoa_renewed_platinum_ms_ip", "mbrmpoa_renewed_total_ms_ip", "mbrmpoa_renewed_bronze_ms_sgp", "mbrmpoa_renewed_silver_ms_sgp")

    val ipSgpCmsipbsGld = ipSgpCmsipbSilData.alias("bsg").join(mbrmpoa_renewed_gold_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
        col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_bronze_ms_ip"), col("mbrmpoa_renewed_silver_ms_ip"), col("mbrmpoa_renewed_gold_ms_ip"),
        col("mbrmpoa_renewed_platinum_ms_ip"), col("mbrmpoa_renewed_total_ms_ip"), col("mbrmpoa_renewed_bronze_ms_sgp"), col("mbrmpoa_renewed_silver_ms_sgp"), col("mbrmpoa_renewed_gold_ms_sgp"))

    val ipSgpCmsipbsGldData = ipSgpCmsipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip", "mbrmpoa_renewed_gold_ms_ip",
        "mbrmpoa_renewed_platinum_ms_ip", "mbrmpoa_renewed_total_ms_ip", "mbrmpoa_renewed_bronze_ms_sgp", "mbrmpoa_renewed_silver_ms_sgp", "mbrmpoa_renewed_gold_ms_sgp")

    val ipSgpCmsipbsgPlt = ipSgpCmsipbsGldData.alias("bsg").join(mbrmpoa_renewed_platinum_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
        col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_bronze_ms_ip"), col("mbrmpoa_renewed_silver_ms_ip"), col("mbrmpoa_renewed_gold_ms_ip"),
        col("mbrmpoa_renewed_platinum_ms_ip"), col("mbrmpoa_renewed_total_ms_ip"), col("mbrmpoa_renewed_bronze_ms_sgp"), col("mbrmpoa_renewed_silver_ms_sgp"), col("mbrmpoa_renewed_gold_ms_sgp"),
        col("mbrmpoa_renewed_platinum_ms_sgp"))

    val ipSgpCmsipbsgPltData = ipSgpCmsipbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip", "mbrmpoa_renewed_gold_ms_ip",
        "mbrmpoa_renewed_platinum_ms_ip", "mbrmpoa_renewed_total_ms_ip", "mbrmpoa_renewed_bronze_ms_sgp", "mbrmpoa_renewed_silver_ms_sgp", "mbrmpoa_renewed_gold_ms_sgp",
        "mbrmpoa_renewed_platinum_ms_sgp")

    val getTotal_ms_sgp = mbrmpoa_renewed_bronze_ms_sgp.union(mbrmpoa_renewed_silver_ms_sgp.union(mbrmpoa_renewed_gold_ms_sgp.union(mbrmpoa_renewed_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrmpoa_renewed_bronze_ms_sgp")

    val mbrmpoa_renewed_total_ms_sgp = getTotal_ms_sgp.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum($"mbrmpoa_renewed_bronze_ms_sgp").alias("mbrmpoa_renewed_total_ms_sgp")).withColumn("mbrmpoa_renewed_total_ms_sgp", $"mbrmpoa_renewed_total_ms_sgp".cast(IntegerType))

    val ipSgpCmsipmsSgp = ipSgpCmsipbsgPltData.alias("bsg").join(mbrmpoa_renewed_total_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_bronze_ip"), col("mbrmpoa_renewed_silver_ip"), col("mbrmpoa_renewed_gold_ip"), col("mbrmpoa_renewed_platinum_ip"),
        col("mbrmpoa_renewed_total_ip"), col("mbrmpoa_renewed_bronze_sgp"), col("mbrmpoa_renewed_silver_sgp"), col("mbrmpoa_renewed_gold_sgp"), col("mbrmpoa_renewed_platinum_sgp"),
        col("mbrmpoa_renewed_total_sgp"), col("mbrmpoa_renewed_catastrophic"), col("mbrmpoa_renewed_bronze_ms_ip"), col("mbrmpoa_renewed_silver_ms_ip"), col("mbrmpoa_renewed_gold_ms_ip"),
        col("mbrmpoa_renewed_platinum_ms_ip"), col("mbrmpoa_renewed_total_ms_ip"), col("mbrmpoa_renewed_bronze_ms_sgp"), col("mbrmpoa_renewed_silver_ms_sgp"), col("mbrmpoa_renewed_gold_ms_sgp"),
        col("mbrmpoa_renewed_platinum_ms_sgp"), col("mbrmpoa_renewed_total_ms_sgp"))

    val finalData = ipSgpCmsipmsSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip", "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp", "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip", "mbrmpoa_renewed_gold_ms_ip",
        "mbrmpoa_renewed_platinum_ms_ip", "mbrmpoa_renewed_total_ms_ip", "mbrmpoa_renewed_bronze_ms_sgp", "mbrmpoa_renewed_silver_ms_sgp", "mbrmpoa_renewed_gold_ms_sgp",
        "mbrmpoa_renewed_platinum_ms_sgp", "mbrmpoa_renewed_total_ms_sgp")

    finalData

  }

  def getMemberIssuedData(naic2018_mcas_hlthex_poa_wrk: DataFrame, naic2018_mcas_hlthex_poag_wrk: DataFrame): DataFrame = {

    var mmissued_wrk = naic2018_mcas_hlthex_poa_wrk.withColumn("Const_date", lit(mmissue_const_date))
    var mmissued_poag_wrk = naic2018_mcas_hlthex_poag_wrk.withColumn("Const_date", lit(mmissue_const_date))

    mmissued_wrk.withColumn("Const_date", to_date($"Const_date"))
    mmissued_poag_wrk.withColumn("Const_date", to_date($"Const_date"))

    //val c4 = tdf.select(col("id"),col("strt").cast(DateType),col("end").cast(DateType))
    val mbrmpoa_issued_bronze_ip = mmissued_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      (naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
      (naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("04") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(
        when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_bronze_ip_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_bronze_ip_1").alias("mbrmpoa_issued_bronze_ip")).withColumn("mbrmpoa_issued_bronze_ip", round($"mbrmpoa_issued_bronze_ip", 0).cast(IntegerType))

    val mbrmpoa_issued_silver_ip = mmissued_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      (naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
      (naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("03") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(
        when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_silver_ip_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_silver_ip_1").alias("mbrmpoa_issued_silver_ip")).withColumn("mbrmpoa_issued_silver_ip", round($"mbrmpoa_issued_silver_ip", 0).cast(IntegerType))

    val brSil = mbrmpoa_issued_bronze_ip.alias("bsg").join(mbrmpoa_issued_silver_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip")

    val mbrmpoa_issued_gold_ip = mmissued_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      (naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
      (naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("02") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      //.withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(
        when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_gold_ip_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_gold_ip_1").alias("mbrmpoa_issued_gold_ip")).withColumn("mbrmpoa_issued_gold_ip", round($"mbrmpoa_issued_gold_ip", 0).cast(IntegerType))

    val bsGld = brSilData.alias("bsg").join(mbrmpoa_issued_gold_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"))

    val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip")

    val mbrmpoa_issued_platinum_ip = mmissued_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      (naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
      (naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("01") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      // .withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(
        when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_platinum_ip_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_platinum_ip_1").alias("mbrmpoa_issued_platinum_ip")).withColumn("mbrmpoa_issued_platinum_ip", round($"mbrmpoa_issued_platinum_ip", 0).cast(IntegerType))

    val bsgPlt = bsGldData.alias("bsg").join(mbrmpoa_issued_platinum_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"))

    val bsgPltData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip")

    val getTotal_ip = mbrmpoa_issued_bronze_ip.union(mbrmpoa_issued_silver_ip.union(mbrmpoa_issued_gold_ip.union(mbrmpoa_issued_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrmpoa_issued_bronze_ip")

    val mbrmpoa_issued_total_ip = getTotal_ip.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum($"mbrmpoa_issued_bronze_ip").alias("mbrmpoa_issued_total_ip")).withColumn("mbrmpoa_issued_total_ip", round($"mbrmpoa_issued_total_ip", 0).cast(IntegerType))

    val ip = bsgPltData.alias("bsg").join(mbrmpoa_issued_total_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"))

    val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip")

    val mbrmpoa_issued_bronze_sgp = mmissued_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
      (naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
      naic2018_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
      (naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
      naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("04") &&
      naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      // .withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(
        when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_bronze_sgp_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_bronze_sgp_1").alias("mbrmpoa_issued_bronze_sgp")).withColumn("mbrmpoa_issued_bronze_sgp", round($"mbrmpoa_issued_bronze_sgp", 0).cast(IntegerType))

    val ipBrz = ipData.alias("bsg").join(mbrmpoa_issued_bronze_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"), $"plt.in_exchange".alias("s_inx"),
        col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"))

    val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp")

    /*  val mbrmpoa_issued_silver_sgp = naic_mcas_hlthex_poa_wrk.filter(naic_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
     |                                     (naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull )  &&
     |                                     (naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") ||  naic_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull)  &&
     |                                     naic_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("3") &&
     |                                     naic_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN")).withColumn("Member_Months", months_between(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT","MM/dd/yyyy").cast(DateType), to_date($"MBR_PROD_ENRLMNT_EFCTV_DT", "MM/dd/yyyy").cast(DateType)))
							 */
    val mbrmpoa_issued_silver_sgp = mmissued_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
      (naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
      naic2018_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
      (naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
      naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("03") &&
      naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      // .withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(
        when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_silver_sgp_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_silver_sgp_1").alias("mbrmpoa_issued_silver_sgp")).withColumn("mbrmpoa_issued_silver_sgp", round($"mbrmpoa_issued_silver_sgp", 0).cast(IntegerType))

    val ipbSil = ipBrzData.alias("bsg").join(mbrmpoa_issued_silver_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"))

    val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp")

    val mbrmpoa_issued_gold_sgp = mmissued_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
      (naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
      naic2018_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
      (naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
      naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("02") &&
      naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      // .withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(
        when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_gold_sgp_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_gold_sgp_1").alias("mbrmpoa_issued_gold_sgp")).withColumn("mbrmpoa_issued_gold_sgp", round($"mbrmpoa_issued_gold_sgp", 0).cast(IntegerType))

    val ipbsGld = ipbSilData.alias("bsg").join(mbrmpoa_issued_gold_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"))

    val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp")

    val mbrmpoa_issued_platinum_sgp = mmissued_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
      (naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
      naic2018_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
      (naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
      naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("01") &&
      naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      // .withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(
        when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_platinum_sgp_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_platinum_sgp_1").alias("mbrmpoa_issued_platinum_sgp")).withColumn("mbrmpoa_issued_platinum_sgp", round($"mbrmpoa_issued_platinum_sgp", 0).cast(IntegerType))

    val ipbsgPlt = ipbsGldData.alias("bsg").join(mbrmpoa_issued_platinum_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"))

    val ipbsgPltData = ipbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp")

    val getTotal_sgp = mbrmpoa_issued_bronze_sgp.union(mbrmpoa_issued_silver_sgp.union(mbrmpoa_issued_gold_sgp.union(mbrmpoa_issued_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrmpoa_issued_bronze_sgp")

    val mbrmpoa_issued_total_sgp = getTotal_sgp.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum($"mbrmpoa_issued_bronze_sgp").alias("mbrmpoa_issued_total_sgp")).withColumn("mbrmpoa_issued_total_sgp", round($"mbrmpoa_issued_total_sgp", 0).cast(IntegerType))

    val ipsgp = ipbsgPltData.alias("bsg").join(mbrmpoa_issued_total_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
        col("mbrmpoa_issued_total_sgp"))

    val ipsgpData = ipsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp")

    val mbrmpoa_issued_catastrophic = mmissued_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_prod_desc").like("%CATASTROPHIC%") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      //						.withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType),
      //								$"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD",
        $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT")
      .agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_catastrophic_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_catastrophic_1").alias("mbrmpoa_issued_catastrophic")).withColumn("mbrmpoa_issued_catastrophic", round($"mbrmpoa_issued_catastrophic", 0).cast(IntegerType))

    val ipsgpCat = ipsgpData.alias("bsg").join(mbrmpoa_issued_catastrophic.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
        col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_catastrophic"))

    val ipsgpCatData = ipsgpCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic")

    val mbrmpoa_issued_bronze_ms_ip = mmissued_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").equalTo("M") &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("04") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      // .withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(
        when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_bronze_ms_ip_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_bronze_ms_ip_1").alias("mbrmpoa_issued_bronze_ms_ip")).withColumn("mbrmpoa_issued_bronze_ms_ip", round($"mbrmpoa_issued_bronze_ms_ip", 0).cast(IntegerType))

    val ipsgpcBrz = ipsgpCatData.alias("bsg").join(mbrmpoa_issued_bronze_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
        col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_catastrophic"), col("mbrmpoa_issued_bronze_ms_ip"))

    val ipsgpcBrzData = ipsgpcBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip")

    val mbrmpoa_issued_silver_ms_ip = mmissued_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").equalTo("M") &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("03") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      // .withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(
        when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_silver_ms_ip_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_silver_ms_ip_1").alias("mbrmpoa_issued_silver_ms_ip")).withColumn("mbrmpoa_issued_silver_ms_ip", round($"mbrmpoa_issued_silver_ms_ip", 0).cast(IntegerType))

    val ipsgpcbSil = ipsgpcBrzData.alias("bsg").join(mbrmpoa_issued_silver_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
        col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_catastrophic"), col("mbrmpoa_issued_bronze_ms_ip"), col("mbrmpoa_issued_silver_ms_ip"))

    val ipsgpcbSilData = ipsgpcbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip")

    val mbrmpoa_issued_gold_ms_ip = mmissued_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").equalTo("M") &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("02") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      // .withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_gold_ms_ip_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_gold_ms_ip_1").alias("mbrmpoa_issued_gold_ms_ip")).withColumn("mbrmpoa_issued_gold_ms_ip", round($"mbrmpoa_issued_gold_ms_ip", 0).cast(IntegerType))

    val ipsgpcbsGld = ipsgpcbSilData.alias("bsg").join(mbrmpoa_issued_gold_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
        col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_catastrophic"), col("mbrmpoa_issued_bronze_ms_ip"), col("mbrmpoa_issued_silver_ms_ip"),
        col("mbrmpoa_issued_gold_ms_ip"))

    val ipsgpcbsGldData = ipsgpcbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip")

    val mbrmpoa_issued_platinum_ms_ip = mmissued_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").equalTo("M") &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("01") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      // .withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_platinum_ms_ip_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_platinum_ms_ip_1").alias("mbrmpoa_issued_platinum_ms_ip")).withColumn("mbrmpoa_issued_platinum_ms_ip", round($"mbrmpoa_issued_platinum_ms_ip", 0).cast(IntegerType))
    val ipsgpcbsgPlt = ipsgpcbsGldData.alias("bsg").join(mbrmpoa_issued_platinum_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
        col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_catastrophic"), col("mbrmpoa_issued_bronze_ms_ip"), col("mbrmpoa_issued_silver_ms_ip"),
        col("mbrmpoa_issued_gold_ms_ip"), col("mbrmpoa_issued_platinum_ms_ip"))

    val ipsgpcbsgPltData = ipsgpcbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip",
        "mbrmpoa_issued_platinum_ms_ip")

    val getTotal_ms_ip = mbrmpoa_issued_bronze_ms_ip.union(mbrmpoa_issued_silver_ms_ip.union(mbrmpoa_issued_gold_ms_ip.union(mbrmpoa_issued_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrmpoa_issued_bronze_ms_ip")
    val mbrmpoa_issued_total_ms_ip = getTotal_ms_ip.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum($"mbrmpoa_issued_bronze_ms_ip").alias("mbrmpoa_issued_total_ms_ip")).withColumn("mbrmpoa_issued_total_ms_ip", round($"mbrmpoa_issued_total_ms_ip", 0).cast(IntegerType))

    val ipsgpmsip = ipsgpcbsgPltData.alias("bsg").join(mbrmpoa_issued_total_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
        col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_catastrophic"), col("mbrmpoa_issued_bronze_ms_ip"), col("mbrmpoa_issued_silver_ms_ip"),
        col("mbrmpoa_issued_gold_ms_ip"), col("mbrmpoa_issued_platinum_ms_ip"), col("mbrmpoa_issued_total_ms_ip"))

    val ipsgpmsipData = ipsgpmsip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip",
        "mbrmpoa_issued_platinum_ms_ip", "mbrmpoa_issued_total_ms_ip")

    val mbrmpoa_issued_bronze_ms_sgp = mmissued_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
      naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").equalTo("M") &&
      naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("04") &&
      naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      // .withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_bronze_ms_sgp_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_bronze_ms_sgp_1").alias("mbrmpoa_issued_bronze_ms_sgp")).withColumn("mbrmpoa_issued_bronze_ms_sgp", round($"mbrmpoa_issued_bronze_ms_sgp", 0).cast(IntegerType))

    val ipsgpmsipBrz = ipsgpmsipData.alias("bsg").join(mbrmpoa_issued_bronze_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
        col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_catastrophic"), col("mbrmpoa_issued_bronze_ms_ip"), col("mbrmpoa_issued_silver_ms_ip"),
        col("mbrmpoa_issued_silver_ms_ip"), col("mbrmpoa_issued_gold_ms_ip"), col("mbrmpoa_issued_platinum_ms_ip"), col("mbrmpoa_issued_total_ms_ip"),
        col("mbrmpoa_issued_bronze_ms_sgp"))

    val ipsgpmsipBrzData = ipsgpmsipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip",
        "mbrmpoa_issued_platinum_ms_ip", "mbrmpoa_issued_total_ms_ip", "mbrmpoa_issued_bronze_ms_sgp")

    val mbrmpoa_issued_silver_ms_sgp = mmissued_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
      naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").equalTo("M") &&
      naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("03") &&
      naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      // .withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_silver_ms_sgp_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_silver_ms_sgp_1").alias("mbrmpoa_issued_silver_ms_sgp")).withColumn("mbrmpoa_issued_silver_ms_sgp", round($"mbrmpoa_issued_silver_ms_sgp", 0).cast(IntegerType))
    val ipsgpmsipbSil = ipsgpmsipBrzData.alias("bsg").join(mbrmpoa_issued_silver_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
        col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_catastrophic"), col("mbrmpoa_issued_bronze_ms_ip"), col("mbrmpoa_issued_silver_ms_ip"),
        col("mbrmpoa_issued_gold_ms_ip"), col("mbrmpoa_issued_platinum_ms_ip"), col("mbrmpoa_issued_total_ms_ip"),
        col("mbrmpoa_issued_bronze_ms_sgp"), col("mbrmpoa_issued_silver_ms_sgp"))

    val ipsgpmsipbSilData = ipsgpmsipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip",
        "mbrmpoa_issued_platinum_ms_ip", "mbrmpoa_issued_total_ms_ip", "mbrmpoa_issued_bronze_ms_sgp", "mbrmpoa_issued_silver_ms_sgp")

    val mbrmpoa_issued_gold_ms_sgp = mmissued_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
      naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").equalTo("M") &&
      naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("02") &&
      naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      // .withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_gold_ms_sgp_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_gold_ms_sgp_1").alias("mbrmpoa_issued_gold_ms_sgp")).withColumn("mbrmpoa_issued_gold_ms_sgp", round($"mbrmpoa_issued_gold_ms_sgp", 0).cast(IntegerType))

    val ipsgpmsipbsGld = ipsgpmsipbSilData.alias("bsg").join(mbrmpoa_issued_gold_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
        col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_catastrophic"), col("mbrmpoa_issued_bronze_ms_ip"), col("mbrmpoa_issued_silver_ms_ip"),
        col("mbrmpoa_issued_gold_ms_ip"), col("mbrmpoa_issued_platinum_ms_ip"), col("mbrmpoa_issued_total_ms_ip"),
        col("mbrmpoa_issued_bronze_ms_sgp"), col("mbrmpoa_issued_silver_ms_sgp"), col("mbrmpoa_issued_gold_ms_sgp"))

    val ipsgpmsipbsGldData = ipsgpmsipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip",
        "mbrmpoa_issued_platinum_ms_ip", "mbrmpoa_issued_total_ms_ip", "mbrmpoa_issued_bronze_ms_sgp", "mbrmpoa_issued_silver_ms_sgp",
        "mbrmpoa_issued_gold_ms_sgp")

    val mbrmpoa_issued_platinum_ms_sgp = mmissued_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
      naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").equalTo("M") &&
      naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("01") &&
      naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      // .withColumn("Member_Months", months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT".cast(DateType), $"MBR_PROD_ENRLMNT_EFCTV_DT".cast(DateType)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"SBSCRBR_ID", $"Const_date", $"MBR_RLTNSHP_CD", $"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT").agg(when(to_date($"MBR_PROD_ENRLMNT_TRMNTN_DT").gt(lit(mmissue_const_date)), round(months_between($"Const_date", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).otherwise(round(months_between($"MBR_PROD_ENRLMNT_TRMNTN_DT", $"MBR_PROD_ENRLMNT_EFCTV_DT"),0)).alias("mbrmpoa_issued_platinum_ms_sgp_1"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("mbrmpoa_issued_platinum_ms_sgp_1").alias("mbrmpoa_issued_platinum_ms_sgp")).withColumn("mbrmpoa_issued_platinum_ms_sgp", round($"mbrmpoa_issued_platinum_ms_sgp", 0).cast(IntegerType))

    val ipsgpmsipbsgPlt = ipsgpmsipbsGldData.alias("bsg").join(mbrmpoa_issued_platinum_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
        col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_catastrophic"), col("mbrmpoa_issued_bronze_ms_ip"), col("mbrmpoa_issued_silver_ms_ip"),
        col("mbrmpoa_issued_gold_ms_ip"), col("mbrmpoa_issued_platinum_ms_ip"), col("mbrmpoa_issued_total_ms_ip"),
        col("mbrmpoa_issued_bronze_ms_sgp"), col("mbrmpoa_issued_silver_ms_sgp"), col("mbrmpoa_issued_gold_ms_sgp"), col("mbrmpoa_issued_platinum_ms_sgp"))

    val ipsgpmsipbsgPltData = ipsgpmsipbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip",
        "mbrmpoa_issued_platinum_ms_ip", "mbrmpoa_issued_total_ms_ip", "mbrmpoa_issued_bronze_ms_sgp", "mbrmpoa_issued_silver_ms_sgp",
        "mbrmpoa_issued_gold_ms_sgp", "mbrmpoa_issued_platinum_ms_sgp")

    val getTotal_ms_sgp = mbrmpoa_issued_bronze_ms_sgp.union(mbrmpoa_issued_silver_ms_sgp.union(mbrmpoa_issued_gold_ms_sgp.union(mbrmpoa_issued_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrmpoa_issued_bronze_ms_sgp")
    val mbrmpoa_issued_total_ms_sgp = getTotal_ms_sgp.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum($"mbrmpoa_issued_bronze_ms_sgp").alias("mbrmpoa_issued_total_ms_sgp")).withColumn("mbrmpoa_issued_total_ms_sgp", round($"mbrmpoa_issued_total_ms_sgp", 0).cast(IntegerType))
    val ipsgpmsipmssgp = ipsgpmsipbsgPltData.alias("bsg").join(mbrmpoa_issued_total_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col("mbrmpoa_issued_bronze_ip"), col("mbrmpoa_issued_silver_ip"), col("mbrmpoa_issued_gold_ip"), col("mbrmpoa_issued_platinum_ip"),
        col("mbrmpoa_issued_total_ip"), col("mbrmpoa_issued_bronze_sgp"), col("mbrmpoa_issued_silver_sgp"), col("mbrmpoa_issued_gold_sgp"), col("mbrmpoa_issued_platinum_sgp"),
        col("mbrmpoa_issued_total_sgp"), col("mbrmpoa_issued_catastrophic"), col("mbrmpoa_issued_bronze_ms_ip"), col("mbrmpoa_issued_silver_ms_ip"),
        col("mbrmpoa_issued_gold_ms_ip"), col("mbrmpoa_issued_platinum_ms_ip"), col("mbrmpoa_issued_total_ms_ip"),
        col("mbrmpoa_issued_bronze_ms_sgp"), col("mbrmpoa_issued_silver_ms_sgp"), col("mbrmpoa_issued_gold_ms_sgp"), col("mbrmpoa_issued_platinum_ms_sgp"),
        col("mbrmpoa_issued_total_ms_sgp"))

    val finalData = ipsgpmsipmssgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip",
        "mbrmpoa_issued_platinum_ms_ip", "mbrmpoa_issued_total_ms_ip", "mbrmpoa_issued_bronze_ms_sgp", "mbrmpoa_issued_silver_ms_sgp",
        "mbrmpoa_issued_gold_ms_sgp", "mbrmpoa_issued_platinum_ms_sgp", "mbrmpoa_issued_total_ms_sgp")
    finalData

  }

  def getTermedLivesData(naic2018_mcas_hlthex_poa_wrk: DataFrame, naic2018_mcas_hlthex_poag_wrk: DataFrame, typeOfData: String): DataFrame = {

    val nbrpoa_bronze_ip = "nbrpoa_" + typeOfData + "_bronze_ip"
    val nbrpoa_termed_nonpay_lives_bronze_ip = naic2018_mcas_hlthex_poa_wrk
      .filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        (naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("04") &&
        naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_bronze_ip))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_bronze_ip).alias(nbrpoa_bronze_ip))

    val nbrpoa_silver_ip = "nbrpoa_" + typeOfData + "_silver_ip"
    val nbrpoa_termed_nonpay_lives_silver_ip = naic2018_mcas_hlthex_poa_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      (naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
      (naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("03") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_silver_ip))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_silver_ip).alias(nbrpoa_silver_ip))
    val brSil = nbrpoa_termed_nonpay_lives_bronze_ip.alias("bronze").join(nbrpoa_termed_nonpay_lives_silver_ip.alias("silver"), $"bronze.health_year" === $"silver.health_year"
      && $"bronze.cmpny_cf_cd" === $"silver.cmpny_cf_cd" && $"bronze.state" === $"silver.state" && $"bronze.in_exchange" === $"silver.in_exchange", "outer")
      .select($"bronze.health_year".alias("b_year"), $"silver.health_year".alias("s_year"),
        $"bronze.cmpny_cf_cd".alias("b_cmpny"), $"silver.cmpny_cf_cd".alias("s_cmpny"), $"bronze.state".alias("b_state"),
        $"silver.state".alias("s_state"), $"bronze.in_exchange".alias("b_inx"),
        $"silver.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip)
    val nbrpoa_gold_ip = "nbrpoa_" + typeOfData + "_gold_ip"
    val nbrpoa_termed_nonpay_lives_gold_ip = naic2018_mcas_hlthex_poa_wrk
      .filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        (naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("02") &&
        naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_gold_ip))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_gold_ip).alias(nbrpoa_gold_ip))
    val bsGold = brSilData.alias("brsil").join(nbrpoa_termed_nonpay_lives_gold_ip.alias("gold"), $"brsil.health_year" === $"gold.health_year"
      && $"brsil.cmpny_cf_cd" === $"gold.cmpny_cf_cd" && $"brsil.state" === $"gold.state" && $"brsil.in_exchange" === $"gold.in_exchange", "outer")
      .select($"brsil.health_year".alias("b_year"), $"gold.health_year".alias("s_year"),
        $"brsil.cmpny_cf_cd".alias("b_cmpny"), $"gold.cmpny_cf_cd".alias("s_cmpny"), $"brsil.state".alias("b_state"),
        $"gold.state".alias("s_state"), $"brsil.in_exchange".alias("b_inx"),
        $"gold.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip))

    val bsGoldData = bsGold.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip)

    val nbrpoa_platinum_ip = "nbrpoa_" + typeOfData + "_platinum_ip"
    val nbrpoa_termed_nonpay_lives_platinum_ip = naic2018_mcas_hlthex_poa_wrk
      .filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        (naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("01") &&
        naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_platinum_ip))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_platinum_ip).alias(nbrpoa_platinum_ip))
    val bsgPlt = bsGoldData.alias("bsg").join(nbrpoa_termed_nonpay_lives_platinum_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip))

    val bsgPltinumData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip)

    val nbrpoa_total_ip = "nbrpoa_" + typeOfData + "_total_ip"
    val getTotal_ip = nbrpoa_termed_nonpay_lives_bronze_ip.union(nbrpoa_termed_nonpay_lives_silver_ip.union(nbrpoa_termed_nonpay_lives_gold_ip.union(nbrpoa_termed_nonpay_lives_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col(nbrpoa_bronze_ip)).withColumn(nbrpoa_bronze_ip, col(nbrpoa_bronze_ip).cast(IntegerType))

    val nbrpoa_termed_nonpay_lives_total_ip = getTotal_ip.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum(col(nbrpoa_bronze_ip)).alias(nbrpoa_total_ip))

    val bsgpTot = bsgPltinumData.alias("bsg").join(nbrpoa_termed_nonpay_lives_total_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip))

    val ipTotData = bsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip)

    // SGP Columns
    val nbrpoa_bronze_sgp = "nbrpoa_" + typeOfData + "_bronze_sgp"
    val nbrpoa_termed_nonpay_lives_bronze_sgp = naic2018_mcas_hlthex_poag_wrk
      .filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        (naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("04") &&
        naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_bronze_sgp))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_bronze_sgp).alias(nbrpoa_bronze_sgp))

    val ipBrz = ipTotData.alias("bsg").join(nbrpoa_termed_nonpay_lives_bronze_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp))

    val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp)

    val nbrpoa_silver_sgp = "nbrpoa_" + typeOfData + "_silver_sgp"
    val nbrpoa_termed_nonpay_lives_silver_sgp = naic2018_mcas_hlthex_poag_wrk
      .filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        (naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("03") &&
        naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_silver_sgp))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_silver_sgp).alias(nbrpoa_silver_sgp))
    val ipbSil = ipBrzData.alias("bsg").join(nbrpoa_termed_nonpay_lives_silver_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp))

    val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp)

    val nbrpoa_gold_sgp = "nbrpoa_" + typeOfData + "_gold_sgp"
    val nbrpoa_termed_nonpay_lives_gold_sgp = naic2018_mcas_hlthex_poag_wrk
      .filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        (naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("02") &&
        naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_gold_sgp))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_gold_sgp).alias(nbrpoa_gold_sgp))
    val ipbsGld = ipbSilData.alias("bsg").join(nbrpoa_termed_nonpay_lives_gold_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp))

    val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp)

    val nbrpoa_platinum_sgp = "nbrpoa_" + typeOfData + "_platinum_sgp"
    val nbrpoa_termed_nonpay_lives_platimun_sgp = naic2018_mcas_hlthex_poag_wrk
      .filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        (naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
        naic2018_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
        (naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
        naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("01") &&
        naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_platinum_sgp))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_platinum_sgp).alias(nbrpoa_platinum_sgp))

    val ipbsgPlt = ipbsGldData.alias("bsg").join(nbrpoa_termed_nonpay_lives_platimun_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp))

    val ipbsgPltData = ipbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp)

    val nbrpoa_total_sgp = "nbrpoa_" + typeOfData + "_total_sgp"
    val getTotal_sgp = nbrpoa_termed_nonpay_lives_bronze_sgp.union(nbrpoa_termed_nonpay_lives_silver_sgp.union(nbrpoa_termed_nonpay_lives_gold_sgp.union(nbrpoa_termed_nonpay_lives_platimun_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col(nbrpoa_bronze_sgp)).withColumn(nbrpoa_bronze_sgp, col(nbrpoa_bronze_sgp).cast(IntegerType))

    val nbrpoa_termed_nonpay_lives_total_sgp = getTotal_sgp.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum(col(nbrpoa_bronze_sgp)).alias(nbrpoa_total_sgp))

    val ipbsgpTot = ipbsgPltData.alias("bsg").join(nbrpoa_termed_nonpay_lives_total_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp))

    val ipsgpData = ipbsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp)
    // ipsgpData.show()

    val nbrpoa_catastrophic = "nbrpoa_" + typeOfData + "_catastrophic"
    val nbrpoa_termed_nonpay_lives_catastrophic = naic2018_mcas_hlthex_poa_wrk
      .filter(naic2018_mcas_hlthex_poa_wrk("naic_prod_desc").like("%CATASTROPHIC%") &&
        naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_catastrophic))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_catastrophic).alias(nbrpoa_catastrophic))

    val ipsgpDatacat = ipsgpData.alias("bsg").join(nbrpoa_termed_nonpay_lives_catastrophic.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"), //nbrpoa_termed_lives_platinum_sgp
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp), col(nbrpoa_catastrophic))

    val ipsgpcatData = ipsgpDatacat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_catastrophic)

    val nbrpoa_bronze_ms_ip = "nbrpoa_" + typeOfData + "_bronze_ms_ip"
    val nbrpoa_termed_nonpay_lives_bronze_ms_ip = naic2018_mcas_hlthex_poa_wrk
      .filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("04") &&
        naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_bronze_ms_ip))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_bronze_ms_ip).alias(nbrpoa_bronze_ms_ip))

    val ipsgpcBrz = ipsgpcatData.alias("bsg").join(nbrpoa_termed_nonpay_lives_bronze_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp), col(nbrpoa_catastrophic),
        col(nbrpoa_bronze_ms_ip))

    val ipsgpcBrzData = ipsgpcBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_catastrophic,
        nbrpoa_bronze_ms_ip)

    val nbrpoa_silver_ms_ip = "nbrpoa_" + typeOfData + "_silver_ms_ip"
    val nbrpoa_termed_nonpay_lives_silver_ms_ip = naic2018_mcas_hlthex_poa_wrk
      .filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        //naic_mcas_hlthex_poa_wrk("grndfthrg_stts_cd").equalTo("Y") &&
        naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("03") &&
        naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_silver_ms_ip))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_silver_ms_ip).alias(nbrpoa_silver_ms_ip))

    val ipsgpcbSil = ipsgpcBrzData.alias("bsg").join(nbrpoa_termed_nonpay_lives_silver_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp), col(nbrpoa_catastrophic),
        col(nbrpoa_bronze_ms_ip), col(nbrpoa_silver_ms_ip))

    val ipsgpcbSilData = ipsgpcbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_catastrophic,
        nbrpoa_bronze_ms_ip, nbrpoa_silver_ms_ip)

    val nbrpoa_gold_ms_ip = "nbrpoa_" + typeOfData + "_gold_ms_ip"
    val nbrpoa_termed_nonpay_lives_gold_ms_ip = naic2018_mcas_hlthex_poa_wrk
      .filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        //naic_mcas_hlthex_poa_wrk("grndfthrg_stts_cd").equalTo("Y") &&
        naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("02") &&
        naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_gold_ms_ip))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_gold_ms_ip).alias(nbrpoa_gold_ms_ip))

    val ipsgpcbsGld = ipsgpcbSilData.alias("bsg").join(nbrpoa_termed_nonpay_lives_gold_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"), //nbrpoa_termed_lives_silver_ms_ip
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp), col(nbrpoa_catastrophic),
        col(nbrpoa_bronze_ms_ip), col(nbrpoa_silver_ms_ip), col(nbrpoa_gold_ms_ip))

    val ipsgpcbsGldData = ipsgpcbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_catastrophic,
        nbrpoa_bronze_ms_ip, nbrpoa_silver_ms_ip, nbrpoa_gold_ms_ip)

    val nbrpoa_platinum_ms_ip = "nbrpoa_" + typeOfData + "_platinum_ms_ip"
    val nbrpoa_termed_nonpay_lives_platinum_ms_ip = naic2018_mcas_hlthex_poa_wrk
      .filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
        naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("01") &&
        naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_platinum_ms_ip))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_platinum_ms_ip).alias(nbrpoa_platinum_ms_ip))

    val ipsgpcbsgPlt = ipsgpcbsGldData.alias("bsg").join(nbrpoa_termed_nonpay_lives_platinum_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp), col(nbrpoa_catastrophic),
        col(nbrpoa_bronze_ms_ip), col(nbrpoa_silver_ms_ip), col(nbrpoa_gold_ms_ip), col(nbrpoa_platinum_ms_ip))

    val ipsgpcbsgPltData = ipsgpcbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_catastrophic,
        nbrpoa_bronze_ms_ip, nbrpoa_silver_ms_ip, nbrpoa_gold_ms_ip, nbrpoa_platinum_ms_ip)

    val nbrpoa_total_ms_ip = "nbrpoa_" + typeOfData + "_total_ms_ip"

    val getTotal_ms_ip = nbrpoa_termed_nonpay_lives_bronze_ms_ip.union(nbrpoa_termed_nonpay_lives_silver_ms_ip.union(nbrpoa_termed_nonpay_lives_gold_ms_ip.union(nbrpoa_termed_nonpay_lives_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col(nbrpoa_bronze_ms_ip)).withColumn(nbrpoa_bronze_ms_ip, col(nbrpoa_bronze_ms_ip).cast(IntegerType))

    val nbrpoa_termed_nonpay_lives_total_ms_ip = getTotal_ms_ip.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum(col(nbrpoa_bronze_ms_ip)).alias(nbrpoa_total_ms_ip))

    val ipsgpcmsip = ipsgpcbsgPltData.alias("bsg").join(nbrpoa_termed_nonpay_lives_total_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp), col(nbrpoa_catastrophic),
        col(nbrpoa_bronze_ms_ip), col(nbrpoa_silver_ms_ip), col(nbrpoa_gold_ms_ip), col(nbrpoa_platinum_ms_ip), col(nbrpoa_total_ms_ip))

    val ipsgpcmsipData = ipsgpcmsip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_catastrophic,
        nbrpoa_bronze_ms_ip, nbrpoa_silver_ms_ip, nbrpoa_gold_ms_ip, nbrpoa_platinum_ms_ip, nbrpoa_total_ms_ip)

    //crct
    val nbrpoa_bronze_ms_sgp = "nbrpoa_" + typeOfData + "_bronze_ms_sgp"
    val nbrpoa_termed_nonpay_lives_bronze_ms_sgp = naic2018_mcas_hlthex_poag_wrk
      .filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("04") &&
        naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_bronze_ms_sgp))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_bronze_ms_sgp).alias(nbrpoa_bronze_ms_sgp))

    val ipsgpcmsipBrz = ipsgpcmsipData.alias("bsg").join(nbrpoa_termed_nonpay_lives_bronze_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp), col(nbrpoa_catastrophic),
        col(nbrpoa_bronze_ms_ip), col(nbrpoa_silver_ms_ip), col(nbrpoa_gold_ms_ip), col(nbrpoa_platinum_ms_ip), col(nbrpoa_total_ms_ip), col(nbrpoa_bronze_ms_sgp))

    val ipsgpcmsipBrzData = ipsgpcmsipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_catastrophic,
        nbrpoa_bronze_ms_ip, nbrpoa_silver_ms_ip, nbrpoa_gold_ms_ip, nbrpoa_platinum_ms_ip, nbrpoa_total_ms_ip, nbrpoa_bronze_ms_sgp)

    val nbrpoa_silver_ms_sgp = "nbrpoa_" + typeOfData + "_silver_ms_sgp"
    val nbrpoa_termed_nonpay_lives_silver_ms_sgp = naic2018_mcas_hlthex_poag_wrk
      .filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        //naic_mcas_hlthex_poa_wrk("grndfthrg_stts_cd").equalTo("Y") &&
        naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("03") &&
        naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_silver_ms_sgp))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_silver_ms_sgp).alias(nbrpoa_silver_ms_sgp))

    val ipsgpcmsipbSil = ipsgpcmsipBrzData.alias("bsg").join(nbrpoa_termed_nonpay_lives_silver_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp), col(nbrpoa_catastrophic),
        col(nbrpoa_bronze_ms_ip), col(nbrpoa_silver_ms_ip), col(nbrpoa_gold_ms_ip), col(nbrpoa_platinum_ms_ip), col(nbrpoa_total_ms_ip), col(nbrpoa_bronze_ms_sgp), col(nbrpoa_silver_ms_sgp))

    val ipsgpcmsipbSilData = ipsgpcmsipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_catastrophic,
        nbrpoa_bronze_ms_ip, nbrpoa_silver_ms_ip, nbrpoa_gold_ms_ip, nbrpoa_platinum_ms_ip, nbrpoa_total_ms_ip, nbrpoa_bronze_ms_sgp, nbrpoa_silver_ms_sgp)

    val nbrpoa_gold_ms_sgp = "nbrpoa_" + typeOfData + "_gold_ms_sgp"
    val nbrpoa_termed_nonpay_lives_gold_ms_sgp = naic2018_mcas_hlthex_poag_wrk
      .filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        //naic_mcas_hlthex_poa_wrk("grndfthrg_stts_cd").equalTo("Y") &&
        naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("02") &&
        naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_gold_ms_sgp))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_gold_ms_sgp).alias(nbrpoa_gold_ms_sgp))

    val ipsgpcmsipbsGld = ipsgpcmsipbSilData.alias("bsg").join(nbrpoa_termed_nonpay_lives_gold_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp), col(nbrpoa_catastrophic),
        col(nbrpoa_bronze_ms_ip), col(nbrpoa_silver_ms_ip), col(nbrpoa_gold_ms_ip), col(nbrpoa_platinum_ms_ip), col(nbrpoa_total_ms_ip), col(nbrpoa_bronze_ms_sgp), col(nbrpoa_silver_ms_sgp), col(nbrpoa_gold_ms_sgp))

    val ipsgpcmsipbsGldData = ipsgpcmsipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_catastrophic,
        nbrpoa_bronze_ms_ip, nbrpoa_silver_ms_ip, nbrpoa_gold_ms_ip, nbrpoa_platinum_ms_ip, nbrpoa_total_ms_ip, nbrpoa_bronze_ms_sgp, nbrpoa_silver_ms_sgp, nbrpoa_gold_ms_sgp)

    val nbrpoa_platinum_ms_sgp = "nbrpoa_" + typeOfData + "_platinum_ms_sgp"
    val nbrpoa_termed_nonpay_lives_platinum_ms_sgp = naic2018_mcas_hlthex_poag_wrk
      .filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
        naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").equalTo("M") &&
        naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("01") &&
        naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"sbscrbr_id", $"mbr_rltnshp_cd").agg((lit(1)).alias(nbrpoa_platinum_ms_sgp))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_platinum_ms_sgp).alias(nbrpoa_platinum_ms_sgp))

    val ipsgpcmsipbsgPlt = ipsgpcmsipbsGldData.alias("bsg").join(nbrpoa_termed_nonpay_lives_platinum_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp), col(nbrpoa_catastrophic),
        col(nbrpoa_bronze_ms_ip), col(nbrpoa_silver_ms_ip), col(nbrpoa_gold_ms_ip), col(nbrpoa_platinum_ms_ip), col(nbrpoa_total_ms_ip), col(nbrpoa_bronze_ms_sgp), col(nbrpoa_silver_ms_sgp), col(nbrpoa_gold_ms_sgp), col(nbrpoa_platinum_ms_sgp))

    val ipsgpcmsipbsgPltData = ipsgpcmsipbsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_catastrophic,
        nbrpoa_bronze_ms_ip, nbrpoa_silver_ms_ip, nbrpoa_gold_ms_ip, nbrpoa_platinum_ms_ip, nbrpoa_total_ms_ip, nbrpoa_bronze_ms_sgp, nbrpoa_silver_ms_sgp, nbrpoa_gold_ms_sgp, nbrpoa_platinum_ms_sgp)

    val nbrpoa_total_ms_sgp = "nbrpoa_" + typeOfData + "_total_ms_sgp"

    val getTotal_ms_sgp = nbrpoa_termed_nonpay_lives_bronze_ms_sgp.union(nbrpoa_termed_nonpay_lives_silver_ms_sgp.union(nbrpoa_termed_nonpay_lives_gold_ms_sgp.union(nbrpoa_termed_nonpay_lives_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col(nbrpoa_bronze_ms_sgp)).withColumn(nbrpoa_bronze_ms_sgp, col(nbrpoa_bronze_ms_sgp).cast(IntegerType)) //nbrpoa_termed_lives_bronze_ms_ip

    val nbrpoa_termed_nonpay_lives_total_ms_sgp = getTotal_ms_sgp.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum(col(nbrpoa_bronze_ms_sgp)).alias(nbrpoa_total_ms_sgp))

    val ipsgpcmsipsgp = ipsgpcmsipbsgPltData.alias("bsg").join(nbrpoa_termed_nonpay_lives_total_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp), col(nbrpoa_total_sgp), col(nbrpoa_catastrophic),
        col(nbrpoa_bronze_ms_ip), col(nbrpoa_silver_ms_ip), col(nbrpoa_gold_ms_ip), col(nbrpoa_platinum_ms_ip), col(nbrpoa_total_ms_ip), col(nbrpoa_bronze_ms_sgp),
        col(nbrpoa_silver_ms_sgp), col(nbrpoa_gold_ms_sgp), col(nbrpoa_platinum_ms_sgp), col(nbrpoa_total_ms_sgp))

    val FinalData = ipsgpcmsipsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp, nbrpoa_total_sgp, nbrpoa_catastrophic,
        nbrpoa_bronze_ms_ip, nbrpoa_silver_ms_ip, nbrpoa_gold_ms_ip, nbrpoa_platinum_ms_ip, nbrpoa_total_ms_ip, nbrpoa_bronze_ms_sgp, nbrpoa_silver_ms_sgp,
        nbrpoa_gold_ms_sgp, nbrpoa_platinum_ms_sgp, nbrpoa_total_ms_sgp)

    FinalData

  }

  def getIssuedData(naic2018_mcas_hlthex_poa_wrk: DataFrame, typeOfData: String): DataFrame = {
    // val finalIssuedDataDf;

    val nbrpoa_bronze_ip = "nbrpoa_" + typeOfData + "_bronze_ip"
    val nbrpoa_issued_bronze_ip = naic2018_mcas_hlthex_poa_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      (naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
      (naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("04") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_bronze_ip))

    val nbrpoa_silver_ip = "nbrpoa_" + typeOfData + "_silver_ip"
    val nbrpoa_issued_silver_ip = naic2018_mcas_hlthex_poa_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      (naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
      (naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("03") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_silver_ip))

    val brSil = nbrpoa_issued_bronze_ip.alias("bronze").join(nbrpoa_issued_silver_ip.alias("silver"), $"bronze.health_year" === $"silver.health_year"
      && $"bronze.cmpny_cf_cd" === $"silver.cmpny_cf_cd" && $"bronze.state" === $"silver.state" && $"bronze.in_exchange" === $"silver.in_exchange", "outer")
      .select($"bronze.health_year".alias("b_year"), $"silver.health_year".alias("s_year"),
        $"bronze.cmpny_cf_cd".alias("b_cmpny"), $"silver.cmpny_cf_cd".alias("s_cmpny"), $"bronze.state".alias("b_state"),
        $"silver.state".alias("s_state"), $"bronze.in_exchange".alias("b_inx"),
        $"silver.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip)

    val nbrpoa_gold_ip = "nbrpoa_" + typeOfData + "_gold_ip"
    val nbrpoa_issued_gold_ip = naic2018_mcas_hlthex_poa_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      (naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
      (naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("02") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_gold_ip))

    val bsGold = brSilData.alias("brsil").join(nbrpoa_issued_gold_ip.alias("gold"), $"brsil.health_year" === $"gold.health_year"
      && $"brsil.cmpny_cf_cd" === $"gold.cmpny_cf_cd" && $"brsil.state" === $"gold.state" && $"brsil.in_exchange" === $"gold.in_exchange", "outer")
      .select($"brsil.health_year".alias("b_year"), $"gold.health_year".alias("s_year"),
        $"brsil.cmpny_cf_cd".alias("b_cmpny"), $"gold.cmpny_cf_cd".alias("s_cmpny"), $"brsil.state".alias("b_state"),
        $"gold.state".alias("s_state"), $"brsil.in_exchange".alias("b_inx"),
        $"gold.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip))

    val bsGoldData = bsGold.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip)

    val nbrpoa_platinum_ip = "nbrpoa_" + typeOfData + "_platinum_ip"
    val nbrpoa_issued_platinum_ip = naic2018_mcas_hlthex_poa_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      (naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poa_wrk("grndfthr_ind_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("hcr_cmplynt_cd").equalTo("Y") &&
      (naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").isNull) &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("01") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_platinum_ip))

    val bsgPlt = bsGoldData.alias("bsg").join(nbrpoa_issued_platinum_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip))

    val bsgPltinumData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip)

    val nbrpoa_total_ip = "nbrpoa_" + typeOfData + "_total_ip"
    val getTotal_ip = nbrpoa_issued_bronze_ip.union(nbrpoa_issued_silver_ip.union(nbrpoa_issued_gold_ip.union(nbrpoa_issued_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col(nbrpoa_bronze_ip)).withColumn(nbrpoa_bronze_ip, col(nbrpoa_bronze_ip).cast(IntegerType))

    val nbrpoa_issued_total_ip = getTotal_ip.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum(col(nbrpoa_bronze_ip)).alias(nbrpoa_total_ip))

    val bsgpTot = bsgPltinumData.alias("bsg").join(nbrpoa_issued_total_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip))

    val bsgPTotData = bsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip)

    val nbrpoa_catastrophic = "nbrpoa_" + typeOfData + "_catastrophic"
    val nbrpoa_issued_catastrophic = naic2018_mcas_hlthex_poa_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_prod_desc").like("%CATASTROPHIC%") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_catastrophic))

    val bsgptCat = bsgPTotData.alias("bsg").join(nbrpoa_issued_catastrophic.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_catastrophic))

    val bsgptCatData = bsgptCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_catastrophic)

    val nbrpoa_bronze_ms_ip = "nbrpoa_" + typeOfData + "_bronze_ms_ip"
    val nbrpoa_issued_bronze_ms_ip = naic2018_mcas_hlthex_poa_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").equalTo("M") &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("04") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_bronze_ms_ip))

    val bsgptcBrz = bsgptCatData.alias("bsg").join(nbrpoa_issued_bronze_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_catastrophic), col(nbrpoa_bronze_ms_ip))

    val bsgptcBrzData = bsgptcBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_catastrophic, nbrpoa_bronze_ms_ip)

    val nbrpoa_silver_ms_ip = "nbrpoa_" + typeOfData + "_silver_ms_ip"
    val nbrpoa_issued_silver_ms_ip = naic2018_mcas_hlthex_poa_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").equalTo("M") &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("03") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_silver_ms_ip))

    val bsgptcbSil = bsgptcBrzData.alias("bsg").join(nbrpoa_issued_silver_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_catastrophic), col(nbrpoa_bronze_ms_ip), col(nbrpoa_silver_ms_ip))

    val bsgptcbSilData = bsgptcbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_catastrophic, nbrpoa_bronze_ms_ip, nbrpoa_silver_ms_ip)

    val nbrpoa_gold_ms_ip = "nbrpoa_" + typeOfData + "_gold_ms_ip"

    val nbrpoa_issued_gold_ms_ip = naic2018_mcas_hlthex_poa_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").equalTo("M") &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("02") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_gold_ms_ip))

    val bsgptcbsGold = bsgptcbSilData.alias("bsg").join(nbrpoa_issued_gold_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_catastrophic), col(nbrpoa_bronze_ms_ip), col(nbrpoa_silver_ms_ip), col(nbrpoa_gold_ms_ip))

    val bsgptcbsGoldData = bsgptcbsGold.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_catastrophic, nbrpoa_bronze_ms_ip, nbrpoa_silver_ms_ip, nbrpoa_gold_ms_ip)

    val nbrpoa_platinum_ms_ip = "nbrpoa_" + typeOfData + "_platinum_ms_ip"
    val nbrpoa_issued_platinum_ms_ip = naic2018_mcas_hlthex_poa_wrk.filter(naic2018_mcas_hlthex_poa_wrk("naic_lob").equalTo("TOTAL INDIVIDUAL CBE") &&
      naic2018_mcas_hlthex_poa_wrk("src_exchng_certfn_cd").equalTo("M") &&
      naic2018_mcas_hlthex_poa_wrk("exchng_metl_type_cd").equalTo("01") &&
      naic2018_mcas_hlthex_poa_wrk("in_exchange").equalTo("IN"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(countDistinct($"sbscrbr_id").alias(nbrpoa_platinum_ms_ip))

    val bsgptcbsfPlt = bsgptcbsGoldData.alias("bsg").join(nbrpoa_issued_platinum_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_catastrophic), col(nbrpoa_bronze_ms_ip), col(nbrpoa_silver_ms_ip), col(nbrpoa_gold_ms_ip),
        col(nbrpoa_platinum_ms_ip))

    val bsgptcbsfPltData = bsgptcbsfPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_catastrophic, nbrpoa_bronze_ms_ip, nbrpoa_silver_ms_ip, nbrpoa_gold_ms_ip, nbrpoa_platinum_ms_ip)
    //bsgptcbsfPltData.show()
    val nbrpoa_total_ms_ip = "nbrpoa_" + typeOfData + "_total_ms_ip"

    val getTotal_ms_ip = nbrpoa_issued_bronze_ms_ip.union(nbrpoa_issued_silver_ms_ip.union(nbrpoa_issued_gold_ms_ip.union(nbrpoa_issued_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col(nbrpoa_bronze_ms_ip)).withColumn(nbrpoa_bronze_ms_ip, col(nbrpoa_bronze_ms_ip).cast(IntegerType))

    val nbrpoa_issued_total_ms_ip = getTotal_ms_ip.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum(nbrpoa_bronze_ms_ip).alias(nbrpoa_total_ms_ip))

    val finalDat = bsgptcbsfPltData.alias("bsg").join(nbrpoa_issued_total_ms_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
      && $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
      .select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
        $"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
        $"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
        $"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_ip), col(nbrpoa_silver_ip), col(nbrpoa_gold_ip), col(nbrpoa_platinum_ip),
        col(nbrpoa_total_ip), col(nbrpoa_catastrophic), col(nbrpoa_bronze_ms_ip), col(nbrpoa_silver_ms_ip), col(nbrpoa_gold_ms_ip),
        col(nbrpoa_platinum_ms_ip), col(nbrpoa_total_ms_ip))

    val FinalData = finalDat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_ip, nbrpoa_silver_ip, nbrpoa_gold_ip, nbrpoa_platinum_ip,
        nbrpoa_total_ip, nbrpoa_catastrophic, nbrpoa_bronze_ms_ip, nbrpoa_silver_ms_ip, nbrpoa_gold_ms_ip, nbrpoa_platinum_ms_ip,
        nbrpoa_total_ms_ip)

    FinalData
  }
  def getStageData(issueFinalDf: DataFrame, rennewedFinalDf: DataFrame, mmissuedFinalDf: DataFrame, mmrenewedFinalDf: DataFrame, termedFinalDf: DataFrame, termed_nonpayFinalDf: DataFrame,
                   termed_livesFinalDf: DataFrame, termed_nonpay_livesFinalDf: DataFrame): DataFrame = {

    val issued_renewed = issueFinalDf.alias("parent").join(rennewedFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
        $"nbrpoa_issued_total_ip", $"nbrpoa_issued_catastrophic", $"nbrpoa_issued_bronze_ms_ip", $"nbrpoa_issued_silver_ms_ip",
        $"nbrpoa_issued_gold_ms_ip", $"nbrpoa_issued_platinum_ms_ip",
        $"nbrpoa_issued_total_ms_ip", $"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
        $"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_catastrophic", $"nbrpoa_renewed_bronze_ms_ip", $"nbrpoa_renewed_silver_ms_ip", $"nbrpoa_renewed_gold_ms_ip",
        $"nbrpoa_renewed_platinum_ms_ip", $"nbrpoa_renewed_total_ms_ip")

    val issued_renewedData = issued_renewed.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
        "nbrpoa_issued_total_ip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_bronze_ms_ip", "nbrpoa_issued_silver_ms_ip",
        "nbrpoa_issued_gold_ms_ip", "nbrpoa_issued_platinum_ms_ip",
        "nbrpoa_issued_total_ms_ip", "nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
        "nbrpoa_renewed_total_ip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_bronze_ms_ip", "nbrpoa_renewed_silver_ms_ip", "nbrpoa_renewed_gold_ms_ip",
        "nbrpoa_renewed_platinum_ms_ip", "nbrpoa_renewed_total_ms_ip") //26

    //issued_renewedData.show()
    //issued_renewedData
    //println("issued_renewedData.count() : "+issued_renewedData.count())
    val irMisused = issued_renewedData.alias("parent").join(mmissuedFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
        $"nbrpoa_issued_total_ip", $"nbrpoa_issued_catastrophic", $"nbrpoa_issued_bronze_ms_ip", $"nbrpoa_issued_silver_ms_ip",
        $"nbrpoa_issued_gold_ms_ip", $"nbrpoa_issued_platinum_ms_ip", $"nbrpoa_issued_total_ms_ip",
        $"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
        $"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_catastrophic", $"nbrpoa_renewed_bronze_ms_ip", $"nbrpoa_renewed_silver_ms_ip", $"nbrpoa_renewed_gold_ms_ip",
        $"nbrpoa_renewed_platinum_ms_ip", $"nbrpoa_renewed_total_ms_ip",
        $"mbrmpoa_issued_bronze_ip", $"mbrmpoa_issued_silver_ip", $"mbrmpoa_issued_gold_ip",
        $"mbrmpoa_issued_platinum_ip", $"mbrmpoa_issued_total_ip", $"mbrmpoa_issued_bronze_sgp", $"mbrmpoa_issued_silver_sgp", $"mbrmpoa_issued_gold_sgp", $"mbrmpoa_issued_platinum_sgp",
        $"mbrmpoa_issued_total_sgp", $"mbrmpoa_issued_catastrophic", $"mbrmpoa_issued_bronze_ms_ip", $"mbrmpoa_issued_silver_ms_ip", $"mbrmpoa_issued_gold_ms_ip",
        $"mbrmpoa_issued_platinum_ms_ip", $"mbrmpoa_issued_total_ms_ip", $"mbrmpoa_issued_bronze_ms_sgp", $"mbrmpoa_issued_silver_ms_sgp",
        $"mbrmpoa_issued_gold_ms_sgp", $"mbrmpoa_issued_platinum_ms_sgp", $"mbrmpoa_issued_total_ms_sgp")

    val irMisusedData = irMisused.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
        "nbrpoa_issued_total_ip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_bronze_ms_ip", "nbrpoa_issued_silver_ms_ip",
        "nbrpoa_issued_gold_ms_ip", "nbrpoa_issued_platinum_ms_ip",
        "nbrpoa_issued_total_ms_ip", "nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
        "nbrpoa_renewed_total_ip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_bronze_ms_ip", "nbrpoa_renewed_silver_ms_ip", "nbrpoa_renewed_gold_ms_ip",
        "nbrpoa_renewed_platinum_ms_ip", "nbrpoa_renewed_total_ms_ip", //26
        "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip",
        "mbrmpoa_issued_platinum_ms_ip", "mbrmpoa_issued_total_ms_ip", "mbrmpoa_issued_bronze_ms_sgp", "mbrmpoa_issued_silver_ms_sgp",
        "mbrmpoa_issued_gold_ms_sgp", "mbrmpoa_issued_platinum_ms_sgp", "mbrmpoa_issued_total_ms_sgp") //47

    val irmimrenew = irMisusedData.alias("parent").join(mmrenewedFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
        $"nbrpoa_issued_total_ip", $"nbrpoa_issued_catastrophic", $"nbrpoa_issued_bronze_ms_ip", $"nbrpoa_issued_silver_ms_ip",
        $"nbrpoa_issued_gold_ms_ip", $"nbrpoa_issued_platinum_ms_ip", $"nbrpoa_issued_total_ms_ip",
        $"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
        $"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_catastrophic", $"nbrpoa_renewed_bronze_ms_ip", $"nbrpoa_renewed_silver_ms_ip", $"nbrpoa_renewed_gold_ms_ip",
        $"nbrpoa_renewed_platinum_ms_ip", $"nbrpoa_renewed_total_ms_ip",
        $"mbrmpoa_issued_bronze_ip", $"mbrmpoa_issued_silver_ip", $"mbrmpoa_issued_gold_ip",
        $"mbrmpoa_issued_platinum_ip", $"mbrmpoa_issued_total_ip", $"mbrmpoa_issued_bronze_sgp", $"mbrmpoa_issued_silver_sgp", $"mbrmpoa_issued_gold_sgp", $"mbrmpoa_issued_platinum_sgp",
        $"mbrmpoa_issued_total_sgp", $"mbrmpoa_issued_catastrophic", $"mbrmpoa_issued_bronze_ms_ip", $"mbrmpoa_issued_silver_ms_ip", $"mbrmpoa_issued_gold_ms_ip",
        $"mbrmpoa_issued_platinum_ms_ip", $"mbrmpoa_issued_total_ms_ip", $"mbrmpoa_issued_bronze_ms_sgp", $"mbrmpoa_issued_silver_ms_sgp",
        $"mbrmpoa_issued_gold_ms_sgp", $"mbrmpoa_issued_platinum_ms_sgp", $"mbrmpoa_issued_total_ms_sgp",
        $"mbrmpoa_renewed_bronze_ip", $"mbrmpoa_renewed_silver_ip", $"mbrmpoa_renewed_gold_ip",
        $"mbrmpoa_renewed_platinum_ip", $"mbrmpoa_renewed_total_ip", $"mbrmpoa_renewed_bronze_sgp", $"mbrmpoa_renewed_silver_sgp", $"mbrmpoa_renewed_gold_sgp", $"mbrmpoa_renewed_platinum_sgp",
        $"mbrmpoa_renewed_total_sgp", $"mbrmpoa_renewed_catastrophic", $"mbrmpoa_renewed_bronze_ms_ip", $"mbrmpoa_renewed_silver_ms_ip", $"mbrmpoa_renewed_gold_ms_ip",
        $"mbrmpoa_renewed_platinum_ms_ip", $"mbrmpoa_renewed_total_ms_ip", $"mbrmpoa_renewed_bronze_ms_sgp", $"mbrmpoa_renewed_silver_ms_sgp",
        $"mbrmpoa_renewed_gold_ms_sgp", $"mbrmpoa_renewed_platinum_ms_sgp", $"mbrmpoa_renewed_total_ms_sgp")

    val irmimrenewData = irmimrenew.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
        "nbrpoa_issued_total_ip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_bronze_ms_ip", "nbrpoa_issued_silver_ms_ip",
        "nbrpoa_issued_gold_ms_ip", "nbrpoa_issued_platinum_ms_ip",
        "nbrpoa_issued_total_ms_ip", "nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
        "nbrpoa_renewed_total_ip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_bronze_ms_ip", "nbrpoa_renewed_silver_ms_ip", "nbrpoa_renewed_gold_ms_ip",
        "nbrpoa_renewed_platinum_ms_ip", "nbrpoa_renewed_total_ms_ip", //26
        "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip",
        "mbrmpoa_issued_platinum_ms_ip", "mbrmpoa_issued_total_ms_ip", "mbrmpoa_issued_bronze_ms_sgp", "mbrmpoa_issued_silver_ms_sgp",
        "mbrmpoa_issued_gold_ms_sgp", "mbrmpoa_issued_platinum_ms_sgp", "mbrmpoa_issued_total_ms_sgp", //47
        "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip",
        "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp",
        "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip", "mbrmpoa_renewed_gold_ms_ip",
        "mbrmpoa_renewed_platinum_ms_ip", "mbrmpoa_renewed_total_ms_ip", "mbrmpoa_renewed_bronze_ms_sgp", "mbrmpoa_renewed_silver_ms_sgp",
        "mbrmpoa_renewed_gold_ms_sgp", "mbrmpoa_renewed_platinum_ms_sgp", "mbrmpoa_renewed_total_ms_sgp") //68

    val irmimrterm = irmimrenewData.alias("parent").join(termedFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
        $"nbrpoa_issued_total_ip", $"nbrpoa_issued_catastrophic", $"nbrpoa_issued_bronze_ms_ip", $"nbrpoa_issued_silver_ms_ip",
        $"nbrpoa_issued_gold_ms_ip", $"nbrpoa_issued_platinum_ms_ip", $"nbrpoa_issued_total_ms_ip",
        $"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
        $"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_catastrophic", $"nbrpoa_renewed_bronze_ms_ip", $"nbrpoa_renewed_silver_ms_ip", $"nbrpoa_renewed_gold_ms_ip",
        $"nbrpoa_renewed_platinum_ms_ip", $"nbrpoa_renewed_total_ms_ip",
        $"mbrmpoa_issued_bronze_ip", $"mbrmpoa_issued_silver_ip", $"mbrmpoa_issued_gold_ip",
        $"mbrmpoa_issued_platinum_ip", $"mbrmpoa_issued_total_ip", $"mbrmpoa_issued_bronze_sgp", $"mbrmpoa_issued_silver_sgp", $"mbrmpoa_issued_gold_sgp", $"mbrmpoa_issued_platinum_sgp",
        $"mbrmpoa_issued_total_sgp", $"mbrmpoa_issued_catastrophic", $"mbrmpoa_issued_bronze_ms_ip", $"mbrmpoa_issued_silver_ms_ip", $"mbrmpoa_issued_gold_ms_ip",
        $"mbrmpoa_issued_platinum_ms_ip", $"mbrmpoa_issued_total_ms_ip", $"mbrmpoa_issued_bronze_ms_sgp", $"mbrmpoa_issued_silver_ms_sgp",
        $"mbrmpoa_issued_gold_ms_sgp", $"mbrmpoa_issued_platinum_ms_sgp", $"mbrmpoa_issued_total_ms_sgp",
        $"mbrmpoa_renewed_bronze_ip", $"mbrmpoa_renewed_silver_ip", $"mbrmpoa_renewed_gold_ip",
        $"mbrmpoa_renewed_platinum_ip", $"mbrmpoa_renewed_total_ip", $"mbrmpoa_renewed_bronze_sgp", $"mbrmpoa_renewed_silver_sgp", $"mbrmpoa_renewed_gold_sgp", $"mbrmpoa_renewed_platinum_sgp",
        $"mbrmpoa_renewed_total_sgp", $"mbrmpoa_renewed_catastrophic", $"mbrmpoa_renewed_bronze_ms_ip", $"mbrmpoa_renewed_silver_ms_ip", $"mbrmpoa_renewed_gold_ms_ip",
        $"mbrmpoa_renewed_platinum_ms_ip", $"mbrmpoa_renewed_total_ms_ip", $"mbrmpoa_renewed_bronze_ms_sgp", $"mbrmpoa_renewed_silver_ms_sgp",
        $"mbrmpoa_renewed_gold_ms_sgp", $"mbrmpoa_renewed_platinum_ms_sgp", $"mbrmpoa_renewed_total_ms_sgp",
        $"nbrpoa_termed_bronze_ip", $"nbrpoa_termed_silver_ip", $"nbrpoa_termed_gold_ip", $"nbrpoa_termed_platinum_ip",
        $"nbrpoa_termed_total_ip", $"nbrpoa_termed_catastrophic", $"nbrpoa_termed_bronze_ms_ip", $"nbrpoa_termed_silver_ms_ip",
        $"nbrpoa_termed_gold_ms_ip", $"nbrpoa_termed_platinum_ms_ip", $"nbrpoa_termed_total_ms_ip")

    val irmimrtermData = irmimrterm.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
        "nbrpoa_issued_total_ip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_bronze_ms_ip", "nbrpoa_issued_silver_ms_ip",
        "nbrpoa_issued_gold_ms_ip", "nbrpoa_issued_platinum_ms_ip",
        "nbrpoa_issued_total_ms_ip", "nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
        "nbrpoa_renewed_total_ip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_bronze_ms_ip", "nbrpoa_renewed_silver_ms_ip", "nbrpoa_renewed_gold_ms_ip",
        "nbrpoa_renewed_platinum_ms_ip", "nbrpoa_renewed_total_ms_ip", //26
        "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip",
        "mbrmpoa_issued_platinum_ms_ip", "mbrmpoa_issued_total_ms_ip", "mbrmpoa_issued_bronze_ms_sgp", "mbrmpoa_issued_silver_ms_sgp",
        "mbrmpoa_issued_gold_ms_sgp", "mbrmpoa_issued_platinum_ms_sgp", "mbrmpoa_issued_total_ms_sgp", //47
        "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip",
        "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp",
        "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip", "mbrmpoa_renewed_gold_ms_ip",
        "mbrmpoa_renewed_platinum_ms_ip", "mbrmpoa_renewed_total_ms_ip", "mbrmpoa_renewed_bronze_ms_sgp", "mbrmpoa_renewed_silver_ms_sgp",
        "mbrmpoa_renewed_gold_ms_sgp", "mbrmpoa_renewed_platinum_ms_sgp", "mbrmpoa_renewed_total_ms_sgp", //68
        "nbrpoa_termed_bronze_ip", "nbrpoa_termed_silver_ip", "nbrpoa_termed_gold_ip", "nbrpoa_termed_platinum_ip",
        "nbrpoa_termed_total_ip", "nbrpoa_termed_catastrophic", "nbrpoa_termed_bronze_ms_ip", "nbrpoa_termed_silver_ms_ip",
        "nbrpoa_termed_gold_ms_ip", "nbrpoa_termed_platinum_ms_ip", "nbrpoa_termed_total_ms_ip") //79

    val irmimrttermlives = irmimrtermData.alias("parent").join(termed_nonpayFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
        $"nbrpoa_issued_total_ip", $"nbrpoa_issued_catastrophic", $"nbrpoa_issued_bronze_ms_ip", $"nbrpoa_issued_silver_ms_ip",
        $"nbrpoa_issued_gold_ms_ip", $"nbrpoa_issued_platinum_ms_ip", $"nbrpoa_issued_total_ms_ip",
        $"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
        $"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_catastrophic", $"nbrpoa_renewed_bronze_ms_ip", $"nbrpoa_renewed_silver_ms_ip", $"nbrpoa_renewed_gold_ms_ip",
        $"nbrpoa_renewed_platinum_ms_ip", $"nbrpoa_renewed_total_ms_ip",
        $"mbrmpoa_issued_bronze_ip", $"mbrmpoa_issued_silver_ip", $"mbrmpoa_issued_gold_ip",
        $"mbrmpoa_issued_platinum_ip", $"mbrmpoa_issued_total_ip", $"mbrmpoa_issued_bronze_sgp", $"mbrmpoa_issued_silver_sgp", $"mbrmpoa_issued_gold_sgp", $"mbrmpoa_issued_platinum_sgp",
        $"mbrmpoa_issued_total_sgp", $"mbrmpoa_issued_catastrophic", $"mbrmpoa_issued_bronze_ms_ip", $"mbrmpoa_issued_silver_ms_ip", $"mbrmpoa_issued_gold_ms_ip",
        $"mbrmpoa_issued_platinum_ms_ip", $"mbrmpoa_issued_total_ms_ip", $"mbrmpoa_issued_bronze_ms_sgp", $"mbrmpoa_issued_silver_ms_sgp",
        $"mbrmpoa_issued_gold_ms_sgp", $"mbrmpoa_issued_platinum_ms_sgp", $"mbrmpoa_issued_total_ms_sgp",
        $"mbrmpoa_renewed_bronze_ip", $"mbrmpoa_renewed_silver_ip", $"mbrmpoa_renewed_gold_ip",
        $"mbrmpoa_renewed_platinum_ip", $"mbrmpoa_renewed_total_ip", $"mbrmpoa_renewed_bronze_sgp", $"mbrmpoa_renewed_silver_sgp", $"mbrmpoa_renewed_gold_sgp", $"mbrmpoa_renewed_platinum_sgp",
        $"mbrmpoa_renewed_total_sgp", $"mbrmpoa_renewed_catastrophic", $"mbrmpoa_renewed_bronze_ms_ip", $"mbrmpoa_renewed_silver_ms_ip", $"mbrmpoa_renewed_gold_ms_ip",
        $"mbrmpoa_renewed_platinum_ms_ip", $"mbrmpoa_renewed_total_ms_ip", $"mbrmpoa_renewed_bronze_ms_sgp", $"mbrmpoa_renewed_silver_ms_sgp",
        $"mbrmpoa_renewed_gold_ms_sgp", $"mbrmpoa_renewed_platinum_ms_sgp", $"mbrmpoa_renewed_total_ms_sgp",
        $"nbrpoa_termed_bronze_ip", $"nbrpoa_termed_silver_ip", $"nbrpoa_termed_gold_ip", $"nbrpoa_termed_platinum_ip",
        $"nbrpoa_termed_total_ip", $"nbrpoa_termed_catastrophic", $"nbrpoa_termed_bronze_ms_ip", $"nbrpoa_termed_silver_ms_ip",
        $"nbrpoa_termed_gold_ms_ip", $"nbrpoa_termed_platinum_ms_ip", $"nbrpoa_termed_total_ms_ip",

        $"nbrpoa_termed_nonpay_bronze_ip", $"nbrpoa_termed_nonpay_silver_ip", $"nbrpoa_termed_nonpay_gold_ip", $"nbrpoa_termed_nonpay_platinum_ip",
        $"nbrpoa_termed_nonpay_total_ip", $"nbrpoa_termed_nonpay_catastrophic", $"nbrpoa_termed_nonpay_bronze_ms_ip", $"nbrpoa_termed_nonpay_silver_ms_ip",
        $"nbrpoa_termed_nonpay_gold_ms_ip", $"nbrpoa_termed_nonpay_platinum_ms_ip", $"nbrpoa_termed_nonpay_total_ms_ip") //,

    val irmimrttermlivesData = irmimrttermlives.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
        "nbrpoa_issued_total_ip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_bronze_ms_ip", "nbrpoa_issued_silver_ms_ip",
        "nbrpoa_issued_gold_ms_ip", "nbrpoa_issued_platinum_ms_ip",
        "nbrpoa_issued_total_ms_ip", "nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
        "nbrpoa_renewed_total_ip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_bronze_ms_ip", "nbrpoa_renewed_silver_ms_ip", "nbrpoa_renewed_gold_ms_ip",
        "nbrpoa_renewed_platinum_ms_ip", "nbrpoa_renewed_total_ms_ip", //26
        "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip",
        "mbrmpoa_issued_platinum_ms_ip", "mbrmpoa_issued_total_ms_ip", "mbrmpoa_issued_bronze_ms_sgp", "mbrmpoa_issued_silver_ms_sgp",
        "mbrmpoa_issued_gold_ms_sgp", "mbrmpoa_issued_platinum_ms_sgp", "mbrmpoa_issued_total_ms_sgp", //47
        "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip",
        "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp",
        "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip", "mbrmpoa_renewed_gold_ms_ip",
        "mbrmpoa_renewed_platinum_ms_ip", "mbrmpoa_renewed_total_ms_ip", "mbrmpoa_renewed_bronze_ms_sgp", "mbrmpoa_renewed_silver_ms_sgp",
        "mbrmpoa_renewed_gold_ms_sgp", "mbrmpoa_renewed_platinum_ms_sgp", "mbrmpoa_renewed_total_ms_sgp", //68
        "nbrpoa_termed_bronze_ip", "nbrpoa_termed_silver_ip", "nbrpoa_termed_gold_ip", "nbrpoa_termed_platinum_ip",
        "nbrpoa_termed_total_ip", "nbrpoa_termed_catastrophic", "nbrpoa_termed_bronze_ms_ip", "nbrpoa_termed_silver_ms_ip",
        "nbrpoa_termed_gold_ms_ip", "nbrpoa_termed_platinum_ms_ip", "nbrpoa_termed_total_ms_ip", //79
        "nbrpoa_termed_nonpay_bronze_ip", "nbrpoa_termed_nonpay_silver_ip", "nbrpoa_termed_nonpay_gold_ip", "nbrpoa_termed_nonpay_platinum_ip",
        "nbrpoa_termed_nonpay_total_ip", "nbrpoa_termed_nonpay_catastrophic", "nbrpoa_termed_nonpay_bronze_ms_ip", "nbrpoa_termed_nonpay_silver_ms_ip",
        "nbrpoa_termed_nonpay_gold_ms_ip", "nbrpoa_termed_nonpay_platinum_ms_ip", "nbrpoa_termed_nonpay_total_ms_ip") //90//

    val temp = irmimrttermlivesData.alias("parent").join(termed_livesFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
        $"nbrpoa_issued_total_ip", $"nbrpoa_issued_catastrophic", $"nbrpoa_issued_bronze_ms_ip", $"nbrpoa_issued_silver_ms_ip",
        $"nbrpoa_issued_gold_ms_ip", $"nbrpoa_issued_platinum_ms_ip", $"nbrpoa_issued_total_ms_ip",
        $"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
        $"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_catastrophic", $"nbrpoa_renewed_bronze_ms_ip", $"nbrpoa_renewed_silver_ms_ip", $"nbrpoa_renewed_gold_ms_ip",
        $"nbrpoa_renewed_platinum_ms_ip", $"nbrpoa_renewed_total_ms_ip",
        $"mbrmpoa_issued_bronze_ip", $"mbrmpoa_issued_silver_ip", $"mbrmpoa_issued_gold_ip",
        $"mbrmpoa_issued_platinum_ip", $"mbrmpoa_issued_total_ip", $"mbrmpoa_issued_bronze_sgp", $"mbrmpoa_issued_silver_sgp", $"mbrmpoa_issued_gold_sgp", $"mbrmpoa_issued_platinum_sgp",
        $"mbrmpoa_issued_total_sgp", $"mbrmpoa_issued_catastrophic", $"mbrmpoa_issued_bronze_ms_ip", $"mbrmpoa_issued_silver_ms_ip", $"mbrmpoa_issued_gold_ms_ip",
        $"mbrmpoa_issued_platinum_ms_ip", $"mbrmpoa_issued_total_ms_ip", $"mbrmpoa_issued_bronze_ms_sgp", $"mbrmpoa_issued_silver_ms_sgp",
        $"mbrmpoa_issued_gold_ms_sgp", $"mbrmpoa_issued_platinum_ms_sgp", $"mbrmpoa_issued_total_ms_sgp",
        $"mbrmpoa_renewed_bronze_ip", $"mbrmpoa_renewed_silver_ip", $"mbrmpoa_renewed_gold_ip",
        $"mbrmpoa_renewed_platinum_ip", $"mbrmpoa_renewed_total_ip", $"mbrmpoa_renewed_bronze_sgp", $"mbrmpoa_renewed_silver_sgp", $"mbrmpoa_renewed_gold_sgp", $"mbrmpoa_renewed_platinum_sgp",
        $"mbrmpoa_renewed_total_sgp", $"mbrmpoa_renewed_catastrophic", $"mbrmpoa_renewed_bronze_ms_ip", $"mbrmpoa_renewed_silver_ms_ip", $"mbrmpoa_renewed_gold_ms_ip",
        $"mbrmpoa_renewed_platinum_ms_ip", $"mbrmpoa_renewed_total_ms_ip", $"mbrmpoa_renewed_bronze_ms_sgp", $"mbrmpoa_renewed_silver_ms_sgp",
        $"mbrmpoa_renewed_gold_ms_sgp", $"mbrmpoa_renewed_platinum_ms_sgp", $"mbrmpoa_renewed_total_ms_sgp", //nbrpoa_termed_nonpay_bronze_ip
        $"nbrpoa_termed_bronze_ip", $"nbrpoa_termed_silver_ip", $"nbrpoa_termed_gold_ip", $"nbrpoa_termed_platinum_ip",
        $"nbrpoa_termed_total_ip", $"nbrpoa_termed_catastrophic", $"nbrpoa_termed_bronze_ms_ip", $"nbrpoa_termed_silver_ms_ip",
        $"nbrpoa_termed_gold_ms_ip", $"nbrpoa_termed_platinum_ms_ip", $"nbrpoa_termed_total_ms_ip",

        $"nbrpoa_termed_nonpay_bronze_ip", $"nbrpoa_termed_nonpay_silver_ip", $"nbrpoa_termed_nonpay_gold_ip", $"nbrpoa_termed_nonpay_platinum_ip",
        $"nbrpoa_termed_nonpay_total_ip", $"nbrpoa_termed_nonpay_catastrophic", $"nbrpoa_termed_nonpay_bronze_ms_ip", $"nbrpoa_termed_nonpay_silver_ms_ip",
        $"nbrpoa_termed_nonpay_gold_ms_ip", $"nbrpoa_termed_nonpay_platinum_ms_ip", $"nbrpoa_termed_nonpay_total_ms_ip",
        $"nbrpoa_termed_lives_bronze_ip", $"nbrpoa_termed_lives_silver_ip", $"nbrpoa_termed_lives_gold_ip", $"nbrpoa_termed_lives_platinum_ip",
        $"nbrpoa_termed_lives_total_ip", $"nbrpoa_termed_lives_bronze_sgp", $"nbrpoa_termed_lives_silver_sgp", $"nbrpoa_termed_lives_gold_sgp", $"nbrpoa_termed_lives_platinum_sgp", $"nbrpoa_termed_lives_total_sgp", $"nbrpoa_termed_lives_catastrophic",
        $"nbrpoa_termed_lives_bronze_ms_ip", $"nbrpoa_termed_lives_silver_ms_ip", $"nbrpoa_termed_lives_gold_ms_ip", $"nbrpoa_termed_lives_platinum_ms_ip", $"nbrpoa_termed_lives_total_ms_ip", $"nbrpoa_termed_lives_bronze_ms_sgp", $"nbrpoa_termed_lives_silver_ms_sgp", $"nbrpoa_termed_lives_gold_ms_sgp", $"nbrpoa_termed_lives_platinum_ms_sgp", $"nbrpoa_termed_lives_total_ms_sgp")

    val tempData = temp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
        "nbrpoa_issued_total_ip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_bronze_ms_ip", "nbrpoa_issued_silver_ms_ip",
        "nbrpoa_issued_gold_ms_ip", "nbrpoa_issued_platinum_ms_ip",
        "nbrpoa_issued_total_ms_ip", "nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
        "nbrpoa_renewed_total_ip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_bronze_ms_ip", "nbrpoa_renewed_silver_ms_ip", "nbrpoa_renewed_gold_ms_ip",
        "nbrpoa_renewed_platinum_ms_ip", "nbrpoa_renewed_total_ms_ip", //26
        "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip",
        "mbrmpoa_issued_platinum_ms_ip", "mbrmpoa_issued_total_ms_ip", "mbrmpoa_issued_bronze_ms_sgp", "mbrmpoa_issued_silver_ms_sgp",
        "mbrmpoa_issued_gold_ms_sgp", "mbrmpoa_issued_platinum_ms_sgp", "mbrmpoa_issued_total_ms_sgp", //47
        "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip",
        "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp",
        "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip", "mbrmpoa_renewed_gold_ms_ip",
        "mbrmpoa_renewed_platinum_ms_ip", "mbrmpoa_renewed_total_ms_ip", "mbrmpoa_renewed_bronze_ms_sgp", "mbrmpoa_renewed_silver_ms_sgp",
        "mbrmpoa_renewed_gold_ms_sgp", "mbrmpoa_renewed_platinum_ms_sgp", "mbrmpoa_renewed_total_ms_sgp", //68
        "nbrpoa_termed_bronze_ip", "nbrpoa_termed_silver_ip", "nbrpoa_termed_gold_ip", "nbrpoa_termed_platinum_ip",
        "nbrpoa_termed_total_ip", "nbrpoa_termed_catastrophic", "nbrpoa_termed_bronze_ms_ip", "nbrpoa_termed_silver_ms_ip",
        "nbrpoa_termed_gold_ms_ip", "nbrpoa_termed_platinum_ms_ip", "nbrpoa_termed_total_ms_ip", //79
        "nbrpoa_termed_nonpay_bronze_ip", "nbrpoa_termed_nonpay_silver_ip", "nbrpoa_termed_nonpay_gold_ip", "nbrpoa_termed_nonpay_platinum_ip",
        "nbrpoa_termed_nonpay_total_ip", "nbrpoa_termed_nonpay_catastrophic", "nbrpoa_termed_nonpay_bronze_ms_ip", "nbrpoa_termed_nonpay_silver_ms_ip",
        "nbrpoa_termed_nonpay_gold_ms_ip", "nbrpoa_termed_nonpay_platinum_ms_ip", "nbrpoa_termed_nonpay_total_ms_ip", //90
        "nbrpoa_termed_lives_bronze_ip", "nbrpoa_termed_lives_silver_ip", "nbrpoa_termed_lives_gold_ip", "nbrpoa_termed_lives_platinum_ip",
        "nbrpoa_termed_lives_total_ip", "nbrpoa_termed_lives_bronze_sgp", "nbrpoa_termed_lives_silver_sgp", "nbrpoa_termed_lives_gold_sgp", "nbrpoa_termed_lives_platinum_sgp", "nbrpoa_termed_lives_total_sgp", "nbrpoa_termed_lives_catastrophic",
        "nbrpoa_termed_lives_bronze_ms_ip", "nbrpoa_termed_lives_silver_ms_ip", "nbrpoa_termed_lives_gold_ms_ip", "nbrpoa_termed_lives_platinum_ms_ip", "nbrpoa_termed_lives_total_ms_ip", "nbrpoa_termed_lives_bronze_ms_sgp", "nbrpoa_termed_lives_silver_ms_sgp", "nbrpoa_termed_lives_gold_ms_sgp", "nbrpoa_termed_lives_platinum_ms_sgp", "nbrpoa_termed_lives_total_ms_sgp") //111

    val irmimrttlTermnonpay = tempData.alias("parent").join(termed_nonpay_livesFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), $"nbrpoa_issued_bronze_ip", $"nbrpoa_issued_silver_ip", $"nbrpoa_issued_gold_ip", $"nbrpoa_issued_platinum_ip",
        $"nbrpoa_issued_total_ip", $"nbrpoa_issued_catastrophic", $"nbrpoa_issued_bronze_ms_ip", $"nbrpoa_issued_silver_ms_ip",
        $"nbrpoa_issued_gold_ms_ip", $"nbrpoa_issued_platinum_ms_ip", $"nbrpoa_issued_total_ms_ip",
        $"nbrpoa_renewed_bronze_ip", $"nbrpoa_renewed_silver_ip", $"nbrpoa_renewed_gold_ip", $"nbrpoa_renewed_platinum_ip",
        $"nbrpoa_renewed_total_ip", $"nbrpoa_renewed_catastrophic", $"nbrpoa_renewed_bronze_ms_ip", $"nbrpoa_renewed_silver_ms_ip", $"nbrpoa_renewed_gold_ms_ip",
        $"nbrpoa_renewed_platinum_ms_ip", $"nbrpoa_renewed_total_ms_ip",
        $"mbrmpoa_issued_bronze_ip", $"mbrmpoa_issued_silver_ip", $"mbrmpoa_issued_gold_ip",
        $"mbrmpoa_issued_platinum_ip", $"mbrmpoa_issued_total_ip", $"mbrmpoa_issued_bronze_sgp", $"mbrmpoa_issued_silver_sgp", $"mbrmpoa_issued_gold_sgp", $"mbrmpoa_issued_platinum_sgp",
        $"mbrmpoa_issued_total_sgp", $"mbrmpoa_issued_catastrophic", $"mbrmpoa_issued_bronze_ms_ip", $"mbrmpoa_issued_silver_ms_ip", $"mbrmpoa_issued_gold_ms_ip",
        $"mbrmpoa_issued_platinum_ms_ip", $"mbrmpoa_issued_total_ms_ip", $"mbrmpoa_issued_bronze_ms_sgp", $"mbrmpoa_issued_silver_ms_sgp",
        $"mbrmpoa_issued_gold_ms_sgp", $"mbrmpoa_issued_platinum_ms_sgp", $"mbrmpoa_issued_total_ms_sgp",
        $"mbrmpoa_renewed_bronze_ip", $"mbrmpoa_renewed_silver_ip", $"mbrmpoa_renewed_gold_ip",
        $"mbrmpoa_renewed_platinum_ip", $"mbrmpoa_renewed_total_ip", $"mbrmpoa_renewed_bronze_sgp", $"mbrmpoa_renewed_silver_sgp", $"mbrmpoa_renewed_gold_sgp", $"mbrmpoa_renewed_platinum_sgp",
        $"mbrmpoa_renewed_total_sgp", $"mbrmpoa_renewed_catastrophic", $"mbrmpoa_renewed_bronze_ms_ip", $"mbrmpoa_renewed_silver_ms_ip", $"mbrmpoa_renewed_gold_ms_ip",
        $"mbrmpoa_renewed_platinum_ms_ip", $"mbrmpoa_renewed_total_ms_ip", $"mbrmpoa_renewed_bronze_ms_sgp", $"mbrmpoa_renewed_silver_ms_sgp",
        $"mbrmpoa_renewed_gold_ms_sgp", $"mbrmpoa_renewed_platinum_ms_sgp", $"mbrmpoa_renewed_total_ms_sgp",
        $"nbrpoa_termed_bronze_ip", $"nbrpoa_termed_silver_ip", $"nbrpoa_termed_gold_ip", $"nbrpoa_termed_platinum_ip",
        $"nbrpoa_termed_total_ip", $"nbrpoa_termed_catastrophic", $"nbrpoa_termed_bronze_ms_ip", $"nbrpoa_termed_silver_ms_ip",
        $"nbrpoa_termed_gold_ms_ip", $"nbrpoa_termed_platinum_ms_ip", $"nbrpoa_termed_total_ms_ip",
        $"nbrpoa_termed_nonpay_bronze_ip", $"nbrpoa_termed_nonpay_silver_ip", $"nbrpoa_termed_nonpay_gold_ip", $"nbrpoa_termed_nonpay_platinum_ip",
        $"nbrpoa_termed_nonpay_total_ip", $"nbrpoa_termed_nonpay_catastrophic", $"nbrpoa_termed_nonpay_bronze_ms_ip", $"nbrpoa_termed_nonpay_silver_ms_ip",
        $"nbrpoa_termed_nonpay_gold_ms_ip", $"nbrpoa_termed_nonpay_platinum_ms_ip", $"nbrpoa_termed_nonpay_total_ms_ip",
        $"nbrpoa_termed_lives_bronze_ip", $"nbrpoa_termed_lives_silver_ip", $"nbrpoa_termed_lives_gold_ip", $"nbrpoa_termed_lives_platinum_ip",
        $"nbrpoa_termed_lives_total_ip", $"nbrpoa_termed_lives_bronze_sgp", $"nbrpoa_termed_lives_silver_sgp", $"nbrpoa_termed_lives_gold_sgp", $"nbrpoa_termed_lives_platinum_sgp", $"nbrpoa_termed_lives_total_sgp", $"nbrpoa_termed_lives_catastrophic",
        $"nbrpoa_termed_lives_bronze_ms_ip", $"nbrpoa_termed_lives_silver_ms_ip", $"nbrpoa_termed_lives_gold_ms_ip", $"nbrpoa_termed_lives_platinum_ms_ip", $"nbrpoa_termed_lives_total_ms_ip", $"nbrpoa_termed_lives_bronze_ms_sgp", $"nbrpoa_termed_lives_silver_ms_sgp", $"nbrpoa_termed_lives_gold_ms_sgp", $"nbrpoa_termed_lives_platinum_ms_sgp", $"nbrpoa_termed_lives_total_ms_sgp",
        $"nbrpoa_termed_nonpay_lives_bronze_ip", $"nbrpoa_termed_nonpay_lives_silver_ip", $"nbrpoa_termed_nonpay_lives_gold_ip", $"nbrpoa_termed_nonpay_lives_platinum_ip",
        $"nbrpoa_termed_nonpay_lives_total_ip", $"nbrpoa_termed_nonpay_lives_bronze_sgp", $"nbrpoa_termed_nonpay_lives_silver_sgp", $"nbrpoa_termed_nonpay_lives_gold_sgp", $"nbrpoa_termed_nonpay_lives_platinum_sgp", $"nbrpoa_termed_nonpay_lives_total_sgp", $"nbrpoa_termed_nonpay_lives_catastrophic",
        $"nbrpoa_termed_nonpay_lives_bronze_ms_ip", $"nbrpoa_termed_nonpay_lives_silver_ms_ip", $"nbrpoa_termed_nonpay_lives_gold_ms_ip", $"nbrpoa_termed_nonpay_lives_platinum_ms_ip", $"nbrpoa_termed_nonpay_lives_total_ms_ip", $"nbrpoa_termed_nonpay_lives_bronze_ms_sgp", $"nbrpoa_termed_nonpay_lives_silver_ms_sgp", $"nbrpoa_termed_nonpay_lives_gold_ms_sgp", $"nbrpoa_termed_nonpay_lives_platinum_ms_sgp", $"nbrpoa_termed_nonpay_lives_total_ms_sgp")

    val finalData = irmimrttlTermnonpay.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("in_exchange", "health_year", "cmpny_cf_cd", "state", "nbrpoa_issued_bronze_ip", "nbrpoa_issued_silver_ip", "nbrpoa_issued_gold_ip", "nbrpoa_issued_platinum_ip",
        "nbrpoa_issued_total_ip", "nbrpoa_issued_catastrophic", "nbrpoa_issued_bronze_ms_ip", "nbrpoa_issued_silver_ms_ip",
        "nbrpoa_issued_gold_ms_ip", "nbrpoa_issued_platinum_ms_ip",
        "nbrpoa_issued_total_ms_ip", "nbrpoa_renewed_bronze_ip", "nbrpoa_renewed_silver_ip", "nbrpoa_renewed_gold_ip", "nbrpoa_renewed_platinum_ip",
        "nbrpoa_renewed_total_ip", "nbrpoa_renewed_catastrophic", "nbrpoa_renewed_bronze_ms_ip", "nbrpoa_renewed_silver_ms_ip", "nbrpoa_renewed_gold_ms_ip",
        "nbrpoa_renewed_platinum_ms_ip", "nbrpoa_renewed_total_ms_ip", //26
        "mbrmpoa_issued_bronze_ip", "mbrmpoa_issued_silver_ip", "mbrmpoa_issued_gold_ip",
        "mbrmpoa_issued_platinum_ip", "mbrmpoa_issued_total_ip", "mbrmpoa_issued_bronze_sgp", "mbrmpoa_issued_silver_sgp", "mbrmpoa_issued_gold_sgp", "mbrmpoa_issued_platinum_sgp",
        "mbrmpoa_issued_total_sgp", "mbrmpoa_issued_catastrophic", "mbrmpoa_issued_bronze_ms_ip", "mbrmpoa_issued_silver_ms_ip", "mbrmpoa_issued_gold_ms_ip",
        "mbrmpoa_issued_platinum_ms_ip", "mbrmpoa_issued_total_ms_ip", "mbrmpoa_issued_bronze_ms_sgp", "mbrmpoa_issued_silver_ms_sgp",
        "mbrmpoa_issued_gold_ms_sgp", "mbrmpoa_issued_platinum_ms_sgp", "mbrmpoa_issued_total_ms_sgp", //47
        "mbrmpoa_renewed_bronze_ip", "mbrmpoa_renewed_silver_ip", "mbrmpoa_renewed_gold_ip",
        "mbrmpoa_renewed_platinum_ip", "mbrmpoa_renewed_total_ip", "mbrmpoa_renewed_bronze_sgp", "mbrmpoa_renewed_silver_sgp", "mbrmpoa_renewed_gold_sgp", "mbrmpoa_renewed_platinum_sgp",
        "mbrmpoa_renewed_total_sgp", "mbrmpoa_renewed_catastrophic", "mbrmpoa_renewed_bronze_ms_ip", "mbrmpoa_renewed_silver_ms_ip", "mbrmpoa_renewed_gold_ms_ip",
        "mbrmpoa_renewed_platinum_ms_ip", "mbrmpoa_renewed_total_ms_ip", "mbrmpoa_renewed_bronze_ms_sgp", "mbrmpoa_renewed_silver_ms_sgp",
        "mbrmpoa_renewed_gold_ms_sgp", "mbrmpoa_renewed_platinum_ms_sgp", "mbrmpoa_renewed_total_ms_sgp", //68
        "nbrpoa_termed_bronze_ip", "nbrpoa_termed_silver_ip", "nbrpoa_termed_gold_ip", "nbrpoa_termed_platinum_ip",
        "nbrpoa_termed_total_ip", "nbrpoa_termed_catastrophic", "nbrpoa_termed_bronze_ms_ip", "nbrpoa_termed_silver_ms_ip",
        "nbrpoa_termed_gold_ms_ip", "nbrpoa_termed_platinum_ms_ip", "nbrpoa_termed_total_ms_ip", //79
        "nbrpoa_termed_nonpay_bronze_ip", "nbrpoa_termed_nonpay_silver_ip", "nbrpoa_termed_nonpay_gold_ip", "nbrpoa_termed_nonpay_platinum_ip",
        "nbrpoa_termed_nonpay_total_ip", "nbrpoa_termed_nonpay_catastrophic", "nbrpoa_termed_nonpay_bronze_ms_ip", "nbrpoa_termed_nonpay_silver_ms_ip",
        "nbrpoa_termed_nonpay_gold_ms_ip", "nbrpoa_termed_nonpay_platinum_ms_ip", "nbrpoa_termed_nonpay_total_ms_ip", //90
        "nbrpoa_termed_lives_bronze_ip", "nbrpoa_termed_lives_silver_ip", "nbrpoa_termed_lives_gold_ip", "nbrpoa_termed_lives_platinum_ip",
        "nbrpoa_termed_lives_total_ip", "nbrpoa_termed_lives_bronze_sgp", "nbrpoa_termed_lives_silver_sgp", "nbrpoa_termed_lives_gold_sgp", "nbrpoa_termed_lives_platinum_sgp", "nbrpoa_termed_lives_total_sgp", "nbrpoa_termed_lives_catastrophic",
        "nbrpoa_termed_lives_bronze_ms_ip", "nbrpoa_termed_lives_silver_ms_ip", "nbrpoa_termed_lives_gold_ms_ip", "nbrpoa_termed_lives_platinum_ms_ip", "nbrpoa_termed_lives_total_ms_ip", "nbrpoa_termed_lives_bronze_ms_sgp", "nbrpoa_termed_lives_silver_ms_sgp", "nbrpoa_termed_lives_gold_ms_sgp", "nbrpoa_termed_lives_platinum_ms_sgp", "nbrpoa_termed_lives_total_ms_sgp", //111
        "nbrpoa_termed_nonpay_lives_bronze_ip", "nbrpoa_termed_nonpay_lives_silver_ip", "nbrpoa_termed_nonpay_lives_gold_ip", "nbrpoa_termed_nonpay_lives_platinum_ip",
        "nbrpoa_termed_nonpay_lives_total_ip", "nbrpoa_termed_nonpay_lives_bronze_sgp", "nbrpoa_termed_nonpay_lives_silver_sgp", "nbrpoa_termed_nonpay_lives_gold_sgp", "nbrpoa_termed_nonpay_lives_platinum_sgp", "nbrpoa_termed_nonpay_lives_total_sgp", "nbrpoa_termed_nonpay_lives_catastrophic",
        "nbrpoa_termed_nonpay_lives_bronze_ms_ip", "nbrpoa_termed_nonpay_lives_silver_ms_ip", "nbrpoa_termed_nonpay_lives_gold_ms_ip", "nbrpoa_termed_nonpay_lives_platinum_ms_ip", "nbrpoa_termed_nonpay_lives_total_ms_ip", "nbrpoa_termed_nonpay_lives_bronze_ms_sgp", "nbrpoa_termed_nonpay_lives_silver_ms_sgp", "nbrpoa_termed_nonpay_lives_gold_ms_sgp",
        "nbrpoa_termed_nonpay_lives_platinum_ms_sgp", "nbrpoa_termed_nonpay_lives_total_ms_sgp")
    finalData
  }

}

object PCADX_SCL_NAIC2018_IEXStgTransformationPOA {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    val iex = new PCADX_SCL_NAIC2018_IEXStgTransformationPOA()
    //iex.setyear(args(1))
    iex.sparkInIt()
  }
}