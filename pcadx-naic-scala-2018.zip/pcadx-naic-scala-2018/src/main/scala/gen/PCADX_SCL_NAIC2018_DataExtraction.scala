package gen

import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import org.apache.spark.sql.functions._ 
import org.apache.spark.sql.expressions.Window


class PCADX_SCL_NAIC2018_DataExtraction {

	/**
	 * 
	 * Initialize Spark session and define class variables
	 */
	val spark = SparkSession.builder().config("hive.exec.dynamic.partition","true").
			config("hive.exec.dynamic.partition.mode", "nonstrict").
			config("spark.sql.parquet.compression.codec", "snappy").
			config("hive.warehouse.data.skipTrash","true").
			config("spark.sql.parquet.writeLegacyFormat","true").
			enableHiveSupport().getOrCreate()  

			var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_DataExtraction])
			
			import spark.implicits._
			
			val dbProperties = new Properties
			dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
			
			val dbOu = dbProperties.getProperty("outbound.db")
			val dbwh = dbProperties.getProperty("warehouse.db")
			val tblOu = "naic2018_mcas_report_outbnd"
			val uri: String = dbProperties.getProperty("uri")
			val fs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI(uri), spark.sparkContext.hadoopConfiguration)
			var fileNameList = Seq[String]()
			
			def sparkInIt(){
	  
				val outTable = readDataFromHive(tblOu)
				val outputFile = dbProperties.getProperty("outbound.path") + "/" + dbProperties.getProperty("outbound.table") + "_report"
				getReports(outTable)
				val audit_log_df = spark.sql("select * from "+dbwh+".audt_load_log")
				var load_log_key:Long = 0
				if(!audit_log_df.take(1).isEmpty){
					load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0)
				}
				//val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC_MCAS" && $"prcs_nm"==="NAIC_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0) 
				println("load_log_key : "+load_log_key)
				println("dbProperties.getProperty(outbound.edge) :" +dbProperties.getProperty("outbound.edge"))
				var audit_ftp_df = fileNameList.toDF("data_file_nm")
				audit_ftp_df= audit_ftp_df.withColumn("id", monotonically_increasing_id())
				.withColumn("subj_are_nm", lit("NAIC_MCAS"))
				.withColumn("prcs_nm", lit("NAIC_MCAS_RPT"))
				.withColumn("load_log_key", lit(load_log_key))
				.withColumn("edge_node_lctn_txt	",lit(dbProperties.getProperty("outbound.edge")))
				.withColumn("evnt_dtm", current_timestamp())                                
				val w = Window.orderBy("data_file_nm")
				audit_ftp_df= audit_ftp_df.withColumn("id", row_number().over(w))
				audit_ftp_df = audit_ftp_df.select("id","subj_are_nm","prcs_nm","load_log_key","data_file_nm","edge_node_lctn_txt	","evnt_dtm")
				writeDataToHive(dbwh+".audt_extrct_ftp",audit_ftp_df)
				//spark.close()  

				new PCADX_SCL_NAIC2018_DQ().sparkInIt()

			}

			/**
			 * Reads output table data from hive into Dataframe
			 * @param : any Dataframe
			 * @return: Dataframe with all the columns placed one after other as required like a list of list
			 * 
			 */
			def extractingReport(inputDf: DataFrame): DataFrame = {
			  
					logger.info("Manipulating dataframe and creating ListofList")

					val listDf = inputDf.map(row => {
						val format = row.getAs[Int]("format_field_nbr")
						var a = 5
						var collectArray = Array.empty[String]
								collectArray = collectArray :+ row.getAs[Int](0).toString()
								collectArray = collectArray :+ row.getAs[Int](1).toString()
								collectArray = collectArray :+ row.getAs[String](2) 
								collectArray = collectArray :+ row.getAs[String](3) 
								collectArray = collectArray :+ row.getAs[Int](4).toString()
								while (a < format) {
									collectArray = collectArray :+ row.getAs(a).toString()
											a += 1
								}
						collectArray.toList
					}).toDF
					
					logger.info("writing data to csv file")
					
					val stringify = udf((vs: Seq[String]) => vs.mkString(",").trim())
					val finalDf = listDf.withColumn("value", stringify($"value"))
					
					logger.info("***********Completed **************************")
					
					finalDf.show
					finalDf
			}

			/**
			 * Reads output table data from hive into Dataframe
			 * @param : Table name 
			 * @return: output table dataframe
			 * 
			 */
			def readDataFromHive(tble: String): DataFrame = {
					val queryOutputTable="""SELECT * FROM """ + dbOu + """.""" + tble
							val tbl_data_df = spark.sql(queryOutputTable).na.fill("")
							logger.info("Read data from hive")
							tbl_data_df
			}

			/**
			 * This method writes the dataframe to the hive table
			 * @param :  table Name and datfarme to be written to the table
			 */
			def writeDataToHive(tblName: String, finalDf: DataFrame) {
				finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
				println("Data added in stage table")
			}
			/**
			 * This method extracts individual reports  based on format_field_nbr
			 * @param : year and company_id wise dataframe
			 * @return : Generates files at given HDFS location 
			 *
			 */
			def getReports(inputDf: DataFrame): Unit = {
					if (fs.exists(new org.apache.hadoop.fs.Path(dbProperties.getProperty("outbound.path") + "/naic2018_mcas_report_outbnd_report"))) fs.delete(new org.apache.hadoop.fs.Path(dbProperties.getProperty("outbound.path") + "/naic2018_mcas_report_outbnd_report"), true)
					inputDf.printSchema
					val compCodeDF = inputDf.select($"naic_cmpny_cd").distinct().collect()
					val healthYearsDF = inputDf.select($"health_year").distinct().collect()
					println(healthYearsDF.size)
					var i = 0

					while (i < healthYearsDF.size) {
						var j = 0
								while (j < compCodeDF.size) {

									val healthYearVal = healthYearsDF(i).getAs[Int](0)
											val compCodeVal = compCodeDF(j).getAs[String](0)
											val tempDf = inputDf.filter($"health_year" === healthYearVal && $"naic_cmpny_cd" === compCodeVal).coalesce(1).sort($"state", $"sel_priority", $"line_nbr", $"format_nbr")
											val outbdDf = extractingReport(tempDf)

											val srcFilePath = new Path(dbProperties.getProperty("outbound.path") + "/naic2018_mcas_report_outbnd_report/temp")
											val destFilePath = new Path(dbProperties.getProperty("outbound.path") + "/naic2018_mcas_report_outbnd_report" + "/" + healthYearVal.toString() + "_" + compCodeVal.toString() + "_HLTH_NAIC2018_MCAS_RPT.csv")
											outbdDf.write.mode(SaveMode.Overwrite).option("quote", "\u0000").csv(dbProperties.getProperty("outbound.path") + "/naic2018_mcas_report_outbnd_report/temp")
											FileUtil.copyMerge(fs, srcFilePath, fs, destFilePath, true, spark.sparkContext.hadoopConfiguration, null)
											println("_____________" +destFilePath+"____________________")
											//fileNameList = fileNameList :+ destFilePath
											fileNameList = fileNameList :+ healthYearVal.toString() + "_" + compCodeVal.toString() + "_HLTH_NAIC2018_MCAS_RPT.csv"
											j += 1
								}
						i += 1
					}
			}
}

object PCADX_SCL_NAIC2018_DataExtraction{
  
	def main(args : Array[String]){
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		new PCADX_SCL_NAIC2018_DataExtraction().sparkInIt()
	}
}

