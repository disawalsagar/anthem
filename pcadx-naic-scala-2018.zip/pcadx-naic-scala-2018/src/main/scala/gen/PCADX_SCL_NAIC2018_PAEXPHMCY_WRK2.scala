package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator

import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit

import org.apache.hadoop.fs._;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
class PCADX_SCL_NAIC2018_PAEXPHMCY_WRK2 {

  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()
  spark.conf.set("spark.sql.crossJoin.enabled", "true")

  import spark.implicits._

  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_PAEXPHMCY_WRK2])

  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  val dbWrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val strtdt = dbProperties.getProperty("paex_strtDt")
  val enddt = dbProperties.getProperty("paex_endDt")
  val reportYear = dbProperties.getProperty("report.year")
  val wrhDb = dbProperties.getProperty("warehouse.db")
  val prcp_cd = dbProperties.getProperty("PRCP_TYPE_CD")
  val audit_log_df = spark.sql("select * from " + wrhDb + ".audt_load_log")
  val load_log_key = audit_log_df.filter($"subj_area_nm" === "NAIC2018_MCAS" && $"prcs_nm" === "NAIC2018_MCAS_RPT" && $"load_stts_cd" === "S")
    .orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString()
  val umRqstCreatFrmDt=dbProperties.getProperty("um_rqst_creat_frmDt")
  val umRqstCreatToDt=dbProperties.getProperty("um_rqst_creat_toDt")

     def TrnctTbl = """Truncate table """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_wrk2"""

    def pa_query1() = """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_wrk2""" + 
    """
      select  
        wrk.MBR_KEY as MBR_KEY,
        wrk.UM_RQST_INITD_DT as UM_RQST_INITD_DT ,
        wrk.UM_RQST_CREAT_DT as UM_RQST_CREAT_DT ,
        wrk.CASE_TYPE_CD as CASE_TYPE_CD ,
        wrk.AUTHRZN_STTS_CD as AUTHRZN_STTS_CD ,
        wrk.RCRD_STTS_CD as RCRD_STTS_CD ,
        wrk.CLNCL_SOR_CD as  CLNCL_SOR_CD ,
        wrk.RFRNC_NBR as RFRNC_NBR , 
        wrk.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
        wrk.UM_SRVC_STTS_CD as UM_SRVC_STTS_CD , 
        uis.UM_SRVC_STTS_CD  as  uis_UM_SRVC_STTS_CD ,
        wrk.SRC_UM_SRVC_STTS_CD as SRC_UM_SRVC_STTS_CD , 
        uis.SRC_UM_SRVC_STTS_CD  as  uis_SRC_UM_SRVC_STTS_CD ,
        wrk.STTS_DT as  STTS_DT , 
        uis.STTS_DT  as  uis_STTS_DT ,
        ussh.ussh_STTS_DT as  ussh_STTS_DT ,
        wrk.SRVC_RVW_TYPE_CD as SRVC_RVW_TYPE_CD ,
        wrk.AUTHRZD_PLACE_OF_SRVC_CD as  AUTHRZD_PLACE_OF_SRVC_CD ,
        wrk.INPAT_RQSTD_CD  as INPAT_RQSTD_CD ,
        wrk.INPAT_AUTHRZD_CD  as INPAT_AUTHRZD_CD ,
        wrk.RQSTD_PLACE_OF_SRVC_CD as RQSTD_PLACE_OF_SRVC_CD ,
        wrk.RQSTD_PROC_SRVC_TYPE_CD as RQSTD_PROC_SRVC_TYPE_CD ,
        uis.INPAT_SRVC_LINE_NBR  as  INPAT_SRVC_LINE_NBR ,
        uis.ACTN_CD as ACTN_CD,
              """+load_log_key+""" as load_log_key,
				current_timestamp
        
        
      from 
        """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_wrk1  wrk
        Left join """ + dbInbnd + """.UM_INPAT_SRVC  uis
        on wrk.RFRNC_NBR = uis.RFRNC_NBR
        and wrk.SRVC_LINE_NBR = uis.SRVC_LINE_NBR
        and wrk.CLNCL_SOR_CD= uis.CLNCL_SOR_CD
        and uis.SRC_UM_SRVC_STTS_CD not in (  'ER' , 'EA'  )
        and uis.ACTN_CD not in ( 'ER' )
        and uis.UM_SRVC_STTS_CD not in ('UNK', 'P') 
        and ( wrk.INPAT_RQSTD_CD   in ( 'Y'  )  or wrk.INPAT_AUTHRZD_CD  in ( 'Y'  ) )
        Left join 
        ( select uss.CLNCL_SOR_CD , uss.RFRNC_NBR , uss.SRVC_LINE_NBR , min( uss.STTS_DT) as ussh_STTS_DT
        from """ + dbInbnd + """.UM_SRVC_STTS_HIST  uss
        where  uss.UM_SRVC_STTS_CD not in (  'P' , 'C' )
        group by uss.CLNCL_SOR_CD , uss.RFRNC_NBR , uss.SRVC_LINE_NBR
        ) ussh
        on wrk.RFRNC_NBR = ussh.RFRNC_NBR
        and wrk.SRVC_LINE_NBR = ussh.SRVC_LINE_NBR
        and wrk.CLNCL_SOR_CD= ussh.CLNCL_SOR_CD
        and ( wrk.INPAT_RQSTD_CD   in ( 'N'  )  or wrk.INPAT_AUTHRZD_CD  in ( 'N'  ) )
        
      where  wrk.STTS_DT >=  """+strtdt+""" 
        and
        (
        (  uis.STTS_DT BETWEEN  """+strtdt+"""  AND  """+enddt+""" )
        or (  ussh.ussh_STTS_DT BETWEEN  """+strtdt+"""  AND  """+enddt+""" )
        )
      group by 
        wrk.MBR_KEY ,
        wrk.UM_RQST_INITD_DT  ,
        wrk.UM_RQST_CREAT_DT  ,
        wrk.CASE_TYPE_CD  ,
        wrk.AUTHRZN_STTS_CD  ,
        wrk.RCRD_STTS_CD  ,
        wrk.CLNCL_SOR_CD  ,
        wrk.RFRNC_NBR  , 
        wrk.SRVC_LINE_NBR  ,
        wrk.UM_SRVC_STTS_CD  , 
        uis.UM_SRVC_STTS_CD   ,
        wrk.SRC_UM_SRVC_STTS_CD  , 
        uis.SRC_UM_SRVC_STTS_CD   ,
        wrk.STTS_DT  , 
        uis.STTS_DT   ,
        ussh.ussh_STTS_DT  ,
        wrk.SRVC_RVW_TYPE_CD  ,
        wrk.AUTHRZD_PLACE_OF_SRVC_CD  ,
        wrk.INPAT_RQSTD_CD  ,
        wrk.INPAT_AUTHRZD_CD  ,
        wrk.RQSTD_PLACE_OF_SRVC_CD  ,
        wrk.RQSTD_PROC_SRVC_TYPE_CD  ,
        uis.INPAT_SRVC_LINE_NBR ,
        uis.ACTN_CD

"""
 def pa_query2() ="""Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_wrk2""" + 
            """ 
      select  
        wrk.MBR_KEY as MBR_KEY,
        wrk.UM_RQST_INITD_DT as UM_RQST_INITD_DT ,
        wrk.UM_RQST_CREAT_DT as UM_RQST_CREAT_DT ,
        wrk.CASE_TYPE_CD as CASE_TYPE_CD ,
        wrk.AUTHRZN_STTS_CD as AUTHRZN_STTS_CD ,
        wrk.RCRD_STTS_CD as RCRD_STTS_CD ,
        wrk.CLNCL_SOR_CD as  CLNCL_SOR_CD ,
        wrk.RFRNC_NBR as RFRNC_NBR , 
        wrk.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
        wrk.UM_SRVC_STTS_CD as UM_SRVC_STTS_CD , 
        'NA'  as  uis_UM_SRVC_STTS_CD ,
        wrk.SRC_UM_SRVC_STTS_CD as SRC_UM_SRVC_STTS_CD , 
        'NA'  as  uis_SRC_UM_SRVC_STTS_CD ,
        wrk.STTS_DT as  STTS_DT , 
        'NA'  as  uis_STTS_DT ,
        'NA' as  ussh_STTS_DT ,
        wrk.SRVC_RVW_TYPE_CD as SRVC_RVW_TYPE_CD ,
        wrk.AUTHRZD_PLACE_OF_SRVC_CD as  AUTHRZD_PLACE_OF_SRVC_CD ,
        wrk.INPAT_RQSTD_CD  as INPAT_RQSTD_CD ,
        wrk.INPAT_AUTHRZD_CD  as INPAT_AUTHRZD_CD ,
        wrk.RQSTD_PLACE_OF_SRVC_CD as RQSTD_PLACE_OF_SRVC_CD ,
        wrk.RQSTD_PROC_SRVC_TYPE_CD as RQSTD_PROC_SRVC_TYPE_CD ,
        'NA'  as  INPAT_SRVC_LINE_NBR,
        'NA'  as ACTN_CD,  """+load_log_key+""" as load_log_key,
				current_timestamp
      from 
        """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_wrk1  wrk
      where  
        wrk.CLNCL_SOR_CD in ( '948' , '1103' , '1035'  )   
        and wrk.STTS_DT  BETWEEN  """+strtdt+"""  AND  """+enddt+"""
      group by 
        wrk.MBR_KEY ,
        wrk.UM_RQST_INITD_DT  ,
        wrk.UM_RQST_CREAT_DT  ,
        wrk.CASE_TYPE_CD  ,
        wrk.AUTHRZN_STTS_CD  ,
        wrk.RCRD_STTS_CD  ,
        wrk.CLNCL_SOR_CD  ,
        wrk.RFRNC_NBR  , 
        wrk.SRVC_LINE_NBR  ,
        wrk.UM_SRVC_STTS_CD  , 
        wrk.SRC_UM_SRVC_STTS_CD  , 
        wrk.STTS_DT  , 
        wrk.SRVC_RVW_TYPE_CD  ,
        wrk.AUTHRZD_PLACE_OF_SRVC_CD  ,
        wrk.INPAT_RQSTD_CD  ,
        wrk.INPAT_AUTHRZD_CD  ,
        wrk.RQSTD_PLACE_OF_SRVC_CD  ,
        wrk.RQSTD_PROC_SRVC_TYPE_CD  
         
        """

  def sparkInIt() {

    spark.sql(TrnctTbl)
    spark.sql(pa_query1())
    spark.sql(pa_query2())
  }

}

object PCADX_SCL_NAIC2018_PAEXPHMCY_WRK2 {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    new PCADX_SCL_NAIC2018_PAEXPHMCY_WRK2().sparkInIt()
    println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
  }
}