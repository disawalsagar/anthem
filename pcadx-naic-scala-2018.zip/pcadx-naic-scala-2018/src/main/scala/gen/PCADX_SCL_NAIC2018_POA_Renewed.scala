package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator

import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit

import org.apache.hadoop.fs._;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
class PCADX_SCL_NAIC2018_POA_Renewed() {

	val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
			config("hive.exec.dynamic.partition.mode", "nonstrict").
			config("spark.sql.parquet.compression.codec", "snappy").
			config("hive.warehouse.data.skipTrash", "true").
			config("spark.sql.parquet.writeLegacyFormat", "true").
			enableHiveSupport().getOrCreate()

			import spark.implicits._

			var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_DataExtraction])

			val dbProperties = new Properties
			dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
			val dbWrk = dbProperties.getProperty("work.db")
			val dbInbnd = dbProperties.getProperty("inbound.db")

			val reportYear = dbProperties.getProperty("report.year")
			val mbrEffBetFrmDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_BET_FROM")
			val mbrEffBetToDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_BET_TO")
			val mbrEffNotBetFrmDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_NOT_BET_FROM")
			val mbrEffNotBetToDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_EFCTV_DT_NOT_BET_TO")
			val mbrTrmntBetFrmDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_TRMNTN_DT_BET_FROM")
			val mbrTrmntBetToDt = dbProperties.getProperty("MBR_PROD_ENRLMNT_TRMNTN_DT_BET_TO")
			val mbrTrmntGrtr = dbProperties.getProperty("MBR_PROD_ENRLMNT_TRMNTN_DT_GREATER")
			val wrhDb = dbProperties.getProperty("warehouse.db")
			val PRCHSREBetFrmDt = dbProperties.getProperty("PRCHSR_ORG_EFCTV_DT_BET_FROM")
			val PRCHSREBetToDt = dbProperties.getProperty("PRCHSR_ORG_EFCTV_DT_BET_TO")
			val PRCHSRENotBetFrmDt = dbProperties.getProperty("PRCHSR_ORG_EFCTV_DT_NOT_BET_FROM")
			val PRCHSRENotBetToDt = dbProperties.getProperty("PRCHSR_ORG_EFCTV_DT_NOT_BET_TO")
			val PRCHSRTrmntBetFrmDt = dbProperties.getProperty("PRCHSR_ORG_TRMNTN_DT_BET_FROM")
			val PRCHSRTrmntBetToDt = dbProperties.getProperty("PRCHSR_ORG_TRMNTN_DT_BET_TO")
			val PRCHSRTrmntGrtr = dbProperties.getProperty("PRCHSR_ORG_TRMNTN_DT_GREATER")
			val audit_log_df = spark.sql("select * from " + wrhDb + ".audt_load_log")
			val load_log_key = audit_log_df.filter($"subj_area_nm" === "NAIC2018_MCAS" && $"prcs_nm" === "NAIC2018_MCAS_RPT" && $"load_stts_cd" === "S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString()
			println("load_log_key : " + load_log_key)
			println(" DB INBND : " + dbInbnd)
			println(" DB wrk : " + dbWrk)
			def renewedTrnctTbl() = """Truncate table """ + dbWrk + """.naic2018_mcas_hlthex_poa_renewed_wrk"""

			def renewedNonCat() = """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_poa_renewed_wrk
			select * from( 
			select 
			""" + reportYear + """  as health_year,
			temp.SBSCRBR_ID AS SBSCRBR_ID,
			temp.MBR_KEY AS MBR_KEY,
			temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,  
			temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD, 
			temp.MBU_CF_CD AS MBU_CF_CD,
			temp.PROD_CF_CD AS PROD_CF_CD,
			temp.CMPNY_CF_CD AS CMPNY_CF_CD,
			temp.FUNDG_CF_CD AS FUNDG_CF_CD,
			temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD,
			temp.hcr_cmplynt_cd AS hcr_cmplynt_cd,
			temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD AS HIX_CD,
			BRD.State AS  State,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    
			and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
			WHEN temp.EXCHNG_IND_CD IN ('PB') THEN 'IN' 
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'IN'
			END AS IN_Exchange ,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and 
			temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
			WHEN temp.EXCHNG_IND_CD IN ('PR' , 'OF') THEN  'OUTOFF'
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'OUTOFF'
			END AS OUTOFF_Exchange, 
			CB.GL_LVL_DESC AS naic_lob,
			MED.GL_CF_DESC  as  naic_prod_desc,
			temp.SRC_GRP_NBR as src_grp_nbr, 
			temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
			""" + load_log_key + """ as load_log_key,	
			current_timestamp as load_dt			

			FROM  """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('TOTAL INDIVIDUAL CBE') 
			group by CF_CD, GL_LVL_DESC
			) as CB
			on CB.CF_CD = temp.MBU_CF_CD
			inner join (
			select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			AND GL_CF_DESC NOT LIKE '%CATASTROPHIC%'
			group by CF_CD,  GL_CF_DESC
			) as MED
			on MED.CF_CD = temp.PROD_CF_CD
			inner join
			(
			select
			gl.CF_CD
			,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
			and ((gl.GL_LVL_DESC like ('NON BLUE%') or gl.GL_LVL_DESC like ('BLUE%')) and gl.GL_LVL_DESC not like '%TOTAL' )

			group by gl.CF_CD,State
			) BRD
			on BRD.CF_CD= temp.MBU_CF_CD
			and BRD.State <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE     GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC
			ON FC.CF_CD = temp.FUNDG_CF_CD

			inner join """+dbWrk+""".sbscrbridCheckin2018 sub
			on temp.SBSCRBR_ID = sub.SBSCRBR_ID
			
			-- Added on 4/25 for Issue #13
			left outer join """+dbWrk+""".sbscrbridcheck_Notin2018 subNotin
			on temp.SBSCRBR_ID = subNotin.SBSCRBR_ID

			WHERE
			temp.RCRD_STTS_CD <> 'DEL'
			AND subNotin.SBSCRBR_ID is null 

			AND 

			( temp.MBR_PROD_ENRLMNT_EFCTV_DT  BETWEEN """ + PRCHSREBetFrmDt + """ AND """ + PRCHSREBetToDt + """ 
			OR  """ + PRCHSREBetFrmDt + """ BETWEEN  temp.MBR_PROD_ENRLMNT_EFCTV_DT AND temp.MBR_PROD_ENRLMNT_TRMNTN_DT )
			AND temp.MBR_PROD_ENRLMNT_TRMNTN_DT  >= """ + PRCHSREBetFrmDt + """ 
			AND BRD.STATE NOT IN ('IL', 'DC', 'MA')

			AND temp.SBSCRBR_ID IN (
			SELECT temp1.SBSCRBR_ID
			FROM  """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp1
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('TOTAL INDIVIDUAL CBE') 
			group by 1,2
			) as CB1
			on CB1.CF_CD = temp1.MBU_CF_CD
			inner join (
			select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			AND GL_CF_DESC NOT LIKE '%CATASTROPHIC%'
			group by 1,2
			) as MED1
			on MED1.CF_CD = temp1.PROD_CF_CD
			inner join
			(
			select
			gl.CF_CD
			,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
			and (gl.GL_LVL_DESC like('NON BLUE%') or gl.GL_LVL_DESC like ('BLUE%')) and gl.GL_LVL_DESC not like  ('%TOTAL')

			group by 1,2
			) BRD1
			on BRD1.CF_CD= temp1.MBU_CF_CD
			and BRD1.State <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE     GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC1
			ON FC1.CF_CD = temp1.FUNDG_CF_CD

			WHERE 
			temp1.RCRD_STTS_CD <> 'DEL'
			AND

			(temp1.MBR_PROD_ENRLMNT_EFCTV_DT  BETWEEN """ + PRCHSRENotBetFrmDt + """ AND """ + PRCHSRENotBetToDt + """  OR  """ + PRCHSRENotBetFrmDt + """ BETWEEN  temp1.MBR_PROD_ENRLMNT_EFCTV_DT AND temp1.MBR_PROD_ENRLMNT_TRMNTN_DT )
			AND temp1.MBR_PROD_ENRLMNT_TRMNTN_DT  >= """ + PRCHSRENotBetFrmDt + """
			GROUP BY temp1.SBSCRBR_ID
			)
			
			GROUP BY 
			temp.SBSCRBR_ID,
			temp.MBR_KEY,
			temp.MBRSHP_SOR_CD,  
			temp.GRNDFTHR_IND_CD,
			temp.HIX_CD,
			temp.GRNDFTHRG_STTS_CD,    
			temp.hcr_cmplynt_cd,
			temp.EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD,
			temp.SRC_EXCHNG_CERTFN_CD,
			temp.MBU_CF_CD,
			temp.PROD_CF_CD,
			temp.CMPNY_CF_CD,
			temp.FUNDG_CF_CD,
			BRD.State,
			CB.GL_LVL_DESC,
			MED.GL_CF_DESC,
			temp.SRC_GRP_NBR, 
			temp.SRC_SUBGRP_NBR 
			)x
			--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'
			"""

			def renewedLG() = """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_poa_renewed_wrk
			select * from( 
			select 
			""" + reportYear + """  as health_year,
			temp.SBSCRBR_ID AS SBSCRBR_ID  ,
			temp.MBR_KEY AS MBR_KEY,
			temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,  
			temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD , 
			temp.MBU_CF_CD AS MBU_CF_CD ,
			temp.PROD_CF_CD AS PROD_CF_CD,
			temp.CMPNY_CF_CD AS CMPNY_CF_CD,
			temp.FUNDG_CF_CD AS FUNDG_CF_CD,
			temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
			temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD AS HIX_CD,
			BRD.State AS  State,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    
			and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
			WHEN temp.EXCHNG_IND_CD IN ('PB') THEN 'IN' 
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'IN'
			END AS IN_Exchange ,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and 
			temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
			WHEN temp.EXCHNG_IND_CD IN ('PR' , 'OF') THEN  'OUTOFF'
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'OUTOFF'
			END AS OUTOFF_Exchange, 
			CB.GL_LVL_DESC AS naic_lob,
			MED.GL_CF_DESC  as  naic_prod_desc ,
			temp.SRC_GRP_NBR as src_grp_nbr, 
			temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
			""" + load_log_key + """ as load_log_key,	
			current_date as load_dt			

			FROM  """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' ) 
			group by CF_CD, GL_LVL_DESC
			) as CB
			on CB.CF_CD = temp.MBU_CF_CD
			inner join (
			select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			group by CF_CD,  GL_CF_DESC
			) as MED
			on MED.CF_CD = temp.PROD_CF_CD
			inner join
			(
			select
			gl.CF_CD
			,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
			and ((gl.GL_LVL_DESC like ('NON BLUE%') or gl.GL_LVL_DESC like ('BLUE%')) and gl.GL_LVL_DESC not like '%TOTAL' )

			group by gl.CF_CD,State
			) BRD
			on BRD.CF_CD= temp.MBU_CF_CD
			and BRD.State <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE     GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC
			ON FC.CF_CD = temp.FUNDG_CF_CD

			WHERE temp.RCRD_STTS_CD <> 'DEL'
			AND 
			( temp.MBR_PROD_ENRLMNT_EFCTV_DT  BETWEEN """ + mbrEffBetFrmDt + """ AND """ + mbrEffBetToDt + """ 
			OR  """ + mbrEffBetFrmDt + """ BETWEEN  temp.MBR_PROD_ENRLMNT_EFCTV_DT AND temp.MBR_PROD_ENRLMNT_TRMNTN_DT )
			AND temp.MBR_PROD_ENRLMNT_TRMNTN_DT  >= """ + mbrEffBetFrmDt + """ 

			AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
			AND temp.MBU_CF_CD NOT IN ( 'EDCASH' , 'SPGAZZ' ,'EDCOSH' , 'EDINSH' )
			AND temp.SBSCRBR_ID IN (
			SELECT temp1.SBSCRBR_ID
			FROM  """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp1 
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' ) 
			group by 1,2
			) as CB1
			on CB1.CF_CD = temp1.MBU_CF_CD
			inner join (
			select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			group by 1,2
			) as MED1
			on MED1.CF_CD = temp1.PROD_CF_CD
			inner join
			(
			select
			gl.CF_CD
			,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
			and (gl.GL_LVL_DESC like('NON BLUE%') or gl.GL_LVL_DESC like ('BLUE%')) and gl.GL_LVL_DESC not like  ('%TOTAL')

			group by 1,2
			) BRD1
			on BRD1.CF_CD= temp1.MBU_CF_CD
			and BRD1.State <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE     GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC1
			ON FC1.CF_CD = temp1.FUNDG_CF_CD
			WHERE 
			temp1.RCRD_STTS_CD <> 'DEL'
			AND

			(temp1.MBR_PROD_ENRLMNT_EFCTV_DT  BETWEEN """ + mbrEffNotBetFrmDt + """ AND """ + mbrEffNotBetToDt + """  OR  """ + mbrEffNotBetFrmDt + """ BETWEEN  temp1.MBR_PROD_ENRLMNT_EFCTV_DT AND temp1.MBR_PROD_ENRLMNT_TRMNTN_DT )
			AND temp1.MBR_PROD_ENRLMNT_TRMNTN_DT  >= """ + mbrEffNotBetFrmDt + """
			AND temp1.MBU_CF_CD NOT IN ( 'EDCASH' , 'SPGAZZ','EDCOSH' , 'EDINSH'  )
			GROUP BY temp1.SBSCRBR_ID
			)
			GROUP BY 
			temp.SBSCRBR_ID  ,
			temp.MBR_KEY ,
			temp.MBRSHP_SOR_CD ,  temp.GRNDFTHR_IND_CD ,
			temp.HIX_CD ,
			temp.GRNDFTHRG_STTS_CD ,    temp.hcr_cmplynt_cd,
			temp.EXCHNG_IND_CD ,
			temp.EXCHNG_METL_TYPE_CD ,
			temp.SRC_EXCHNG_CERTFN_CD ,
			temp.MBU_CF_CD  ,
			temp.PROD_CF_CD ,
			temp.CMPNY_CF_CD ,
			temp.FUNDG_CF_CD ,
			BRD.State ,
			CB.GL_LVL_DESC,
			MED.GL_CF_DESC,
			temp.SRC_GRP_NBR, 
			temp.SRC_SUBGRP_NBR 
			)x 
			--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'
			"""

			def renewedCat() = """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_poa_renewed_wrk
			SELECT * FROM(
			select 
			""" + reportYear + """  as health_year,
			temp.SBSCRBR_ID AS SBSCRBR_ID,
			temp.MBR_KEY AS MBR_KEY,
			temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,  
			temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD, 
			temp.MBU_CF_CD AS MBU_CF_CD,
			temp.PROD_CF_CD AS PROD_CF_CD,
			temp.CMPNY_CF_CD AS CMPNY_CF_CD,
			temp.FUNDG_CF_CD AS FUNDG_CF_CD,
			temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
			temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD AS HIX_CD,
			BRD.State AS  State,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    
			and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
			WHEN temp.EXCHNG_IND_CD IN ('PB') THEN 'IN' 
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'IN'
			END AS IN_Exchange ,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and 
			temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
			WHEN temp.EXCHNG_IND_CD IN ('PR' , 'OF') THEN  'OUTOFF'
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'OUTOFF'
			END AS OUTOFF_Exchange, 
			MED.GL_LVL_DESC AS naic_lob,
			MED.GL_CF_DESC  as  naic_prod_desc ,
			temp.SRC_GRP_NBR as src_grp_nbr, 
			temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
			""" + load_log_key + """ as load_log_key,
			current_timestamp as load_dt

			FROM  """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp
			inner join (
			select CF_CD,  GL_CF_DESC, GL_LVL_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			AND GL_CF_DESC  LIKE '%CATASTROPHIC%'
			group by CF_CD,  GL_CF_DESC, GL_LVL_DESC
			) as MED
			on MED.CF_CD = temp.PROD_CF_CD
			inner join
			(
			select
			gl.CF_CD
			,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
			and ((gl.GL_LVL_DESC like('NON BLUE%') or gl.GL_LVL_DESC like('BLUE%')) and gl.GL_LVL_DESC not like  ('%TOTAL'))
			group by gl.CF_CD,State
			) BRD
			on BRD.CF_CD= temp.MBU_CF_CD 
			and BRD.State <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE    GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC
			ON FC.CF_CD = temp.FUNDG_CF_CD

			inner join """+dbWrk+""".sbscrbridCheckin2018 sub
			on temp.SBSCRBR_ID = sub.SBSCRBR_ID
			
			-- Added on 4/25
			left outer join """+dbWrk+""".sbscrbridcheck_Notin2018 subNotin
			on temp.SBSCRBR_ID = subNotin.SBSCRBR_ID

			WHERE temp.RCRD_STTS_CD <> 'DEL'
			AND subNotin.SBSCRBR_ID is null 

			AND 

			( temp.MBR_PROD_ENRLMNT_EFCTV_DT  BETWEEN """ + PRCHSREBetFrmDt + """ AND """ + PRCHSREBetToDt + """ 
			OR  """ + PRCHSREBetFrmDt + """ BETWEEN  temp.MBR_PROD_ENRLMNT_EFCTV_DT AND temp.MBR_PROD_ENRLMNT_TRMNTN_DT )
			AND temp.MBR_PROD_ENRLMNT_TRMNTN_DT  >= """ + PRCHSREBetFrmDt + """ 

			AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
			AND temp.SBSCRBR_ID IN (
			SELECT temp1.SBSCRBR_ID
			FROM  """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp1
			inner join (
			select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			AND GL_CF_DESC  LIKE '%CATASTROPHIC%'
			group by 1,2
			) as MED1
			on MED1.CF_CD = temp1.PROD_CF_CD
			inner join
			(
			select
			gl.CF_CD
			,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
			and ((gl.GL_LVL_DESC like('NON BLUE%')or gl.GL_LVL_DESC like('BLUE%')) and gl.GL_LVL_DESC not like  ('%TOTAL') )	
			group by gl.CF_CD,State
			) BRD1
			on BRD1.CF_CD= temp1.MBU_CF_CD 
			and BRD1.State <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE    GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC1
			ON FC1.CF_CD = temp1.FUNDG_CF_CD
			WHERE 
			temp1.RCRD_STTS_CD <> 'DEL'
			AND
			(temp1.MBR_PROD_ENRLMNT_EFCTV_DT  BETWEEN """ + PRCHSRENotBetFrmDt + """ AND """ + PRCHSRENotBetToDt + """  OR  """ + PRCHSRENotBetFrmDt + """ BETWEEN  temp1.MBR_PROD_ENRLMNT_EFCTV_DT AND temp1.MBR_PROD_ENRLMNT_TRMNTN_DT )
			AND temp1.MBR_PROD_ENRLMNT_TRMNTN_DT  >= """ + PRCHSRENotBetFrmDt + """

			GROUP BY temp1.SBSCRBR_ID
			)

			GROUP BY 
			temp.SBSCRBR_ID,
			temp.MBR_KEY,
			temp.MBRSHP_SOR_CD,  
			temp.GRNDFTHR_IND_CD,
			temp.HIX_CD,
			temp.GRNDFTHRG_STTS_CD, 
			temp.hcr_cmplynt_cd,
			temp.EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD,
			temp.SRC_EXCHNG_CERTFN_CD,
			temp.MBU_CF_CD,
			temp.PROD_CF_CD,
			temp.CMPNY_CF_CD,
			temp.FUNDG_CF_CD,
			BRD.State,
			MED.GL_LVL_DESC,
			MED.GL_CF_DESC,
			temp.SRC_GRP_NBR,
			temp.SRC_SUBGRP_NBR 
			)x
			--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'
			"""

			def renewed_2017() = """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_poa_renewed_wrk
			select * from( 
			select 
			""" + reportYear + """  as health_year,
			temp.SBSCRBR_ID AS SBSCRBR_ID  ,
			temp.MBR_KEY AS MBR_KEY,
			temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,  
			temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD , 
			temp.MBU_CF_CD AS MBU_CF_CD ,
			temp.PROD_CF_CD AS PROD_CF_CD,
			temp.CMPNY_CF_CD AS CMPNY_CF_CD,
			temp.FUNDG_CF_CD AS FUNDG_CF_CD,
			temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
			temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD AS HIX_CD,
			BRD.State AS  State,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    
			and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
			WHEN temp.EXCHNG_IND_CD IN ('PB') THEN 'IN' 
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'IN'
			END AS IN_Exchange ,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and 
			temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
			WHEN temp.EXCHNG_IND_CD IN ('PR' , 'OF') THEN  'OUTOFF'
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'OUTOFF'
			END AS OUTOFF_Exchange, 
			CB.GL_LVL_DESC AS naic_lob,
			MED.GL_CF_DESC  as  naic_prod_desc ,
			temp.SRC_GRP_NBR as src_grp_nbr, 
			temp.SRC_SUBGRP_NBR as src_subgrp_nbr
			""" + load_log_key + """ as load_log_key,	
			current_date as load_dt			

			FROM  """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' ) 
			group by CF_CD, GL_LVL_DESC
			) as CB
			on CB.CF_CD = temp.MBU_CF_CD
			inner join (
			select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			group by CF_CD,  GL_CF_DESC
			) as MED
			on MED.CF_CD = temp.PROD_CF_CD
			inner join
			(
			select
			gl.CF_CD
			,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
			and ((gl.GL_LVL_DESC like ('NON BLUE%') or gl.GL_LVL_DESC like ('BLUE%')) and gl.GL_LVL_DESC not like '%TOTAL' )

			group by gl.CF_CD,State
			) BRD
			on BRD.CF_CD= temp.MBU_CF_CD
			and BRD.State <> 'LT'
			WHERE temp.RCRD_STTS_CD <> 'DEL'
			AND 
			( temp.MBR_PROD_ENRLMNT_EFCTV_DT  BETWEEN """ + mbrEffBetFrmDt + """ AND """ + mbrEffBetToDt + """ 
			OR  """ + mbrEffBetFrmDt + """ BETWEEN  temp.MBR_PROD_ENRLMNT_EFCTV_DT AND temp.MBR_PROD_ENRLMNT_TRMNTN_DT )
			AND temp.MBR_PROD_ENRLMNT_TRMNTN_DT  >= """ + mbrEffBetFrmDt + """ 

			AND   BRD.State IN ( 'GA', 'KY', 'NH', 'VA' )
			AND temp.FUNDG_CF_CD = '45'
			AND temp.SBSCRBR_ID IN (
			SELECT temp1.SBSCRBR_ID
			FROM  """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp1 
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' ) 
			group by 1,2
			) as CB1
			on CB1.CF_CD = temp1.MBU_CF_CD
			inner join (
			select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			group by 1,2
			) as MED1
			on MED1.CF_CD = temp1.PROD_CF_CD
			inner join
			(
			select
			gl.CF_CD
			,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
			and (gl.GL_LVL_DESC like('NON BLUE%') or gl.GL_LVL_DESC like ('BLUE%')) and gl.GL_LVL_DESC not like  ('%TOTAL')

			group by 1,2
			) BRD1
			on BRD1.CF_CD= temp1.MBU_CF_CD
			and BRD1.State <> 'LT'

			WHERE 
			temp1.RCRD_STTS_CD <> 'DEL'
			AND  BRD1.State IN ( 'GA', 'KY', 'NH', 'VA' )
			AND temp1.FUNDG_CF_CD = '45'
			AND

			(temp1.MBR_PROD_ENRLMNT_EFCTV_DT  BETWEEN """ + mbrEffNotBetFrmDt + """ AND """ + mbrEffNotBetToDt + """  OR  """ + mbrEffNotBetFrmDt + """ BETWEEN  temp1.MBR_PROD_ENRLMNT_EFCTV_DT AND temp1.MBR_PROD_ENRLMNT_TRMNTN_DT )
			AND temp1.MBR_PROD_ENRLMNT_TRMNTN_DT  >= """ + mbrEffNotBetFrmDt + """
			GROUP BY temp1.SBSCRBR_ID
			)
			GROUP BY 
			temp.SBSCRBR_ID  ,
			temp.MBR_KEY ,
			temp.MBRSHP_SOR_CD , 
			temp.GRNDFTHR_IND_CD ,
			temp.HIX_CD ,
			temp.GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd,
			temp.EXCHNG_IND_CD ,
			temp.EXCHNG_METL_TYPE_CD ,
			temp.SRC_EXCHNG_CERTFN_CD ,
			temp.MBU_CF_CD  ,
			temp.PROD_CF_CD ,
			temp.CMPNY_CF_CD ,
			temp.FUNDG_CF_CD ,
			BRD.State ,
			CB.GL_LVL_DESC,
			MED.GL_CF_DESC,
			temp.SRC_GRP_NBR,
			temp.SRC_SUBGRP_NBR 
			)x 
			--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'
			"""
			def renewedLG_srcgrp() = """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_poa_renewed_wrk
			select * from( 
			select 
			""" + reportYear + """  as health_year,
			temp.SBSCRBR_ID AS SBSCRBR_ID  ,
			temp.MBR_KEY AS MBR_KEY,
			temp.MBRSHP_SOR_CD AS MBRSHP_SOR_CD,  
			temp.GRNDFTHR_IND_CD AS GRNDFTHR_IND_CD , 
			temp.MBU_CF_CD AS MBU_CF_CD ,
			temp.PROD_CF_CD AS PROD_CF_CD,
			temp.CMPNY_CF_CD AS CMPNY_CF_CD,
			temp.FUNDG_CF_CD AS FUNDG_CF_CD,
			temp.EXCHNG_IND_CD AS EXCHNG_IND_CD,
			temp.EXCHNG_METL_TYPE_CD AS EXCHNG_METL_TYPE_CD,
			temp.GRNDFTHRG_STTS_CD AS GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd AS hcr_cmplynt_cd ,
			temp.SRC_EXCHNG_CERTFN_CD AS SRC_EXCHNG_CERTFN_CD,
			temp.HIX_CD AS HIX_CD,
			BRD.State AS  State,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    
			and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
			WHEN temp.EXCHNG_IND_CD IN ('PB') THEN 'IN' 
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'IN'
			END AS IN_Exchange ,
			CASE WHEN substr(temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and 
			temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
			WHEN temp.EXCHNG_IND_CD IN ('PR' , 'OF') THEN  'OUTOFF'
			WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( temp.EXCHNG_IND_CD IS NULL OR temp.EXCHNG_IND_CD ='UNK') AND 
			HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA')  THEN 'OUTOFF'
			END AS OUTOFF_Exchange, 
			CB.GL_LVL_DESC AS naic_lob,
			MED.GL_CF_DESC  as  naic_prod_desc ,
			temp.SRC_GRP_NBR as src_grp_nbr, 
			temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
			""" + load_log_key + """ as load_log_key,	
			current_date as load_dt			

			FROM  """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' ) 
			group by CF_CD, GL_LVL_DESC
			) as CB
			on CB.CF_CD = temp.MBU_CF_CD
			inner join (
			select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			group by CF_CD,  GL_CF_DESC
			) as MED
			on MED.CF_CD = temp.PROD_CF_CD
			inner join
			(
			select
			gl.CF_CD
			,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
			and ((gl.GL_LVL_DESC like ('NON BLUE%') or gl.GL_LVL_DESC like ('BLUE%')) and gl.GL_LVL_DESC not like ('%TOTAL') )

			group by gl.CF_CD,State
			) BRD
			on BRD.CF_CD= temp.MBU_CF_CD
			and BRD.State <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE     GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC
			ON FC.CF_CD = temp.FUNDG_CF_CD

			WHERE
			temp.RCRD_STTS_CD <> 'DEL'
			AND 

			( temp.MBR_PROD_ENRLMNT_EFCTV_DT  BETWEEN """ + mbrEffBetFrmDt + """ AND """ + mbrEffBetToDt + """ 
			OR  """ + mbrEffBetFrmDt + """ BETWEEN  temp.MBR_PROD_ENRLMNT_EFCTV_DT AND temp.MBR_PROD_ENRLMNT_TRMNTN_DT )
			AND temp.MBR_PROD_ENRLMNT_TRMNTN_DT  >= """ + mbrEffBetFrmDt + """ 

			AND BRD.STATE NOT IN ('IL', 'DC', 'MA')
			AND temp.MBU_CF_CD  IN ( 'EDCASH' , 'SPGAZZ' ,'EDCOSH' , 'EDINSH' )
			AND temp.SRC_GRP_NBR IN  ( '278777'  , '175089' , '175147' , '276470' ,'276500' , '277956' , '277960' , '278547' , '280438' , '280531' , '281249' , '281285' ,'281297'  , 'GA7649')
			AND temp.SBSCRBR_ID IN (
			SELECT temp1.SBSCRBR_ID
			FROM  """ + dbWrk + """.naic2018_mcas_hlthex_poa_wrk temp1 
			inner join (
			select CF_CD, GL_LVL_DESC 
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			WHERE GL_CF_TYPE_DESC = 'CBE'
			AND GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' ) 
			group by 1,2
			) as CB1
			on CB1.CF_CD = temp1.MBU_CF_CD
			inner join (
			select CF_CD,  GL_CF_DESC  from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where GL_CF_TYPE_DESC = 'PRODUCT' 
			group by 1,2
			) as MED1
			on MED1.CF_CD = temp1.PROD_CF_CD
			inner join
			(
			select
			gl.CF_CD
			,trim(substring(gl.GL_LVL_DESC , length(gl.GL_LVL_DESC) - 1) ) as State
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY gl
			where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
			and ((gl.GL_LVL_DESC like('NON BLUE%') or gl.GL_LVL_DESC like ('BLUE%')) and gl.GL_LVL_DESC not like  ('%TOTAL'))

			group by 1,2
			) BRD1
			on BRD1.CF_CD= temp1.MBU_CF_CD
			and BRD1.State <> 'LT'
			inner join
			(
			select DISTINCT CF_CD
			from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY
			where  GL_CF_TYPE_DESC = 'FUND_CODE'
			and CF_CD NOT IN ( select  DISTINCT CF_CD from """ + dbInbnd + """.GL_CF_VRTCL_HRCHY  
			WHERE     GL_CF_TYPE_DESC = 'FUND_CODE' AND  
			( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
			)
			) FC1
			ON FC1.CF_CD = temp1.FUNDG_CF_CD
			WHERE 
			temp1.RCRD_STTS_CD <> 'DEL'
			AND

			(temp1.MBR_PROD_ENRLMNT_EFCTV_DT  BETWEEN """ + mbrEffNotBetFrmDt + """ AND """ + mbrEffNotBetToDt + """  OR  """ + mbrEffNotBetFrmDt + """ BETWEEN  temp1.MBR_PROD_ENRLMNT_EFCTV_DT AND temp1.MBR_PROD_ENRLMNT_TRMNTN_DT )
			AND temp1.MBR_PROD_ENRLMNT_TRMNTN_DT  >= """ + mbrEffNotBetFrmDt + """
			AND temp1.MBU_CF_CD  IN ( 'EDCASH' , 'SPGAZZ','EDCOSH' , 'EDINSH'  )
			AND temp1.SRC_GRP_NBR IN  ( '278777'  , '175089' , '175147' , '276470' ,'276500' , '277956' , '277960' , '278547' , '280438' , '280531' , '281249' , '281285' ,'281297'  , 'GA7649')

			GROUP BY temp1.SBSCRBR_ID
			)
			GROUP BY 
			temp.SBSCRBR_ID  ,
			temp.MBR_KEY ,
			temp.MBRSHP_SOR_CD , 
			temp.GRNDFTHR_IND_CD ,
			temp.HIX_CD ,
			temp.GRNDFTHRG_STTS_CD ,
			temp.hcr_cmplynt_cd,
			temp.EXCHNG_IND_CD ,
			temp.EXCHNG_METL_TYPE_CD ,
			temp.SRC_EXCHNG_CERTFN_CD ,
			temp.MBU_CF_CD  ,
			temp.PROD_CF_CD ,
			temp.CMPNY_CF_CD ,
			temp.FUNDG_CF_CD ,
			BRD.State ,
			CB.GL_LVL_DESC,
			MED.GL_CF_DESC, 
			temp.SRC_GRP_NBR, 
			temp.SRC_SUBGRP_NBR
			)x 
			--where x.IN_Exchange = 'IN' OR OUTOFF_Exchange = 'OUTOFF'
			"""
			def sparkInIt() {
				spark.sql(renewedTrnctTbl())
				spark.sql(renewedNonCat())
				spark.sql(renewedCat())
				//commented as on 5th feb spark.sql(renewedLG())


				/*  if (reportYear.toInt == 2017) {
      println(" ************************** For year 2017 ")
      spark.sql(renewed_2017())
    }
    spark.sql(renewedLG_srcgrp())
				 * 
				 */
				spark.close()
			}

}

object PCADX_SCL_NAIC2018_POA_Renewed {
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val renewed = new PCADX_SCL_NAIC2018_POA_Renewed()
		renewed.sparkInIt()
		println("$$$$$$$$$$$$")
	}
}