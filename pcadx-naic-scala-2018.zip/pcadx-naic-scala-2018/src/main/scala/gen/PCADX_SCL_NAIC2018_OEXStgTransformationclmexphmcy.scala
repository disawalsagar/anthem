package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy(val spark: SparkSession) {  import spark.implicits._

  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy])

  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clmex")
  val end_year = dbProperties.getProperty("end_year_clmex")
  
  var naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame = null
  var naic2018_mcas_src_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame = null
  
  val mbu_cf_cdvals = dbProperties.getProperty("mbu_Cf_cdVals").split(",").toSeq
  
  def sparkInIt() {
    naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk")
    naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk")
    naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk")
    naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk")
    naic2018_mcas_src_eob_cd_inbnd = readDataFromHive(dbInbnd + ".naic2018_mcas_src_eob_cd_inbnd")
    naic2018_mcas_eob_cd_inbnd = readDataFromHive(dbInbnd + ".naic2018_mcas_eob_cd_inbnd")
    naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd = readDataFromHive(dbInbnd + ".naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd")
    naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk")
    naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk")
    naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk")
    naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk")

    populateStgTbl()
    spark.close()
  }

  def populateStgTbl() {

    truncateTbl(dbsg + ".naic2018_mcas_hlthoex_clmexphmcy_stg")
    val oexclmphrmcy_1 = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_1(spark)
    val oexclmphrmcy_2018 = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_2018(spark)
    //clmReceivedData(naic_mcas_hlthex_clmexphmcy_received_ip_wrk,naic_mcas_hlthex_clmexphmcy_received_cat_wrk,naic_mcas_hlthex_clmexphmcy_received_sgp_wrk,naic_mcas_hlthex_clmexphmcy_received_lgp_wrk )
    val objclmReceivedData = clmReceivedData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk)
    val objsubInntwkData = getSubInntwkData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk)
    val objsubOutntwkData = getSubOutntwkData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk)
    val objDeniedInntwk = getDeniedInntwk(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk,
      naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk0_30 = getDeniedInntwkBetweenDates(0, 30, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk31_60 = getDeniedInntwkBetweenDates(31, 60, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedInntwk61_90 = getDeniedInntwkBetweenDates(61, 90, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    //objDeniedInntwk61_90.show
    val objDeniedInntwk_90 = getDeniedInntwk_90(end_year, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val objDeniedOutntwk = getDeniedOutntwk(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk,
      naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedOutntwk0_30 = getDeniedOutntwkBetweenDates(0, 30, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedOutntwk31_60 = getDeniedOutntwkBetweenDates(31, 60, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val objDeniedOutntwk61_90 = getDeniedOutntwkBetweenDates(61, 90, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    //objDeniedInntwk61_90.show
    val objDeniedOutntwk_90 = getDeniedOutntwk_90(end_year, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val paidInntwk = oexclmphrmcy_1.getPaidInntwk(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val paidInntwk0_30 = oexclmphrmcy_1.getPaidInntwkBetweenDays(0, 30, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val paidInntwk31_60 = oexclmphrmcy_1.getPaidInntwkBetweenDays(31, 60, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val paidInntwk61_90 = oexclmphrmcy_1.getPaidInntwkBetweenDays(61, 90, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val paidInntwk_90 = oexclmphrmcy_1.getPaidInntwk_90(end_year, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)

    val paidOutntwk = oexclmphrmcy_1.getPaidOutntwk(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val paidOutntwk0_30 = oexclmphrmcy_1.getPaidOutntwkBetweenDays(0, 30, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val paidOutntwk31_60 = oexclmphrmcy_1.getPaidOutntwkBetweenDays(31, 60, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val paidOutntwk61_90 = oexclmphrmcy_1.getPaidOutntwkBetweenDays(61, 90, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val paidOutntwk_90 = oexclmphrmcy_1.getPaidOutntwk_90(end_year, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)

    val clm_paidamt = oexclmphrmcy_1.getamtData("PAID_AMT", "paid", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val clm_cpayamt = oexclmphrmcy_1.getamtData("CPAY_AMT", "copay", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val clm_coinsrnamt = oexclmphrmcy_1.getamtData("COINSRN_AMT", "coinsrn", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)
    val clm_ddctblamt = oexclmphrmcy_1.getamtData("DDCTBL_AMT", "ddctbl", naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, mbu_cf_cdvals)

  }
  def truncateTbl(tblName: String) {
    spark.sql("TRUNCATE TABLE " + tblName)
  }
  def writeDataToHive(tblName: String, finalDf: DataFrame) {
    finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
    println("Data added in stage table")
  }
  def readDataFromHive(tble: String): DataFrame = {
    val queryOutputTable = """SELECT * FROM """ + tble
    val tbl_data_df = spark.sql(queryOutputTable)
    logger.info("Read data from hive")
    tbl_data_df
  }

  def getIpSgpPlan(wrk_df: DataFrame, lob_type: String): DataFrame = {
    val metl_cd = Seq("01", "02", "03", "04")
    val ip_df = wrk_df.filter($"naic_lob".equalTo(lob_type) &&
      ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"hcr_cmplynt_cd".equalTo("Y") &&
      ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull) &&
      $"exchng_metl_type_cd".isin(metl_cd: _*) &&
      $"in_exchange".isNull)

    ip_df
  }
  def getGtData(wrk_df: DataFrame, lob_type: String, islgp: Boolean): DataFrame = {
    var gt_df: DataFrame = null
    if (islgp) {
      gt_df = wrk_df.filter($"grndfthr_ind_cd".equalTo("YES") &&
        //($"grndfthr_ind_cd".equalTo("YES") || $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull ) &&
        $"in_exchange".isNull)
    } else {
      gt_df = wrk_df.filter($"naic_lob".equalTo(lob_type) &&
        ($"grndfthr_ind_cd".equalTo("YES") || $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
        $"in_exchange".isNull)
    }
    gt_df
  }
  def clmReceivedData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame): DataFrame = {
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val nbrclm_received_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_bronze_ip"))

    val nbrclm_received_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_silver_ip"))

    val brSil = nbrclm_received_bronze_ip.alias("parent").join(nbrclm_received_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip")
    val nbrclm_received_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_gold_ip"))
    val bsGld = brSilData.alias("parent").join(nbrclm_received_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"))

    val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip")
    val nbrclm_received_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_platinum_ip"))

    val bsgchild = bsGldData.alias("parent").join(nbrclm_received_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"))

    val bsgchildData = bsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip")
    val total_ip = nbrclm_received_bronze_ip.union(nbrclm_received_silver_ip.union(nbrclm_received_gold_ip.union(nbrclm_received_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_received_bronze_ip")

    val nbrclm_received_total_ip = total_ip.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_received_bronze_ip").alias("nbrclm_received_total_ip"))
    val ip = bsgchildData.alias("parent").join(nbrclm_received_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"))

    val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)
    val nbrclm_received_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_bronze_sgp"))
    val ipBrz = ipData.alias("parent").join(nbrclm_received_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"))

    val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp")

    val nbrclm_received_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_silver_sgp"))
    val ipbSil = ipBrzData.alias("parent").join(nbrclm_received_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"))

    val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp")
    val nbrclm_received_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_gold_sgp"))
    val ipbsGld = ipbSilData.alias("parent").join(nbrclm_received_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"))

    val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp")
    val nbrclm_received_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_platinum_sgp"))
    val ipbsgchild = ipbsGldData.alias("parent").join(nbrclm_received_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"))

    val ipbsgchildData = ipbsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp")
    val total_sgp = nbrclm_received_bronze_sgp.union(nbrclm_received_silver_sgp.union(nbrclm_received_gold_sgp.union(nbrclm_received_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_received_bronze_sgp")

    val nbrclm_received_total_sgp = total_sgp.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_received_bronze_sgp").alias("nbrclm_received_total_sgp"))
    val ipsgp = ipbsgchildData.alias("parent").join(nbrclm_received_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"))

    val ipsgpData = ipsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp")

    lob_type = ""
    var islgp = true
    val gt_lgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp)

    val nbrclm_received_gtlgp = gt_lgp_df.filter($"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_gtlgp"))

    val gtLgp = ipsgpData.alias("parent").join(nbrclm_received_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"))

    val gtLgpData = gtLgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_gtlgp")

    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gt_sgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type, islgp)

    val nbrclm_received_gtsgp = gt_sgp_df.filter($"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_gtsgp"))

    val gtSgp = gtLgpData.alias("parent").join(nbrclm_received_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"))

    val gtSgpData = gtSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_gtlgp", "nbrclm_received_gtsgp")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val gt_ip_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp)

    val nbrclm_received_gtip = gt_ip_df.filter($"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_gtip"))

    val gtIp = gtSgpData.alias("parent").join(nbrclm_received_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"))

    val gtIpData = gtIp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_gtlgp", "nbrclm_received_gtsgp", "nbrclm_received_gtip")

    val tot_gt = nbrclm_received_gtip.union(nbrclm_received_gtsgp.union(nbrclm_received_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_received_gtip")

    val nbrclm_received_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_received_gtip").alias("nbrclm_received_total_gtip"))

    val gttot = gtIpData.alias("parent").join(nbrclm_received_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"))

    val gttotData = gttot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_gtlgp", "nbrclm_received_gtsgp", "nbrclm_received_gtip", "nbrclm_received_total_gtip")

    val nbrclm_received_lgp_mmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) && (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) &&
      $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_lgp_mmcare"))

    val lgpmmcare = gttotData.alias("parent").join(nbrclm_received_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"), col("nbrclm_received_lgp_mmcare"))

    val lgpmmcareData = lgpmmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_gtlgp", "nbrclm_received_gtsgp", "nbrclm_received_gtip", "nbrclm_received_total_gtip", "nbrclm_received_lgp_mmcare")

    val nbrclm_received_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
        $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_stucvg"))

    val stuvg = lgpmmcareData.alias("parent").join(nbrclm_received_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"), col("nbrclm_received_lgp_mmcare"), col("nbrclm_received_stucvg"))

    val stuvgData = stuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_gtlgp", "nbrclm_received_gtsgp", "nbrclm_received_gtip", "nbrclm_received_total_gtip", "nbrclm_received_lgp_mmcare", "nbrclm_received_stucvg")
    val nbrclm_received_catastrophic = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_catastrophic"))
    val cat = stuvgData.alias("parent").join(nbrclm_received_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_received_bronze_ip"), col("nbrclm_received_silver_ip"), col("nbrclm_received_gold_ip"), col("nbrclm_received_platinum_ip"),
        col("nbrclm_received_total_ip"), col("nbrclm_received_bronze_sgp"), col("nbrclm_received_silver_sgp"), col("nbrclm_received_gold_sgp"), col("nbrclm_received_platinum_sgp"),
        col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"), col("nbrclm_received_lgp_mmcare"), col("nbrclm_received_stucvg"), col("nbrclm_received_catastrophic"))

    val catData = cat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_received_bronze_ip", "nbrclm_received_silver_ip", "nbrclm_received_gold_ip", "nbrclm_received_platinum_ip",
        "nbrclm_received_total_ip", "nbrclm_received_bronze_sgp", "nbrclm_received_silver_sgp", "nbrclm_received_gold_sgp", "nbrclm_received_platinum_sgp",
        "nbrclm_received_total_sgp", "nbrclm_received_gtlgp", "nbrclm_received_gtsgp", "nbrclm_received_gtip", "nbrclm_received_total_gtip", "nbrclm_received_catastrophic", "nbrclm_received_lgp_mmcare", "nbrclm_received_stucvg")

    catData
  }
  def getSubInntwkData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame): DataFrame = {
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val nbrclm_sub_inntwk_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      $"inn_cd".isin(clminn_cd: _*)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_bronze_ip"))

    val nbrclm_sub_inntwk_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      $"inn_cd".isin(clminn_cd: _*)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_silver_ip"))

    val brzSil = nbrclm_sub_inntwk_bronze_ip.alias("parent").join(nbrclm_sub_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"))

    val brzSilData = brzSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip")

    val nbrclm_sub_inntwk_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      $"inn_cd".isin(clminn_cd: _*)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_gold_ip"))

    val bsGld = brzSilData.alias("parent").join(nbrclm_sub_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"))

    val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip")

    val nbrclm_sub_inntwk_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      $"inn_cd".isin(clminn_cd: _*)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_platinum_ip"))

    val bsgchild = bsGldData.alias("parent").join(nbrclm_sub_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"))

    val bsgchildData = bsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip")

    val tot_ip = nbrclm_sub_inntwk_bronze_ip.union(nbrclm_sub_inntwk_silver_ip.union(nbrclm_sub_inntwk_gold_ip.union(nbrclm_sub_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_sub_inntwk_bronze_ip")

    val nbrclm_sub_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_sub_inntwk_bronze_ip").alias("nbrclm_sub_inntwk_total_ip"))

    val ip = bsgchildData.alias("parent").join(nbrclm_sub_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"))

    val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val nbrclm_sub_inntwk_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)
      && $"inn_cd".isin(clminn_cd: _*)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_bronze_sgp"))
    val ipBrz = ipData.alias("parent").join(nbrclm_sub_inntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"))

    val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp")

    val nbrclm_sub_inntwk_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      $"inn_cd".isin(clminn_cd: _*)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_silver_sgp"))
    val ipbSil = ipBrzData.alias("parent").join(nbrclm_sub_inntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"))

    val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp")

    val nbrclm_sub_inntwk_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      $"inn_cd".isin(clminn_cd: _*)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_gold_sgp"))
    val ipbsGld = ipbSilData.alias("parent").join(nbrclm_sub_inntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"))

    val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp")

    val nbrclm_sub_inntwk_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      $"inn_cd".isin(clminn_cd: _*)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_platinum_sgp"))
    val ipbsgchild = ipbsGldData.alias("parent").join(nbrclm_sub_inntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"))

    val ipbsgchildData = ipbsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip",
        "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp")

    val tot_sgp = nbrclm_sub_inntwk_bronze_sgp.union(nbrclm_sub_inntwk_silver_sgp.union(nbrclm_sub_inntwk_gold_sgp.union(nbrclm_sub_inntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_sub_inntwk_bronze_sgp")

    val nbrclm_sub_inntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_sub_inntwk_bronze_sgp").alias("nbrclm_sub_inntwk_total_sgp"))

    val ipsgp = ipbsgchildData.alias("parent").join(nbrclm_sub_inntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"))

    val ipsgpData = ipsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp")
    lob_type = ""
    var islgp = true
    val gt_lgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp)

    val nbrclm_sub_inntwk_gtlgp = gt_lgp_df.filter($"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_gtlgp"))

    val gtlgp = ipsgpData.alias("parent").join(nbrclm_sub_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_gtlgp"))

    val gtlgpData = gtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false

    val gt_sgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type, islgp)
    val nbrclm_sub_inntwk_gtsgp = gt_sgp_df.filter($"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_gtsgp"))
    val gtsgp = gtlgpData.alias("parent").join(nbrclm_sub_inntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_gtlgp"), col("nbrclm_sub_inntwk_gtsgp"))

    val gtsgpData = gtsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp", "nbrclm_sub_inntwk_gtsgp")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val gt_ip_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp)
    val nbrclm_sub_inntwk_gtip = gt_ip_df.filter($"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_gtip"))

    val gtip = gtsgpData.alias("parent").join(nbrclm_sub_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_gtlgp"), col("nbrclm_sub_inntwk_gtsgp"), col("nbrclm_sub_inntwk_gtip"))

    val gtipData = gtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_gtsgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp", "nbrclm_sub_inntwk_gtsgp", "nbrclm_sub_inntwk_gtip")
    val tot_gt = nbrclm_sub_inntwk_gtip.union(nbrclm_sub_inntwk_gtsgp.union(nbrclm_sub_inntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_sub_inntwk_gtip")

    val nbrclm_sub_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_sub_inntwk_gtip").alias("nbrclm_sub_inntwk_total_gtip"))

    val gttot = gtipData.alias("parent").join(nbrclm_sub_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"),
        col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"), col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_gtlgp"), col("nbrclm_sub_inntwk_gtsgp"), col("nbrclm_sub_inntwk_gtip"), col("nbrclm_sub_inntwk_total_gtip"))
    //nbrclm_sub_inntwk_platinum_sgp
    val gttotData = gttot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp", "nbrclm_sub_inntwk_gtsgp", "nbrclm_sub_inntwk_gtip", "nbrclm_sub_inntwk_total_gtip")

    val nbrclm_sub_inntwk_catastrophic = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) && $"inn_cd".isin(clminn_cd: _*) &&
      $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_catastrophic"))

    val cat = gttotData.alias("parent").join(nbrclm_sub_inntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"), col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"),
        col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_gtlgp"), col("nbrclm_sub_inntwk_gtsgp"), col("nbrclm_sub_inntwk_gtip"), col("nbrclm_sub_inntwk_total_gtip"), col("nbrclm_sub_inntwk_catastrophic"))

    val catData = cat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp", "nbrclm_sub_inntwk_gtsgp", "nbrclm_sub_inntwk_gtip", "nbrclm_sub_inntwk_total_gtip",
        "nbrclm_sub_inntwk_catastrophic")

    val nbrclm_sub_inntwk_lgp_mmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) && $"inn_cd".isin(clminn_cd: _*) &&
      $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_lgp_mmcare"))

    val lgp = catData.alias("parent").join(nbrclm_sub_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"), col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"),
        col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_gtlgp"), col("nbrclm_sub_inntwk_gtsgp"), col("nbrclm_sub_inntwk_gtip"), col("nbrclm_sub_inntwk_total_gtip"), col("nbrclm_sub_inntwk_catastrophic"), col("nbrclm_sub_inntwk_lgp_mmcare"))

    val lgpData = lgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp", "nbrclm_sub_inntwk_gtsgp", "nbrclm_sub_inntwk_gtip", "nbrclm_sub_inntwk_total_gtip",
        "nbrclm_sub_inntwk_catastrophic", "nbrclm_sub_inntwk_lgp_mmcare")

    val nbrclm_sub_inntwk_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) && $"inn_cd".isin(clminn_cd: _*) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
        $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_inntwk_stucvg"))

    val stuvg = lgpData.alias("parent").join(nbrclm_sub_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_inntwk_bronze_ip"), col("nbrclm_sub_inntwk_silver_ip"), col("nbrclm_sub_inntwk_gold_ip"), col("nbrclm_sub_inntwk_platinum_ip"), col("nbrclm_sub_inntwk_total_ip"), col("nbrclm_sub_inntwk_bronze_sgp"), col("nbrclm_sub_inntwk_silver_sgp"),
        col("nbrclm_sub_inntwk_gold_sgp"), col("nbrclm_sub_inntwk_platinum_sgp"), col("nbrclm_sub_inntwk_total_sgp"), col("nbrclm_sub_inntwk_gtlgp"), col("nbrclm_sub_inntwk_gtsgp"), col("nbrclm_sub_inntwk_gtip"), col("nbrclm_sub_inntwk_total_gtip"), col("nbrclm_sub_inntwk_catastrophic"), col("nbrclm_sub_inntwk_lgp_mmcare"), col("nbrclm_sub_inntwk_stucvg"))

    val stuvgData = stuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_inntwk_bronze_ip", "nbrclm_sub_inntwk_silver_ip", "nbrclm_sub_inntwk_gold_ip", "nbrclm_sub_inntwk_platinum_ip", "nbrclm_sub_inntwk_total_ip", "nbrclm_sub_inntwk_bronze_sgp", "nbrclm_sub_inntwk_silver_sgp", "nbrclm_sub_inntwk_gold_sgp", "nbrclm_sub_inntwk_platinum_sgp", "nbrclm_sub_inntwk_total_sgp", "nbrclm_sub_inntwk_gtlgp", "nbrclm_sub_inntwk_gtsgp", "nbrclm_sub_inntwk_gtip", "nbrclm_sub_inntwk_total_gtip",
        "nbrclm_sub_inntwk_catastrophic", "nbrclm_sub_inntwk_lgp_mmcare", "nbrclm_sub_inntwk_stucvg")

    stuvgData
  }
  def getSubOutntwkData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame): DataFrame = {
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val nbrclm_sub_outntwk_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_bronze_ip"))

    val nbrclm_sub_outntwk_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_silver_ip"))

    val brzSil = nbrclm_sub_outntwk_bronze_ip.alias("parent").join(nbrclm_sub_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"))

    val brzSilData = brzSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip")

    val nbrclm_sub_outntwk_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_gold_ip"))

    val bsGld = brzSilData.alias("parent").join(nbrclm_sub_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"))

    val bsGldData = bsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip")

    val nbrclm_sub_outntwk_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_platinum_ip"))

    val bsgchild = bsGldData.alias("parent").join(nbrclm_sub_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"))

    val bsgchildData = bsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip")

    val tot_ip = nbrclm_sub_outntwk_bronze_ip.union(nbrclm_sub_outntwk_silver_ip.union(nbrclm_sub_outntwk_gold_ip.union(nbrclm_sub_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_sub_outntwk_bronze_ip")

    val nbrclm_sub_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_sub_outntwk_bronze_ip").alias("nbrclm_sub_outntwk_total_ip"))

    val ip = bsgchildData.alias("parent").join(nbrclm_sub_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"))

    val ipData = ip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val nbrclm_sub_outntwk_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_bronze_sgp"))
    val ipBrz = ipData.alias("parent").join(nbrclm_sub_outntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"))

    val ipBrzData = ipBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp")

    val nbrclm_sub_outntwk_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_silver_sgp"))
    val ipbSil = ipBrzData.alias("parent").join(nbrclm_sub_outntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"))

    val ipbSilData = ipbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp")

    val nbrclm_sub_outntwk_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_gold_sgp"))
    val ipbsGld = ipbSilData.alias("parent").join(nbrclm_sub_outntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"))

    val ipbsGldData = ipbsGld.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp")

    val nbrclm_sub_outntwk_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_platinum_sgp"))
    val ipbsgchild = ipbsGldData.alias("parent").join(nbrclm_sub_outntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"))

    val ipbsgchildData = ipbsgchild.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip",
        "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp")

    val tot_sgp = nbrclm_sub_outntwk_bronze_sgp.union(nbrclm_sub_outntwk_silver_sgp.union(nbrclm_sub_outntwk_gold_sgp.union(nbrclm_sub_outntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_sub_outntwk_bronze_sgp")

    val nbrclm_sub_outntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_sub_outntwk_bronze_sgp").alias("nbrclm_sub_outntwk_total_sgp"))

    val ipsgp = ipbsgchildData.alias("parent").join(nbrclm_sub_outntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"))

    val ipsgpData = ipsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp")
    lob_type = ""
    var islgp = true
    val gt_lgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp)

    val nbrclm_sub_outntwk_gtlgp = gt_lgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_gtlgp"))

    val gtlgp = ipsgpData.alias("parent").join(nbrclm_sub_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_gtlgp"))

    val gtlgpData = gtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false

    val gt_sgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type, islgp)
    val nbrclm_sub_outntwk_gtsgp = gt_sgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_gtsgp"))
    val gtsgp = gtlgpData.alias("parent").join(nbrclm_sub_outntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_gtlgp"), col("nbrclm_sub_outntwk_gtsgp"))

    val gtsgpData = gtsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_gtlgp", "nbrclm_sub_outntwk_gtsgp")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val gt_ip_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp)
    val nbrclm_sub_outntwk_gtip = gt_ip_df.filter((!$"inn_cd".isin(clminn_cd: _*)) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_gtip"))

    val gtip = gtsgpData.alias("parent").join(nbrclm_sub_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_gtlgp"), col("nbrclm_sub_outntwk_gtsgp"), col("nbrclm_sub_outntwk_gtip"))

    val gtipData = gtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_gtlgp", "nbrclm_sub_outntwk_gtsgp", "nbrclm_sub_outntwk_gtip")
    val tot_gt = nbrclm_sub_outntwk_gtip.union(nbrclm_sub_outntwk_gtsgp.union(nbrclm_sub_outntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_sub_outntwk_gtip")

    val nbrclm_sub_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_sub_outntwk_gtip").alias("nbrclm_sub_outntwk_total_gtip"))

    val gttot = gtipData.alias("parent").join(nbrclm_sub_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"),
        col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"), col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_gtlgp"), col("nbrclm_sub_outntwk_gtsgp"), col("nbrclm_sub_outntwk_gtip"), col("nbrclm_sub_outntwk_total_gtip"))

    val gttotData = gttot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_gtlgp", "nbrclm_sub_outntwk_gtsgp", "nbrclm_sub_outntwk_gtip", "nbrclm_sub_outntwk_total_gtip")

    val nbrclm_sub_outntwk_catastrophic = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) && (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_catastrophic"))

    val cat = gttotData.alias("parent").join(nbrclm_sub_outntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"), col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"),
        col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_gtlgp"), col("nbrclm_sub_outntwk_gtsgp"), col("nbrclm_sub_outntwk_gtip"), col("nbrclm_sub_outntwk_total_gtip"), col("nbrclm_sub_outntwk_catastrophic"))

    val catData = cat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_gtlgp", "nbrclm_sub_outntwk_gtsgp", "nbrclm_sub_outntwk_gtip", "nbrclm_sub_outntwk_total_gtip",
        "nbrclm_sub_outntwk_catastrophic")

    val nbrclm_sub_outntwk_lgp_mmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) && $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) &&
      (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) && (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_lgp_mmcare"))

    val lgp = catData.alias("parent").join(nbrclm_sub_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"), col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"),
        col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_gtlgp"), col("nbrclm_sub_outntwk_gtsgp"), col("nbrclm_sub_outntwk_gtip"), col("nbrclm_sub_outntwk_total_gtip"), col("nbrclm_sub_outntwk_catastrophic"), col("nbrclm_sub_outntwk_lgp_mmcare"))

    val lgpData = lgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_gtlgp", "nbrclm_sub_outntwk_gtsgp", "nbrclm_sub_outntwk_gtip", "nbrclm_sub_outntwk_total_gtip",
        "nbrclm_sub_outntwk_catastrophic", "nbrclm_sub_outntwk_lgp_mmcare")

    val nbrclm_sub_outntwk_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"PRMPT_PAY_CLM_RCVD_DT".between(strt_year, end_year) && $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) && (!$"inn_cd".isin(clminn_cd: _*)) &&
        $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_sub_outntwk_stucvg"))

    val stuvg = lgpData.alias("parent").join(nbrclm_sub_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_sub_outntwk_bronze_ip"), col("nbrclm_sub_outntwk_silver_ip"), col("nbrclm_sub_outntwk_gold_ip"), col("nbrclm_sub_outntwk_platinum_ip"), col("nbrclm_sub_outntwk_total_ip"), col("nbrclm_sub_outntwk_bronze_sgp"), col("nbrclm_sub_outntwk_silver_sgp"),
        col("nbrclm_sub_outntwk_gold_sgp"), col("nbrclm_sub_outntwk_platinum_sgp"), col("nbrclm_sub_outntwk_total_sgp"), col("nbrclm_sub_outntwk_gtlgp"), col("nbrclm_sub_outntwk_gtsgp"), col("nbrclm_sub_outntwk_gtip"), col("nbrclm_sub_outntwk_total_gtip"), col("nbrclm_sub_outntwk_catastrophic"), col("nbrclm_sub_outntwk_lgp_mmcare"), col("nbrclm_sub_outntwk_stucvg"))

    val stuvgData = stuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_sub_outntwk_bronze_ip", "nbrclm_sub_outntwk_silver_ip", "nbrclm_sub_outntwk_gold_ip", "nbrclm_sub_outntwk_platinum_ip", "nbrclm_sub_outntwk_total_ip", "nbrclm_sub_outntwk_bronze_sgp", "nbrclm_sub_outntwk_silver_sgp", "nbrclm_sub_outntwk_gold_sgp", "nbrclm_sub_outntwk_platinum_sgp", "nbrclm_sub_outntwk_total_sgp", "nbrclm_sub_outntwk_gtlgp", "nbrclm_sub_outntwk_gtsgp", "nbrclm_sub_outntwk_gtip", "nbrclm_sub_outntwk_total_gtip",
        "nbrclm_sub_outntwk_catastrophic", "nbrclm_sub_outntwk_lgp_mmcare", "nbrclm_sub_outntwk_stucvg")

    stuvgData
  }
  def joinedDf(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_src_eob_cd_inbnd: DataFrame, naic2018_mcas_eob_cd_inbnd: DataFrame,
               naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    val joined_df = naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.alias("received_wrk").join(
      naic2018_mcas_src_eob_cd_inbnd.alias("sec"),
      $"received_wrk.src_eob_cd" === $"sec.src_eob_cd" &&
        $"received_wrk.clm_sor_cd" === $"sec.clm_sor_cd", "left_outer")
      .join(
        naic2018_mcas_eob_cd_inbnd.alias("chip"),
        $"received_wrk.eob_cd" === $"chip.eob_cd" &&
          $"received_wrk.clm_sor_cd" === $"chip.clm_sor_cd", "left_outer")
      .join(
        naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd.alias("aces"),
        $"received_wrk.src_clm_line_disp_rsn_cd" === $"aces.src_clm_line_disp_rsn_cd" &&
          $"received_wrk.clm_sor_cd" === $"aces.clm_sor_cd", "left_outer")
      .filter($"sec.src_eob_cd".isNull && $"sec.clm_sor_cd".isNull &&
        $"chip.eob_cd".isNull && $"chip.clm_sor_cd".isNull &&
        $"aces.src_clm_line_disp_rsn_cd".isNull && $"aces.clm_sor_cd".isNull)
    //chip.src_eob_cd
    joined_df

  }
  def getDeniedInntwk(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
                      naic2018_mcas_src_eob_cd_inbnd: DataFrame, naic2018_mcas_eob_cd_inbnd: DataFrame,
                      naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_brz = joinedDf(received_brnz, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sil = joinedDf(received_silver, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip")
    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gld = joinedDf(received_gold, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_plt = joinedDf(received_platinum, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_bronze_ip.union(nbrclm_denied_inntwk_silver_ip.union(nbrclm_denied_inntwk_gold_ip.union(nbrclm_denied_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_denied_inntwk_bronze_ip")

    val nbrclm_denied_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_bronze_ip").alias("nbrclm_denied_inntwk_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"),
        col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_brz = joinedDf(received_sgp_bronze, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_sil = joinedDf(received_sgp_silver, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_gld = joinedDf(received_sgp_gold, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_plt = joinedDf(received_sgp_plt, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp")

    val tot_sgp = nbrclm_denied_inntwk_bronze_sgp.union(nbrclm_denied_inntwk_silver_sgp.union(nbrclm_denied_inntwk_gold_sgp.union(nbrclm_denied_inntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_denied_inntwk_bronze_sgp")

    val nbrclm_denied_inntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_bronze_sgp").alias("nbrclm_denied_inntwk_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp")

    lob_type = ""
    var islgp = true
    val lgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp)

    val received_gtlgp = lgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gtlgp = joinedDf(received_gtlgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gtlgp"))
    val gtlgpMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gtsgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type, islgp)

    val received_gtsgp = gtsgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))
    val denied_in_gtsgp = joinedDf(received_gtsgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_gtsgp = denied_in_gtsgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val gtip_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp)

    val received_gtip = gtip_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))
    val denied_in_gtip = joinedDf(received_gtip, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp", "nbrclm_denied_inntwk_gtip")
    val tot_gt = nbrclm_denied_inntwk_gtip.union(nbrclm_denied_inntwk_gtsgp.union(nbrclm_denied_inntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_denied_inntwk_gtip")

    val nbrclm_denied_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_denied_inntwk_gtip").alias("nbrclm_denied_inntwk_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"), col("nbrclm_denied_inntwk_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp", "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip")
    val received_cat = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".isNull &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_cat = joinedDf(received_cat, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_catastrophic"))
    val catMaster = gttotMasterData.alias("parent").join(nbrclm_denied_inntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"), col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp", "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic")
    // catMasterData
    val received_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) &&
      $"in_exchange".isNull &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_lgpmmcare = joinedDf(received_lgpmmcare, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_lgp_mmcare"))

    val lgpmmcareMaster = catMasterData.alias("parent").join(nbrclm_denied_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"), col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp", "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare")

    val received_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) &&
        $"in_exchange".isNull &&
        $"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_stucvg = joinedDf(received_stucvg, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_stucvg = denied_in_stucvg.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_bronze_ip"), col("nbrclm_denied_inntwk_silver_ip"), col("nbrclm_denied_inntwk_gold_ip"), col("nbrclm_denied_inntwk_platinum_ip"), col("nbrclm_denied_inntwk_total_ip"),
        col("nbrclm_denied_inntwk_bronze_sgp"), col("nbrclm_denied_inntwk_silver_sgp"), col("nbrclm_denied_inntwk_gold_sgp"), col("nbrclm_denied_inntwk_platinum_sgp"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"), col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"), col("nbrclm_denied_inntwk_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_bronze_ip", "nbrclm_denied_inntwk_silver_ip", "nbrclm_denied_inntwk_gold_ip", "nbrclm_denied_inntwk_platinum_ip", "nbrclm_denied_inntwk_total_ip",
        "nbrclm_denied_inntwk_bronze_sgp", "nbrclm_denied_inntwk_silver_sgp", "nbrclm_denied_inntwk_gold_sgp", "nbrclm_denied_inntwk_platinum_sgp", "nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp", "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare", "nbrclm_denied_inntwk_stucvg")
    stucvgMasterData
  }
  def getDeniedInntwkBetweenDates(start_day: Int, end_day: Int, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
                                  naic2018_mcas_src_eob_cd_inbnd: DataFrame, naic2018_mcas_eob_cd_inbnd: DataFrame,
                                  naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = start_day.toString + "to" + end_day
    val fend_day = end_day + 1

    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_brz = joinedDf(received_brnz, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sil = joinedDf(received_silver, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip")
    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_gld = joinedDf(received_gold, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_plt = joinedDf(received_platinum, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_bronze_ip.union(nbrclm_denied_inntwk_silver_ip.union(nbrclm_denied_inntwk_gold_ip.union(nbrclm_denied_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_ip").alias("nbrclm_denied_inntwk_" + colVal + "_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_brz = joinedDf(received_sgp_bronze, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_sil = joinedDf(received_sgp_silver, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_gld = joinedDf(received_sgp_gold, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_plt = joinedDf(received_sgp_plt, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp")

    val tot_sgp = nbrclm_denied_inntwk_bronze_sgp.union(nbrclm_denied_inntwk_silver_sgp.union(nbrclm_denied_inntwk_gold_sgp.union(nbrclm_denied_inntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_denied_inntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp").alias("nbrclm_denied_inntwk_" + colVal + "_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp")

    lob_type = ""
    var islgp = true
    val lgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp)

    val received_gtlgp = lgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_gtlgp = joinedDf(received_gtlgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gtlgp"))
    val gtlgpMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gtsgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type, islgp)

    val received_gtsgp = gtsgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
    val denied_in_gtsgp = joinedDf(received_gtsgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_gtsgp = denied_in_gtsgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val gtip_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp)

    val received_gtip = gtip_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
    val denied_in_gtip = joinedDf(received_gtip, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip")
    val tot_gt = nbrclm_denied_inntwk_gtip.union(nbrclm_denied_inntwk_gtsgp.union(nbrclm_denied_inntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colVal + "_gtip"))

    val nbrclm_denied_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col("nbrclm_denied_inntwk_" + colVal + "_gtip")).alias("nbrclm_denied_inntwk_" + colVal + "_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip")
    val received_cat = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".isNull &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_cat = joinedDf(received_cat, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_catastrophic"))
    val catMaster = gttotMasterData.alias("parent").join(nbrclm_denied_inntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip", "nbrclm_denied_inntwk_" + colVal + "_catastrophic")

    val received_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) &&
      $"in_exchange".isNull &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_lgpmmcare = joinedDf(received_lgpmmcare, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMaster = catMasterData.alias("parent").join(nbrclm_denied_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip", "nbrclm_denied_inntwk_" + colVal + "_catastrophic", "nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare")

    val received_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) &&
        $"in_exchange".isNull &&
        $"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year) &&
        $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_stucvg = joinedDf(received_stucvg, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_stucvg = denied_in_stucvg.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_denied_inntwk_" + colVal + "_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip", "nbrclm_denied_inntwk_" + colVal + "_catastrophic", "nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare", "nbrclm_denied_inntwk_" + colVal + "_stucvg")
    stucvgMasterData
  }
  def getDeniedOutntwkBetweenDates(start_day: Int, end_day: Int, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
                                   naic2018_mcas_src_eob_cd_inbnd: DataFrame, naic2018_mcas_eob_cd_inbnd: DataFrame,
                                   naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = start_day.toString + "to" + end_day
    val fend_day = end_day + 1

    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_brz = joinedDf(received_brnz, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sil = joinedDf(received_silver, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip")
    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_gld = joinedDf(received_gold, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_plt = joinedDf(received_platinum, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_bronze_ip.union(nbrclm_denied_outntwk_silver_ip.union(nbrclm_denied_outntwk_gold_ip.union(nbrclm_denied_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_ip").alias("nbrclm_denied_outntwk_" + colVal + "_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_brz = joinedDf(received_sgp_bronze, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_sil = joinedDf(received_sgp_silver, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_gld = joinedDf(received_sgp_gold, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_sgp_plt = joinedDf(received_sgp_plt, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp")

    val tot_sgp = nbrclm_denied_outntwk_bronze_sgp.union(nbrclm_denied_outntwk_silver_sgp.union(nbrclm_denied_outntwk_gold_sgp.union(nbrclm_denied_outntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_denied_outntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp").alias("nbrclm_denied_outntwk_" + colVal + "_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp")

    lob_type = ""
    var islgp = true
    val lgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp)

    val received_gtlgp = lgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_gtlgp = joinedDf(received_gtlgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gtlgp"))
    val gtlgpMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gtsgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type, islgp)

    val received_gtsgp = gtsgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
    val denied_in_gtsgp = joinedDf(received_gtsgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_gtsgp = denied_in_gtsgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val gtip_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp)

    val received_gtip = gtip_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
    val denied_in_gtip = joinedDf(received_gtip, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip")
    val tot_gt = nbrclm_denied_outntwk_gtip.union(nbrclm_denied_outntwk_gtsgp.union(nbrclm_denied_outntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colVal + "_gtip"))

    val nbrclm_denied_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum(col("nbrclm_denied_outntwk_" + colVal + "_gtip")).alias("nbrclm_denied_outntwk_" + colVal + "_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip")
    val received_cat = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".isNull &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_cat = joinedDf(received_cat, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_catastrophic"))
    val catMaster = gttotMasterData.alias("parent").join(nbrclm_denied_outntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip", "nbrclm_denied_outntwk_" + colVal + "_catastrophic")
    // catMasterData
    val received_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) &&
      $"in_exchange".isNull &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_lgpmmcare = joinedDf(received_lgpmmcare, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMaster = catMasterData.alias("parent").join(nbrclm_denied_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip", "nbrclm_denied_outntwk_" + colVal + "_catastrophic", "nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare")

    val received_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) &&
        $"in_exchange".isNull &&
        (!$"inn_cd".isin(clminn_cd: _*)) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year) &&
        $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))

    val denied_in_stucvg = joinedDf(received_stucvg, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_stucvg = denied_in_stucvg.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_denied_outntwk_" + colVal + "_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip", "nbrclm_denied_outntwk_" + colVal + "_catastrophic", "nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare", "nbrclm_denied_outntwk_" + colVal + "_stucvg")
    stucvgMasterData
  }
  def getDeniedInntwk_90(end_year: String, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
                         naic2018_mcas_src_eob_cd_inbnd: DataFrame, naic2018_mcas_eob_cd_inbnd: DataFrame,
                         naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = "90"
    val strt_day: Int = 91

    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_brz = joinedDf(received_brnz, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sil = joinedDf(received_silver, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip")
    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_gld = joinedDf(received_gold, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_plt = joinedDf(received_platinum, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_bronze_ip.union(nbrclm_denied_inntwk_silver_ip.union(nbrclm_denied_inntwk_gold_ip.union(nbrclm_denied_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_ip").alias("nbrclm_denied_inntwk_" + colVal + "_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type).withColumn("constant_date", lit(end_year)).withColumn("constant_date", lit(end_year))

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_brz = joinedDf(received_sgp_bronze, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_sil = joinedDf(received_sgp_silver, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_gld = joinedDf(received_sgp_gold, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_plt = joinedDf(received_sgp_plt, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp")

    val tot_sgp = nbrclm_denied_inntwk_bronze_sgp.union(nbrclm_denied_inntwk_silver_sgp.union(nbrclm_denied_inntwk_gold_sgp.union(nbrclm_denied_inntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_denied_inntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp").alias("nbrclm_denied_inntwk_" + colVal + "_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp")

    lob_type = ""
    var islgp = true
    val lgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val received_gtlgp = lgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_gtlgp = joinedDf(received_gtlgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gtlgp"))
    val gtlgpMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gtsgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val received_gtsgp = gtsgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
    val denied_in_gtsgp = joinedDf(received_gtsgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_gtsgp = denied_in_gtsgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val gtip_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val received_gtip = gtip_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
    val denied_in_gtip = joinedDf(received_gtip, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_denied_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip")
    val tot_gt = nbrclm_denied_inntwk_gtip.union(nbrclm_denied_inntwk_gtsgp.union(nbrclm_denied_inntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_inntwk_" + colVal + "_gtip"))

    val nbrclm_denied_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("nbrclm_denied_inntwk_" + colVal + "_gtip").alias("nbrclm_denied_inntwk_" + colVal + "_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip")
    val received_cat = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.withColumn("constant_date", lit(end_year)).filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".isNull &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_cat = joinedDf(received_cat, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_catastrophic"))
    val catMaster = gttotMasterData.alias("parent").join(nbrclm_denied_inntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip", "nbrclm_denied_inntwk_" + colVal + "_catastrophic")
    // catMasterData
    val received_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.withColumn("constant_date", lit(end_year)).filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) &&
      $"in_exchange".isNull &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_lgpmmcare = joinedDf(received_lgpmmcare, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMaster = catMasterData.withColumn("constant_date", lit(end_year)).alias("parent").join(nbrclm_denied_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip", "nbrclm_denied_inntwk_" + colVal + "_catastrophic", "nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare")

    val received_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.withColumn("constant_date", lit(end_year)).filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) &&
        $"in_exchange".isNull &&
        $"inn_cd".isin(clminn_cd: _*) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year) &&
        $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_stucvg = joinedDf(received_stucvg, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_inntwk_stucvg = denied_in_stucvg.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_" + colVal + "_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_inntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_inntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_inntwk_" + colVal + "_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_inntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_denied_inntwk_" + colVal + "_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_inntwk_" + colVal + "_bronze_ip", "nbrclm_denied_inntwk_" + colVal + "_silver_ip", "nbrclm_denied_inntwk_" + colVal + "_gold_ip", "nbrclm_denied_inntwk_" + colVal + "_platinum_ip", "nbrclm_denied_inntwk_" + colVal + "_total_ip",
        "nbrclm_denied_inntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_inntwk_" + colVal + "_silver_sgp", "nbrclm_denied_inntwk_" + colVal + "_gold_sgp", "nbrclm_denied_inntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_inntwk_" + colVal + "_total_sgp", "nbrclm_denied_inntwk_" + colVal + "_gtlgp", "nbrclm_denied_inntwk_" + colVal + "_gtsgp", "nbrclm_denied_inntwk_" + colVal + "_gtip", "nbrclm_denied_inntwk_" + colVal + "_total_gtip", "nbrclm_denied_inntwk_" + colVal + "_catastrophic", "nbrclm_denied_inntwk_" + colVal + "_lgp_mmcare", "nbrclm_denied_inntwk_" + colVal + "_stucvg")
    stucvgMasterData
  }
  def getDeniedOutntwk_90(end_year: String, naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
                          naic2018_mcas_src_eob_cd_inbnd: DataFrame, naic2018_mcas_eob_cd_inbnd: DataFrame,
                          naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val colVal = "90"
    val strt_day: Int = 91

    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_brz = joinedDf(received_brnz, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sil = joinedDf(received_silver, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip")
    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_gld = joinedDf(received_gold, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_plt = joinedDf(received_platinum, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_bronze_ip.union(nbrclm_denied_outntwk_silver_ip.union(nbrclm_denied_outntwk_gold_ip.union(nbrclm_denied_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_denied_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_ip").alias("nbrclm_denied_outntwk_" + colVal + "_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type).withColumn("constant_date", lit(end_year)).withColumn("constant_date", lit(end_year))

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_brz = joinedDf(received_sgp_bronze, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_sil = joinedDf(received_sgp_silver, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_gld = joinedDf(received_sgp_gold, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_sgp_plt = joinedDf(received_sgp_plt, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp")

    val tot_sgp = nbrclm_denied_outntwk_bronze_sgp.union(nbrclm_denied_outntwk_silver_sgp.union(nbrclm_denied_outntwk_gold_sgp.union(nbrclm_denied_outntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_denied_outntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp").alias("nbrclm_denied_outntwk_" + colVal + "_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp")

    lob_type = ""
    var islgp = true
    val lgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val received_gtlgp = lgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_gtlgp = joinedDf(received_gtlgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gtlgp"))
    val gtlgpMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gtsgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val received_gtsgp = gtsgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
    val denied_in_gtsgp = joinedDf(received_gtsgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_gtsgp = denied_in_gtsgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val gtip_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val received_gtip = gtip_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
    val denied_in_gtip = joinedDf(received_gtip, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip")
    val tot_gt = nbrclm_denied_outntwk_gtip.union(nbrclm_denied_outntwk_gtsgp.union(nbrclm_denied_outntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_denied_outntwk_" + colVal + "_gtip"))

    val nbrclm_denied_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("nbrclm_denied_outntwk_" + colVal + "_gtip").alias("nbrclm_denied_outntwk_" + colVal + "_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip")
    val received_cat = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.withColumn("constant_date", lit(end_year)).filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".isNull &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_cat = joinedDf(received_cat, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_catastrophic"))
    val catMaster = gttotMasterData.alias("parent").join(nbrclm_denied_outntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip", "nbrclm_denied_outntwk_" + colVal + "_catastrophic")
    // catMasterData
    val received_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.withColumn("constant_date", lit(end_year)).filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) &&
      $"in_exchange".isNull &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year) &&
      $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_lgpmmcare = joinedDf(received_lgpmmcare, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMaster = catMasterData.withColumn("constant_date", lit(end_year)).alias("parent").join(nbrclm_denied_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip", "nbrclm_denied_outntwk_" + colVal + "_catastrophic", "nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare")

    val received_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.withColumn("constant_date", lit(end_year)).filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) &&
        $"in_exchange".isNull &&
        (!$"inn_cd".isin(clminn_cd: _*)) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year) &&
        $"ADJDCTN_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))

    val denied_in_stucvg = joinedDf(received_stucvg, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_stucvg = denied_in_stucvg.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_" + colVal + "_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_denied_outntwk_" + colVal + "_silver_ip"), col("nbrclm_denied_outntwk_" + colVal + "_gold_ip"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_denied_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_denied_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_total_sgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtlgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtsgp"), col("nbrclm_denied_outntwk_" + colVal + "_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_total_gtip"), col("nbrclm_denied_outntwk_" + colVal + "_catastrophic"), col("nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_denied_outntwk_" + colVal + "_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_" + colVal + "_bronze_ip", "nbrclm_denied_outntwk_" + colVal + "_silver_ip", "nbrclm_denied_outntwk_" + colVal + "_gold_ip", "nbrclm_denied_outntwk_" + colVal + "_platinum_ip", "nbrclm_denied_outntwk_" + colVal + "_total_ip",
        "nbrclm_denied_outntwk_" + colVal + "_bronze_sgp", "nbrclm_denied_outntwk_" + colVal + "_silver_sgp", "nbrclm_denied_outntwk_" + colVal + "_gold_sgp", "nbrclm_denied_outntwk_" + colVal + "_platinum_sgp", "nbrclm_denied_outntwk_" + colVal + "_total_sgp", "nbrclm_denied_outntwk_" + colVal + "_gtlgp", "nbrclm_denied_outntwk_" + colVal + "_gtsgp", "nbrclm_denied_outntwk_" + colVal + "_gtip", "nbrclm_denied_outntwk_" + colVal + "_total_gtip", "nbrclm_denied_outntwk_" + colVal + "_catastrophic", "nbrclm_denied_outntwk_" + colVal + "_lgp_mmcare", "nbrclm_denied_outntwk_" + colVal + "_stucvg")
    stucvgMasterData
  }
  def getDeniedOutntwk(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk: DataFrame,
                       naic2018_mcas_src_eob_cd_inbnd: DataFrame, naic2018_mcas_eob_cd_inbnd: DataFrame,
                       naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_brz = joinedDf(received_brnz, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sil = joinedDf(received_silver, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip")
    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gld = joinedDf(received_gold, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_plt = joinedDf(received_platinum, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_bronze_ip.union(nbrclm_denied_outntwk_silver_ip.union(nbrclm_denied_outntwk_gold_ip.union(nbrclm_denied_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_denied_outntwk_bronze_ip")

    val nbrclm_denied_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_bronze_ip").alias("nbrclm_denied_outntwk_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"),
        col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_brz = joinedDf(received_sgp_bronze, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_sil = joinedDf(received_sgp_silver, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))

      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_gld = joinedDf(received_sgp_gold, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_plt = joinedDf(received_sgp_plt, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp")

    val tot_sgp = nbrclm_denied_outntwk_bronze_sgp.union(nbrclm_denied_outntwk_silver_sgp.union(nbrclm_denied_outntwk_gold_sgp.union(nbrclm_denied_outntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_denied_outntwk_bronze_sgp")

    val nbrclm_denied_outntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_denied_outntwk_bronze_sgp").alias("nbrclm_denied_outntwk_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp")

    lob_type = ""
    var islgp = true
    val lgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk, lob_type, islgp)

    val received_gtlgp = lgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gtlgp = joinedDf(received_gtlgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_gtlgp = denied_in_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gtlgp"))
    val gtlgpMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gtsgp_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type, islgp)

    val received_gtsgp = gtsgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))
    val denied_in_gtsgp = joinedDf(received_gtsgp, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_gtsgp = denied_in_gtsgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val gtip_df = getGtData(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type, islgp)

    val received_gtip = gtip_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))
    val denied_in_gtip = joinedDf(received_gtip, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_gtip = denied_in_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_denied_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp", "nbrclm_denied_outntwk_gtip")
    val tot_gt = nbrclm_denied_outntwk_gtip.union(nbrclm_denied_outntwk_gtsgp.union(nbrclm_denied_outntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_denied_outntwk_gtip")

    val nbrclm_denied_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_denied_outntwk_gtip").alias("nbrclm_denied_outntwk_total_gtip"))

    val gttotMaster = gtipMasterData.alias("parent").join(nbrclm_denied_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"), col("nbrclm_denied_outntwk_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp", "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip")
    val received_cat = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".isNull &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_cat = joinedDf(received_cat, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_catastrophic"))
    val catMaster = gttotMasterData.alias("parent").join(nbrclm_denied_outntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"), col("nbrclm_denied_outntwk_total_gtip"), col("nbrclm_denied_outntwk_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp", "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic")
    // catMasterData
    val received_lgpmmcare = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) &&
      $"in_exchange".isNull &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_lgpmmcare = joinedDf(received_lgpmmcare, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_lgp_mmcare = denied_in_lgpmmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_lgp_mmcare"))

    val lgpmmcareMaster = catMasterData.alias("parent").join(nbrclm_denied_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"), col("nbrclm_denied_outntwk_total_gtip"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp", "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare")

    val received_stucvg = naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) &&
        $"in_exchange".isNull &&
        (!$"inn_cd".isin(clminn_cd: _*)) &&
        $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
        $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_stucvg = joinedDf(received_stucvg, naic2018_mcas_src_eob_cd_inbnd, naic2018_mcas_eob_cd_inbnd, naic2018_mcas_src_clm_line_disp_rsn_cd_inbnd)
    val nbrclm_denied_outntwk_stucvg = denied_in_stucvg.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_stucvg"))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(nbrclm_denied_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_denied_outntwk_bronze_ip"), col("nbrclm_denied_outntwk_silver_ip"), col("nbrclm_denied_outntwk_gold_ip"), col("nbrclm_denied_outntwk_platinum_ip"), col("nbrclm_denied_outntwk_total_ip"),
        col("nbrclm_denied_outntwk_bronze_sgp"), col("nbrclm_denied_outntwk_silver_sgp"), col("nbrclm_denied_outntwk_gold_sgp"), col("nbrclm_denied_outntwk_platinum_sgp"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"), col("nbrclm_denied_outntwk_total_gtip"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_lgp_mmcare"), col("nbrclm_denied_outntwk_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_denied_outntwk_bronze_ip", "nbrclm_denied_outntwk_silver_ip", "nbrclm_denied_outntwk_gold_ip", "nbrclm_denied_outntwk_platinum_ip", "nbrclm_denied_outntwk_total_ip",
        "nbrclm_denied_outntwk_bronze_sgp", "nbrclm_denied_outntwk_silver_sgp", "nbrclm_denied_outntwk_gold_sgp", "nbrclm_denied_outntwk_platinum_sgp", "nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp", "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare", "nbrclm_denied_outntwk_stucvg")
    stucvgMasterData
  }
}
object PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    //new PCADX_SCL_NAIC_OEXStgTransformationclmexphmcy().sparkInIt()
  }
}