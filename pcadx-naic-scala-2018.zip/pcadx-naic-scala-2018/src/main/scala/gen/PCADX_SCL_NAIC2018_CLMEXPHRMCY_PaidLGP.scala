package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator

import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit

import org.apache.hadoop.fs._;
class PCADX_SCL_NAIC2018_CLMEXPHRMCY_PaidLGP {
	val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
			config("hive.exec.dynamic.partition.mode", "nonstrict").
			config("spark.sql.parquet.compression.codec", "snappy").
			config("hive.warehouse.data.skipTrash", "true").
			config("spark.sql.parquet.writeLegacyFormat", "true").
			enableHiveSupport().getOrCreate()
			import spark.implicits._
			val dbProperties = new Properties
			dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
			var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_CLMEXPHRMCY_PaidLGP])
			val dbWrk = dbProperties.getProperty("work.db")
			val dbInbnd = dbProperties.getProperty("inbound.db")
			val wrhDb = dbProperties.getProperty("warehouse.db")
			val audit_log_df = spark.sql("select * from "+wrhDb+".audt_load_log") 
			val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString() 
			println("load_log_key : "+load_log_key)
			val reportYear =dbProperties.getProperty("report.year")

			def naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk() = """Insert overwrite table """+dbWrk+""".naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk"""+"""
					select * from              
					(
					select
					"""+reportYear+""" as health_year,
					mclm_paid_wrk.CLM_ADJSTMNT_KEY  AS CLM_ADJSTMNT_KEY,
					mclm_paid_wrk.CLM_LINE_NBR      AS CLM_LINE_NBR ,
					mclm_paid_wrk.CLM_SOR_CD        AS CLM_SOR_CD ,
					mclm_paid_wrk.PRMPT_PAY_CLM_RCVD_DT AS PRMPT_PAY_CLM_RCVD_DT,
					mclm_paid_wrk.CLM_RCVD_DT           AS CLM_RCVD_DT,
					mclm_paid_wrk.GL_POST_DT            AS GL_POST_DT,
					mclm_paid_wrk.INN_CD             AS INN_CD ,
					mclm_paid_wrk.inn_paid           AS inn_paid ,
					mclm_paid_wrk.outn_paid          AS outn_paid ,
					mclm_paid_wrk.PAID_AMT           AS    PAID_AMT  ,
					mclm_paid_wrk.CPAY_AMT           AS   CPAY_AMT  ,
					mclm_paid_wrk.COINSRN_AMT        AS   COINSRN_AMT  ,
					mclm_paid_wrk.DDCTBL_AMT         AS  DDCTBL_AMT ,
					temp.MBRSHP_SOR_CD                AS MBRSHP_SOR_CD, 
					temp.GRNDFTHR_IND_CD              AS GRNDFTHR_IND_CD ,
					 MHE.HIX_CD                     AS HIX_CD,
           BPA.GRNDFTHRG_STTS_CD          AS GRNDFTHRG_STTS_CD , 
           BPA.hcr_cmplynt_cd             AS hcr_cmplynt_cd ,
           BPA.EXCHNG_IND_CD              AS EXCHNG_IND_CD,
           BPA.EXCHNG_METL_TYPE_CD        AS EXCHNG_METL_TYPE_CD,
           BPA.SRC_EXCHNG_CERTFN_CD       AS SRC_EXCHNG_CERTFN_CD,
					temp.MBU_CF_CD                 AS MBU_CF_CD ,
					temp.PROD_CF_CD                AS PROD_CF_CD,
					temp.CMPNY_CF_CD               AS CMPNY_CF_CD,
					temp.FUNDG_CF_CD               AS FUNDG_CF_CD,
					BRD.State                        AS  State,
					CASE 
					WHEN substr (temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
					WHEN BPA.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN' 
					WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( BPA.EXCHNG_IND_CD IS NULL OR BPA.EXCHNG_IND_CD ='UNK' )AND MHE.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
					END AS IN_Exchange ,
					CASE 
					WHEN substr (temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
					WHEN BPA.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
					WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( BPA.EXCHNG_IND_CD IS NULL OR BPA.EXCHNG_IND_CD ='UNK' )AND MHE.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
					END AS OUTOFF_Exchange, 
					CB.GL_LVL_DESC                 AS naic_lob,
					MED.GL_CF_DESC                  as  naic_prod_desc,
					temp.SRC_GRP_NBR as src_grp_nbr ,
					temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
					"""+load_log_key+""",
					current_timestamp()

					FROM   """+dbWrk+""".naic2018_mcas_mclm_paid_wrk mclm_paid_wrk
					inner join """+dbWrk+""".clm_inter temp
					ON mclm_paid_wrk.MBR_KEY = temp.MBR_KEY

					inner join (
					select CF_CD, GL_LVL_DESC from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
					WHERE GL_CF_TYPE_DESC = 'CBE'
					AND  GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' )
					group by 1,2
					) as CB
					on CB.CF_CD =temp.MBU_CF_CD
					inner join (
					select CF_CD,  GL_CF_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
					where GL_CF_TYPE_DESC = 'PRODUCT' 
					group by 1,2
					) as MED
					on MED.CF_CD = temp.PROD_CF_CD
					inner join (
					select gl.CF_CD,trim(substring(gl.GL_LVL_DESC ,length(gl.GL_LVL_DESC) - 1) ) as State
					from """+dbInbnd+""".GL_CF_VRTCL_HRCHY gl
					where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
					and ((gl.GL_LVL_DESC like 'NON BLUE%' or gl.GL_LVL_DESC like 'BLUE%') 
					and gl.GL_LVL_DESC not like  ('%TOTAL') )
					--and State = 'MO'
					group by 1,2
					) BRD
					on BRD.CF_CD= temp.MBU_CF_CD 
                    and BRD.State <> 'LT'
					inner join (
					select DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
					where  GL_CF_TYPE_DESC = 'FUND_CODE'
					and CF_CD NOT IN ( select  DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY 

					WHERE  GL_CF_TYPE_DESC = 'FUND_CODE'
					AND  ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
					)
					) FC
					ON FC.CF_CD = temp.FUNDG_CF_CD
     LEFT OUTER JOIN """+dbInbnd+""".MBR_HIX_ENRLMNT MHE
 ON temp.MBR_KEY = MHE.MBR_KEY
 AND temp.PROD_OFRG_KEY = MHE.PROD_OFRG_KEY
 AND temp.MBR_PROD_ENRLMNT_EFCTV_DT = MHE.MBR_PROD_ENRLMNT_EFCTV_DT
 AND MHE.RCRD_STTS_CD <> 'DEL'
 LEFT OUTER JOIN """+dbInbnd+""".BNFT_PKG_ADDNL BPA
 ON temp.BNFT_PKG_KEY = BPA.BNFT_PKG_KEY 
 AND BPA.RCRD_STTS_CD <> 'DEL'
  
					where BRD.State NOT IN ( 'IL', 'MA', 'DC' )
					AND 
					((mclm_paid_wrk.prmpt_pay_clm_rcvd_dt  between temp.mbr_prod_enrlmnt_efctv_dt and temp.mbr_prod_enrlmnt_trmntn_dt)
					or 
					(mclm_paid_wrk.clm_line_srvc_strt_dt  between temp.mbr_prod_enrlmnt_efctv_dt and temp.mbr_prod_enrlmnt_trmntn_dt)
					)
					AND  temp.MBU_CF_CD NOT IN ( 'EDCASH' , 'SPGAZZ','EDCOSH' , 'EDINSH')
					GROUP BY 
					mclm_paid_wrk.CLM_ADJSTMNT_KEY  ,
					mclm_paid_wrk.CLM_LINE_NBR  ,
					mclm_paid_wrk.CLM_SOR_CD   ,
					mclm_paid_wrk.PRMPT_PAY_CLM_RCVD_DT ,
					mclm_paid_wrk.CLM_RCVD_DT  ,
					mclm_paid_wrk.GL_POST_DT  ,
					mclm_paid_wrk.INN_CD      ,
					mclm_paid_wrk.inn_paid ,
					mclm_paid_wrk.outn_paid ,
					mclm_paid_wrk.PAID_AMT             ,
					mclm_paid_wrk.CPAY_AMT             ,
					mclm_paid_wrk.COINSRN_AMT        ,
					mclm_paid_wrk.DDCTBL_AMT         ,
					mclm_paid_wrk.MBR_KEY  ,
					temp.MBRSHP_SOR_CD , 
					temp.GRNDFTHR_IND_CD  ,
					MHE.HIX_CD ,
          BPA.GRNDFTHRG_STTS_CD , 
          BPA.hcr_cmplynt_cd ,
          BPA.EXCHNG_IND_CD ,
          BPA.EXCHNG_METL_TYPE_CD ,
          BPA.SRC_EXCHNG_CERTFN_CD ,
					temp.MBU_CF_CD  ,
					temp.PROD_CF_CD ,
					temp.CMPNY_CF_CD ,
					temp.FUNDG_CF_CD ,
					BRD.State ,
					CB.GL_LVL_DESC,
					MED.GL_CF_DESC,
					temp.SRC_GRP_NBR ,
					temp.SRC_SUBGRP_NBR 


					)
					"""

					def naic_mcas_hlthex_clmexphmcy_paid_lgp_2017_wrk() = """Insert into table """+dbWrk+""".naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk"""+"""
							select * from              
							(
							select
							"""+reportYear+""" as health_year,
							mclm_paid_wrk.CLM_ADJSTMNT_KEY  AS CLM_ADJSTMNT_KEY,
							mclm_paid_wrk.CLM_LINE_NBR      AS CLM_LINE_NBR ,
							mclm_paid_wrk.CLM_SOR_CD        AS CLM_SOR_CD ,
							mclm_paid_wrk.PRMPT_PAY_CLM_RCVD_DT AS PRMPT_PAY_CLM_RCVD_DT,
							mclm_paid_wrk.CLM_RCVD_DT           AS CLM_RCVD_DT,
							mclm_paid_wrk.GL_POST_DT            AS GL_POST_DT,
							mclm_paid_wrk.INN_CD             AS INN_CD ,
							mclm_paid_wrk.inn_paid           AS inn_paid ,
							mclm_paid_wrk.outn_paid          AS outn_paid ,
							mclm_paid_wrk.PAID_AMT           AS    PAID_AMT  ,
							mclm_paid_wrk.CPAY_AMT           AS   CPAY_AMT  ,
							mclm_paid_wrk.COINSRN_AMT        AS   COINSRN_AMT  ,
							mclm_paid_wrk.DDCTBL_AMT         AS  DDCTBL_AMT ,
							temp.MBRSHP_SOR_CD                AS MBRSHP_SOR_CD, 
							temp.GRNDFTHR_IND_CD              AS GRNDFTHR_IND_CD ,
							temp.HIX_CD                       AS HIX_CD,
							temp.GRNDFTHRG_STTS_CD            AS GRNDFTHRG_STTS_CD , 
							temp.hcr_cmplynt_cd               AS hcr_cmplynt_cd ,
							BPA.EXCHNG_IND_CD                AS EXCHNG_IND_CD,
							temp.EXCHNG_METL_TYPE_CD          AS EXCHNG_METL_TYPE_CD,
							temp.SRC_EXCHNG_CERTFN_CD         AS SRC_EXCHNG_CERTFN_CD,
							temp.MBU_CF_CD                 AS MBU_CF_CD ,
							temp.PROD_CF_CD                AS PROD_CF_CD,
							temp.CMPNY_CF_CD               AS CMPNY_CF_CD,
							temp.FUNDG_CF_CD               AS FUNDG_CF_CD,
							BRD.State                        AS  State,
							CASE 
							WHEN substr (temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
							WHEN BPA.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN' 
							WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( BPA.EXCHNG_IND_CD IS NULL OR BPA.EXCHNG_IND_CD ='UNK' )AND temp.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
							END AS IN_Exchange ,
							CASE 
							WHEN substr (temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
							WHEN BPA.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
							WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( BPA.EXCHNG_IND_CD IS NULL OR BPA.EXCHNG_IND_CD ='UNK' )AND temp.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
							END AS OUTOFF_Exchange, 
							CB.GL_LVL_DESC                 AS naic_lob,
							MED.GL_CF_DESC                  as  naic_prod_desc,
							"""+load_log_key+""",
							current_date

							FROM   """+dbWrk+""".naic2018_mcas_mclm_paid_wrk mclm_paid_wrk
							inner join """+dbWrk+""".naic2018_mcas_hlthex_clmexphmcy_paid_temp_wrk temp
							ON mclm_paid_wrk.MBR_KEY = temp.MBR_KEY

							inner join (
							select CF_CD, GL_LVL_DESC from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
							WHERE GL_CF_TYPE_DESC = 'CBE'
							AND  GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' )
							group by 1,2
							) as CB
							on CB.CF_CD =temp.MBU_CF_CD
							inner join (
							select CF_CD,  GL_CF_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
							where GL_CF_TYPE_DESC = 'PRODUCT' 
							group by 1,2
							) as MED
							on MED.CF_CD = temp.PROD_CF_CD
							inner join (
							select gl.CF_CD,trim(substring(gl.GL_LVL_DESC ,length(gl.GL_LVL_DESC) - 1) ) as State
							from """+dbInbnd+""".GL_CF_VRTCL_HRCHY gl
							where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
							and ((gl.GL_LVL_DESC like 'NON BLUE%' or gl.GL_LVL_DESC like 'BLUE%') 
							and gl.GL_LVL_DESC not like  ('%TOTAL') )
							--and State = 'MO'
							group by 1,2
							) BRD
							on BRD.CF_CD= temp.MBU_CF_CD
                            and BRD.State <> 'LT'                            


							where BRD.State IN ( 'GA', 'KY', 'NH', 'VA' )
							AND temp.FUNDG_CF_CD = '45' 
							AND ((mclm_paid_wrk.prmpt_pay_clm_rcvd_dt  between temp.mbr_prod_enrlmnt_efctv_dt and temp.mbr_prod_enrlmnt_trmntn_dt)
							or
							(mclm_paid_wrk.clm_line_srvc_strt_dt  between temp.mbr_prod_enrlmnt_efctv_dt and temp.mbr_prod_enrlmnt_trmntn_dt)
							)
							GROUP BY 
							mclm_paid_wrk.CLM_ADJSTMNT_KEY  ,
							mclm_paid_wrk.CLM_LINE_NBR  ,
							mclm_paid_wrk.CLM_SOR_CD   ,
							mclm_paid_wrk.PRMPT_PAY_CLM_RCVD_DT ,
							mclm_paid_wrk.CLM_RCVD_DT  ,
							mclm_paid_wrk.GL_POST_DT  ,
							mclm_paid_wrk.INN_CD      ,
							mclm_paid_wrk.inn_paid ,
							mclm_paid_wrk.outn_paid ,
							mclm_paid_wrk.PAID_AMT             ,
							mclm_paid_wrk.CPAY_AMT             ,
							mclm_paid_wrk.COINSRN_AMT        ,
							mclm_paid_wrk.DDCTBL_AMT         ,
							mclm_paid_wrk.MBR_KEY  ,
							temp.MBRSHP_SOR_CD , 
							temp.GRNDFTHR_IND_CD  ,
							temp.HIX_CD ,
							temp.GRNDFTHRG_STTS_CD , 
							temp.hcr_cmplynt_cd ,
							BPA.EXCHNG_IND_CD ,
							temp.EXCHNG_METL_TYPE_CD ,
							temp.SRC_EXCHNG_CERTFN_CD ,
							temp.MBU_CF_CD  ,
							temp.PROD_CF_CD ,
							temp.CMPNY_CF_CD ,
							temp.FUNDG_CF_CD ,
							BRD.State ,
							CB.GL_LVL_DESC,
							MED.GL_CF_DESC


							)
							"""
							def naic_mcas_hlthex_clmexphmcy_paid_lgp_srcgrp_wrk() = """Insert into table """+dbWrk+""".naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk"""+"""
									select * from              
									(
									select
									"""+reportYear+""" as health_year,
									mclm_paid_wrk.CLM_ADJSTMNT_KEY  AS CLM_ADJSTMNT_KEY,
									mclm_paid_wrk.CLM_LINE_NBR      AS CLM_LINE_NBR ,
									mclm_paid_wrk.CLM_SOR_CD        AS CLM_SOR_CD ,
									mclm_paid_wrk.PRMPT_PAY_CLM_RCVD_DT AS PRMPT_PAY_CLM_RCVD_DT,
									mclm_paid_wrk.CLM_RCVD_DT           AS CLM_RCVD_DT,
									mclm_paid_wrk.GL_POST_DT            AS GL_POST_DT,
									mclm_paid_wrk.INN_CD             AS INN_CD ,
									mclm_paid_wrk.inn_paid           AS inn_paid ,
									mclm_paid_wrk.outn_paid          AS outn_paid ,
									mclm_paid_wrk.PAID_AMT           AS    PAID_AMT  ,
									mclm_paid_wrk.CPAY_AMT           AS   CPAY_AMT  ,
									mclm_paid_wrk.COINSRN_AMT        AS   COINSRN_AMT  ,
									mclm_paid_wrk.DDCTBL_AMT         AS  DDCTBL_AMT ,
									temp.MBRSHP_SOR_CD                AS MBRSHP_SOR_CD, 
									temp.GRNDFTHR_IND_CD              AS GRNDFTHR_IND_CD ,
							 MHE.HIX_CD                     AS HIX_CD,
           BPA.GRNDFTHRG_STTS_CD          AS GRNDFTHRG_STTS_CD , 
           BPA.hcr_cmplynt_cd             AS hcr_cmplynt_cd ,
           BPA.EXCHNG_IND_CD              AS EXCHNG_IND_CD,
           BPA.EXCHNG_METL_TYPE_CD        AS EXCHNG_METL_TYPE_CD,
           BPA.SRC_EXCHNG_CERTFN_CD       AS SRC_EXCHNG_CERTFN_CD,
									temp.MBU_CF_CD                 AS MBU_CF_CD ,
									temp.PROD_CF_CD                AS PROD_CF_CD,
									temp.CMPNY_CF_CD               AS CMPNY_CF_CD,
									temp.FUNDG_CF_CD               AS FUNDG_CF_CD,
									BRD.State                        AS  State,
									CASE 
									WHEN substr (temp.PROD_CF_CD,4,2) in ('1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K')    and temp.FUNDG_CF_CD in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP' ) THEN 'IN' 
									WHEN BPA.EXCHNG_IND_CD IN ( 'PB' ) THEN 'IN' 
									WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( BPA.EXCHNG_IND_CD IS NULL OR BPA.EXCHNG_IND_CD ='UNK' )AND MHE.HIX_CD IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'IN'
									END AS IN_Exchange ,
									CASE 
									WHEN substr (temp.PROD_CF_CD,4,2) in ('1N', '2N', '3N', '4N', '5N', '1Y', '2Y', '3Y', '4Y', '5Y', '1P', '2P', '3P', '4P', '5P','3K') and temp.FUNDG_CF_CD not in ('1E', '1P', '2P', '4P', '5P', '9P', 'QP', 'RP', 'SP') THEN 'OUTOFF' 
									WHEN BPA.EXCHNG_IND_CD IN ( 'PR' , 'OF' ) THEN  'OUTOFF'
									WHEN SUBSTR(temp.PROD_CF_CD, 4, 1) not in ('1','2','3','4','5','6','7','8','9') AND ( BPA.EXCHNG_IND_CD IS NULL OR BPA.EXCHNG_IND_CD ='UNK' )AND MHE.HIX_CD NOT IN ('PB','NY','NV','KY','FF','CT','CO','CA' )  THEN 'OUTOFF'
									END AS OUTOFF_Exchange, 
									CB.GL_LVL_DESC                 AS naic_lob,
									MED.GL_CF_DESC                  as  naic_prod_desc,
									temp.SRC_GRP_NBR as src_grp_nbr ,
									temp.SRC_SUBGRP_NBR as src_subgrp_nbr,
									"""+load_log_key+""",
									current_timestamp()

									FROM   """+dbWrk+""".naic2018_mcas_mclm_paid_wrk mclm_paid_wrk
									inner join """+dbWrk+""".clm_inter temp
									ON mclm_paid_wrk.MBR_KEY = temp.MBR_KEY

									inner join (
									select CF_CD, GL_LVL_DESC from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
									WHERE GL_CF_TYPE_DESC = 'CBE'
									AND  GL_LVL_DESC in ('LARGE GROUP CBE EXCLUDING MEDICARE' , 'TOTAL NATIONAL CBE' )
									group by 1,2
									) as CB
									on CB.CF_CD =temp.MBU_CF_CD
									inner join (
									select CF_CD,  GL_CF_DESC  from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
									where GL_CF_TYPE_DESC = 'PRODUCT' 
									group by 1,2
									) as MED
									on MED.CF_CD = temp.PROD_CF_CD
									inner join (
									select gl.CF_CD,trim(substring(gl.GL_LVL_DESC ,length(gl.GL_LVL_DESC) - 1) ) as State
									from """+dbInbnd+""".GL_CF_VRTCL_HRCHY gl
									where gl.GL_CF_TYPE_DESC = 'BRANDSTATE'
									and ((gl.GL_LVL_DESC like 'NON BLUE%' or gl.GL_LVL_DESC like 'BLUE%') 
									and gl.GL_LVL_DESC not like  ('%TOTAL') )
									
									--and State = 'MO'
									group by 1,2
									) BRD
									on BRD.CF_CD= temp.MBU_CF_CD
                                    and BRD.State <> 'LT'                                    
									inner join (
									select DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY
									where  GL_CF_TYPE_DESC = 'FUND_CODE'
									and CF_CD NOT IN ( select  DISTINCT CF_CD from """+dbInbnd+""".GL_CF_VRTCL_HRCHY 

									WHERE  GL_CF_TYPE_DESC = 'FUND_CODE'
									AND  ( GL_CF_DESC in ('ALTERNATE FUNDED') or GL_LVL_DESC in ('ALTERNATE FUNDED') )
									)
									) FC
									ON FC.CF_CD = temp.FUNDG_CF_CD
     LEFT OUTER JOIN """+dbInbnd+""".MBR_HIX_ENRLMNT MHE
 ON temp.MBR_KEY = MHE.MBR_KEY
 AND temp.PROD_OFRG_KEY = MHE.PROD_OFRG_KEY
 AND temp.MBR_PROD_ENRLMNT_EFCTV_DT = MHE.MBR_PROD_ENRLMNT_EFCTV_DT
 AND MHE.RCRD_STTS_CD <> 'DEL'
 LEFT OUTER JOIN """+dbInbnd+""".BNFT_PKG_ADDNL BPA
 ON temp.BNFT_PKG_KEY = BPA.BNFT_PKG_KEY 
 AND BPA.RCRD_STTS_CD <> 'DEL'
  

									where BRD.State NOT IN ( 'IL', 'MA', 'DC' )
									AND ((mclm_paid_wrk.prmpt_pay_clm_rcvd_dt  between temp.mbr_prod_enrlmnt_efctv_dt and temp.mbr_prod_enrlmnt_trmntn_dt)
									or (mclm_paid_wrk.clm_line_srvc_strt_dt  between temp.mbr_prod_enrlmnt_efctv_dt and temp.mbr_prod_enrlmnt_trmntn_dt)
									)
									--added on 0108
									AND ( ( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN temp.PRCHSR_ORG_EFCTV_DT AND temp.PRCHSR_ORG_TRMNTN_DT) OR temp.PRCHSR_ORG_TRMNTN_DT IS NULL)
									AND ( temp.MBR_PROD_ENRLMNT_TRMNTN_DT BETWEEN temp.MBR_COA_EFCTV_DT AND temp.MBR_COA_TRMNTN_DT)

									--commented on 0108

									--AND (                                                        
									--((PRCHSR_ORG_GROUP.PRCHSR_ORG_TRMNTN_DT >= CURRENT_DATE)
									--OR PRCHSR_ORG_GROUP.PRCHSR_ORG_TRMNTN_DT IS NULL)                                                        
									--AND ((PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TRMNTN_DT >= CURRENT_DATE)
									--OR PRCHSR_ORG_SUBGROUP.PRCHSR_ORG_TRMNTN_DT IS NULL)                                                        
									--AND ((temp.PROD_OFRG_TRMNTN_DT >= CURRENT_DATE)
									--  OR temp.PROD_OFRG_TRMNTN_DT IS NULL)                                                            
									--AND ((temp.MBR_COA_TRMNTN_DT >= CURRENT_DATE)                                                        
									--   OR temp.MBR_COA_TRMNTN_DT IS NULL)                                                        

									--   )    
									AND  temp.MBU_CF_CD  IN ( 'EDCASH' , 'SPGAZZ', 'EDCOSH' , 'EDINSH' )
									AND ( temp.SRC_GRP_NBR IN ( '278777'  , '175089' , '175147' , '276470' ,'276500' , '277956' , '277960' , '278547' , '280438' , '280531' , '281249' , '281285' ,'281297'  , 'GA7649','175093' , '281729' , '196519' , '196614'  , 'IN2008') or
									temp.src_subgrp_nbr IN   ( '278777'  , '175089' , '175147' , '276470' ,'276500' , '277956' , '277960' , '278547' , '280438' , '280531' , '281249' , '281285' ,'281297'  , 'GA7649' ,'175093' , '281729' , '196519' , '196614'  , 'IN2008')
									)
									GROUP BY 
									mclm_paid_wrk.CLM_ADJSTMNT_KEY  ,
									mclm_paid_wrk.CLM_LINE_NBR  ,
									mclm_paid_wrk.CLM_SOR_CD   ,
									mclm_paid_wrk.PRMPT_PAY_CLM_RCVD_DT ,
									mclm_paid_wrk.CLM_RCVD_DT  ,
									mclm_paid_wrk.GL_POST_DT  ,
									mclm_paid_wrk.INN_CD      ,
									mclm_paid_wrk.inn_paid ,
									mclm_paid_wrk.outn_paid ,
									mclm_paid_wrk.PAID_AMT             ,
									mclm_paid_wrk.CPAY_AMT             ,
									mclm_paid_wrk.COINSRN_AMT        ,
									mclm_paid_wrk.DDCTBL_AMT         ,
									mclm_paid_wrk.MBR_KEY  ,
									temp.MBRSHP_SOR_CD , 
									temp.GRNDFTHR_IND_CD  ,
									 MHE.HIX_CD ,
                  BPA.GRNDFTHRG_STTS_CD , 
                   BPA.hcr_cmplynt_cd ,
                   BPA.EXCHNG_IND_CD ,
                   BPA.EXCHNG_METL_TYPE_CD ,
                  BPA.SRC_EXCHNG_CERTFN_CD ,
									temp.MBU_CF_CD  ,
									temp.PROD_CF_CD ,
									temp.CMPNY_CF_CD ,
									temp.FUNDG_CF_CD ,
									BRD.State ,
									CB.GL_LVL_DESC,
									MED.GL_CF_DESC,
									temp.SRC_GRP_NBR,
									temp.SRC_SUBGRP_NBR


									)
									"""


									def sparkInIt(){
				spark.sql(naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk())
				// if(reportYear.toInt == 2017){
				//    println (" ************************** For year 2017 ")
				//     spark.sql(naic_mcas_hlthex_clmexphmcy_paid_lgp_2017_wrk())
				//   }
				spark.sql(naic_mcas_hlthex_clmexphmcy_paid_lgp_srcgrp_wrk())
				spark.close()
			}
}
object PCADX_SCL_NAIC2018_CLMEXPHRMCY_PaidLGP{
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val clmexPhmy = new PCADX_SCL_NAIC2018_CLMEXPHRMCY_PaidLGP()
		//OEX.setYear(args(1))
		clmexPhmy.sparkInIt()
	} 
}