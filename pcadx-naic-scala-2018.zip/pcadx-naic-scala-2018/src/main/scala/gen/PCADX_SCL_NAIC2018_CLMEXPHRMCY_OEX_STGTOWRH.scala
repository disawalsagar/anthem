package gen
import org.apache.spark.sql.SparkSession
import java.io.File
import java.util.Properties
import java.io.FileInputStream
import java.io.File
import scala.io.Source

object PCADX_SCL_NAIC2018_CLMEXPHRMCY_OEX_STGTOWRH {
       def main(args: Array[String]): Unit = {
   PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
 try{
    val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
                                      config("hive.exec.dynamic.partition.mode", "nonstrict").
                                      config("spark.sql.parquet.compression.codec", "snappy").
                                      config("hive.warehouse.data.skipTrash", "true").
                                      config("spark.sql.parquet.writeLegacyFormat", "true").
                                      enableHiveSupport().getOrCreate()
    val dbProperties = new Properties()
    println("PCADX_SCL_NAIC_EnvironValues.fileName" + PCADX_SCL_NAIC2018_EnvironValues.fileName)                                 
    dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
    loadDataIntoTables(dbProperties,spark)
    }
catch{
      case e:Exception =>{
      println("Exception Occured")
      e.getStackTrace.foreach(println)
      }
    }
    println("closing spark session ")
  }

  def loadDataIntoTables(prop: Properties,spark:SparkSession) = {
      import spark.implicits._
      try {
      val load_queries = prop.getProperty("CLMEX_OEX_STGTOWRH_HQL")
      val year = prop.getProperty("report.year")
      val wrhDb = prop.getProperty("warehouse.db")
      val dbsg = prop.getProperty("stage.db")
      val inbndPath = prop.getProperty("inbound.path")
      println(load_queries,year,wrhDb,dbsg)
      var str = new StringBuilder
      if (load_queries != null && !load_queries.isEmpty()
       && year != null && !year.isEmpty()) 
      {
       val audit_log_df = spark.sql("select * from "+wrhDb+".audt_load_log") 
       val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString() 
      println("load_log_key : "+load_log_key)
      println(inbndPath+"/"+load_queries)
      val inputtext = spark.read.textFile(inbndPath+"/"+load_queries)
      var string = ""
      inputtext.collect().foreach(i => string+=i+" ")
      var mod_str = string.toString()
      mod_str = mod_str.replace("${hivevar:STGDB}", dbsg.trim())
        mod_str = mod_str.replace("${hivevar:WRHDB}", wrhDb.trim())
        mod_str = mod_str.replace("${hivevar:YEAR}", year.trim())
        mod_str = mod_str.replace("${hivevar:LLK}", load_log_key.trim())
         println("Query we have generated from the file \n"+mod_str.toString())
        try {
          println("Started executing  query")
          val exu = spark.sql(mod_str.toString().trim())
          println("Completed execution of  query")
        } catch {
          case e: Exception => {
            e.printStackTrace()
           }
        }
      } else println("Invalid property")
    } catch {
      case e: Exception => {
        println("Property not found ")
        e.getStackTrace.foreach(println)
      }
    }
    finally{
      println("Closing Spark Session and clearing cache")
      spark.sqlContext.clearCache()
      spark.close()
    }
  }
}
