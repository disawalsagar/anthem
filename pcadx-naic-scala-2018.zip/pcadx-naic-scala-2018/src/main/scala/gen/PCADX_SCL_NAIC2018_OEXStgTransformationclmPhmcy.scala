package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit
class PCADX_SCL_NAIC2018_OEXStgTransformationclmPhmcy {
  var year =""
  val dbProperties = new Properties
  
  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()

  import spark.implicits._
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_OEXStgTransformationclmPhmcy])
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbin = dbProperties.getProperty("inbound.db")
  val tblreceived_ip = dbProperties.getProperty("received_ip")
  val tblreceived_sgp = dbProperties.getProperty("received_sgp")
  val tblreceived_lgp = dbProperties.getProperty("received_lgp")
  val tblreceived_cat = dbProperties.getProperty("received_cat")
  val tblpclm_denied = dbProperties.getProperty("pclm_denied")
  
  
  val tblpclm_paid = dbProperties.getProperty("pclm_paid")  
  val tblpaid_ip = dbProperties.getProperty("paid_ip")
  val tblpaid_sgp = dbProperties.getProperty("paid_sgp")
  val tblpaid_cat = dbProperties.getProperty("paid_cat")
  val tblpaid_lgp =  dbProperties.getProperty("paid_lgp")
  println("***********************"+tblreceived_cat+"*********************************")
  val tblsrvc_dnl = dbProperties.getProperty("srvc_dnl")
   var naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk :DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_received_cat_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_received_lgp_wrk:DataFrame= null
  var naic2018_mcas_hlthex_clmPhmcy_denied_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_paid_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_paid_cat_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmPhmcy_paid_lgp_wrk:DataFrame = null
  var naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd:DataFrame = null
  val  mbu_cf_cdvals= dbProperties.getProperty("mbu_Cf_cdVals").split(",").toSeq
  //val  mbu_cf_cdvals= Seq("EDCASH","EDCOSH","EDCTSH","EDGASH","EDINSH","EDKYSH","EDMESH","EDMOSH","EDNHSH","EDNVSH","EDNYSH","EDOHSH","EDVASH","EDWISH","SHUNCE","SHUNEA","SHUNWS")
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clm")
  val end_year =dbProperties.getProperty("end_year_clm")
  //val strt_year =  LocalDate.parse(date1)
   // val end_year= LocalDate.parse(date2)
  //val  mbu_cf_cdvals= Seq("EDCASH","EDCOSH","EDCTSH","EDGASH","EDINSH","EDKYSH","EDMESH","EDMOSH","EDNHSH","EDNVSH","EDNYSH","EDOHSH","EDVASH","EDWISH","SHUNCE","SHUNEA","SHUNWS")
  def setyear(yr:String){
    year = yr
  }
  def sparkInIt(){
    println("dbwrk.tblreceived_ip : "+dbwrk+"."+tblreceived_ip)
     naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk = readDataFromHive(dbwrk+"."+tblreceived_ip)
     
     naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk = readDataFromHive(dbwrk+"."+tblreceived_sgp)
     naic2018_mcas_hlthex_clmPhmcy_received_lgp_wrk = readDataFromHive(dbwrk+"."+tblreceived_lgp)
     println(dbwrk+"."+tblreceived_cat)
     naic2018_mcas_hlthex_clmPhmcy_received_cat_wrk = readDataFromHive(dbwrk+"."+tblreceived_cat)
     naic2018_mcas_hlthex_clmPhmcy_denied_wrk = readDataFromHive(dbwrk+"."+tblpclm_denied)
     naic2018_mcas_hlthex_clmPhmcy_paid_wrk = readDataFromHive(dbwrk+"."+tblpclm_paid)
     naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk = readDataFromHive(dbwrk+"."+tblpaid_ip)
     naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk = readDataFromHive(dbwrk+"."+tblpaid_sgp)
     naic2018_mcas_hlthex_clmPhmcy_paid_cat_wrk = readDataFromHive(dbwrk+"."+tblpaid_cat)
     naic2018_mcas_hlthex_clmPhmcy_paid_lgp_wrk = readDataFromHive(dbwrk+"."+tblpaid_lgp)
     println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
     println(dbin+"."+tblsrvc_dnl)
     naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd = readDataFromHive(dbin+"."+tblsrvc_dnl)
     val finalReceivedData = getClmReceivedData()
    val finalDeniedInntwk = getDeniedInntwkData()
    val finalDeniedOutntwk = getDeniedOutntwkData()
     println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
    val finalPaidInntwk = getPaidInntwkData()
    val finalPaidOutntwk=getPaidOutntwkData()
   val finalPay = getTotalPaidCpaid("PAID_AMT","paid")
   //finalPay.show(1)
    val finalCPay = getTotalPaidCpaid("CPAY_AMT","copay")
    val finalCoinSrcPay = getTotalPaidCpaid("COINSRN_AMT","coinsrn")
    val finalddctblPay = getTotalPaidCpaid("DDCTBL_AMT","ddctbl")
   val stagData = getStgdata(finalReceivedData,finalDeniedInntwk,finalDeniedOutntwk,finalPaidInntwk,finalPaidOutntwk,finalPay,
        finalCPay,finalCoinSrcPay,finalddctblPay)
        
         var load_log_key = ""
    if(!naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.take(1).isEmpty){
     load_log_key = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.select($"load_log_key").first.getString(0)
    }
        val finalStgData = stagData.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
     
    
   
        writeDataToHive(dbsg+".naic2018_mcas_hlthoex_clmphmcy_stg",finalStgData)    
        spark.close()
  }
  def truncateTbl(tblName:String){
			  spark.sql("TRUNCATE TABLE "+tblName)
	}
  def writeDataToHive(tblName: String, finalDf: DataFrame) {
    finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
    println("Data added in stage table")
  }
 def readDataFromHive(tble: String): DataFrame = {
    val queryOutputTable="""SELECT * FROM """ +  tble
    val tbl_data_df = spark.sql(queryOutputTable)//.na.fill("")
    logger.info("Read data from hive")
    tbl_data_df
 } 
 
 def getClmReceivedData():DataFrame={
 
  val nbrclm_received_total_ip = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                              ($"src_exchng_certfn_cd".notEqual("M") ||  $"src_exchng_certfn_cd".isNull) &&
                              $"in_exchange".isNull)
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state",$"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_total_ip")).withColumn("nbrclm_received_total_ip",$"nbrclm_received_total_ip".cast(IntegerType))
                              
    val nbrclm_received_total_sgp = naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                              ($"src_exchng_certfn_cd".notEqual("M") ||  $"src_exchng_certfn_cd".isNull) &&
                             $"in_exchange".isNull)
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_total_sgp")).withColumn("nbrclm_received_total_sgp",$"nbrclm_received_total_sgp".cast(IntegerType))
    
    val ipSgp=  nbrclm_received_total_ip.alias("parent").join(nbrclm_received_total_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"))
                                            
     val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp")                         
      println("************************ GTLGP *********************************************")                         
      val nbrclm_received_gtlgp  = naic2018_mcas_hlthex_clmPhmcy_received_lgp_wrk.filter(
                              //($"grndfthr_ind_cd".equalTo("YES") || $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull ) &&
                              $"grndfthr_ind_cd".equalTo("YES") &&
                              $"in_exchange".isNull)
                            .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                            .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_gtlgp")).withColumn("nbrclm_received_gtlgp",$"nbrclm_received_gtlgp".cast(IntegerType))
    
    
       val ipSgplgp=  nbrclm_received_gtlgp.alias("parent").join(ipSgpData.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"))
                                            
     val ipSgplgpData = ipSgplgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp") 
                           
       val nbrclm_received_gtsgp  = naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                             ($"grndfthr_ind_cd".equalTo("YES") ||
                              $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                              $"in_exchange".isNull)
                            .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_gtsgp")).withColumn("nbrclm_received_gtsgp",$"nbrclm_received_gtsgp".cast(IntegerType))
                         
       val ipSgplgpgtSgp=  nbrclm_received_gtsgp.alias("parent").join(ipSgplgpData.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"))
                                            
     val ipSgplgpgtSgpData = ipSgplgpgtSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp")

     val nbrclm_received_gtip  = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                             ($"grndfthr_ind_cd".equalTo("YES") ||
                              $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                              $"in_exchange".isNull)
                            .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_gtip")).withColumn("nbrclm_received_gtip",$"nbrclm_received_gtip".cast(IntegerType))
                         
          
      val ipSgplgpgtSgpgtip=  nbrclm_received_gtip.alias("parent").join(ipSgplgpgtSgpData.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"),
           col("nbrclm_received_gtip"))
                                            
     val ipSgplgpgtSgpgtipData = ipSgplgpgtSgpgtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip")
    
          
      val totalgtIp=  nbrclm_received_gtip.union(nbrclm_received_gtsgp.union(nbrclm_received_gtlgp)) 
                      .select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_received_gtip")
      val nbrclm_received_total_gtip = totalgtIp.groupBy("health_year","cmpny_cf_cd", "state").agg(sum($"nbrclm_received_gtip").alias("nbrclm_received_total_gtip"))
      
      
       val ipSgplgpgtSgpgtipTot=  nbrclm_received_total_gtip.alias("parent").join(ipSgplgpgtSgpgtipData.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"),
           col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"))
                                            
     val ipsgpTotipData = ipSgplgpgtSgpgtipTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip")
    
       val nbrclm_received_catastrophic  = naic2018_mcas_hlthex_clmPhmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                             $"in_exchange".isNull)
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_catastrophic")).withColumn("nbrclm_received_catastrophic",$"nbrclm_received_catastrophic".cast(IntegerType))
       
      
      
       val ipsgpTotipCat=  nbrclm_received_catastrophic.alias("parent").join(ipsgpTotipData.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"),
           col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"), col("nbrclm_received_catastrophic"))
                                            
     val ipsgpTotipcatData = ipsgpTotipCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip", "nbrclm_received_catastrophic")
    
      val nbrclm_received_lgp_mmcare = naic2018_mcas_hlthex_clmPhmcy_received_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                                          (!$"mbu_cf_cd".isin(mbu_cf_cdvals:_*)) &&
                                           $"in_exchange".isNull)
                                           .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_lgp_mmcare")).withColumn("nbrclm_received_lgp_mmcare",$"nbrclm_received_lgp_mmcare".cast(IntegerType))
       val ipsgpTotipCatmmCar=  nbrclm_received_lgp_mmcare.alias("parent").join(ipsgpTotipcatData.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"),
           col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"), col("nbrclm_received_catastrophic"), col("nbrclm_received_lgp_mmcare"))
                                            
     val ipsgpTotipcatmmcarData = ipsgpTotipCatmmCar.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip","nbrclm_received_catastrophic", "nbrclm_received_lgp_mmcare")
                               
     val nbrclm_received_stucvg = naic2018_mcas_hlthex_clmPhmcy_received_lgp_wrk.filter(
                                          $"mbu_cf_cd".isin(mbu_cf_cdvals:_*) &&
                                           $"in_exchange".isNull)
                                           .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_received_stucvg")).withColumn("nbrclm_received_stucvg",$"nbrclm_received_stucvg".cast(IntegerType))
       val received=  nbrclm_received_stucvg.alias("parent").join(ipsgpTotipcatmmcarData.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"),
           col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"), col("nbrclm_received_catastrophic"), col("nbrclm_received_lgp_mmcare"), col("nbrclm_received_stucvg"))
                                            
     val receivedData = received.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip","nbrclm_received_catastrophic", "nbrclm_received_lgp_mmcare", "nbrclm_received_stucvg")                          
                               
                               
                               
       receivedData   
 
  
 
 
 }
 def getDeniedJoindataFrame(naic2018_mcas_pclm_denied_wrk:DataFrame, naic2018_mcas_hlthex_clmphmcy_received_wrk:DataFrame,  
     naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd:DataFrame) :DataFrame = {
   
   val joinedDf = naic2018_mcas_hlthex_clmphmcy_received_wrk.alias("received_wrk").join(naic2018_mcas_pclm_denied_wrk.alias("denied_wrk"), 
                                                                   $"received_wrk.CLM_NBR" === $"denied_wrk.CLM_NBR" &&
                                                                   $"received_wrk.MBR_KEY" === $"denied_wrk.MBR_KEY" &&
                                                                   $"received_wrk.RX_FILLED_DT" === $"denied_wrk.RX_FILLED_DT" &&
                                                                   $"received_wrk.ADJDCTN_DT" === $"denied_wrk.ADJDCTN_DT" &&
                                                                   $"received_wrk.NDC" === $"denied_wrk.NDC" &&
                                                                   $"received_wrk.RX_NBR" === $"denied_wrk.RX_NBR" , "inner")
                                                                   .join(naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd.alias("sec"),
                                                                        $"received_wrk.src_srvc_dnl_rsn_cd" === $"sec.src_srvc_dnl_rsn_cd" &&
                                                                        $"received_wrk.clm_sor_cd" === $"sec.clm_sor_cd", "left_outer")
                                                                    .filter( $"sec.src_srvc_dnl_rsn_cd".isNull && 
                                                                     $"sec.clm_sor_cd".isNull)
                                                                     .groupBy($"received_wrk.health_year".alias("health_year"), $"received_wrk.cmpny_cf_cd".alias("cmpny_cf_cd"), $"received_wrk.state".alias("state"), 
                                                                      $"received_wrk.CLM_NBR", $"received_wrk.CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                                        
    joinedDf                                                                
 }
 def getDeniedInntwkData(): DataFrame = {
     val clminn_cd = Seq("IN", "PAR")
    
   val clmLineAdjdctn = Seq("DND","DNDZB")
   val receivedipFilters = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                              ($"src_exchng_certfn_cd".notEqual("M") ||  $"src_exchng_certfn_cd".isNull) &&
                              $"in_exchange".isNull &&
                              $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
               
   
   
   val denied_ip = getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedipFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
  
   
   val nbrclm_denied_inntwk_total_ip = denied_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_total_ip"))
   
   
    val receivedsgpFilters = naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                              ($"src_exchng_certfn_cd".notEqual("M") ||  $"src_exchng_certfn_cd".isNull) &&
                              $"in_exchange".isNull &&
                               $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_sgp =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedsgpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_inntwk_total_sgp  = denied_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_total_sgp"))

  val ipSgp=  nbrclm_denied_inntwk_total_ip.alias("parent").join(nbrclm_denied_inntwk_total_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"))
                                            
     val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp")   
        
   
   val receivedgtlgpFilters = naic2018_mcas_hlthex_clmPhmcy_received_lgp_wrk.filter(
                              //($"grndfthr_ind_cd".equalTo("YES") ||  $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                             $"grndfthr_ind_cd".equalTo("YES") &&
                              $"in_exchange".isNull &&
                               $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_gtlgp =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedgtlgpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_inntwk_gtlgp   = denied_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gtlgp"))

   val ipSgpgtlgp=  ipSgpData.alias("parent").join(nbrclm_denied_inntwk_gtlgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"))
                                            
     val ipSgpgtlgpData = ipSgpgtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp")   
        
   val receivedgtsgpFilters = naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk.filter(//$"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                              ($"grndfthr_ind_cd".equalTo("YES") ||
                              $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                              $"in_exchange".isNull &&
                               $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_gtsgp =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedgtsgpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_inntwk_gtsgp    = denied_gtsgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gtsgp"))
    val ipSgpgtlgpgtsgp=  ipSgpgtlgpData.alias("parent").join(nbrclm_denied_inntwk_gtsgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"))
                                            
     val ipSgpgtlgpgtsgpData = ipSgpgtlgpgtsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp")   
                           
   val receivedgtipFilters = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".equalTo("YES") ||
                              $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull ) &&
                              $"in_exchange".isNull &&
                               $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_gtip =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedgtipFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_inntwk_gtip  = denied_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gtip"))
    
    
    val ipSgpgtlgpgtsgpgtipData=  ipSgpgtlgpgtsgpData.alias("parent").join(nbrclm_denied_inntwk_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"),
           col("nbrclm_denied_inntwk_gtip"))
                                            
     val ipSgpgtData = ipSgpgtlgpgtsgpgtipData.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip")
                               
     
    val tot_gtip = nbrclm_denied_inntwk_gtip.union(nbrclm_denied_inntwk_gtsgp.union(nbrclm_denied_inntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_denied_inntwk_gtip")
    
    val nbrclm_denied_inntwk_total_gtip = tot_gtip.groupBy("health_year","cmpny_cf_cd", "state").agg(sum($"nbrclm_denied_inntwk_gtip").alias("nbrclm_denied_inntwk_total_gtip"))//.withColumn("mbrmpoa_renewed_total_ip",$"mbrmpoa_renewed_total_ip".cast(IntegerType))
    
    
    val ipSgptotgt=  ipSgpgtData.alias("parent").join(nbrclm_denied_inntwk_total_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"),
           col("nbrclm_denied_inntwk_gtip"), col("nbrclm_denied_inntwk_total_gtip"))
                                            
     val ipSgptotgtData = ipSgptotgt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip")
    
    
    val receivedcatFilters = naic2018_mcas_hlthex_clmPhmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                              $"in_exchange".isNull &&
                               $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_cat =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedcatFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_inntwk_catastrophic   = denied_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_catastrophic"))
    
   val ipSgptotgtCat=  ipSgptotgtData.alias("parent").join(nbrclm_denied_inntwk_catastrophic.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"),
           col("nbrclm_denied_inntwk_gtip"), col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"))
                                            
     val ipSgptotgtCatData = ipSgptotgtCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic")
     
    val receivedmmcareFilters = naic2018_mcas_hlthex_clmPhmcy_received_lgp_wrk.filter(
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              (!$"mbu_cf_cd".isin(mbu_cf_cdvals:_*)) &&
                              $"in_exchange".isNull &&
                               $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
    val denied_mmcare =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedmmcareFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
    
    val nbrclm_denied_inntwk_lgp_mmcare   = denied_mmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_lgp_mmcare"))
    
     val ipSgptotgtCatmmcare=  ipSgptotgtCatData.alias("parent").join(nbrclm_denied_inntwk_lgp_mmcare.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"),
           col("nbrclm_denied_inntwk_gtip"), col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"))
                                            
     val ipSgptotgtCatmmcareData = ipSgptotgtCatmmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare")
     
    
    val receivedstuvgFilters = naic2018_mcas_hlthex_clmPhmcy_received_lgp_wrk.filter(
                              ($"mbu_cf_cd".isin(mbu_cf_cdvals:_*)) &&
                              $"in_exchange".isNull &&
                               $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
    val denied_stuvg =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedstuvgFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
    
    val nbrclm_denied_inntwk_stucvg   = denied_stuvg.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_inntwk_stucvg"))
    
    val ipSgptotgtCatmmcarestuvg=  ipSgptotgtCatmmcareData.alias("parent").join(nbrclm_denied_inntwk_stucvg.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"),
           col("nbrclm_denied_inntwk_gtip"), col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"), col("nbrclm_denied_inntwk_stucvg"))
                                            
     val deniedInntwkData = ipSgptotgtCatmmcarestuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare","nbrclm_denied_inntwk_stucvg")
     
    deniedInntwkData
    
    
  }
 
 def getDeniedOutntwkData(): DataFrame = {
     val clminn_cd = Seq("IN", "PAR")
    
   val clmLineAdjdctn = Seq("DND","DNDZB")
   val receivedipFilters = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                              ($"src_exchng_certfn_cd".notEqual("M") ||  $"src_exchng_certfn_cd".isNull) &&
                              $"in_exchange".isNull &&
                              (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
               
   
   
   val denied_ip = getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedipFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
  
   
   val nbrclm_denied_outntwk_total_ip = denied_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_total_ip"))
   
   
    val receivedsgpFilters = naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                              ($"src_exchng_certfn_cd".notEqual("M") ||  $"src_exchng_certfn_cd".isNull) &&
                              $"in_exchange".isNull &&
                               (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_sgp =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedsgpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_outntwk_total_sgp  = denied_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_total_sgp"))

  val ipSgp=  nbrclm_denied_outntwk_total_ip.alias("parent").join(nbrclm_denied_outntwk_total_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"))
                                            
     val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp")   
        
   
   val receivedgtlgpFilters = naic2018_mcas_hlthex_clmPhmcy_received_lgp_wrk.filter(
                              //($"grndfthr_ind_cd".equalTo("YES") || $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                               $"grndfthr_ind_cd".equalTo("YES") &&
                              $"in_exchange".isNull &&
                               (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_gtlgp =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedgtlgpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_outntwk_gtlgp   = denied_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gtlgp"))

   val ipSgpgtlgp=  ipSgpData.alias("parent").join(nbrclm_denied_outntwk_gtlgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"))
                                            
     val ipSgpgtlgpData = ipSgpgtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp")   
        
   val receivedgtsgpFilters = naic2018_mcas_hlthex_clmPhmcy_received_sgp_wrk.filter(
                              ($"grndfthr_ind_cd".equalTo("YES") ||
                              $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                              $"in_exchange".isNull &&
                               (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_gtsgp =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedgtsgpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_outntwk_gtsgp    = denied_gtsgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gtsgp"))
    val ipSgpgtlgpgtsgp=  ipSgpgtlgpData.alias("parent").join(nbrclm_denied_outntwk_gtsgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"))
                                            
     val ipSgpgtlgpgtsgpData = ipSgpgtlgpgtsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp")   
                           
   val receivedgtipFilters = naic2018_mcas_hlthex_clmPhmcy_received_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".equalTo("YES") ||
                              $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                              $"in_exchange".isNull &&
                               (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_gtip =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedgtipFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_outntwk_gtip  = denied_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gtip"))
    
    
    val ipSgpgtlgpgtsgpgtipData=  ipSgpgtlgpgtsgpData.alias("parent").join(nbrclm_denied_outntwk_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"),
           col("nbrclm_denied_outntwk_gtip"))
                                            
     val ipSgpgtData = ipSgpgtlgpgtsgpgtipData.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip")
                               
     
    val tot_gtip = nbrclm_denied_outntwk_gtip.union(nbrclm_denied_outntwk_gtsgp.union(nbrclm_denied_outntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_denied_outntwk_gtip")
    
    val nbrclm_denied_outntwk_total_gtip = tot_gtip.groupBy("health_year","cmpny_cf_cd", "state").agg(sum($"nbrclm_denied_outntwk_gtip").alias("nbrclm_denied_outntwk_total_gtip"))//.withColumn("mbrmpoa_renewed_total_ip",$"mbrmpoa_renewed_total_ip".cast(IntegerType))
    
    
    val ipSgptotgt=  ipSgpgtData.alias("parent").join(nbrclm_denied_outntwk_total_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"),
           col("nbrclm_denied_outntwk_gtip"), col("nbrclm_denied_outntwk_total_gtip"))
                                            
     val ipSgptotgtData = ipSgptotgt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip")
    
    
    val receivedcatFilters = naic2018_mcas_hlthex_clmPhmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                              $"in_exchange".isNull &&
                               (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_cat =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedcatFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_outntwk_catastrophic   = denied_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_catastrophic"))
    
   val ipSgptotgtCat=  ipSgptotgtData.alias("parent").join(nbrclm_denied_outntwk_catastrophic.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"),
           col("nbrclm_denied_outntwk_gtip"), col("nbrclm_denied_outntwk_total_gtip"), col("nbrclm_denied_outntwk_catastrophic"))
                                            
     val ipSgptotgtCatData = ipSgptotgtCat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic")
     
    val receivedmmcareFilters = naic2018_mcas_hlthex_clmPhmcy_received_lgp_wrk.filter(
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              (!$"mbu_cf_cd".isin(mbu_cf_cdvals:_*)) &&
                              $"in_exchange".isNull &&
                               (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
    val denied_mmcare =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedmmcareFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
    
    val nbrclm_denied_outntwk_lgp_mmcare   = denied_mmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_lgp_mmcare"))
    
     val ipSgptotgtCatmmcare=  ipSgptotgtCatData.alias("parent").join(nbrclm_denied_outntwk_lgp_mmcare.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"),
           col("nbrclm_denied_outntwk_gtip"), col("nbrclm_denied_outntwk_total_gtip"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_lgp_mmcare"))
                                            
     val ipSgptotgtCatmmcareData = ipSgptotgtCatmmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare")
     
    
    val receivedstuvgFilters = naic2018_mcas_hlthex_clmPhmcy_received_lgp_wrk.filter(
                              ($"mbu_cf_cd".isin(mbu_cf_cdvals:_*)) &&
                              $"in_exchange".isNull &&
                               (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
    val denied_stuvg =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedstuvgFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
    
    val nbrclm_denied_outntwk_stucvg   = denied_stuvg.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_denied_outntwk_stucvg"))
    
    val ipSgptotgtCatmmcarestuvg=  ipSgptotgtCatmmcareData.alias("parent").join(nbrclm_denied_outntwk_stucvg.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"),
           col("nbrclm_denied_outntwk_gtip"), col("nbrclm_denied_outntwk_total_gtip"), col("nbrclm_denied_outntwk_catastrophic"), col("nbrclm_denied_outntwk_lgp_mmcare"), col("nbrclm_denied_outntwk_stucvg"))
                                            
     val deniedOutntwkData = ipSgptotgtCatmmcarestuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare","nbrclm_denied_outntwk_stucvg")
     
    deniedOutntwkData
    
    
  }
 def getPaidInntwkData():DataFrame = {
   val clminn_cd = Seq("IN", "PAR")
   val nbrclm_paid_inntwk_total_ip = naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                              ($"src_exchng_certfn_cd".notEqual("M") ||  $"src_exchng_certfn_cd".isNull) &&
                              $"in_exchange".isNull &&
                              $"inn_cd".isin(clminn_cd:_*))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_total_ip"))
  val nbrclm_paid_inntwk_total_sgp = naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                              ($"src_exchng_certfn_cd".notEqual("M") ||  $"src_exchng_certfn_cd".isNull) &&
                             $"in_exchange".isNull &&
                             $"inn_cd".isin(clminn_cd:_*)) 
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_total_sgp"))                          
   
   val ipSgp=  nbrclm_paid_inntwk_total_ip.alias("parent").join(nbrclm_paid_inntwk_total_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"))
                                            
     val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp")
                           
                           
                           
    val nbrclm_paid_inntwk_gtlgp = naic2018_mcas_hlthex_clmPhmcy_paid_lgp_wrk.filter(
                                    //($"grndfthr_ind_cd".equalTo("YES") || $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                                    $"grndfthr_ind_cd".equalTo("YES") &&
                                     $"in_exchange".isNull &&
                                    $"inn_cd".isin(clminn_cd:_*)) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gtlgp"))                          
   
    val ipSgpgtlgp=  ipSgpData.alias("parent").join(nbrclm_paid_inntwk_gtlgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"))
                                            
     val ipSgpgtlgpData = ipSgpgtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp")
                  
                           
     val nbrclm_paid_inntwk_gtsgp = naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&                      
                                     ($"grndfthr_ind_cd".equalTo("YES") ||
                                     $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                                      $"in_exchange".isNull &&
                                    $"inn_cd".isin(clminn_cd:_*)) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gtsgp"))                          
   
    val ipSgpgtlgpgtsgp=  ipSgpgtlgpData.alias("parent").join(nbrclm_paid_inntwk_gtsgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"))
                                            
     val gtsgpMasterData = ipSgpgtlgpgtsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp")
                                         
      val nbrclm_paid_inntwk_gtip = naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&                     
                                   ($"grndfthr_ind_cd".equalTo("YES") ||
                                     $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                                      $"in_exchange".isNull &&
                                    $"inn_cd".isin(clminn_cd:_*)) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gtip"))                          
   
                           
        val gtip=  gtsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"),
           col("nbrclm_paid_inntwk_gtip"))
                                            
         val gtipMasterData = gtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip")
          
      val totalgtip = nbrclm_paid_inntwk_gtip.union(nbrclm_paid_inntwk_gtsgp.union(nbrclm_paid_inntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_paid_inntwk_gtip")
      
      val nbrclm_paid_inntwk_total_gtip = totalgtip.groupBy("health_year","cmpny_cf_cd", "state").agg(sum($"nbrclm_paid_inntwk_gtip").alias("nbrclm_paid_inntwk_total_gtip"))
      
       val totgtip=  gtipMasterData.alias("parent").join(nbrclm_paid_inntwk_total_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"),
           col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"))
                                            
         val totgtipMasterData = totgtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip")
                           
        val nbrclm_paid_inntwk_catastrophic = naic2018_mcas_hlthex_clmPhmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                                               $"in_exchange".isNull &&
                                                $"inn_cd".isin(clminn_cd:_*)) 
                                                .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_catastrophic"))                          
   
          val cat=  totgtipMasterData.alias("parent").join(nbrclm_paid_inntwk_catastrophic.alias("child") , $"parent.health_year"===$"child.health_year" 
                      && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                      .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                       $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                       $"child.state".alias("s_state") , 
                       col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"),
                       col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"))
                                            
         val catMasterData = cat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic")
                               
           val nbrclm_paid_inntwk_lgp_mmcare = naic2018_mcas_hlthex_clmPhmcy_paid_lgp_wrk.filter(
                                    ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                                     (!$"mbu_cf_cd".isin(mbu_cf_cdvals:_*)) &&
                                        $"in_exchange".isNull &&
                                    $"inn_cd".isin(clminn_cd:_*)) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_lgp_mmcare"))                          
   
                           
             val mmcare=  catMasterData.alias("parent").join(nbrclm_paid_inntwk_lgp_mmcare.alias("child") , $"parent.health_year"===$"child.health_year" 
                      && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                      .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                       $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                       $"child.state".alias("s_state") , 
                       col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"),
                       col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"))
                                            
         val mmcareMasterData = mmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare")               
                           
             val nbrclm_paid_inntwk_stucvg = naic2018_mcas_hlthex_clmPhmcy_paid_lgp_wrk.filter(
                                     $"mbu_cf_cd".isin(mbu_cf_cdvals:_*) &&
                                        $"in_exchange".isNull &&
                                    $"inn_cd".isin(clminn_cd:_*)) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_stucvg"))                          
                  
              val stuvg=  mmcareMasterData.alias("parent").join(nbrclm_paid_inntwk_stucvg.alias("child") , $"parent.health_year"===$"child.health_year" 
                      && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                      .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                       $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                       $"child.state".alias("s_state") , 
                       col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"),
                       col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"), col("nbrclm_paid_inntwk_stucvg"))
                                            
         val paidInntwkData = stuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg")               
                                        
                           
                           
                           
 paidInntwkData
 }
 def getPaidOutntwkData():DataFrame = {
   val clminn_cd = Seq("IN", "PAR")
   val nbrclm_paid_outntwk_total_ip = naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                              ($"src_exchng_certfn_cd".notEqual("M") ||  $"src_exchng_certfn_cd".isNull) &&
                              $"in_exchange".isNull &&
                              (!$"inn_cd".isin(clminn_cd:_*)))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_total_ip"))
  val nbrclm_paid_outntwk_total_sgp = naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                              ($"src_exchng_certfn_cd".notEqual("M") ||  $"src_exchng_certfn_cd".isNull) &&
                             $"in_exchange".isNull &&
                             (!$"inn_cd".isin(clminn_cd:_*))) 
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_total_sgp"))                          
   
   val ipSgp=  nbrclm_paid_outntwk_total_ip.alias("parent").join(nbrclm_paid_outntwk_total_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"))
                                            
     val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp")
                           
                           
                           
    val nbrclm_paid_outntwk_gtlgp = naic2018_mcas_hlthex_clmPhmcy_paid_lgp_wrk.filter(
                                    //($"grndfthr_ind_cd".equalTo("YES") || $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                                      $"grndfthr_ind_cd".equalTo("YES") &&
                                     $"in_exchange".isNull &&
                                    (!$"inn_cd".isin(clminn_cd:_*))) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gtlgp"))                          
   
    val ipSgpgtlgp=  ipSgpData.alias("parent").join(nbrclm_paid_outntwk_gtlgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"))
                                            
     val ipSgpgtlgpData = ipSgpgtlgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp")
                  
                           
     val nbrclm_paid_outntwk_gtsgp = naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&                      
                                     ($"grndfthr_ind_cd".equalTo("YES") ||
                                     $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                                      $"in_exchange".isNull &&
                                    (!$"inn_cd".isin(clminn_cd:_*))) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gtsgp"))                          
   
    val ipSgpgtlgpgtsgp=  ipSgpgtlgpData.alias("parent").join(nbrclm_paid_outntwk_gtsgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"))
                                            
     val gtsgpMasterData = ipSgpgtlgpgtsgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp")
                                         
      val nbrclm_paid_outntwk_gtip = naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&                     
                                   ($"grndfthr_ind_cd".equalTo("YES") ||
                                     $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                                      $"in_exchange".isNull &&
                                    (!$"inn_cd".isin(clminn_cd:_*))) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gtip"))                          
   
                           
        val gtip=  gtsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"),
           col("nbrclm_paid_outntwk_gtip"))
                                            
         val gtipMasterData = gtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp",
                               "nbrclm_paid_outntwk_gtip")
          
      val totalgtip = nbrclm_paid_outntwk_gtip.union(nbrclm_paid_outntwk_gtsgp.union(nbrclm_paid_outntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_paid_outntwk_gtip")
      
      val nbrclm_paid_outntwk_total_gtip = totalgtip.groupBy("health_year","cmpny_cf_cd", "state").agg(sum($"nbrclm_paid_outntwk_gtip").alias("nbrclm_paid_outntwk_total_gtip"))
      
       val totgtip=  gtipMasterData.alias("parent").join(nbrclm_paid_outntwk_total_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"),
           col("nbrclm_paid_outntwk_gtip"), col("nbrclm_paid_outntwk_total_gtip"))
                                            
         val totgtipMasterData = totgtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp",
                               "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip")
                           
        val nbrclm_paid_outntwk_catastrophic = naic2018_mcas_hlthex_clmPhmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                                               $"in_exchange".isNull &&
                                                (!$"inn_cd".isin(clminn_cd:_*))) 
                                                .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_catastrophic"))                          
   
          val cat=  totgtipMasterData.alias("parent").join(nbrclm_paid_outntwk_catastrophic.alias("child") , $"parent.health_year"===$"child.health_year" 
                      && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                      .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                       $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                       $"child.state".alias("s_state") , 
                       col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"),
                       col("nbrclm_paid_outntwk_gtip"), col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_catastrophic"))
                                            
         val catMasterData = cat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp",
                               "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic")
                               
           val nbrclm_paid_outntwk_lgp_mmcare = naic2018_mcas_hlthex_clmPhmcy_paid_lgp_wrk.filter(
                                    ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                                     (!$"mbu_cf_cd".isin(mbu_cf_cdvals:_*)) &&
                                        $"in_exchange".isNull &&
                                    (!$"inn_cd".isin(clminn_cd:_*))) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_lgp_mmcare"))                          
   
                           
             val mmcare=  catMasterData.alias("parent").join(nbrclm_paid_outntwk_lgp_mmcare.alias("child") , $"parent.health_year"===$"child.health_year" 
                      && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                      .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                       $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                       $"child.state".alias("s_state") , 
                       col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"),
                       col("nbrclm_paid_outntwk_gtip"), col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_lgp_mmcare"))
                                            
         val mmcareMasterData = mmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp",
                               "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_lgp_mmcare")               
                           
             val nbrclm_paid_outntwk_stucvg = naic2018_mcas_hlthex_clmPhmcy_paid_lgp_wrk.filter(
                                   // ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                                     $"mbu_cf_cd".isin(mbu_cf_cdvals:_*) &&
                                        $"in_exchange".isNull &&
                                    (!$"inn_cd".isin(clminn_cd:_*))) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_stucvg"))                          
                  
              val stuvg=  mmcareMasterData.alias("parent").join(nbrclm_paid_outntwk_stucvg.alias("child") , $"parent.health_year"===$"child.health_year" 
                      && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                      .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                       $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                       $"child.state".alias("s_state") , 
                       col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"),
                       col("nbrclm_paid_outntwk_gtip"), col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_lgp_mmcare"), col("nbrclm_paid_outntwk_stucvg"))
                                            
         val paidoutntwkData = stuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp",
                               "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_lgp_mmcare", "nbrclm_paid_outntwk_stucvg")               
                                        
                                    
                           
 paidoutntwkData
 }
 def getTotalPaidCpaid(paid_col:String, typeOfPay:String):DataFrame={
   val total_ip = "clm_total_"+typeOfPay+"_amt_total_ip"//clm_total_paid_amt_total_ip   clm_total_paid_amt_total_ip
   val clm_total_paid_amt_total_ip = naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                              ($"src_exchng_certfn_cd".notEqual("M") ||  $"src_exchng_certfn_cd".isNull) &&
                              $"in_exchange".isNull)
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(col(paid_col)).alias(total_ip)).withColumn(total_ip,col(total_ip).cast(IntegerType))
  val total_sgp = "clm_total_"+typeOfPay+"_amt_total_sgp" 
  val clm_total_paid_amt_total_sgp = naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&
                              ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                              $"hcr_cmplynt_cd".equalTo("Y") &&
                              ($"src_exchng_certfn_cd".notEqual("M") ||  $"src_exchng_certfn_cd".isNull) &&
                              $"in_exchange".isNull)
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR",  col(paid_col)).agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(col(paid_col)).alias(total_sgp)).withColumn(total_sgp,col(total_sgp).cast(IntegerType))
   
   
   val ipSgp=  clm_total_paid_amt_total_ip.alias("parent").join(clm_total_paid_amt_total_sgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col(total_ip), col(total_sgp))
                                            
     val ipSgpData = ipSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", total_ip ,total_sgp) 
                           
       val total_lgp = "clm_total_"+typeOfPay+"_amt_gtlgp"                    
      val clm_total_paid_amt_gtlgp = naic2018_mcas_hlthex_clmPhmcy_paid_lgp_wrk.filter(
                                  //($"grndfthr_ind_cd".equalTo("YES") || $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                                    $"grndfthr_ind_cd".equalTo("YES") &&
                                   $"in_exchange".isNull)
                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR",  col(paid_col)).agg((lit(1)).alias("count_Val"))
                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(col(paid_col)).alias(total_lgp)).withColumn(total_lgp,col(total_lgp).cast(IntegerType))
   
    val gtLgp=  ipSgpData.alias("parent").join(clm_total_paid_amt_gtlgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col(total_ip), col(total_sgp), col(total_lgp))
                                            
     val gtLgpMasterData = gtLgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year","cmpny_cf_cd", "state", total_ip ,total_sgp, total_lgp)
                           
       val total_gtsgp = "clm_total_"+typeOfPay+"_amt_gtsgp"                     
                           
        val clm_total_paid_amt_total_gtsgp = naic2018_mcas_hlthex_clmPhmcy_paid_sgp_wrk.filter($"naic_lob".equalTo("TOTAL SMALL GROUP CBE") &&                   
                                   ($"grndfthr_ind_cd".equalTo("YES") ||
                                   $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                                   $"in_exchange".isNull)
                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR",  col(paid_col)).agg((lit(1)).alias("count_Val"))
                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(col(paid_col)).alias(total_gtsgp)).withColumn(total_gtsgp,col(total_gtsgp).cast(IntegerType))
   
        val gtSgp=  gtLgpMasterData.alias("parent").join(clm_total_paid_amt_total_gtsgp.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col(total_ip), col(total_sgp), col(total_lgp), col(total_gtsgp))
                                            
     val gtSgpMasterData = gtSgp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year","cmpny_cf_cd", "state", total_ip ,total_sgp, total_lgp, total_gtsgp)
                                           
      val total_gtip = "clm_total_"+typeOfPay+"_amt_gtip"
   val clm_total_paid_amt_total_gtip = naic2018_mcas_hlthex_clmPhmcy_paid_ip_wrk.filter($"naic_lob".equalTo("TOTAL INDIVIDUAL CBE") &&                     
                                   ($"grndfthr_ind_cd".equalTo("YES") ||
                                   $"hcr_cmplynt_cd".notEqual("Y") || $"hcr_cmplynt_cd".isNull) &&
                                   $"in_exchange".isNull)
                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR",  col(paid_col)).agg((lit(1)).alias("count_Val"))
                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(col(paid_col)).alias(total_gtip)).withColumn(total_gtip,col(total_gtip).cast(IntegerType))
   
                           
         val gtIp=  gtSgpMasterData.alias("parent").join(clm_total_paid_amt_total_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col(total_ip), col(total_sgp), col(total_lgp), col(total_gtsgp), col(total_gtip))
                                            
     val gtIpMasterData = gtIp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", total_ip ,total_sgp, total_lgp, total_gtsgp, total_gtip)
      val total_sum_gtip =   "clm_total_"+typeOfPay+"_amt_total_gtip"                   
      val totalgtip = clm_total_paid_amt_total_gtip.union(clm_total_paid_amt_total_gtsgp.union(clm_total_paid_amt_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", col(total_gtip))
      
      val nbrclm_paid_outntwk_total_gtip = totalgtip.groupBy("health_year","cmpny_cf_cd", "state").agg(sum(col(total_gtip)).alias(total_sum_gtip)).withColumn(total_sum_gtip,col(total_sum_gtip).cast(IntegerType))
      
       val totgtIp=  gtIpMasterData.alias("parent").join(nbrclm_paid_outntwk_total_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col(total_ip), col(total_sgp), col(total_lgp), col(total_gtsgp), col(total_gtip), col(total_sum_gtip))
                                            
     val totgtIpMasterData = totgtIp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", total_ip ,total_sgp, total_lgp, total_gtsgp, total_gtip, total_sum_gtip)
       
                           
      val total_cat =   "clm_total_"+typeOfPay+"_amt_catastrophic"
      
       val nbrclm_paid_outntwk_catastrophic = naic2018_mcas_hlthex_clmPhmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
                                               $"in_exchange".isNull)
                                          .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR",  col(paid_col)).agg((lit(1)).alias("count_Val"))
                                         .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(col(paid_col)).alias(total_cat)).withColumn(total_cat,col(total_cat).cast(IntegerType))
     val cat=  totgtIpMasterData.alias("parent").join(nbrclm_paid_outntwk_catastrophic.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col(total_ip), col(total_sgp), col(total_lgp), col(total_gtsgp), col(total_gtip), col(total_sum_gtip), col(total_cat))
                                            
     val catMasterData = cat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year","cmpny_cf_cd", "state", total_ip ,total_sgp, total_lgp, total_gtsgp, total_gtip, total_sum_gtip, total_cat)
       
                           
                          
                           
      val total_lgpmmcare =   "clm_total_"+typeOfPay+"_amt_lgp_mmcare"
      
      val clm_total_paid_amt_lgp_mmcare = naic2018_mcas_hlthex_clmPhmcy_paid_lgp_wrk.filter(
                                      ($"grndfthr_ind_cd".notEqual("YES") ||  $"grndfthr_ind_cd".isNull) &&
                                     (!$"mbu_cf_cd".isin(mbu_cf_cdvals:_*)) &&
                                      $"in_exchange".isNull)
                                      .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR",  col(paid_col)).agg((lit(1)).alias("count_Val"))
                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(col(paid_col)).alias(total_lgpmmcare)).withColumn(total_lgpmmcare,col(total_lgpmmcare).cast(IntegerType))
     
        val mmcare=  catMasterData.alias("parent").join(clm_total_paid_amt_lgp_mmcare.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , 
           col(total_ip), col(total_sgp), col(total_lgp), col(total_gtsgp), col(total_gtip), col(total_sum_gtip), col(total_cat),
           col(total_lgpmmcare))
                                            
     val mmcareMasterData = mmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .select("health_year","cmpny_cf_cd", "state", total_ip ,total_sgp, total_lgp, total_gtsgp, total_gtip, total_sum_gtip, total_cat,
                               total_lgpmmcare)
       
                                             
       val total_lgpstuvg =   "clm_total_"+typeOfPay+"_amt_stucvg"                    
            println("clm_total_paid_amt_stucvg : "+ total_lgpstuvg)              
       val clm_total_paid_amt_stuvg = naic2018_mcas_hlthex_clmPhmcy_paid_lgp_wrk.filter(
                                     $"mbu_cf_cd".isin(mbu_cf_cdvals:_*) &&
                                      $"in_exchange".isNull)
                                      .groupBy($"health_year", $"cmpny_cf_cd", $"state",  $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR",  col(paid_col)).agg((lit(1)).alias("count_Val"))
                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(col(paid_col)).alias(total_lgpstuvg)).withColumn(total_lgpstuvg,col(total_lgpstuvg).cast(IntegerType))
                         
                           
       val stuvg=  mmcareMasterData.alias("parent").join(clm_total_paid_amt_stuvg.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , col(total_ip), col(total_sgp), col(total_lgp), col(total_gtsgp), col(total_gtip), col(total_sum_gtip), col(total_cat),
           col(total_lgpmmcare), col(total_lgpstuvg))
                                            
     val clmPaidData = stuvg.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", total_ip ,total_sgp, total_lgp, total_gtsgp, total_gtip, total_sum_gtip, total_cat,
                               total_lgpmmcare, total_lgpstuvg)                  
                           
                           
                           
                           
                           
 
    clmPaidData                       
  }
 def  getStgdata(finalReceivedData:DataFrame,finalDeniedInntwk:DataFrame,finalDeniedOutntwk:DataFrame,finalPaidInntwk:DataFrame,finalPaidOutntwk:DataFrame,finalPay:DataFrame,
        finalCPay:DataFrame,finalCoinSrcPay:DataFrame,finalddctblPay:DataFrame): DataFrame ={
   
   val rec_denied = finalReceivedData.alias("parent").join(finalDeniedInntwk.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"),
                   col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"),col("nbrclm_received_catastrophic"), col("nbrclm_received_lgp_mmcare"),
                   col("nbrclm_received_stucvg"), col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"),col("nbrclm_denied_inntwk_gtlgp"),col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"),
                   col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"), col("nbrclm_denied_inntwk_stucvg"))
   
   val recDenMaster = rec_denied.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip","nbrclm_received_catastrophic", "nbrclm_received_lgp_mmcare", "nbrclm_received_stucvg","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare","nbrclm_denied_inntwk_stucvg")
   
   
   
   val deniedOutMaster =  recDenMaster.alias("parent").join(finalDeniedOutntwk.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"),
                   col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"),col("nbrclm_received_catastrophic"), col("nbrclm_received_lgp_mmcare"),
                   col("nbrclm_received_stucvg"), col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"),col("nbrclm_denied_inntwk_gtlgp"),col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"),
                   col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"), col("nbrclm_denied_inntwk_stucvg"), col("nbrclm_denied_outntwk_total_ip"),
                   col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"),col("nbrclm_denied_outntwk_total_gtip"),col("nbrclm_denied_outntwk_catastrophic"),
                   col("nbrclm_denied_outntwk_lgp_mmcare"), col("nbrclm_denied_outntwk_stucvg"))
   
   val deniedOutMasterData = deniedOutMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip","nbrclm_received_catastrophic", "nbrclm_received_lgp_mmcare", "nbrclm_received_stucvg","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare","nbrclm_denied_inntwk_stucvg",
                                "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare","nbrclm_denied_outntwk_stucvg")
   
   
    val paidInMaster =  deniedOutMasterData.alias("parent").join(finalPaidInntwk.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"),
                   col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"),col("nbrclm_received_catastrophic"), col("nbrclm_received_lgp_mmcare"),
                   col("nbrclm_received_stucvg"), col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"),col("nbrclm_denied_inntwk_gtlgp"),col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"),
                   col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"), col("nbrclm_denied_inntwk_stucvg"), col("nbrclm_denied_outntwk_total_ip"),
                   col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"),col("nbrclm_denied_outntwk_total_gtip"),col("nbrclm_denied_outntwk_catastrophic"),
                   col("nbrclm_denied_outntwk_lgp_mmcare"), col("nbrclm_denied_outntwk_stucvg"), col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"),
                   col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"), col("nbrclm_paid_inntwk_stucvg"))
                   
                  
                  
   
   val paidInMasterData = paidInMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip","nbrclm_received_catastrophic", "nbrclm_received_lgp_mmcare", "nbrclm_received_stucvg","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare","nbrclm_denied_inntwk_stucvg",
                                "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare","nbrclm_denied_outntwk_stucvg",
                               "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",               
                                 "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg")               
                                        
   
   val paidOutMaster =  paidInMasterData.alias("parent").join(finalPaidOutntwk.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"),
                   col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"),col("nbrclm_received_catastrophic"), col("nbrclm_received_lgp_mmcare"),
                   col("nbrclm_received_stucvg"), col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"),col("nbrclm_denied_inntwk_gtlgp"),col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"),
                   col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"), col("nbrclm_denied_inntwk_stucvg"), col("nbrclm_denied_outntwk_total_ip"),
                   col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"),col("nbrclm_denied_outntwk_total_gtip"),col("nbrclm_denied_outntwk_catastrophic"),
                   col("nbrclm_denied_outntwk_lgp_mmcare"), col("nbrclm_denied_outntwk_stucvg"), col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"),
                   col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"), col("nbrclm_paid_inntwk_stucvg"),
                   col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"),
                   col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_lgp_mmcare"), col("nbrclm_paid_outntwk_stucvg"))
                   
                  
                  
   
   val paidOutMasterData = paidOutMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip","nbrclm_received_catastrophic", "nbrclm_received_lgp_mmcare", "nbrclm_received_stucvg","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare","nbrclm_denied_inntwk_stucvg",
                                "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare","nbrclm_denied_outntwk_stucvg",
                               "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",               
                                 "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",
                                "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp",
                               "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_lgp_mmcare", "nbrclm_paid_outntwk_stucvg")
                                         
   
 val payMaster =  paidOutMasterData.alias("parent").join(finalPay.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"),
                   col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"),col("nbrclm_received_catastrophic"), col("nbrclm_received_lgp_mmcare"),
                   col("nbrclm_received_stucvg"), col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"),col("nbrclm_denied_inntwk_gtlgp"),col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"),
                   col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"), col("nbrclm_denied_inntwk_stucvg"), col("nbrclm_denied_outntwk_total_ip"),
                   col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"),col("nbrclm_denied_outntwk_total_gtip"),col("nbrclm_denied_outntwk_catastrophic"),
                   col("nbrclm_denied_outntwk_lgp_mmcare"), col("nbrclm_denied_outntwk_stucvg"), col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"),
                   col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"), col("nbrclm_paid_inntwk_stucvg"),
                   col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"),
                   col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_lgp_mmcare"), col("nbrclm_paid_outntwk_stucvg"),
                   col("clm_total_paid_amt_total_ip"), col("clm_total_paid_amt_total_sgp"), col("clm_total_paid_amt_gtlgp"), col("clm_total_paid_amt_gtsgp"), col("clm_total_paid_amt_gtip"),
                   col("clm_total_paid_amt_total_gtip"), col("clm_total_paid_amt_catastrophic"), col("clm_total_paid_amt_lgp_mmcare"), col("clm_total_paid_amt_stucvg"))
                   
                  
                  
   
   val payMasterData = payMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip","nbrclm_received_catastrophic", "nbrclm_received_lgp_mmcare", "nbrclm_received_stucvg","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare","nbrclm_denied_inntwk_stucvg",
                                "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare","nbrclm_denied_outntwk_stucvg",
                               "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",               
                                 "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",
                                "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp",
                               "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_lgp_mmcare", "nbrclm_paid_outntwk_stucvg",
                               "clm_total_paid_amt_total_ip", "clm_total_paid_amt_total_sgp", "clm_total_paid_amt_gtlgp","clm_total_paid_amt_gtsgp", "clm_total_paid_amt_gtip",
                               "clm_total_paid_amt_total_gtip", "clm_total_paid_amt_catastrophic", "clm_total_paid_amt_lgp_mmcare", "clm_total_paid_amt_stucvg")
                                         
  val cpayMaster =  payMasterData.alias("parent").join(finalCPay.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"),
                   col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"),col("nbrclm_received_catastrophic"), col("nbrclm_received_lgp_mmcare"),
                   col("nbrclm_received_stucvg"), col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"),col("nbrclm_denied_inntwk_gtlgp"),col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"),
                   col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"), col("nbrclm_denied_inntwk_stucvg"), col("nbrclm_denied_outntwk_total_ip"),
                   col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"),col("nbrclm_denied_outntwk_total_gtip"),col("nbrclm_denied_outntwk_catastrophic"),
                   col("nbrclm_denied_outntwk_lgp_mmcare"), col("nbrclm_denied_outntwk_stucvg"), col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"),
                   col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"), col("nbrclm_paid_inntwk_stucvg"),
                   col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"),
                   col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_lgp_mmcare"), col("nbrclm_paid_outntwk_stucvg"),
                   col("clm_total_paid_amt_total_ip"), col("clm_total_paid_amt_total_sgp"), col("clm_total_paid_amt_gtlgp"), col("clm_total_paid_amt_gtsgp"), col("clm_total_paid_amt_gtip"),
                   col("clm_total_paid_amt_total_gtip"), col("clm_total_paid_amt_catastrophic"), col("clm_total_paid_amt_lgp_mmcare"), col("clm_total_paid_amt_stucvg"),
                    col("clm_total_paid_amt_total_ip"), col("clm_total_paid_amt_total_sgp"), col("clm_total_paid_amt_gtlgp"), col("clm_total_paid_amt_gtsgp"), col("clm_total_paid_amt_gtip"),
                   col("clm_total_paid_amt_total_gtip"), col("clm_total_paid_amt_catastrophic"), col("clm_total_paid_amt_lgp_mmcare"), col("clm_total_paid_amt_stucvg"),
                   col("clm_total_copay_amt_total_ip"),col("clm_total_copay_amt_total_sgp"), col("clm_total_copay_amt_gtlgp"), col("clm_total_copay_amt_gtsgp"), col("clm_total_copay_amt_gtip"),
                   col("clm_total_copay_amt_total_gtip"), col("clm_total_copay_amt_catastrophic"), col("clm_total_copay_amt_lgp_mmcare"), col("clm_total_copay_amt_stucvg"))
                   
                  
                  
   
   val cpayMasterData = cpayMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip","nbrclm_received_catastrophic", "nbrclm_received_lgp_mmcare", "nbrclm_received_stucvg","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare","nbrclm_denied_inntwk_stucvg",
                                "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare","nbrclm_denied_outntwk_stucvg",
                               "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",               
                                 "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",
                                "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp",
                               "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_lgp_mmcare", "nbrclm_paid_outntwk_stucvg",
                                "clm_total_paid_amt_total_ip", "clm_total_paid_amt_total_sgp", "clm_total_paid_amt_gtlgp","clm_total_paid_amt_gtsgp", "clm_total_paid_amt_gtip",
                               "clm_total_paid_amt_total_gtip", "clm_total_paid_amt_catastrophic", "clm_total_paid_amt_lgp_mmcare", "clm_total_paid_amt_stucvg",
                               "clm_total_copay_amt_total_ip","clm_total_copay_amt_total_sgp", "clm_total_copay_amt_gtlgp","clm_total_copay_amt_gtsgp","clm_total_copay_amt_gtip",
                               "clm_total_copay_amt_total_gtip", "clm_total_copay_amt_catastrophic","clm_total_copay_amt_lgp_mmcare","clm_total_copay_amt_stucvg")
   
   val coinSrcPayMaster =  cpayMasterData.alias("parent").join(finalCoinSrcPay.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"),
                   col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"),col("nbrclm_received_catastrophic"), col("nbrclm_received_lgp_mmcare"),
                   col("nbrclm_received_stucvg"), col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"),col("nbrclm_denied_inntwk_gtlgp"),col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"),
                   col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"), col("nbrclm_denied_inntwk_stucvg"), col("nbrclm_denied_outntwk_total_ip"),
                   col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"),col("nbrclm_denied_outntwk_total_gtip"),col("nbrclm_denied_outntwk_catastrophic"),
                   col("nbrclm_denied_outntwk_lgp_mmcare"), col("nbrclm_denied_outntwk_stucvg"), col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"),
                   col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"), col("nbrclm_paid_inntwk_stucvg"),
                   col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"),
                   col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_lgp_mmcare"), col("nbrclm_paid_outntwk_stucvg"),
                   col("clm_total_paid_amt_total_ip"), col("clm_total_paid_amt_total_sgp"), col("clm_total_paid_amt_gtlgp"), col("clm_total_paid_amt_gtsgp"), col("clm_total_paid_amt_gtip"),
                   col("clm_total_paid_amt_total_gtip"), col("clm_total_paid_amt_catastrophic"), col("clm_total_paid_amt_lgp_mmcare"), col("clm_total_paid_amt_stucvg"),
                   col("clm_total_copay_amt_total_ip"),col("clm_total_copay_amt_total_sgp"), col("clm_total_copay_amt_gtlgp"), col("clm_total_copay_amt_gtsgp"), col("clm_total_copay_amt_gtip"),
                   col("clm_total_copay_amt_total_gtip"), col("clm_total_copay_amt_catastrophic"), col("clm_total_copay_amt_lgp_mmcare"), col("clm_total_copay_amt_stucvg"),
                   col("clm_total_coinsrn_amt_total_ip"), col("clm_total_coinsrn_amt_total_sgp"), col("clm_total_coinsrn_amt_gtlgp"), col("clm_total_coinsrn_amt_gtsgp"), col("clm_total_coinsrn_amt_gtip"), 
                   col("clm_total_coinsrn_amt_total_gtip"), col("clm_total_coinsrn_amt_catastrophic"), col("clm_total_coinsrn_amt_lgp_mmcare"), col("clm_total_coinsrn_amt_stucvg"))
                   
                  
                  
   
   val coinSrcPayMasterData = coinSrcPayMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           //.withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
                           .select("health_year","cmpny_cf_cd", "state", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip","nbrclm_received_catastrophic", "nbrclm_received_lgp_mmcare", "nbrclm_received_stucvg","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare","nbrclm_denied_inntwk_stucvg",
                                "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare","nbrclm_denied_outntwk_stucvg",
                               "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",               
                                 "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",
                                "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp",
                               "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_lgp_mmcare", "nbrclm_paid_outntwk_stucvg",
                                "clm_total_paid_amt_total_ip", "clm_total_paid_amt_total_sgp", "clm_total_paid_amt_gtlgp","clm_total_paid_amt_gtsgp", "clm_total_paid_amt_gtip",
                               "clm_total_paid_amt_total_gtip", "clm_total_paid_amt_catastrophic", "clm_total_paid_amt_lgp_mmcare", "clm_total_paid_amt_stucvg",
                               "clm_total_copay_amt_total_ip","clm_total_copay_amt_total_sgp", "clm_total_copay_amt_gtlgp","clm_total_copay_amt_gtsgp","clm_total_copay_amt_gtip",
                               "clm_total_copay_amt_total_gtip", "clm_total_copay_amt_catastrophic","clm_total_copay_amt_lgp_mmcare","clm_total_copay_amt_stucvg",
                               "clm_total_coinsrn_amt_total_ip", "clm_total_coinsrn_amt_total_sgp", "clm_total_coinsrn_amt_gtlgp", "clm_total_coinsrn_amt_gtsgp","clm_total_coinsrn_amt_gtip",
                               "clm_total_coinsrn_amt_total_gtip", "clm_total_coinsrn_amt_catastrophic", "clm_total_coinsrn_amt_lgp_mmcare", "clm_total_coinsrn_amt_stucvg")
   
    val ddctblPayMaster =  coinSrcPayMasterData.alias("parent").join(finalddctblPay.alias("child"),  $"parent.health_year"===$"child.health_year" 
                  && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" , "outer")
                  .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                   $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                   $"child.state".alias("s_state") , col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"),
                   col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"), col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"),col("nbrclm_received_catastrophic"), col("nbrclm_received_lgp_mmcare"),
                   col("nbrclm_received_stucvg"), col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"),col("nbrclm_denied_inntwk_gtlgp"),col("nbrclm_denied_inntwk_gtsgp"), col("nbrclm_denied_inntwk_gtip"),
                   col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_catastrophic"), col("nbrclm_denied_inntwk_lgp_mmcare"), col("nbrclm_denied_inntwk_stucvg"), col("nbrclm_denied_outntwk_total_ip"),
                   col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"), col("nbrclm_denied_outntwk_gtip"),col("nbrclm_denied_outntwk_total_gtip"),col("nbrclm_denied_outntwk_catastrophic"),
                   col("nbrclm_denied_outntwk_lgp_mmcare"), col("nbrclm_denied_outntwk_stucvg"), col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"),
                   col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"), col("nbrclm_paid_inntwk_stucvg"),
                   col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"),
                   col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_lgp_mmcare"), col("nbrclm_paid_outntwk_stucvg"),
                   col("clm_total_paid_amt_total_ip"), col("clm_total_paid_amt_total_sgp"), col("clm_total_paid_amt_gtlgp"), col("clm_total_paid_amt_gtsgp"), col("clm_total_paid_amt_gtip"),
                   col("clm_total_paid_amt_total_gtip"), col("clm_total_paid_amt_catastrophic"), col("clm_total_paid_amt_lgp_mmcare"), col("clm_total_paid_amt_stucvg"),
                   col("clm_total_copay_amt_total_ip"),col("clm_total_copay_amt_total_sgp"), col("clm_total_copay_amt_gtlgp"), col("clm_total_copay_amt_gtsgp"), col("clm_total_copay_amt_gtip"),
                   col("clm_total_copay_amt_total_gtip"), col("clm_total_copay_amt_catastrophic"), col("clm_total_copay_amt_lgp_mmcare"), col("clm_total_copay_amt_stucvg"),
                   col("clm_total_coinsrn_amt_total_ip"), col("clm_total_coinsrn_amt_total_sgp"), col("clm_total_coinsrn_amt_gtlgp"), col("clm_total_coinsrn_amt_gtsgp"), col("clm_total_coinsrn_amt_gtip"), 
                   col("clm_total_coinsrn_amt_total_gtip"), col("clm_total_coinsrn_amt_catastrophic"), col("clm_total_coinsrn_amt_lgp_mmcare"), col("clm_total_coinsrn_amt_stucvg"),
                   col("clm_total_ddctbl_amt_total_ip"), col("clm_total_ddctbl_amt_total_sgp"), col("clm_total_ddctbl_amt_gtlgp"), col("clm_total_ddctbl_amt_gtsgp"), col("clm_total_ddctbl_amt_gtip"),
                   col("clm_total_ddctbl_amt_total_gtip"), col("clm_total_ddctbl_amt_catastrophic"), col("clm_total_ddctbl_amt_lgp_mmcare"), col("clm_total_ddctbl_amt_stucvg"))
                   
                  
                  
   
   val ddctblPayMasterData = ddctblPayMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                              .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                            .withColumn("outoff_exchange", lit("OUTOFF"))
                           .select("outoff_exchange","health_year","cmpny_cf_cd", "state",  "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip","nbrclm_received_catastrophic", "nbrclm_received_lgp_mmcare", "nbrclm_received_stucvg","nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare","nbrclm_denied_inntwk_stucvg",
                                "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare","nbrclm_denied_outntwk_stucvg",
                               "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg",               
                                "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp",
                               "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_lgp_mmcare", "nbrclm_paid_outntwk_stucvg",
                                "clm_total_paid_amt_total_ip", "clm_total_paid_amt_total_sgp", "clm_total_paid_amt_gtlgp","clm_total_paid_amt_gtsgp", "clm_total_paid_amt_gtip",
                               "clm_total_paid_amt_total_gtip", "clm_total_paid_amt_catastrophic", "clm_total_paid_amt_lgp_mmcare", "clm_total_paid_amt_stucvg",
                                "clm_total_copay_amt_total_ip","clm_total_copay_amt_total_sgp", "clm_total_copay_amt_gtlgp","clm_total_copay_amt_gtsgp","clm_total_copay_amt_gtip",
                               "clm_total_copay_amt_total_gtip", "clm_total_copay_amt_catastrophic","clm_total_copay_amt_lgp_mmcare","clm_total_copay_amt_stucvg",
                               "clm_total_coinsrn_amt_total_ip", "clm_total_coinsrn_amt_total_sgp", "clm_total_coinsrn_amt_gtlgp", "clm_total_coinsrn_amt_gtsgp","clm_total_coinsrn_amt_gtip",
                               "clm_total_coinsrn_amt_total_gtip", "clm_total_coinsrn_amt_catastrophic", "clm_total_coinsrn_amt_lgp_mmcare", "clm_total_coinsrn_amt_stucvg",
                               "clm_total_ddctbl_amt_total_ip", "clm_total_ddctbl_amt_total_sgp", "clm_total_ddctbl_amt_gtlgp", "clm_total_ddctbl_amt_gtsgp", "clm_total_ddctbl_amt_gtip",
                               "clm_total_ddctbl_amt_total_gtip", "clm_total_ddctbl_amt_catastrophic", "clm_total_ddctbl_amt_lgp_mmcare", "clm_total_ddctbl_amt_stucvg")                                       
                               
                               
   ddctblPayMasterData                            
                               
   
 }
 
 
}
object PCADX_SCL_NAIC2018_OEXStgTransformationclmPhmcy{
  def main(args: Array[String]) {
  PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
  val oex =  new PCADX_SCL_NAIC2018_OEXStgTransformationclmPhmcy()
  //iex.setyear(args(1))
  oex.sparkInIt()
  }
}