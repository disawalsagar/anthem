package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy_1(val spark: SparkSession) {

  val clmexphmcy = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy(spark)
  /* val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()*/
  
  import spark.implicits._
  //val  mbu_cf_cdvals= dbProperties.getProperty("mbu_Cf_cdVals").split(",").toSeq
  def getPaidInntwk(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
                    naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    var lob_type = "TOTAL INDIVIDUAL CBE"

    val ip_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val nbrclm_paid_inntwk_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_bronze_ip"))

    val nbrclm_paid_inntwk_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_silver_ip"))

    val brSil = nbrclm_paid_inntwk_bronze_ip.alias("parent").join(nbrclm_paid_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip")

    val nbrclm_paid_inntwk_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gold_ip"))

    val gldMaster = brSilData.alias("parent").join(nbrclm_paid_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip")

    val nbrclm_paid_inntwk_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip")

    val tot_ip = nbrclm_paid_inntwk_bronze_ip.union(nbrclm_paid_inntwk_silver_ip.union(nbrclm_paid_inntwk_gold_ip.union(nbrclm_paid_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_inntwk_bronze_ip"))

    val nbrclm_paid_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_inntwk_bronze_ip").alias("nbrclm_paid_inntwk_total_ip"))

    val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"))

    val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"

    val sgp_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val nbrclm_paid_inntwk_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_bronze_sgp"))

    val BrzsgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_inntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"))

    val BrzsgpMasterData = BrzsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp")

    val nbrclm_paid_inntwk_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_silver_sgp"))

    val silsgpMaster = BrzsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"))

    val silsgpMasterData = silsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp")

    val nbrclm_paid_inntwk_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gold_sgp"))

    val gldsgpMaster = silsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"))

    val gldsgpMasterData = gldsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp")

    val nbrclm_paid_inntwk_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_platinum_sgp"))

    val pltsgpMaster = gldsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"))

    val pltsgpMasterData = pltsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp")
    val tot_sgp = nbrclm_paid_inntwk_bronze_sgp.union(nbrclm_paid_inntwk_silver_sgp.union(nbrclm_paid_inntwk_gold_sgp.union(nbrclm_paid_inntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_inntwk_bronze_sgp"))

    val nbrclm_paid_inntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_inntwk_bronze_sgp").alias("nbrclm_paid_inntwk_total_sgp"))

    val sgpMaster = pltsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"))

    val sgpMasterData = sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp")

    lob_type = ""
    var islgp = true
    val gt_lgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, lob_type, islgp)

    val nbrclm_paid_inntwk_gtlgp = gt_lgp_df.filter($"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gtlgp"))

    val gtlgpMaster = sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gt_sgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type, islgp)

    val nbrclm_paid_inntwk_gtsgp = gt_sgp_df.filter($"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp")
    lob_type = "TOTAL INDIVIDUAL CBE"
    val gt_ip_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type, islgp)

    val nbrclm_paid_inntwk_gtip = gt_ip_df.filter($"inn_cd".isin(clminn_cd: _*))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp", "nbrclm_paid_inntwk_gtip")

    val tot_gt = nbrclm_paid_inntwk_gtip.union(nbrclm_paid_inntwk_gtsgp.union(nbrclm_paid_inntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_paid_inntwk_gtip")

    val nbrclm_paid_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_paid_inntwk_gtip").alias("nbrclm_paid_inntwk_total_gtip"))

    val gtMaster = gtipMasterData.alias("parent").join(nbrclm_paid_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"))

    val gtMasterData = gtMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp", "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip")

    val nbrclm_paid_inntwk_catastrophic = naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") && $"inn_cd".isin(clminn_cd: _*) &&
      $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_catastrophic"))

    val catMaster = gtMasterData.alias("parent").join(nbrclm_paid_inntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp", "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic")

    val nbrclm_paid_inntwk_lgp_mmcare = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) && $"inn_cd".isin(clminn_cd: _*) &&
      $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_lgp_mmcare"))
    val lgpMaster = catMasterData.alias("parent").join(nbrclm_paid_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"))

    val lgpMasterData = lgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp", "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare")

    val nbrclm_paid_inntwk_stucvg = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) && $"inn_cd".isin(clminn_cd: _*) &&
        $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_stucvg"))
    val stucvgMaster = lgpMasterData.alias("parent").join(nbrclm_paid_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
        col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"), col("nbrclm_paid_inntwk_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
        "nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp", "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg")

    stucvgMasterData
  }
  def getPaidOutntwk(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
                     naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    var lob_type = "TOTAL INDIVIDUAL CBE"

    val ip_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val nbrclm_paid_outntwk_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_bronze_ip"))

    val nbrclm_paid_outntwk_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_silver_ip"))

    val brSil = nbrclm_paid_outntwk_bronze_ip.alias("parent").join(nbrclm_paid_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip")

    val nbrclm_paid_outntwk_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gold_ip"))

    val gldMaster = brSilData.alias("parent").join(nbrclm_paid_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip")

    val nbrclm_paid_outntwk_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip")

    val tot_ip = nbrclm_paid_outntwk_bronze_ip.union(nbrclm_paid_outntwk_silver_ip.union(nbrclm_paid_outntwk_gold_ip.union(nbrclm_paid_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_outntwk_bronze_ip"))

    val nbrclm_paid_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_outntwk_bronze_ip").alias("nbrclm_paid_outntwk_total_ip"))

    val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"))

    val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"

    val sgp_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val nbrclm_paid_outntwk_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_bronze_sgp"))

    val BrzsgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_outntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"))

    val BrzsgpMasterData = BrzsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp")

    val nbrclm_paid_outntwk_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_silver_sgp"))

    val silsgpMaster = BrzsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"))

    val silsgpMasterData = silsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp")

    val nbrclm_paid_outntwk_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gold_sgp"))

    val gldsgpMaster = silsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"))

    val gldsgpMasterData = gldsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp")

    val nbrclm_paid_outntwk_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_platinum_sgp"))

    val pltsgpMaster = gldsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"))

    val pltsgpMasterData = pltsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp")
    val tot_sgp = nbrclm_paid_outntwk_bronze_sgp.union(nbrclm_paid_outntwk_silver_sgp.union(nbrclm_paid_outntwk_gold_sgp.union(nbrclm_paid_outntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_outntwk_bronze_sgp"))

    val nbrclm_paid_outntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_outntwk_bronze_sgp").alias("nbrclm_paid_outntwk_total_sgp"))

    val sgpMaster = pltsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"))

    val sgpMasterData = sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp")

    lob_type = ""
    var islgp = true
    val gt_lgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, lob_type, islgp)

    val nbrclm_paid_outntwk_gtlgp = gt_lgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gtlgp"))

    val gtlgpMaster = sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gt_sgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type, islgp)

    val nbrclm_paid_outntwk_gtsgp = gt_sgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp")
    lob_type = "TOTAL INDIVIDUAL CBE"
    val gt_ip_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type, islgp)

    val nbrclm_paid_outntwk_gtip = gt_ip_df.filter((!$"inn_cd".isin(clminn_cd: _*)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp", "nbrclm_paid_outntwk_gtip")

    val tot_gt = nbrclm_paid_outntwk_gtip.union(nbrclm_paid_outntwk_gtsgp.union(nbrclm_paid_outntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_paid_outntwk_gtip")

    val nbrclm_paid_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_paid_outntwk_gtip").alias("nbrclm_paid_outntwk_total_gtip"))

    val gtMaster = gtipMasterData.alias("parent").join(nbrclm_paid_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"), col("nbrclm_paid_outntwk_total_gtip"))

    val gtMasterData = gtMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp", "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip")

    val nbrclm_paid_outntwk_catastrophic = naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") && (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_catastrophic"))

    val catMaster = gtMasterData.alias("parent").join(nbrclm_paid_outntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"), col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp", "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic")

    val nbrclm_paid_outntwk_lgp_mmcare = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) && (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_lgp_mmcare"))
   
    val lgpMaster = catMasterData.alias("parent").join(nbrclm_paid_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"), col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_lgp_mmcare"))

    val lgpMasterData = lgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp", "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_lgp_mmcare")

    val nbrclm_paid_outntwk_stucvg = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) && (!$"inn_cd".isin(clminn_cd: _*)) &&
        $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_stucvg"))

    val stucvgMaster = lgpMasterData.alias("parent").join(nbrclm_paid_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
        col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"), col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_lgp_mmcare"), col("nbrclm_paid_outntwk_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
        "nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp", "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_lgp_mmcare", "nbrclm_paid_outntwk_stucvg")

    stucvgMasterData
  }
  
  def getPaidInntwkBetweenDays(start_day: Int, end_day: Int, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
                               naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {
   
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val colVal = start_day.toString + "to" + end_day
    val fend_day = end_day + 1
    val ip_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val nbrclm_paid_inntwk_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_inntwk_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_silver_ip"))

    val brSil = nbrclm_paid_inntwk_bronze_ip.alias("parent").join(nbrclm_paid_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip")

    val nbrclm_paid_inntwk_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gold_ip"))

    val gldMaster = brSilData.alias("parent").join(nbrclm_paid_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip")

    val nbrclm_paid_inntwk_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_paid_inntwk_bronze_ip.union(nbrclm_paid_inntwk_silver_ip.union(nbrclm_paid_inntwk_gold_ip.union(nbrclm_paid_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_ip").alias("nbrclm_paid_inntwk_" + colVal + "_total_ip"))

    val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"))

    val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"

    val sgp_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val nbrclm_paid_inntwk_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"))

    val BrzsgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_inntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"))

    val BrzsgpMasterData = BrzsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp")

    val nbrclm_paid_inntwk_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"))

    val silsgpMaster = BrzsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"))

    val silsgpMasterData = silsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp")

    val nbrclm_paid_inntwk_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"))

    val gldsgpMaster = silsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"))

    val gldsgpMasterData = gldsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp")

    val nbrclm_paid_inntwk_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"))

    val pltsgpMaster = gldsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"))

    val pltsgpMasterData = pltsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp")
    val tot_sgp = nbrclm_paid_inntwk_bronze_sgp.union(nbrclm_paid_inntwk_silver_sgp.union(nbrclm_paid_inntwk_gold_sgp.union(nbrclm_paid_inntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_paid_inntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp").alias("nbrclm_paid_inntwk_" + colVal + "_total_sgp"))

    val sgpMaster = pltsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"))

    val sgpMasterData = sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp")

    lob_type = ""
    var islgp = true
    val gt_lgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, lob_type, islgp)

    val nbrclm_paid_inntwk_gtlgp = gt_lgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gtlgp"))

    val gtlgpMaster = sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gt_sgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type, islgp)

    val nbrclm_paid_inntwk_gtsgp = gt_sgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp")
    lob_type = "TOTAL INDIVIDUAL CBE"
    val gt_ip_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type, islgp)

    val nbrclm_paid_inntwk_gtip = gt_ip_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip")

    val tot_gt = nbrclm_paid_inntwk_gtip.union(nbrclm_paid_inntwk_gtsgp.union(nbrclm_paid_inntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_inntwk_" + colVal + "_gtip"))

    val nbrclm_paid_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("nbrclm_paid_inntwk_" + colVal + "_gtip").alias("nbrclm_paid_inntwk_" + colVal + "_total_gtip"))

    val gtMaster = gtipMasterData.alias("parent").join(nbrclm_paid_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"))

    val gtMasterData = gtMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip")

    val nbrclm_paid_inntwk_catastrophic = naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") && $"inn_cd".isin(clminn_cd: _*) &&
      $"in_exchange".isNull &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_catastrophic"))

    val catMaster = gtMasterData.alias("parent").join(nbrclm_paid_inntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip", "nbrclm_paid_inntwk_" + colVal + "_catastrophic")

    val nbrclm_paid_inntwk_lgp_mmcare = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) && $"inn_cd".isin(clminn_cd: _*) &&
      $"in_exchange".isNull &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare"))
    val lgpMaster = catMasterData.alias("parent").join(nbrclm_paid_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare"))

    val lgpMasterData = lgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip", "nbrclm_paid_inntwk_" + colVal + "_catastrophic", "nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare")

    val nbrclm_paid_inntwk_stucvg = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) && $"inn_cd".isin(clminn_cd: _*) &&
        $"in_exchange".isNull &&
        $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_stucvg"))
    val stucvgMaster = lgpMasterData.alias("parent").join(nbrclm_paid_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_paid_inntwk_" + colVal + "_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip", "nbrclm_paid_inntwk_" + colVal + "_catastrophic", "nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare", "nbrclm_paid_inntwk_" + colVal + "_stucvg")

    stucvgMasterData
  }
  def getPaidOutntwkBetweenDays(start_day: Int, end_day: Int, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
                                naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val colVal = start_day.toString + "to" + end_day
    val fend_day = end_day + 1
    val ip_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val nbrclm_paid_outntwk_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_outntwk_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_silver_ip"))

    val brSil = nbrclm_paid_outntwk_bronze_ip.alias("parent").join(nbrclm_paid_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip")

    val nbrclm_paid_outntwk_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gold_ip"))

    val gldMaster = brSilData.alias("parent").join(nbrclm_paid_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip")

    val nbrclm_paid_outntwk_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_paid_outntwk_bronze_ip.union(nbrclm_paid_outntwk_silver_ip.union(nbrclm_paid_outntwk_gold_ip.union(nbrclm_paid_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_ip").alias("nbrclm_paid_outntwk_" + colVal + "_total_ip"))

    val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"))

    val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"

    val sgp_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val nbrclm_paid_outntwk_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"))

    val BrzsgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_outntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"))

    val BrzsgpMasterData = BrzsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp")

    val nbrclm_paid_outntwk_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"))

    val silsgpMaster = BrzsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"))

    val silsgpMasterData = silsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp")

    val nbrclm_paid_outntwk_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"))

    val gldsgpMaster = silsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"))

    val gldsgpMasterData = gldsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp")

    val nbrclm_paid_outntwk_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"))

    val pltsgpMaster = gldsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"))

    val pltsgpMasterData = pltsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp")
    val tot_sgp = nbrclm_paid_outntwk_bronze_sgp.union(nbrclm_paid_outntwk_silver_sgp.union(nbrclm_paid_outntwk_gold_sgp.union(nbrclm_paid_outntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_paid_outntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp").alias("nbrclm_paid_outntwk_" + colVal + "_total_sgp"))

    val sgpMaster = pltsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"))

    val sgpMasterData = sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp")

    lob_type = ""
    var islgp = true
    val gt_lgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, lob_type, islgp)

    val nbrclm_paid_outntwk_gtlgp = gt_lgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gtlgp"))

    val gtlgpMaster = sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gt_sgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type, islgp)

    val nbrclm_paid_outntwk_gtsgp = gt_sgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp")
    lob_type = "TOTAL INDIVIDUAL CBE"
    val gt_ip_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type, islgp)

    val nbrclm_paid_outntwk_gtip = gt_ip_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip")

    val tot_gt = nbrclm_paid_outntwk_gtip.union(nbrclm_paid_outntwk_gtsgp.union(nbrclm_paid_outntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_outntwk_" + colVal + "_gtip"))

    val nbrclm_paid_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("nbrclm_paid_outntwk_" + colVal + "_gtip").alias("nbrclm_paid_outntwk_" + colVal + "_total_gtip"))

    val gtMaster = gtipMasterData.alias("parent").join(nbrclm_paid_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"))

    val gtMasterData = gtMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip")

    val nbrclm_paid_outntwk_catastrophic = naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") && (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"in_exchange".isNull &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_catastrophic"))

    val catMaster = gtMasterData.alias("parent").join(nbrclm_paid_outntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip", "nbrclm_paid_outntwk_" + colVal + "_catastrophic")

    val nbrclm_paid_outntwk_lgp_mmcare = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) && (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"in_exchange".isNull &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare"))
    val lgpMaster = catMasterData.alias("parent").join(nbrclm_paid_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare"))

    val lgpMasterData = lgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip", "nbrclm_paid_outntwk_" + colVal + "_catastrophic", "nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare")

    val nbrclm_paid_outntwk_stucvg = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter( //($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"mbu_cf_cd".isin(mbu_cf_cdvals: _*) && (!$"inn_cd".isin(clminn_cd: _*)) &&
        $"in_exchange".isNull &&
        $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_stucvg"))
    val stucvgMaster = lgpMasterData.alias("parent").join(nbrclm_paid_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_paid_outntwk_" + colVal + "_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip", "nbrclm_paid_outntwk_" + colVal + "_catastrophic", "nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare", "nbrclm_paid_outntwk_" + colVal + "_stucvg")

    stucvgMasterData
  }
  def getPaidInntwk_90(end_year: String, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
                       naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val colVal = "90"
    val strt_day: Int = 91
    val ip_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_inntwk_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_inntwk_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_silver_ip"))

    val brSil = nbrclm_paid_inntwk_bronze_ip.alias("parent").join(nbrclm_paid_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip")

    val nbrclm_paid_inntwk_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gold_ip"))

    val gldMaster = brSilData.alias("parent").join(nbrclm_paid_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip")

    val nbrclm_paid_inntwk_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_paid_inntwk_bronze_ip.union(nbrclm_paid_inntwk_silver_ip.union(nbrclm_paid_inntwk_gold_ip.union(nbrclm_paid_inntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_ip").alias("nbrclm_paid_inntwk_" + colVal + "_total_ip"))

    val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"))

    val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"

    val sgp_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_inntwk_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"))

    val BrzsgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_inntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"))

    val BrzsgpMasterData = BrzsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp")

    val nbrclm_paid_inntwk_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"))

    val silsgpMaster = BrzsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"))

    val silsgpMasterData = silsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp")

    val nbrclm_paid_inntwk_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"))

    val gldsgpMaster = silsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"))

    val gldsgpMasterData = gldsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp")

    val nbrclm_paid_inntwk_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"))

    val pltsgpMaster = gldsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"))

    val pltsgpMasterData = pltsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp")
    val tot_sgp = nbrclm_paid_inntwk_bronze_sgp.union(nbrclm_paid_inntwk_silver_sgp.union(nbrclm_paid_inntwk_gold_sgp.union(nbrclm_paid_inntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_paid_inntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp").alias("nbrclm_paid_inntwk_" + colVal + "_total_sgp"))

    val sgpMaster = pltsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"))

    val sgpMasterData = sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp")

    lob_type = ""
    var islgp = true
    val gt_lgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_inntwk_gtlgp = gt_lgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gtlgp"))

    val gtlgpMaster = sgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gt_sgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_inntwk_gtsgp = gt_sgp_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp")
    lob_type = "TOTAL INDIVIDUAL CBE"
    val gt_ip_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_inntwk_gtip = gt_ip_df.filter($"inn_cd".isin(clminn_cd: _*) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip")

    val tot_gt = nbrclm_paid_inntwk_gtip.union(nbrclm_paid_inntwk_gtsgp.union(nbrclm_paid_inntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_inntwk_" + colVal + "_gtip"))

    val nbrclm_paid_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("nbrclm_paid_inntwk_" + colVal + "_gtip").alias("nbrclm_paid_inntwk_" + colVal + "_total_gtip"))

    val gtMaster = gtipMasterData.alias("parent").join(nbrclm_paid_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"))

    val gtMasterData = gtMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip")

    val nbrclm_paid_inntwk_catastrophic = naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk.withColumn("constant_date", lit(end_year))
      .filter($"naic_prod_desc".like("%CATASTROPHIC%") && $"inn_cd".isin(clminn_cd: _*) &&
        $"in_exchange".isNull &&
        $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_catastrophic"))

    val catMaster = gtMasterData.alias("parent").join(nbrclm_paid_inntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip", "nbrclm_paid_inntwk_" + colVal + "_catastrophic")

    val nbrclm_paid_inntwk_lgp_mmcare = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.withColumn("constant_date", lit(end_year))
      .filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
        (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) && $"inn_cd".isin(clminn_cd: _*) &&
        $"in_exchange".isNull &&
        $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date")).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare"))
    val lgpMaster = catMasterData.alias("parent").join(nbrclm_paid_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare"))

    val lgpMasterData = lgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip", "nbrclm_paid_inntwk_" + colVal + "_catastrophic", "nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare")

    val nbrclm_paid_inntwk_stucvg = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.withColumn("constant_date", lit(end_year))
      .filter($"mbu_cf_cd".isin(mbu_cf_cdvals: _*) && $"inn_cd".isin(clminn_cd: _*) &&
        $"in_exchange".isNull &&
        $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_stucvg"))
    val stucvgMaster = lgpMasterData.alias("parent").join(nbrclm_paid_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_paid_inntwk_" + colVal + "_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
        "nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip", "nbrclm_paid_inntwk_" + colVal + "_catastrophic", "nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare", "nbrclm_paid_inntwk_" + colVal + "_stucvg")

    stucvgMasterData
  }
  def getPaidOutntwk_90(end_year: String, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
                        naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    var lob_type = "TOTAL INDIVIDUAL CBE"
    val colVal = "90"
    val strt_day: Int = 91
    val ip_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_outntwk_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_outntwk_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_silver_ip"))

    val brSil = nbrclm_paid_outntwk_bronze_ip.alias("parent").join(nbrclm_paid_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip")

    val nbrclm_paid_outntwk_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gold_ip"))

    val gldMaster = brSilData.alias("parent").join(nbrclm_paid_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip")

    val nbrclm_paid_outntwk_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip")

    val tot_ip = nbrclm_paid_outntwk_bronze_ip.union(nbrclm_paid_outntwk_silver_ip.union(nbrclm_paid_outntwk_gold_ip.union(nbrclm_paid_outntwk_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"))

    val nbrclm_paid_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_ip").alias("nbrclm_paid_outntwk_" + colVal + "_total_ip"))

    val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"))

    val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"

    val sgp_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_outntwk_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"))

    val BrzsgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_outntwk_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"))

    val BrzsgpMasterData = BrzsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp")

    val nbrclm_paid_outntwk_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"))

    val silsgpMaster = BrzsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"))

    val silsgpMasterData = silsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp")

    val nbrclm_paid_outntwk_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"))

    val gldsgpMaster = silsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"))

    val gldsgpMasterData = gldsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp")

    val nbrclm_paid_outntwk_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"))

    val pltsgpMaster = gldsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"))

    val pltsgpMasterData = pltsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp")
    val tot_sgp = nbrclm_paid_outntwk_bronze_sgp.union(nbrclm_paid_outntwk_silver_sgp.union(nbrclm_paid_outntwk_gold_sgp.union(nbrclm_paid_outntwk_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"))

    val nbrclm_paid_outntwk_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp").alias("nbrclm_paid_outntwk_" + colVal + "_total_sgp"))

    val sgpMaster = pltsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"))

    val sgpMasterData = sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp")

    lob_type = ""
    var islgp = true
    val gt_lgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_outntwk_gtlgp = gt_lgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gtlgp"))

    val gtlgpMaster = sgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp")
    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gt_sgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_outntwk_gtsgp = gt_sgp_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gtsgp"))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp")
    lob_type = "TOTAL INDIVIDUAL CBE"
    val gt_ip_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type, islgp).withColumn("constant_date", lit(end_year))

    val nbrclm_paid_outntwk_gtip = gt_ip_df.filter((!$"inn_cd".isin(clminn_cd: _*)) &&
      $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gtip"))

    val gtipMaster = gtsgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip")

    val tot_gt = nbrclm_paid_outntwk_gtip.union(nbrclm_paid_outntwk_gtsgp.union(nbrclm_paid_outntwk_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_outntwk_" + colVal + "_gtip"))

    val nbrclm_paid_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("nbrclm_paid_outntwk_" + colVal + "_gtip").alias("nbrclm_paid_outntwk_" + colVal + "_total_gtip"))

    val gtMaster = gtipMasterData.alias("parent").join(nbrclm_paid_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"))

    val gtMasterData = gtMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip")

    val nbrclm_paid_outntwk_catastrophic = naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk.withColumn("constant_date", lit(end_year))
      .filter($"naic_prod_desc".like("%CATASTROPHIC%") && (!$"inn_cd".isin(clminn_cd: _*)) &&
        $"in_exchange".isNull &&
        $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_catastrophic"))

    val catMaster = gtMasterData.alias("parent").join(nbrclm_paid_outntwk_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip", "nbrclm_paid_outntwk_" + colVal + "_catastrophic")

    val nbrclm_paid_outntwk_lgp_mmcare = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.withColumn("constant_date", lit(end_year))
      .filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
        (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) && (!$"inn_cd".isin(clminn_cd: _*)) &&
        $"in_exchange".isNull &&
        $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date")).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare"))
    val lgpMaster = catMasterData.alias("parent").join(nbrclm_paid_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare"))

    val lgpMasterData = lgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip", "nbrclm_paid_outntwk_" + colVal + "_catastrophic", "nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare")

    val nbrclm_paid_outntwk_stucvg = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.withColumn("constant_date", lit(end_year))
      .filter($"mbu_cf_cd".isin(mbu_cf_cdvals: _*) && (!$"inn_cd".isin(clminn_cd: _*)) &&
        $"in_exchange".isNull &&
        $"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_stucvg"))
    val stucvgMaster = lgpMasterData.alias("parent").join(nbrclm_paid_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
        col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_paid_outntwk_" + colVal + "_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
        "nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip", "nbrclm_paid_outntwk_" + colVal + "_catastrophic", "nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare", "nbrclm_paid_outntwk_" + colVal + "_stucvg")

    stucvgMasterData
  }
  def getamtData(paid_col: String, typeOfPay: String, naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk: DataFrame,
                 naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"

    val ip_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)

    val clm_total_amt_bronze_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("04"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_bronze_ip")).withColumn("clm_total_" + typeOfPay + "_amt_bronze_ip", col("clm_total_" + typeOfPay + "_amt_bronze_ip").cast(IntegerType))

    val clm_total_amt_silver_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("03"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_silver_ip")).withColumn("clm_total_" + typeOfPay + "_amt_silver_ip", col("clm_total_" + typeOfPay + "_amt_silver_ip").cast(IntegerType))

    val brSil = clm_total_amt_bronze_ip.alias("parent").join(clm_total_amt_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"))

    val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip")

    val clm_total_amt_gold_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("02"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_gold_ip")).withColumn("clm_total_" + typeOfPay + "_amt_gold_ip", col("clm_total_" + typeOfPay + "_amt_gold_ip").cast(IntegerType))

    val gldMaster = brSilData.alias("parent").join(clm_total_amt_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip")

    val clm_total_amt_platinum_ip = ip_df.filter($"exchng_metl_type_cd".equalTo("01"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_platinum_ip")).withColumn("clm_total_" + typeOfPay + "_amt_platinum_ip", col("clm_total_" + typeOfPay + "_amt_platinum_ip").cast(IntegerType))

    val pltMaster = gldMasterData.alias("parent").join(clm_total_amt_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip")

    val tot_ip = clm_total_amt_bronze_ip.union(clm_total_amt_silver_ip.union(clm_total_amt_gold_ip.union(clm_total_amt_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("clm_total_" + typeOfPay + "_amt_bronze_ip"))

    val clm_total_amt_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("clm_total_" + typeOfPay + "_amt_bronze_ip").alias("clm_total_" + typeOfPay + "_amt_total_ip"))

    val ipMaster = pltMasterData.alias("parent").join(clm_total_amt_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"))

    val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"

    val sgp_df = clmexphmcy.getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type)

    val clm_total_amt_bronze_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("04"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_bronze_sgp")).withColumn("clm_total_" + typeOfPay + "_amt_bronze_sgp", col("clm_total_" + typeOfPay + "_amt_bronze_sgp").cast(IntegerType))

    val BrzsgpMaster = ipMasterData.alias("parent").join(clm_total_amt_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"))

    val BrzsgpMasterData = BrzsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp")

    val clm_total_amt_silver_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("03"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_silver_sgp")).withColumn("clm_total_" + typeOfPay + "_amt_silver_sgp", col("clm_total_" + typeOfPay + "_amt_silver_sgp").cast(IntegerType))

    val silsgpMaster = BrzsgpMasterData.alias("parent").join(clm_total_amt_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"))

    val silsgpMasterData = silsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp")

    val clm_total_amt_gold_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("02"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_gold_sgp")).withColumn("clm_total_" + typeOfPay + "_amt_gold_sgp", col("clm_total_" + typeOfPay + "_amt_gold_sgp").cast(IntegerType))

    val gldsgpMaster = silsgpMasterData.alias("parent").join(clm_total_amt_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"))

    val gldsgpMasterData = gldsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp")
    val clm_total_amt_platinum_sgp = sgp_df.filter($"exchng_metl_type_cd".equalTo("01"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_platinum_sgp")).withColumn("clm_total_" + typeOfPay + "_amt_platinum_sgp", col("clm_total_" + typeOfPay + "_amt_platinum_sgp").cast(IntegerType))

    val pltsgpMaster = gldsgpMasterData.alias("parent").join(clm_total_amt_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"))

    val pltsgpMasterData = pltsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp")

    val tot_sgp = clm_total_amt_bronze_sgp.union(clm_total_amt_silver_sgp.union(clm_total_amt_gold_sgp.union(clm_total_amt_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", col("clm_total_" + typeOfPay + "_amt_bronze_sgp"))

    val clm_total_amt_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("clm_total_" + typeOfPay + "_amt_bronze_sgp").alias("clm_total_" + typeOfPay + "_amt_total_sgp"))

    val sgpMaster = pltsgpMasterData.alias("parent").join(clm_total_amt_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"))

    val sgpMasterData = sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp")

    lob_type = ""
    var islgp = true
    val gt_lgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk, lob_type, islgp)

    val clm_total_amt_gtlgp = gt_lgp_df.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_gtlgp")).withColumn("clm_total_" + typeOfPay + "_amt_gtlgp", col("clm_total_" + typeOfPay + "_amt_gtlgp").cast(IntegerType))

    val gtlgpMaster = sgpMasterData.alias("parent").join(clm_total_amt_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"), col("clm_total_" + typeOfPay + "_amt_gtlgp"))

    val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp", "clm_total_" + typeOfPay + "_amt_gtlgp")

    lob_type = "TOTAL SMALL GROUP CBE"
    islgp = false
    val gt_sgp_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_sgp_wrk, lob_type, islgp)

    val clm_total_amt_gtsgp = gt_sgp_df.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_gtsgp")).withColumn("clm_total_" + typeOfPay + "_amt_gtsgp", col("clm_total_" + typeOfPay + "_amt_gtsgp").cast(IntegerType))

    val gtsgpMaster = gtlgpMasterData.alias("parent").join(clm_total_amt_gtsgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"), col("clm_total_" + typeOfPay + "_amt_gtlgp"), col("clm_total_" + typeOfPay + "_amt_gtsgp"))

    val gtsgpMasterData = gtsgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp", "clm_total_" + typeOfPay + "_amt_gtlgp", "clm_total_" + typeOfPay + "_amt_gtsgp")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val gt_ip_df = clmexphmcy.getGtData(naic2018_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type, islgp)

    val clm_total_amt_gtip = gt_ip_df.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_gtip")).withColumn("clm_total_" + typeOfPay + "_amt_gtip", col("clm_total_" + typeOfPay + "_amt_gtip").cast(IntegerType))

    val gtipMaster = gtsgpMasterData.alias("parent").join(clm_total_amt_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"), col("clm_total_" + typeOfPay + "_amt_gtlgp"), col("clm_total_" + typeOfPay + "_amt_gtsgp"), col("clm_total_" + typeOfPay + "_amt_gtip"))

    val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp", "clm_total_" + typeOfPay + "_amt_gtlgp", "clm_total_" + typeOfPay + "_amt_gtsgp", "clm_total_" + typeOfPay + "_amt_gtip")

    val tot_gt = clm_total_amt_gtip.union(clm_total_amt_gtsgp.union(clm_total_amt_gtlgp)).select($"health_year", $"cmpny_cf_cd", $"state", col("clm_total_" + typeOfPay + "_amt_gtip"))
    val clm_total_amt_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("clm_total_" + typeOfPay + "_amt_gtip").alias("clm_total_" + typeOfPay + "_amt_total_gtip"))
    val gttotMaster = gtipMasterData.alias("parent").join(clm_total_amt_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"), col("clm_total_" + typeOfPay + "_amt_gtlgp"), col("clm_total_" + typeOfPay + "_amt_gtsgp"), col("clm_total_" + typeOfPay + "_amt_gtip"), col("clm_total_" + typeOfPay + "_amt_total_gtip"))

    val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp", "clm_total_" + typeOfPay + "_amt_gtlgp", "clm_total_" + typeOfPay + "_amt_gtsgp", "clm_total_" + typeOfPay + "_amt_gtip", "clm_total_" + typeOfPay + "_amt_total_gtip")

    val clm_total_amt_catastrophic = naic2018_mcas_hlthex_clmexphmcy_paid_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%")
      && $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_catastrophic")).withColumn("clm_total_" + typeOfPay + "_amt_catastrophic", col("clm_total_" + typeOfPay + "_amt_catastrophic").cast(IntegerType))

    val catMaster = gttotMasterData.alias("parent").join(clm_total_amt_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"), col("clm_total_" + typeOfPay + "_amt_gtlgp"), col("clm_total_" + typeOfPay + "_amt_gtsgp"), col("clm_total_" + typeOfPay + "_amt_gtip"), col("clm_total_" + typeOfPay + "_amt_total_gtip"), col("clm_total_" + typeOfPay + "_amt_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp", "clm_total_" + typeOfPay + "_amt_gtlgp", "clm_total_" + typeOfPay + "_amt_gtsgp", "clm_total_" + typeOfPay + "_amt_gtip", "clm_total_" + typeOfPay + "_amt_total_gtip", "clm_total_" + typeOfPay + "_amt_catastrophic")

    val clm_tot_amt_lgp_mmcare = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter(($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      (!$"mbu_cf_cd".isin(mbu_cf_cdvals: _*)) && $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_lgp_mmcare")).withColumn("clm_total_" + typeOfPay + "_amt_lgp_mmcare", col("clm_total_" + typeOfPay + "_amt_lgp_mmcare").cast(IntegerType))

    val lgpmmcareMaster = catMasterData.alias("parent").join(clm_tot_amt_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"), col("clm_total_" + typeOfPay + "_amt_gtlgp"), col("clm_total_" + typeOfPay + "_amt_gtsgp"), col("clm_total_" + typeOfPay + "_amt_gtip"), col("clm_total_" + typeOfPay + "_amt_total_gtip"), col("clm_total_" + typeOfPay + "_amt_catastrophic"), col("clm_total_" + typeOfPay + "_amt_lgp_mmcare"))

    val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp", "clm_total_" + typeOfPay + "_amt_gtlgp", "clm_total_" + typeOfPay + "_amt_gtsgp", "clm_total_" + typeOfPay + "_amt_gtip", "clm_total_" + typeOfPay + "_amt_total_gtip", "clm_total_" + typeOfPay + "_amt_catastrophic", "clm_total_" + typeOfPay + "_amt_lgp_mmcare")
  
    val clm_tot_amt_stucvg = naic2018_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter($"mbu_cf_cd".isin(mbu_cf_cdvals: _*) && $"in_exchange".isNull).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_stucvg")).withColumn("clm_total_" + typeOfPay + "_amt_stucvg", col("clm_total_" + typeOfPay + "_amt_stucvg").cast(IntegerType))

    val stucvgMaster = lgpmmcareMasterData.alias("parent").join(clm_tot_amt_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
        col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"), col("clm_total_" + typeOfPay + "_amt_gtlgp"), col("clm_total_" + typeOfPay + "_amt_gtsgp"), col("clm_total_" + typeOfPay + "_amt_gtip"), col("clm_total_" + typeOfPay + "_amt_total_gtip"), col("clm_total_" + typeOfPay + "_amt_catastrophic"), col("clm_total_" + typeOfPay + "_amt_lgp_mmcare"), col("clm_total_" + typeOfPay + "_amt_stucvg"))

    val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
        "clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp", "clm_total_" + typeOfPay + "_amt_gtlgp", "clm_total_" + typeOfPay + "_amt_gtsgp", "clm_total_" + typeOfPay + "_amt_gtip", "clm_total_" + typeOfPay + "_amt_total_gtip", "clm_total_" + typeOfPay + "_amt_catastrophic", "clm_total_" + typeOfPay + "_amt_lgp_mmcare", "clm_total_" + typeOfPay + "_amt_stucvg")

    stucvgMasterData
  }
}