  package gen
  import java.util.Properties
  import org.apache.log4j.PropertyConfigurator
  import org.apache.spark.sql.SparkSession
  import org.apache.spark
  import org.apache.spark.SparkConf
  import org.apache.spark.SparkContext._
  
  import org.apache.spark.SparkContext
  import org.apache.spark.sql.SQLContext
  import org.apache.spark.sql.SparkSession
  import org.apache.spark.sql.SaveMode
  
  import org.apache.spark.sql.functions.udf
  import java.sql.Timestamp
  import org.slf4j.{ Logger, LoggerFactory }
  import scala.io.Source
  import java.io._
  import java.util.Properties
  import java.io.FileInputStream
  import java.io.IOException;
  
  import org.apache.spark.sql.functions._
  import org.apache.spark.sql.types._
  import org.apache.spark.sql.DataFrame
  import org.apache.spark.sql.Row
  
  import org.apache.hadoop.fs._;
  import java.time.LocalDateTime
  import java.time.format.DateTimeFormatter
  import java.time.LocalDate
  import java.time.temporal.ChronoUnit
  
  class PCADX_SCL_NAIC2018_UnicareStgTransformationclmexphmcy_1(val spark: SparkSession) {
  
  	val clmexphmcy = new PCADX_SCL_NAIC2018_OEXStgTransformationclmexphmcy(spark)
  	
  import spark.implicits._
  
  			def getPaidInntwk(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame,
  					naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {
  							val clminn_cd = Seq("IN", "PAR")
  									val clmLineAdjdctn = Seq("DND", "DNDZB")
  									var lob_type = "TOTAL INDIVIDUAL CBE"
  
  									val nbrclm_paid_inntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_bronze_ip"))
  
  									val nbrclm_paid_inntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_silver_ip"))
  
  									val brSil = nbrclm_paid_inntwk_bronze_ip.alias("parent").join(nbrclm_paid_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  											$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"))
  
  									val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  									.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip")
  
  									val nbrclm_paid_inntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_gold_ip"))
  
  									val gldMaster = brSilData.alias("parent").join(nbrclm_paid_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  											$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"))
  
  									val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  									.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip")
  
  									val nbrclm_paid_inntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_platinum_ip"))
  
  									val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  											$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"))
  
  									val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  									.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip")
  
  									val tot_ip = nbrclm_paid_inntwk_bronze_ip.union(nbrclm_paid_inntwk_silver_ip.union(nbrclm_paid_inntwk_gold_ip.union(nbrclm_paid_inntwk_platinum_ip)))
  									.select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_inntwk_bronze_ip"))
  
  									val nbrclm_paid_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_inntwk_bronze_ip").alias("nbrclm_paid_inntwk_total_ip"))
  
  									val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  											$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"))
  
  									val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  									.withColumn("nbrclm_paid_inntwk_bronze_sgp", lit(0))
  									.withColumn("nbrclm_paid_inntwk_silver_sgp", lit(0))
  									.withColumn("nbrclm_paid_inntwk_gold_sgp", lit(0))
  									.withColumn("nbrclm_paid_inntwk_platinum_sgp", lit(0))
  									.withColumn("nbrclm_paid_inntwk_total_sgp", col("nbrclm_paid_inntwk_bronze_sgp") + col("nbrclm_paid_inntwk_silver_sgp") + col("nbrclm_paid_inntwk_gold_sgp") + col("nbrclm_paid_inntwk_platinum_sgp"))
  									.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
  											"nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp")
  
  									val nbrclm_paid_inntwk_gtlgp = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") && $"inn_cd".isin(clminn_cd: _*))
  									.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  									.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gtlgp"))
  
  									val gtlgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
  									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  											$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
  											col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"))
  
  									val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  									.withColumn("nbrclm_paid_inntwk_gtsgp", lit(0))
  									.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
  											"nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp")
  
  									val nbrclm_paid_inntwk_gtip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") && $"inn_cd".isin(clminn_cd: _*))
  									.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  									.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gtip"))
  
  									val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  											$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
  											col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"))
  
  									val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  									.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
  											"nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp", "nbrclm_paid_inntwk_gtip")
  
  									val tot_gt = nbrclm_paid_inntwk_gtip.union(nbrclm_paid_inntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_paid_inntwk_gtip")
  
  									val nbrclm_paid_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_paid_inntwk_gtip").alias("nbrclm_paid_inntwk_total_gtip"))
  
  									val gtMaster = gtipMasterData.alias("parent").join(nbrclm_paid_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  											$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
  											col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"))
  
  									val gtMasterData = gtMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  									.withColumn("nbrclm_paid_inntwk_catastrophic", lit(0))
  									.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
  											"nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp", "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic")
  
  									val nbrclm_paid_inntwk_lgp_mmcare = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
  											$"inn_cd".isin(clminn_cd: _*)).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  									.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_lgp_mmcare"))
  									val lgpMaster = gtMasterData.alias("parent").join(nbrclm_paid_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
  									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  											$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
  											col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"))
  
  									val lgpMasterData = lgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  									.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
  											"nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp", "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare")
  
  									val nbrclm_paid_inntwk_stucvg = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_stucvg"))
  
  									val stucvgMaster = lgpMasterData.alias("parent").join(nbrclm_paid_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
  									&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  									.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  											$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  											$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_bronze_ip"), col("nbrclm_paid_inntwk_silver_ip"), col("nbrclm_paid_inntwk_gold_ip"), col("nbrclm_paid_inntwk_platinum_ip"), col("nbrclm_paid_inntwk_total_ip"),
  											col("nbrclm_paid_inntwk_bronze_sgp"), col("nbrclm_paid_inntwk_silver_sgp"), col("nbrclm_paid_inntwk_gold_sgp"), col("nbrclm_paid_inntwk_platinum_sgp"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"), col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_catastrophic"), col("nbrclm_paid_inntwk_lgp_mmcare"), col("nbrclm_paid_inntwk_stucvg"))
  
  									val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  									.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  									.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  									.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_bronze_ip", "nbrclm_paid_inntwk_silver_ip", "nbrclm_paid_inntwk_gold_ip", "nbrclm_paid_inntwk_platinum_ip", "nbrclm_paid_inntwk_total_ip",
  											"nbrclm_paid_inntwk_bronze_sgp", "nbrclm_paid_inntwk_silver_sgp", "nbrclm_paid_inntwk_gold_sgp", "nbrclm_paid_inntwk_platinum_sgp", "nbrclm_paid_inntwk_total_sgp", "nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp", "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg")
  
  									stucvgMasterData
  	}
  	def getPaidOutntwk(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame,
  			naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {
  					val clminn_cd = Seq("IN", "PAR")
  							val clmLineAdjdctn = Seq("DND", "DNDZB")
  							var lob_type = "TOTAL INDIVIDUAL CBE"
  
  							val nbrclm_paid_outntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_bronze_ip"))
  
  							val nbrclm_paid_outntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_silver_ip"))
  
  							val brSil = nbrclm_paid_outntwk_bronze_ip.alias("parent").join(nbrclm_paid_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"))
  
  							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip")
  
  							val nbrclm_paid_outntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_gold_ip"))
  
  							val gldMaster = brSilData.alias("parent").join(nbrclm_paid_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"))
  
  							val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip")
  
  							val nbrclm_paid_outntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_platinum_ip"))
  
  							val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"))
  
  							val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip")
  
  							val tot_ip = nbrclm_paid_outntwk_bronze_ip.union(nbrclm_paid_outntwk_silver_ip.union(nbrclm_paid_outntwk_gold_ip.union(nbrclm_paid_outntwk_platinum_ip)))
  							.select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_outntwk_bronze_ip"))
  
  							val nbrclm_paid_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_outntwk_bronze_ip").alias("nbrclm_paid_outntwk_total_ip"))
  
  							val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"))
  
  							val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_outntwk_bronze_sgp", lit(0))
  							.withColumn("nbrclm_paid_outntwk_silver_sgp", lit(0))
  							.withColumn("nbrclm_paid_outntwk_gold_sgp", lit(0))
  							.withColumn("nbrclm_paid_outntwk_platinum_sgp", lit(0))
  							.withColumn("nbrclm_paid_outntwk_total_sgp", col("nbrclm_paid_outntwk_bronze_sgp") + col("nbrclm_paid_outntwk_silver_sgp") + col("nbrclm_paid_outntwk_gold_sgp") + col("nbrclm_paid_outntwk_platinum_sgp"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
  									"nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp")
  
  							val nbrclm_paid_outntwk_gtlgp = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") &&
  									(!$"inn_cd".isin(clminn_cd: _*)))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gtlgp"))
  
  							val gtlgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
  									col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"))
  
  							val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_outntwk_gtsgp", lit(0))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
  									"nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp")
  
  							val nbrclm_paid_outntwk_gtip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
  									(!$"inn_cd".isin(clminn_cd: _*)))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gtip"))
  
  							val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
  									col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"))
  
  							val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
  									"nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp", "nbrclm_paid_outntwk_gtip")
  
  							val tot_gt = nbrclm_paid_outntwk_gtip.union(nbrclm_paid_outntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", $"nbrclm_paid_outntwk_gtip")
  
  							val nbrclm_paid_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum($"nbrclm_paid_outntwk_gtip").alias("nbrclm_paid_outntwk_total_gtip"))
  
  							val gtMaster = gtipMasterData.alias("parent").join(nbrclm_paid_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
  									col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"), col("nbrclm_paid_outntwk_total_gtip"))
  
  							val gtMasterData = gtMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_outntwk_catastrophic", lit(0))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
  									"nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp", "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic")
  
  							val nbrclm_paid_outntwk_lgp_mmcare = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
  									(!$"inn_cd".isin(clminn_cd: _*))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_lgp_mmcare"))
  							val lgpMaster = gtMasterData.alias("parent").join(nbrclm_paid_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
  									col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"), col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_lgp_mmcare"))
  
  							val lgpMasterData = lgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
  									"nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp", "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_lgp_mmcare")
  
  							val nbrclm_paid_outntwk_stucvg = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_stucvg"))
  							val stucvgMaster = lgpMasterData.alias("parent").join(nbrclm_paid_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_bronze_ip"), col("nbrclm_paid_outntwk_silver_ip"), col("nbrclm_paid_outntwk_gold_ip"), col("nbrclm_paid_outntwk_platinum_ip"), col("nbrclm_paid_outntwk_total_ip"),
  									col("nbrclm_paid_outntwk_bronze_sgp"), col("nbrclm_paid_outntwk_silver_sgp"), col("nbrclm_paid_outntwk_gold_sgp"), col("nbrclm_paid_outntwk_platinum_sgp"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"), col("nbrclm_paid_outntwk_gtip"), col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_catastrophic"), col("nbrclm_paid_outntwk_lgp_mmcare"), col("nbrclm_paid_outntwk_stucvg"))
  
  							val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_bronze_ip", "nbrclm_paid_outntwk_silver_ip", "nbrclm_paid_outntwk_gold_ip", "nbrclm_paid_outntwk_platinum_ip", "nbrclm_paid_outntwk_total_ip",
  									"nbrclm_paid_outntwk_bronze_sgp", "nbrclm_paid_outntwk_silver_sgp", "nbrclm_paid_outntwk_gold_sgp", "nbrclm_paid_outntwk_platinum_sgp", "nbrclm_paid_outntwk_total_sgp", "nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp", "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_lgp_mmcare", "nbrclm_paid_outntwk_stucvg")
  
  							stucvgMasterData
  	}
  
  	def getPaidInntwkBetweenDays(start_day: Int, end_day: Int, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame,
  			naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {
  					val clminn_cd = Seq("IN", "PAR")
  							val clmLineAdjdctn = Seq("DND", "DNDZB")
  							var lob_type = "TOTAL INDIVIDUAL CBE"
  							val colVal = start_day.toString + "to" + end_day
  							val fend_day = end_day + 1
  
  							val nbrclm_paid_inntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"))
  
  							val nbrclm_paid_inntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_" + colVal + "_silver_ip"))
  
  							val brSil = nbrclm_paid_inntwk_bronze_ip.alias("parent").join(nbrclm_paid_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"))
  
  							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip")
  
  							val nbrclm_paid_inntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_" + colVal + "_gold_ip"))
  
  							val gldMaster = brSilData.alias("parent").join(nbrclm_paid_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"))
  
  							val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip")
  
  							val nbrclm_paid_inntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"))
  
  							val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"))
  
  							val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip")
  
  							val tot_ip = nbrclm_paid_inntwk_bronze_ip.union(nbrclm_paid_inntwk_silver_ip.union(nbrclm_paid_inntwk_gold_ip.union(nbrclm_paid_inntwk_platinum_ip)))
  							.select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"))
  
  							val nbrclm_paid_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_ip").alias("nbrclm_paid_inntwk_" + colVal + "_total_ip"))
  
  							val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"))
  
  							val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", lit(0))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_silver_sgp", lit(0))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_gold_sgp", lit(0))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", lit(0))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_total_sgp", col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp") + col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp") + col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp") + col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp")
  
  							val nbrclm_paid_inntwk_gtlgp = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND")
  									&& $"inn_cd".isin(clminn_cd: _*) &&
  									$"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gtlgp"))
  
  							val gtlgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"))
  
  							val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_gtsgp", lit(0))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp")
  
  							val nbrclm_paid_inntwk_gtip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") && $"inn_cd".isin(clminn_cd: _*) &&
  									$"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gtip"))
  
  							val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"))
  
  							val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip")
  
  							val tot_gt = nbrclm_paid_inntwk_gtip.union(nbrclm_paid_inntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_inntwk_" + colVal + "_gtip"))
  
  							val nbrclm_paid_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("nbrclm_paid_inntwk_" + colVal + "_gtip").alias("nbrclm_paid_inntwk_" + colVal + "_total_gtip"))
  
  							val gtMaster = gtipMasterData.alias("parent").join(nbrclm_paid_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"))
  
  							val gtMasterData = gtMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_catastrophic", lit(0))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip", "nbrclm_paid_inntwk_" + colVal + "_catastrophic")
  
  							val nbrclm_paid_inntwk_lgp_mmcare = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
  									$"inn_cd".isin(clminn_cd: _*) &&
  									$"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare"))
  							val lgpMaster = gtMasterData.alias("parent").join(nbrclm_paid_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare"))
  
  							val lgpMasterData = lgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip", "nbrclm_paid_inntwk_" + colVal + "_catastrophic", "nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare")
  
  							val nbrclm_paid_inntwk_stucvg = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_" + colVal + "_stucvg"))
  							val stucvgMaster = lgpMasterData.alias("parent").join(nbrclm_paid_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_paid_inntwk_" + colVal + "_stucvg"))
  
  							val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip", "nbrclm_paid_inntwk_" + colVal + "_catastrophic", "nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare", "nbrclm_paid_inntwk_" + colVal + "_stucvg")
  
  							stucvgMasterData
  	}
  	def getPaidOutntwkBetweenDays(start_day: Int, end_day: Int, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame,
  			naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {
  					val clminn_cd = Seq("IN", "PAR")
  							val clmLineAdjdctn = Seq("DND", "DNDZB")
  							var lob_type = "TOTAL INDIVIDUAL CBE"
  							val colVal = start_day.toString + "to" + end_day
  							val fend_day = end_day + 1
  							val ip_df = clmexphmcy.getIpSgpPlan(naic_mcas_hlthex_clmexphmcy_paid_ip_wrk, lob_type)
  
  							val nbrclm_paid_outntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"))
  
  							val nbrclm_paid_outntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_" + colVal + "_silver_ip"))
  
  							val brSil = nbrclm_paid_outntwk_bronze_ip.alias("parent").join(nbrclm_paid_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"))
  
  							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip")
  
  							val nbrclm_paid_outntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_" + colVal + "_gold_ip"))
  
  							val gldMaster = brSilData.alias("parent").join(nbrclm_paid_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"))
  
  							val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip")
  
  							val nbrclm_paid_outntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"))
  
  							val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"))
  
  							val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip")
  
  							val tot_ip = nbrclm_paid_outntwk_bronze_ip.union(nbrclm_paid_outntwk_silver_ip.union(nbrclm_paid_outntwk_gold_ip.union(nbrclm_paid_outntwk_platinum_ip)))
  							.select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"))
  
  							val nbrclm_paid_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_ip").alias("nbrclm_paid_outntwk_" + colVal + "_total_ip"))
  
  							val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"))
  
  							val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", lit(0))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_silver_sgp", lit(0))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_gold_sgp", lit(0))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", lit(0))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_total_sgp", col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp") + col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp") + col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp") + col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp")
  
  							val nbrclm_paid_outntwk_gtlgp = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND") &&
  									(!$"inn_cd".isin(clminn_cd: _*)) &&
  									$"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gtlgp"))
  
  							val gtlgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"))
  
  							val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_gtsgp", lit(0))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp")
  
  							val nbrclm_paid_outntwk_gtip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") && (!$"inn_cd".isin(clminn_cd: _*)) &&
  									$"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day)))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gtip"))
  
  							val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"))
  
  							val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip")
  
  							val tot_gt = nbrclm_paid_outntwk_gtip.union(nbrclm_paid_outntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_outntwk_" + colVal + "_gtip"))
  
  							val nbrclm_paid_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("nbrclm_paid_outntwk_" + colVal + "_gtip").alias("nbrclm_paid_outntwk_" + colVal + "_total_gtip"))
  
  							val gtMaster = gtipMasterData.alias("parent").join(nbrclm_paid_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"))
  
  							val gtMasterData = gtMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_catastrophic", lit(0))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip", "nbrclm_paid_outntwk_" + colVal + "_catastrophic")
  
  							val nbrclm_paid_outntwk_lgp_mmcare = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
  									(!$"inn_cd".isin(clminn_cd: _*)) &&
  									$"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", start_day), date_add($"PRMPT_PAY_CLM_RCVD_DT", fend_day))).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare"))
  							val lgpMaster = gtMasterData.alias("parent").join(nbrclm_paid_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare"))
  
  							val lgpMasterData = lgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip", "nbrclm_paid_outntwk_" + colVal + "_catastrophic", "nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare")
  
  							val nbrclm_paid_outntwk_stucvg = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_" + colVal + "_stucvg"))
  							val stucvgMaster = lgpMasterData.alias("parent").join(nbrclm_paid_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_paid_outntwk_" + colVal + "_stucvg"))
  
  							val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip", "nbrclm_paid_outntwk_" + colVal + "_catastrophic", "nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare", "nbrclm_paid_outntwk_" + colVal + "_stucvg")
  
  							stucvgMasterData
  	}
  	def getPaidInntwk_90(end_year: String, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame,
  			naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {
  					val clminn_cd = Seq("IN", "PAR")
  							val clmLineAdjdctn = Seq("DND", "DNDZB")
  							var lob_type = "TOTAL INDIVIDUAL CBE"
  							val colVal = "90"
  							val strt_day: Int = 91
  
  							val nbrclm_paid_inntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"))
  
  							val nbrclm_paid_inntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_" + colVal + "_silver_ip"))
  
  							val brSil = nbrclm_paid_inntwk_bronze_ip.alias("parent").join(nbrclm_paid_inntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"))
  
  							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip")
  
  							val nbrclm_paid_inntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_" + colVal + "_gold_ip"))
  
  							val gldMaster = brSilData.alias("parent").join(nbrclm_paid_inntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"))
  
  							val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip")
  
  							val nbrclm_paid_inntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"))
  
  							val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_inntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"))
  
  							val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip")
  
  							val tot_ip = nbrclm_paid_inntwk_bronze_ip.union(nbrclm_paid_inntwk_silver_ip.union(nbrclm_paid_inntwk_gold_ip.union(nbrclm_paid_inntwk_platinum_ip)))
  							.select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"))
  
  							val nbrclm_paid_inntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_inntwk_" + colVal + "_bronze_ip").alias("nbrclm_paid_inntwk_" + colVal + "_total_ip"))
  
  							val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_inntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"))
  
  							val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", lit(0))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_silver_sgp", lit(0))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_gold_sgp", lit(0))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", lit(0))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_total_sgp", col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp") + col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp") + col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp") + col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp")
  
  							val nbrclm_paid_inntwk_gtlgp = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.withColumn("constant_date", lit(end_year)).filter($"naic_lob".equalTo("LARGE GROUP GRAND") && $"inn_cd".isin(clminn_cd: _*) &&
  									$"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gtlgp"))
  
  							val gtlgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_inntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"))
  
  							val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_gtsgp", lit(0))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp")
  
  							val nbrclm_paid_inntwk_gtip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.withColumn("constant_date", lit(end_year)).filter($"naic_lob".equalTo("INDIVIDUAL GRAND") && $"inn_cd".isin(clminn_cd: _*) &&
  									$"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_gtip"))
  
  							val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_paid_inntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"))
  
  							val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip")
  
  							val tot_gt = nbrclm_paid_inntwk_gtip.union(nbrclm_paid_inntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_inntwk_" + colVal + "_gtip"))
  
  							val nbrclm_paid_inntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("nbrclm_paid_inntwk_" + colVal + "_gtip").alias("nbrclm_paid_inntwk_" + colVal + "_total_gtip"))
  
  							val gtMaster = gtipMasterData.alias("parent").join(nbrclm_paid_inntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"))
  
  							val gtMasterData = gtMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_inntwk_" + colVal + "_catastrophic", lit(0))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip", "nbrclm_paid_inntwk_" + colVal + "_catastrophic")
  
  							val nbrclm_paid_inntwk_lgp_mmcare = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.withColumn("constant_date", lit(end_year))
  							.filter($"naic_lob".equalTo("LARGE GROUP CBE") && $"inn_cd".isin(clminn_cd: _*) &&
  									$"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date")).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare"))
  							val lgpMaster = gtMasterData.alias("parent").join(nbrclm_paid_inntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare"))
  
  							val lgpMasterData = lgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip", "nbrclm_paid_inntwk_" + colVal + "_catastrophic", "nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare")
  
  							val nbrclm_paid_inntwk_stucvg = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_inntwk_" + colVal + "_stucvg"))
  							val stucvgMaster = lgpMasterData.alias("parent").join(nbrclm_paid_inntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_inntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_inntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_inntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_inntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_inntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_inntwk_" + colVal + "_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_inntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_paid_inntwk_" + colVal + "_stucvg"))
  
  							val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_inntwk_" + colVal + "_bronze_ip", "nbrclm_paid_inntwk_" + colVal + "_silver_ip", "nbrclm_paid_inntwk_" + colVal + "_gold_ip", "nbrclm_paid_inntwk_" + colVal + "_platinum_ip", "nbrclm_paid_inntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_inntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_inntwk_" + colVal + "_silver_sgp", "nbrclm_paid_inntwk_" + colVal + "_gold_sgp", "nbrclm_paid_inntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_inntwk_" + colVal + "_total_sgp", "nbrclm_paid_inntwk_" + colVal + "_gtlgp", "nbrclm_paid_inntwk_" + colVal + "_gtsgp", "nbrclm_paid_inntwk_" + colVal + "_gtip", "nbrclm_paid_inntwk_" + colVal + "_total_gtip", "nbrclm_paid_inntwk_" + colVal + "_catastrophic", "nbrclm_paid_inntwk_" + colVal + "_lgp_mmcare", "nbrclm_paid_inntwk_" + colVal + "_stucvg")
  
  							stucvgMasterData
  	}
  	def getPaidOutntwk_90(end_year: String, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame,
  			naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {
  					val clminn_cd = Seq("IN", "PAR")
  							val clmLineAdjdctn = Seq("DND", "DNDZB")
  							var lob_type = "TOTAL INDIVIDUAL CBE"
  							val colVal = "90"
  							val strt_day: Int = 91
  
  							val nbrclm_paid_outntwk_bronze_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"))
  
  							val nbrclm_paid_outntwk_silver_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_" + colVal + "_silver_ip"))
  
  							val brSil = nbrclm_paid_outntwk_bronze_ip.alias("parent").join(nbrclm_paid_outntwk_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"))
  
  							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip")
  
  							val nbrclm_paid_outntwk_gold_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_" + colVal + "_gold_ip"))
  
  							val gldMaster = brSilData.alias("parent").join(nbrclm_paid_outntwk_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"))
  
  							val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip")
  
  							val nbrclm_paid_outntwk_platinum_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"))
  
  							val pltMaster = gldMasterData.alias("parent").join(nbrclm_paid_outntwk_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"))
  
  							val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip")
  
  							val tot_ip = nbrclm_paid_outntwk_bronze_ip.union(nbrclm_paid_outntwk_silver_ip.union(nbrclm_paid_outntwk_gold_ip.union(nbrclm_paid_outntwk_platinum_ip)))
  							.select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"))
  
  							val nbrclm_paid_outntwk_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("nbrclm_paid_outntwk_" + colVal + "_bronze_ip").alias("nbrclm_paid_outntwk_" + colVal + "_total_ip"))
  
  							val ipMaster = pltMasterData.alias("parent").join(nbrclm_paid_outntwk_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"))
  
  							val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", lit(0))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_silver_sgp", lit(0))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_gold_sgp", lit(0))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", lit(0))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_total_sgp", col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp") + col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp") + col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp") + col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp")
  
  							val nbrclm_paid_outntwk_gtlgp = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.withColumn("constant_date", lit(end_year)).filter($"naic_lob".equalTo("LARGE GROUP GRAND") && (!$"inn_cd".isin(clminn_cd: _*)) &&
  									$"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gtlgp"))
  
  							val gtlgpMaster = ipMasterData.alias("parent").join(nbrclm_paid_outntwk_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"))
  
  							val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_gtsgp", lit(0))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp")
  
  							val nbrclm_paid_outntwk_gtip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.withColumn("constant_date", lit(end_year)).filter($"naic_lob".equalTo("INDIVIDUAL GRAND") && (!$"inn_cd".isin(clminn_cd: _*)) &&
  									$"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_gtip"))
  
  							val gtipMaster = gtlgpMasterData.alias("parent").join(nbrclm_paid_outntwk_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"))
  
  							val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip")
  
  							val tot_gt = nbrclm_paid_outntwk_gtip.union(nbrclm_paid_outntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", col("nbrclm_paid_outntwk_" + colVal + "_gtip"))
  
  							val nbrclm_paid_outntwk_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("nbrclm_paid_outntwk_" + colVal + "_gtip").alias("nbrclm_paid_outntwk_" + colVal + "_total_gtip"))
  
  							val gtMaster = gtipMasterData.alias("parent").join(nbrclm_paid_outntwk_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"))
  
  							val gtMasterData = gtMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("nbrclm_paid_outntwk_" + colVal + "_catastrophic", lit(0))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip", "nbrclm_paid_outntwk_" + colVal + "_catastrophic")
  
  							val nbrclm_paid_outntwk_lgp_mmcare = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.withColumn("constant_date", lit(end_year))
  							.filter($"naic_lob".equalTo("LARGE GROUP CBE") &&
  									(!$"inn_cd".isin(clminn_cd: _*)) &&
  									$"GL_POST_DT".between(date_add($"PRMPT_PAY_CLM_RCVD_DT", strt_day), $"constant_date")).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("count_Val").alias("nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare"))
  							val lgpMaster = gtMasterData.alias("parent").join(nbrclm_paid_outntwk_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare"))
  
  							val lgpMasterData = lgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip", "nbrclm_paid_outntwk_" + colVal + "_catastrophic", "nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare")
  
  							val nbrclm_paid_outntwk_stucvg = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("nbrclm_paid_outntwk_" + colVal + "_stucvg"))
  							val stucvgMaster = lgpMasterData.alias("parent").join(nbrclm_paid_outntwk_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("nbrclm_paid_outntwk_" + colVal + "_bronze_ip"), col("nbrclm_paid_outntwk_" + colVal + "_silver_ip"), col("nbrclm_paid_outntwk_" + colVal + "_gold_ip"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_ip"), col("nbrclm_paid_outntwk_" + colVal + "_total_ip"),
  									col("nbrclm_paid_outntwk_" + colVal + "_bronze_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_silver_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gold_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_platinum_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_total_sgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtlgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtsgp"), col("nbrclm_paid_outntwk_" + colVal + "_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_total_gtip"), col("nbrclm_paid_outntwk_" + colVal + "_catastrophic"), col("nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare"), col("nbrclm_paid_outntwk_" + colVal + "_stucvg"))
  
  							val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "nbrclm_paid_outntwk_" + colVal + "_bronze_ip", "nbrclm_paid_outntwk_" + colVal + "_silver_ip", "nbrclm_paid_outntwk_" + colVal + "_gold_ip", "nbrclm_paid_outntwk_" + colVal + "_platinum_ip", "nbrclm_paid_outntwk_" + colVal + "_total_ip",
  									"nbrclm_paid_outntwk_" + colVal + "_bronze_sgp", "nbrclm_paid_outntwk_" + colVal + "_silver_sgp", "nbrclm_paid_outntwk_" + colVal + "_gold_sgp", "nbrclm_paid_outntwk_" + colVal + "_platinum_sgp", "nbrclm_paid_outntwk_" + colVal + "_total_sgp", "nbrclm_paid_outntwk_" + colVal + "_gtlgp", "nbrclm_paid_outntwk_" + colVal + "_gtsgp", "nbrclm_paid_outntwk_" + colVal + "_gtip", "nbrclm_paid_outntwk_" + colVal + "_total_gtip", "nbrclm_paid_outntwk_" + colVal + "_catastrophic", "nbrclm_paid_outntwk_" + colVal + "_lgp_mmcare", "nbrclm_paid_outntwk_" + colVal + "_stucvg")
  
  							stucvgMasterData
  	}
  	def getamtData(paid_col: String, typeOfPay: String, naic_mcas_hlthex_clmexphmcy_paid_ip_wrk: DataFrame,
  			naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk: DataFrame, mbu_cf_cdvals: Seq[String]): DataFrame = {
  
  					val clm_total_amt_bronze_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("clm_total_" + typeOfPay + "_amt_bronze_ip")).withColumn("clm_total_" + typeOfPay + "_amt_bronze_ip", col("clm_total_" + typeOfPay + "_amt_bronze_ip").cast(IntegerType))
  
  							val clm_total_amt_silver_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("clm_total_" + typeOfPay + "_amt_silver_ip")).withColumn("clm_total_" + typeOfPay + "_amt_silver_ip", col("clm_total_" + typeOfPay + "_amt_silver_ip").cast(IntegerType))
  
  							val brSil = clm_total_amt_bronze_ip.alias("parent").join(clm_total_amt_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"))
  
  							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip")
  
  							val clm_total_amt_gold_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("clm_total_" + typeOfPay + "_amt_gold_ip")).withColumn("clm_total_" + typeOfPay + "_amt_gold_ip", col("clm_total_" + typeOfPay + "_amt_gold_ip").cast(IntegerType))
  
  							val gldMaster = brSilData.alias("parent").join(clm_total_amt_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"))
  
  							val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip")
  
  							val clm_total_amt_platinum_ip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("clm_total_" + typeOfPay + "_amt_platinum_ip")).withColumn("clm_total_" + typeOfPay + "_amt_platinum_ip", col("clm_total_" + typeOfPay + "_amt_platinum_ip").cast(IntegerType))
  
  							val pltMaster = gldMasterData.alias("parent").join(clm_total_amt_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"))
  
  							val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip")
  
  							val tot_ip = clm_total_amt_bronze_ip.union(clm_total_amt_silver_ip.union(clm_total_amt_gold_ip.union(clm_total_amt_platinum_ip)))
  							.select($"health_year", $"cmpny_cf_cd", $"state", col("clm_total_" + typeOfPay + "_amt_bronze_ip"))
  
  							val clm_total_amt_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum("clm_total_" + typeOfPay + "_amt_bronze_ip").alias("clm_total_" + typeOfPay + "_amt_total_ip"))
  
  							val ipMaster = pltMasterData.alias("parent").join(clm_total_amt_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"))
  
  							val ipMasterData = ipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("clm_total_" + typeOfPay + "_amt_bronze_sgp", lit(0))
  							.withColumn("clm_total_" + typeOfPay + "_amt_silver_sgp", lit(0))
  							.withColumn("clm_total_" + typeOfPay + "_amt_gold_sgp", lit(0))
  							.withColumn("clm_total_" + typeOfPay + "_amt_platinum_sgp", lit(0)) //clm_total_paid_amt_total_sgp
  							.withColumn("clm_total_" + typeOfPay + "_amt_total_sgp", col("clm_total_" + typeOfPay + "_amt_bronze_sgp") + col("clm_total_" + typeOfPay + "_amt_silver_sgp") + col("clm_total_" + typeOfPay + "_amt_gold_sgp") + col("clm_total_" + typeOfPay + "_amt_platinum_sgp"))
  							.select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
  									"clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp")
  
  							val clm_total_amt_gtlgp = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP GRAND")).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_gtlgp")).withColumn("clm_total_" + typeOfPay + "_amt_gtlgp", col("clm_total_" + typeOfPay + "_amt_gtlgp").cast(IntegerType))
  
  							val gtlgpMaster = ipMasterData.alias("parent").join(clm_total_amt_gtlgp.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
  									col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"), col("clm_total_" + typeOfPay + "_amt_gtlgp"))
  
  							val gtlgpMasterData = gtlgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("clm_total_" + typeOfPay + "_amt_gtsgp", lit(0))
  							.select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
  									"clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp", "clm_total_" + typeOfPay + "_amt_gtlgp", "clm_total_" + typeOfPay + "_amt_gtsgp")
  
  							val clm_total_amt_gtip = naic_mcas_hlthex_clmexphmcy_paid_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND")).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_gtip")).withColumn("clm_total_" + typeOfPay + "_amt_gtip", col("clm_total_" + typeOfPay + "_amt_gtip").cast(IntegerType))
  
  							val gtipMaster = gtlgpMasterData.alias("parent").join(clm_total_amt_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
  									col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"), col("clm_total_" + typeOfPay + "_amt_gtlgp"), col("clm_total_" + typeOfPay + "_amt_gtsgp"), col("clm_total_" + typeOfPay + "_amt_gtip"))
  
  							val gtipMasterData = gtipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
  									"clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp", "clm_total_" + typeOfPay + "_amt_gtlgp", "clm_total_" + typeOfPay + "_amt_gtsgp", "clm_total_" + typeOfPay + "_amt_gtip")
  
  							val tot_gt = clm_total_amt_gtip.union(clm_total_amt_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", col("clm_total_" + typeOfPay + "_amt_gtip"))
  							val clm_total_amt_total_gtip = tot_gt.groupBy("health_year", "cmpny_cf_cd", "state").agg(sum("clm_total_" + typeOfPay + "_amt_gtip").alias("clm_total_" + typeOfPay + "_amt_total_gtip"))
  							val gttotMaster = gtipMasterData.alias("parent").join(clm_total_amt_total_gtip.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
  									col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"), col("clm_total_" + typeOfPay + "_amt_gtlgp"), col("clm_total_" + typeOfPay + "_amt_gtsgp"), col("clm_total_" + typeOfPay + "_amt_gtip"), col("clm_total_" + typeOfPay + "_amt_total_gtip"))
  
  							val gttotMasterData = gttotMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.withColumn("clm_total_" + typeOfPay + "_amt_catastrophic", lit(0))
  							.select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
  									"clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp", "clm_total_" + typeOfPay + "_amt_gtlgp", "clm_total_" + typeOfPay + "_amt_gtsgp", "clm_total_" + typeOfPay + "_amt_gtip", "clm_total_" + typeOfPay + "_amt_total_gtip", "clm_total_" + typeOfPay + "_amt_catastrophic")
  
  							val clm_tot_amt_lgp_mmcare = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE")).groupBy($"health_year", $"cmpny_cf_cd", $"state", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR", col(paid_col)).agg((lit(1)).alias("count_Val"))
  							.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(sum(paid_col).alias("clm_total_" + typeOfPay + "_amt_lgp_mmcare")).withColumn("clm_total_" + typeOfPay + "_amt_lgp_mmcare", col("clm_total_" + typeOfPay + "_amt_lgp_mmcare").cast(IntegerType))
  
  							val lgpmmcareMaster = gttotMasterData.alias("parent").join(clm_tot_amt_lgp_mmcare.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
  									col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"), col("clm_total_" + typeOfPay + "_amt_gtlgp"), col("clm_total_" + typeOfPay + "_amt_gtsgp"), col("clm_total_" + typeOfPay + "_amt_gtip"), col("clm_total_" + typeOfPay + "_amt_total_gtip"), col("clm_total_" + typeOfPay + "_amt_catastrophic"), col("clm_total_" + typeOfPay + "_amt_lgp_mmcare"))
  
  							val lgpmmcareMasterData = lgpmmcareMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
  									"clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp", "clm_total_" + typeOfPay + "_amt_gtlgp", "clm_total_" + typeOfPay + "_amt_gtsgp", "clm_total_" + typeOfPay + "_amt_gtip", "clm_total_" + typeOfPay + "_amt_total_gtip", "clm_total_" + typeOfPay + "_amt_catastrophic", "clm_total_" + typeOfPay + "_amt_lgp_mmcare")
  							val clm_tot_amt_stucvg = naic_mcas_hlthex_clmexphmcy_paid_lgp_wrk.groupBy($"health_year", $"cmpny_cf_cd", $"state").agg(lit(0).alias("clm_total_" + typeOfPay + "_amt_stucvg")).withColumn("clm_total_" + typeOfPay + "_amt_stucvg", col("clm_total_" + typeOfPay + "_amt_stucvg").cast(IntegerType))
  
  							val stucvgMaster = lgpmmcareMasterData.alias("parent").join(clm_tot_amt_stucvg.alias("child"), $"parent.health_year" === $"child.health_year"
  							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state", "outer")
  							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
  									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
  									$"child.state".alias("s_state"), col("clm_total_" + typeOfPay + "_amt_bronze_ip"), col("clm_total_" + typeOfPay + "_amt_silver_ip"), col("clm_total_" + typeOfPay + "_amt_gold_ip"), col("clm_total_" + typeOfPay + "_amt_platinum_ip"), col("clm_total_" + typeOfPay + "_amt_total_ip"),
  									col("clm_total_" + typeOfPay + "_amt_bronze_sgp"), col("clm_total_" + typeOfPay + "_amt_silver_sgp"), col("clm_total_" + typeOfPay + "_amt_gold_sgp"), col("clm_total_" + typeOfPay + "_amt_platinum_sgp"), col("clm_total_" + typeOfPay + "_amt_total_sgp"), col("clm_total_" + typeOfPay + "_amt_gtlgp"), col("clm_total_" + typeOfPay + "_amt_gtsgp"), col("clm_total_" + typeOfPay + "_amt_gtip"), col("clm_total_" + typeOfPay + "_amt_total_gtip"), col("clm_total_" + typeOfPay + "_amt_catastrophic"), col("clm_total_" + typeOfPay + "_amt_lgp_mmcare"), col("clm_total_" + typeOfPay + "_amt_stucvg"))
  
  							val stucvgMasterData = stucvgMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
  							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
  							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
  							.select("health_year", "cmpny_cf_cd", "state", "clm_total_" + typeOfPay + "_amt_bronze_ip", "clm_total_" + typeOfPay + "_amt_silver_ip", "clm_total_" + typeOfPay + "_amt_gold_ip", "clm_total_" + typeOfPay + "_amt_platinum_ip", "clm_total_" + typeOfPay + "_amt_total_ip",
  									"clm_total_" + typeOfPay + "_amt_bronze_sgp", "clm_total_" + typeOfPay + "_amt_silver_sgp", "clm_total_" + typeOfPay + "_amt_gold_sgp", "clm_total_" + typeOfPay + "_amt_platinum_sgp", "clm_total_" + typeOfPay + "_amt_total_sgp", "clm_total_" + typeOfPay + "_amt_gtlgp", "clm_total_" + typeOfPay + "_amt_gtsgp", "clm_total_" + typeOfPay + "_amt_gtip", "clm_total_" + typeOfPay + "_amt_total_gtip", "clm_total_" + typeOfPay + "_amt_catastrophic", "clm_total_" + typeOfPay + "_amt_lgp_mmcare", "clm_total_" + typeOfPay + "_amt_stucvg")
  
  							stucvgMasterData
  	}
  
  
  
  	//	val objdeniedPAInntwk = unicare1.getdeniedPAInntwk(naic2018_mcas_hlthex_clmexphmcy_received_lgp_wrk,naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk,naic2018_mcas_pa_src_eob_cd_inbnd,naic2018_mcas_pa_eob_cd_inbnd,naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)
  
  
  
  
 
  
  }