package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit
class PCADX_SCL_NAIC2018_CLMEXPHRMCY_MCLM_Paid {
    val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
                                      config("hive.exec.dynamic.partition.mode", "nonstrict").
                                      config("spark.sql.parquet.compression.codec", "snappy").
                                      config("hive.warehouse.data.skipTrash", "true").
                                      config("spark.sql.parquet.writeLegacyFormat", "true").
                                      enableHiveSupport().getOrCreate()
import spark.implicits._
  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_DataExtraction])
  val dbWrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
	val clmexRcvdStrtDt = dbProperties.getProperty("CLM_EX_RCVD_DT_STRT")
	val clmexRcvdEndDt = dbProperties.getProperty("CLM_EX_RCVD_DT_END")  
	val glPostStrtDt = dbProperties.getProperty("GL_POST_STRT_DT")
	val glPostEndDt = dbProperties.getProperty("GL_POST_END_DT")
  val reportYear =dbProperties.getProperty("report.year")
  val wrhDb = dbProperties.getProperty("warehouse.db")
	val audit_log_df = spark.sql("select * from "+wrhDb+".audt_load_log") 
  val load_log_key= audit_log_df.filter($"subj_area_nm"==="NAIC2018_MCAS" && $"prcs_nm"==="NAIC2018_MCAS_RPT" && $"load_stts_cd"==="S").orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString() 
  println("load_log_key : "+load_log_key)
  println(clmexRcvdEndDt)
  println(clmexRcvdStrtDt)
  
  def naic_mcas_mclm_paid_wrk() = """INSERT OVERWRITE TABLE  """+dbWrk+""".naic2018_mcas_mclm_paid_wrk         
  (
SELECT 
"""+reportYear+"""                 AS health_year, 
wrk.CLM_ADJSTMNT_KEY               AS CLM_ADJSTMNT_KEY,
wrk.CLM_LINE_NBR                   AS CLM_LINE_NBR,
wrk.CLM_SOR_CD                     AS CLM_SOR_CD,
wrk.MBR_KEY                        AS MBR_KEY,
wrk.MBRSHP_SOR_CD                  AS MBRSHP_SOR_CD,
wrk.PRMPT_PAY_CLM_RCVD_DT          AS PRMPT_PAY_CLM_RCVD_DT, 
wrk.CLM_RCVD_DT                    AS CLM_RCVD_DT,
wrk.ADJDCTN_STTS_CD                AS ADJDCTN_STTS_CD,
wrk.RPTG_CLM_ADJDCTN_STTS_CD       AS RPTG_CLM_ADJDCTN_STTS_CD,
wrk.CLM_DISP_CD                    AS CLM_DISP_CD,
wrk.ADJDCTN_DT                     AS ADJDCTN_DT,
wrk.SRVC_RNDRG_TYPE_CD             AS SRVC_RNDRG_TYPE_CD,
wrk.SRC_BILLG_TAX_ID               AS SRC_BILLG_TAX_ID,
wrk.GL_POST_DT                     AS GL_POST_DT,
wrk.BNFT_PKG_ID                    AS BNFT_PKG_ID,
wrk.INN_CD                         AS INN_CD,
wrk.CLM_LINE_STTS_CD               AS CLM_LINE_STTS_CD,
wrk.RPTG_CLM_LINE_ADJDCTN_STTS_CD  AS RPTG_CLM_LINE_ADJDCTN_STTS_CD,
wrk.BNFT_PAYMNT_STTS_CD            AS BNFT_PAYMNT_STTS_CD,
wrk.PAID_AMT                       AS PAID_AMT,
wrk.CPAY_AMT                       AS CPAY_AMT,
wrk.COINSRN_AMT                    AS COINSRN_AMT,
wrk.DDCTBL_AMT                     AS DDCTBL_AMT,
wrk.SRC_SRVC_DNL_RSN_CD            AS SRC_SRVC_DNL_RSN_CD,
wrk.SRC_EOB_CD                     AS SRC_EOB_CD,
wrk.EOB_CD                         AS EOB_CD,
wrk.src_clm_line_disp_rsn_cd       AS src_clm_line_disp_cd,
CASE 
WHEN wrk.INN_CD IN ('IN' ) AND wrk.BNFT_PAYMNT_STTS_CD IN ( 'UNK', 'NA', 'Y', 'O') THEN  'innetwork_paid'
WHEN wrk.INN_CD IN ('OUT') AND wrk.BNFT_PAYMNT_STTS_CD IN (  'Y', 'O')             THEN  'innetwork_paid'
WHEN wrk.INN_CD IN ('PAR') AND wrk.BNFT_PAYMNT_STTS_CD IN (  'Y', 'O')             THEN  'innetwork_paid'
WHEN wrk.INN_CD IN ('UNK') AND wrk.BNFT_PAYMNT_STTS_CD IN (  'Y', 'O')             THEN  'innetwork_paid'  
END AS inn_paid ,

CASE
WHEN wrk.INN_CD IN ('IN') AND wrk.BNFT_PAYMNT_STTS_CD IN ( 'N')                THEN    'outnetwork_paid'
WHEN wrk.INN_CD IN ('OUT') AND wrk.BNFT_PAYMNT_STTS_CD IN ( 'N' , 'UNK', 'NA') THEN   'outnetwork_paid'
WHEN wrk.INN_CD IN ('UNK') AND wrk.BNFT_PAYMNT_STTS_CD IN ( 'N')               THEN   'outnetwork_paid'  
WHEN wrk.INN_CD NOT IN ('IN', 'OUT', 'PAR' )                                   THEN   'outnetwork_paid'  
END AS outn_paid,
wrk.CLM_LINE_SRVC_STRT_DT AS CLM_LINE_SRVC_STRT_DT,
"""+load_log_key+""",
current_timestamp()

FROM """+dbWrk+""".naic2018_mcas_mclm_wrk wrk
Where 
    wrk.ADJDCTN_STTS_CD IN ('01','08')           
and wrk.CLM_DISP_CD NOT IN ('VOID','RVRSL')
and wrk.RPTG_CLM_LINE_ADJDCTN_STTS_CD IN ( 'APRVD','APRZB','PD', 'PDZB' ) 
and wrk.GL_POST_DT BETWEEN """+glPostStrtDt+""" AND  """+glPostEndDt+""" 


Group by
wrk.CLM_ADJSTMNT_KEY ,
wrk.CLM_LINE_NBR  ,
wrk.CLM_SOR_CD  ,
wrk.MBR_KEY  ,
wrk.MBRSHP_SOR_CD  ,
wrk.PRMPT_PAY_CLM_RCVD_DT , 
wrk.CLM_RCVD_DT  ,
wrk.ADJDCTN_STTS_CD  ,
wrk.RPTG_CLM_ADJDCTN_STTS_CD  ,
wrk.CLM_DISP_CD  ,
wrk.ADJDCTN_DT   ,
wrk.SRVC_RNDRG_TYPE_CD ,
wrk.SRC_BILLG_TAX_ID,
wrk.BNFT_PKG_ID ,
wrk.GL_POST_DT ,
wrk.INN_CD ,
wrk.CLM_LINE_STTS_CD   ,
wrk.RPTG_CLM_LINE_ADJDCTN_STTS_CD ,
wrk.BNFT_PAYMNT_STTS_CD ,
wrk.PAID_AMT ,
wrk.CPAY_AMT  ,
wrk.COINSRN_AMT  ,
wrk.DDCTBL_AMT  ,
wrk.SRC_SRVC_DNL_RSN_CD  ,
wrk.SRC_EOB_CD  ,
wrk.EOB_CD ,
wrk.src_clm_line_disp_rsn_cd,
wrk.CLM_LINE_SRVC_STRT_DT             
) 
"""

  
   def sparkInIt()
    {
      
    spark.sql(naic_mcas_mclm_paid_wrk())
    val clmexphmcy_tmp_table= new  PCADX_SCL_NAIC2018_CLMEXPHRMCY_PAID_Temp()
    clmexphmcy_tmp_table.sparkInIt()
    }
}
  object PCADX_SCL_NAIC2018_CLMEXPHRMCY_MCLM_Paid{
	def main(args: Array[String]) {
	PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
	val clmexPhmy = new PCADX_SCL_NAIC2018_CLMEXPHRMCY_MCLM_Paid()
	clmexPhmy.sparkInIt()
	}
  }