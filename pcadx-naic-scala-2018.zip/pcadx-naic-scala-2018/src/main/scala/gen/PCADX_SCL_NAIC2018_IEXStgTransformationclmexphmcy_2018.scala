package gen

import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit

// Create this class for 2018 Requirement
class PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_2018(val spark: SparkSession) {

  var year = ""
  val dbProperties = new Properties

  import spark.implicits._

  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy])
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clmex")
  val end_year = dbProperties.getProperty("end_year_clmex")

  var naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame = null
  var naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame = null

  // New Looked up Tables-2018 @12/21/2018
  var naic2018_mcas_ce_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd: DataFrame = null
  var naic2018_mcas_ce_src_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_ncb_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd: DataFrame = null
  var naic2018_mcas_ncb_src_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_nmn_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame = null
  var naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_nmnbh_hlth_srvc_cd_inbnd: DataFrame = null
  var naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame = null
  var naic2018_mcas_nmnbh_icd_proc_cd_inbnd: DataFrame = null
  var naic2018_mcas_pa_eob_cd_inbnd: DataFrame = null
  var naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd: DataFrame = null
  var naic2018_mcas_pa_src_eob_cd_inbnd: DataFrame = null

  def sparkInIt() {

    naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk")
    naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk")
    naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk = readDataFromHive(dbwrk + ".naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk")

    naic2018_mcas_ce_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_ce_eob_cd_inbnd")
    naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd")
    naic2018_mcas_ce_src_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_ce_src_eob_cd_inbnd")
    naic2018_mcas_ncb_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_ncb_eob_cd_inbnd")
    naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd")
    naic2018_mcas_ncb_src_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_ncb_src_eob_cd_inbnd")
    naic2018_mcas_nmn_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_nmn_eob_cd_inbnd")
    naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd")
    naic2018_mcas_nmn_src_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_nmn_src_eob_cd_inbnd")
    naic2018_mcas_nmnbh_hlth_srvc_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_nmnbh_hlth_srvc_cd_inbnd")
    naic2018_mcas_nmnbh_icd_diag_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_nmnbh_icd_diag_cd_inbnd")
    naic2018_mcas_nmnbh_icd_proc_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_nmnbh_icd_proc_cd_inbnd")
    naic2018_mcas_pa_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_pa_eob_cd_inbnd")
    naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd")
    naic2018_mcas_pa_src_eob_cd_inbnd = readDataFromHive(dbwrk + ".naic2018_mcas_pa_src_eob_cd_inbnd")

    spark.close()
  }

  def truncateTbl(tblName: String) {
    spark.sql("TRUNCATE TABLE " + tblName)
  }

  def writeDataToHive(tblName: String, finalDf: DataFrame) {
    finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
    println("Data added in stage table")
  }

  def readDataFromHive(tble: String): DataFrame = {
    val queryOutputTable = """SELECT * FROM """ + tble
    val tbl_data_df = spark.sql(queryOutputTable) //.na.fill("")
    logger.info("Read data from hive")

    tbl_data_df
  }

  def getIpSgpPlan(wrk_df: DataFrame, lob_type: String): DataFrame = {
    val metl_cd = Seq("01", "02", "03", "04")
    val ip_df = wrk_df.filter($"naic_lob".equalTo(lob_type) &&
      ($"grndfthr_ind_cd".notEqual("YES") || $"grndfthr_ind_cd".isNull) &&
      $"hcr_cmplynt_cd".equalTo("Y") &&
      ($"src_exchng_certfn_cd".notEqual("M") || $"src_exchng_certfn_cd".isNull) &&
      $"exchng_metl_type_cd".isin(metl_cd: _*) &&
      $"in_exchange".equalTo("IN"))

    ip_df
  }

  def getMSPlan(wrk_df: DataFrame, lob_type: String): DataFrame = {
    val metl_cd = Seq("01", "02", "03", "04")
    val msip_df = wrk_df.filter($"naic_lob".equalTo(lob_type) &&
      $"src_exchng_certfn_cd".equalTo("M") &&
      $"exchng_metl_type_cd".isin(metl_cd: _*) && //263
      $"in_exchange".equalTo("IN"))

    msip_df
  }

  def joinedDf2018(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, src_eob_cd_inbnd: DataFrame, eob_cd_inbnd: DataFrame, src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    val joined_df = naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.alias("received_wrk")
      .join(
        src_eob_cd_inbnd.alias("sec"),
        $"received_wrk.src_eob_cd" === $"sec.src_eob_cd" &&
          $"received_wrk.clm_sor_cd" === $"sec.clm_sor_cd", "left_outer")
      .join(
        eob_cd_inbnd.alias("chip"),
        $"received_wrk.eob_cd" === $"chip.eob_cd" &&
          $"received_wrk.clm_sor_cd" === $"chip.clm_sor_cd", "left_outer")
      .join(
        src_clm_line_disp_rsn_cd_inbnd.alias("aces"),
        $"received_wrk.src_clm_line_disp_rsn_cd" === $"aces.src_clm_line_disp_rsn_cd" &&
          $"received_wrk.clm_sor_cd" === $"aces.clm_sor_cd", "left_outer")
      .filter(($"sec.src_eob_cd".isNotNull && $"sec.clm_sor_cd".isNotNull) ||
        ($"chip.eob_cd".isNotNull && $"chip.clm_sor_cd".isNotNull) ||
        ($"aces.src_clm_line_disp_rsn_cd".isNotNull && $"aces.clm_sor_cd".isNotNull))

    joined_df
  }

  def joinedDfEbh(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_eob_cd_inbnd: DataFrame, 
      naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame, naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame): DataFrame = {

    val joined_df = naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.alias("received_wrk")
      .join(
        naic2018_mcas_nmn_src_eob_cd_inbnd.alias("sec"),
        $"received_wrk.src_eob_cd" === $"sec.src_eob_cd" &&
          $"received_wrk.clm_sor_cd" === $"sec.clm_sor_cd", "left_outer")
      .join(
        naic2018_mcas_nmn_eob_cd_inbnd.alias("chip"),
        $"received_wrk.eob_cd" === $"chip.eob_cd" &&
          $"received_wrk.clm_sor_cd" === $"chip.clm_sor_cd", "left_outer")
      .join(
        naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd.alias("aces"),
        $"received_wrk.src_clm_line_disp_rsn_cd" === $"aces.src_clm_line_disp_rsn_cd" &&
          $"received_wrk.clm_sor_cd" === $"aces.clm_sor_cd", "left_outer")
      .join(
        naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc1"),
        $"received_wrk.diag_1_cd" === $"idc1.icd_diag_cd", "left_outer")
       
//       Commented on 15/02/2019       
//      .join(
//        naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc2"),
//        $"received_wrk.diag_2_cd" === $"idc2.icd_diag_cd", "left_outer")
//      .join(
//        naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc3"),
//        $"received_wrk.diag_3_cd" === $"idc3.icd_diag_cd", "left_outer")
//      .join(
//        naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc4"),
//        $"received_wrk.diag_4_cd" === $"idc4.icd_diag_cd", "left_outer")
//      .join(
//        naic2018_mcas_nmnbh_icd_proc_cd_inbnd.alias("ipc"),
//        $"received_wrk.icd_proc_cd" === $"ipc.icd_proc_cd", "left_outer")
//      .join(
//        naic2018_mcas_nmnbh_hlth_srvc_cd_inbnd.alias("hsc"),
//        $"received_wrk.hlth_srvc_cd" === $"hsc.hlth_srvc_cd", "left_outer")
        
      .filter((($"sec.src_eob_cd".isNotNull && $"sec.clm_sor_cd".isNotNull) ||
        ($"chip.eob_cd".isNotNull && $"chip.clm_sor_cd".isNotNull) ||
        ($"aces.src_clm_line_disp_rsn_cd".isNotNull && $"aces.clm_sor_cd".isNotNull)) &&
        $"idc1.icd_diag_cd".isNull 
        )

    joined_df
  }

  def joinedDfbh(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_eob_cd_inbnd: DataFrame, 
      naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame, naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame ): DataFrame = {

    val joined_df = naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk.alias("received_wrk").join(
      naic2018_mcas_nmn_src_eob_cd_inbnd.alias("sec"),
      $"received_wrk.src_eob_cd" === $"sec.src_eob_cd" &&
        $"received_wrk.clm_sor_cd" === $"sec.clm_sor_cd", "left_outer")
      .join(
        naic2018_mcas_nmn_eob_cd_inbnd.alias("chip"),
        $"received_wrk.eob_cd" === $"chip.eob_cd" &&
          $"received_wrk.clm_sor_cd" === $"chip.clm_sor_cd", "left_outer")
      .join(
        naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd.alias("aces"),
        $"received_wrk.src_clm_line_disp_rsn_cd" === $"aces.src_clm_line_disp_rsn_cd" &&
          $"received_wrk.clm_sor_cd" === $"aces.clm_sor_cd", "left_outer")
      .join(
        naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc1"),
        $"received_wrk.diag_1_cd" === $"idc1.icd_diag_cd", "left_outer")
      
/*      Commented om 15/02/2019
      .join(
        naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc2"),
        $"received_wrk.diag_2_cd" === $"idc2.icd_diag_cd", "left_outer")
      .join(
        naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc3"),
        $"received_wrk.diag_3_cd" === $"idc3.icd_diag_cd", "left_outer")
      .join(
        naic2018_mcas_nmnbh_icd_diag_cd_inbnd.alias("idc4"),
        $"received_wrk.diag_4_cd" === $"idc4.icd_diag_cd", "left_outer")
      .join(
        naic2018_mcas_nmnbh_icd_proc_cd_inbnd.alias("ipc"),
        $"received_wrk.icd_proc_cd" === $"ipc.icd_proc_cd", "left_outer")
      .join(
        naic2018_mcas_nmnbh_hlth_srvc_cd_inbnd.alias("hsc"),
        $"received_wrk.hlth_srvc_cd" === $"hsc.hlth_srvc_cd", "left_outer")
        */
      .filter((($"sec.src_eob_cd".isNotNull && $"sec.clm_sor_cd".isNotNull) || 
               ($"chip.eob_cd".isNotNull && $"chip.clm_sor_cd".isNotNull) ||
               ($"aces.src_clm_line_disp_rsn_cd".isNotNull && $"aces.clm_sor_cd".isNotNull)) &&
               $"idc1.icd_diag_cd".isNotNull
             )

    joined_df
  }

  def getDeniedInntwkce(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame,
                        naic2018_mcas_ce_src_eob_cd_inbnd: DataFrame, naic2018_mcas_ce_eob_cd_inbnd: DataFrame, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_brz = joinedDf2018(received_brnz, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sil = joinedDf2018(received_silver, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_ce_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_ce_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip")

    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gld = joinedDf2018(received_gold, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_plt = joinedDf2018(received_platinum, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_ce_bronze_ip.union(nbrclm_denied_inntwk_ce_silver_ip.union(nbrclm_denied_inntwk_ce_gold_ip.union(nbrclm_denied_inntwk_ce_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_ce_bronze_ip")

    val nbrclm_denied_inntwk_ce_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_ce_bronze_ip").alias("nbrclm_denied_inntwk_ce_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_brz = joinedDf2018(received_sgp_bronze, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_sil = joinedDf2018(received_sgp_silver, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_gld = joinedDf2018(received_sgp_gold, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_plt = joinedDf2018(received_sgp_plt, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"), col("nbrclm_denied_inntwk_ce_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp", "nbrclm_denied_inntwk_ce_platinum_sgp")

    val tot_sgp = nbrclm_denied_inntwk_ce_bronze_sgp.union(nbrclm_denied_inntwk_ce_silver_sgp.union(nbrclm_denied_inntwk_ce_gold_sgp.union(nbrclm_denied_inntwk_ce_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_ce_bronze_sgp")

    val nbrclm_denied_inntwk_ce_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_ce_bronze_sgp").alias("nbrclm_denied_inntwk_ce_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"), col("nbrclm_denied_inntwk_ce_platinum_sgp"), col("nbrclm_denied_inntwk_ce_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp", "nbrclm_denied_inntwk_ce_platinum_sgp", "nbrclm_denied_inntwk_ce_total_sgp")

    val receivedCatFilters = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_cat = joinedDf2018(receivedCatFilters, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"), col("nbrclm_denied_inntwk_ce_platinum_sgp"), col("nbrclm_denied_inntwk_ce_total_sgp"), col("nbrclm_denied_inntwk_ce_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp", "nbrclm_denied_inntwk_ce_platinum_sgp", "nbrclm_denied_inntwk_ce_total_sgp", "nbrclm_denied_inntwk_ce_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_brz = joinedDf2018(received_msip_Brz, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_bronze_ms_ip = denied_in_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"), col("nbrclm_denied_inntwk_ce_platinum_sgp"), col("nbrclm_denied_inntwk_ce_total_sgp"), col("nbrclm_denied_inntwk_ce_catastrophic"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp", "nbrclm_denied_inntwk_ce_platinum_sgp", "nbrclm_denied_inntwk_ce_total_sgp", "nbrclm_denied_inntwk_ce_catastrophic",
        "nbrclm_denied_inntwk_ce_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_sil = joinedDf2018(received_msip_Sil, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_silver_ms_ip = denied_in_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"), col("nbrclm_denied_inntwk_ce_platinum_sgp"), col("nbrclm_denied_inntwk_ce_total_sgp"), col("nbrclm_denied_inntwk_ce_catastrophic"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_ip"), col("nbrclm_denied_inntwk_ce_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp", "nbrclm_denied_inntwk_ce_platinum_sgp", "nbrclm_denied_inntwk_ce_total_sgp", "nbrclm_denied_inntwk_ce_catastrophic",
        "nbrclm_denied_inntwk_ce_bronze_ms_ip", "nbrclm_denied_inntwk_ce_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_gld = joinedDf2018(received_msip_Gld, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_gold_ms_ip = denied_in_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"), col("nbrclm_denied_inntwk_ce_platinum_sgp"), col("nbrclm_denied_inntwk_ce_total_sgp"), col("nbrclm_denied_inntwk_ce_catastrophic"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_ip"), col("nbrclm_denied_inntwk_ce_silver_ms_ip"), col("nbrclm_denied_inntwk_ce_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp", "nbrclm_denied_inntwk_ce_platinum_sgp", "nbrclm_denied_inntwk_ce_total_sgp", "nbrclm_denied_inntwk_ce_catastrophic",
        "nbrclm_denied_inntwk_ce_bronze_ms_ip", "nbrclm_denied_inntwk_ce_silver_ms_ip", "nbrclm_denied_inntwk_ce_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_plt = joinedDf2018(received_msip_Plt, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_platinum_ms_ip = denied_in_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"), col("nbrclm_denied_inntwk_ce_platinum_sgp"), col("nbrclm_denied_inntwk_ce_total_sgp"), col("nbrclm_denied_inntwk_ce_catastrophic"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_ip"), col("nbrclm_denied_inntwk_ce_silver_ms_ip"), col("nbrclm_denied_inntwk_ce_gold_ms_ip"), col("nbrclm_denied_inntwk_ce_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp", "nbrclm_denied_inntwk_ce_platinum_sgp", "nbrclm_denied_inntwk_ce_total_sgp", "nbrclm_denied_inntwk_ce_catastrophic",
        "nbrclm_denied_inntwk_ce_bronze_ms_ip", "nbrclm_denied_inntwk_ce_silver_ms_ip", "nbrclm_denied_inntwk_ce_gold_ms_ip", "nbrclm_denied_inntwk_ce_platinum_ms_ip")

    val tot_msip = nbrclm_denied_inntwk_ce_bronze_ms_ip.union(nbrclm_denied_inntwk_ce_silver_ms_ip.union(nbrclm_denied_inntwk_ce_gold_ms_ip.union(nbrclm_denied_inntwk_ce_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_ce_bronze_ms_ip")

    val nbrclm_denied_inntwk_ce_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_ce_bronze_ms_ip").alias("nbrclm_denied_inntwk_ce_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"), col("nbrclm_denied_inntwk_ce_platinum_sgp"), col("nbrclm_denied_inntwk_ce_total_sgp"), col("nbrclm_denied_inntwk_ce_catastrophic"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_ip"), col("nbrclm_denied_inntwk_ce_silver_ms_ip"), col("nbrclm_denied_inntwk_ce_gold_ms_ip"), col("nbrclm_denied_inntwk_ce_platinum_ms_ip"), col("nbrclm_denied_inntwk_ce_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp", "nbrclm_denied_inntwk_ce_platinum_sgp", "nbrclm_denied_inntwk_ce_total_sgp", "nbrclm_denied_inntwk_ce_catastrophic",
        "nbrclm_denied_inntwk_ce_bronze_ms_ip", "nbrclm_denied_inntwk_ce_silver_ms_ip", "nbrclm_denied_inntwk_ce_gold_ms_ip", "nbrclm_denied_inntwk_ce_platinum_ms_ip", "nbrclm_denied_inntwk_ce_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_brz = joinedDf2018(received_mssgp_Brz, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_bronze_ms_sgp = denied_in_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"), col("nbrclm_denied_inntwk_ce_platinum_sgp"), col("nbrclm_denied_inntwk_ce_total_sgp"), col("nbrclm_denied_inntwk_ce_catastrophic"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_ip"), col("nbrclm_denied_inntwk_ce_silver_ms_ip"), col("nbrclm_denied_inntwk_ce_gold_ms_ip"), col("nbrclm_denied_inntwk_ce_platinum_ms_ip"), col("nbrclm_denied_inntwk_ce_total_ms_ip"), col("nbrclm_denied_inntwk_ce_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp", "nbrclm_denied_inntwk_ce_platinum_sgp", "nbrclm_denied_inntwk_ce_total_sgp", "nbrclm_denied_inntwk_ce_catastrophic",
        "nbrclm_denied_inntwk_ce_bronze_ms_ip", "nbrclm_denied_inntwk_ce_silver_ms_ip", "nbrclm_denied_inntwk_ce_gold_ms_ip", "nbrclm_denied_inntwk_ce_platinum_ms_ip", "nbrclm_denied_inntwk_ce_total_ms_ip",
        "nbrclm_denied_inntwk_ce_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_sil = joinedDf2018(received_mssgp_Sil, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_silver_ms_sgp = denied_in_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"), col("nbrclm_denied_inntwk_ce_platinum_sgp"), col("nbrclm_denied_inntwk_ce_total_sgp"), col("nbrclm_denied_inntwk_ce_catastrophic"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_ip"), col("nbrclm_denied_inntwk_ce_silver_ms_ip"), col("nbrclm_denied_inntwk_ce_gold_ms_ip"), col("nbrclm_denied_inntwk_ce_platinum_ms_ip"), col("nbrclm_denied_inntwk_ce_total_ms_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_sgp"), col("nbrclm_denied_inntwk_ce_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp", "nbrclm_denied_inntwk_ce_platinum_sgp", "nbrclm_denied_inntwk_ce_total_sgp", "nbrclm_denied_inntwk_ce_catastrophic",
        "nbrclm_denied_inntwk_ce_bronze_ms_ip", "nbrclm_denied_inntwk_ce_silver_ms_ip", "nbrclm_denied_inntwk_ce_gold_ms_ip", "nbrclm_denied_inntwk_ce_platinum_ms_ip", "nbrclm_denied_inntwk_ce_total_ms_ip",
        "nbrclm_denied_inntwk_ce_bronze_ms_sgp", "nbrclm_denied_inntwk_ce_silver_ms_sgp")

    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_gld = joinedDf2018(received_mssgp_Gld, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_gold_ms_sgp = denied_in_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"), col("nbrclm_denied_inntwk_ce_platinum_sgp"), col("nbrclm_denied_inntwk_ce_total_sgp"), col("nbrclm_denied_inntwk_ce_catastrophic"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_ip"), col("nbrclm_denied_inntwk_ce_silver_ms_ip"), col("nbrclm_denied_inntwk_ce_gold_ms_ip"), col("nbrclm_denied_inntwk_ce_platinum_ms_ip"), col("nbrclm_denied_inntwk_ce_total_ms_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_sgp"), col("nbrclm_denied_inntwk_ce_silver_ms_sgp"), col("nbrclm_denied_inntwk_ce_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp", "nbrclm_denied_inntwk_ce_platinum_sgp", "nbrclm_denied_inntwk_ce_total_sgp", "nbrclm_denied_inntwk_ce_catastrophic",
        "nbrclm_denied_inntwk_ce_bronze_ms_ip", "nbrclm_denied_inntwk_ce_silver_ms_ip", "nbrclm_denied_inntwk_ce_gold_ms_ip", "nbrclm_denied_inntwk_ce_platinum_ms_ip", "nbrclm_denied_inntwk_ce_total_ms_ip",
        "nbrclm_denied_inntwk_ce_bronze_ms_sgp", "nbrclm_denied_inntwk_ce_silver_ms_sgp", "nbrclm_denied_inntwk_ce_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_plt = joinedDf2018(received_mssgp_Plt, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ce_platinum_ms_sgp = denied_in_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ce_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"), col("nbrclm_denied_inntwk_ce_platinum_sgp"), col("nbrclm_denied_inntwk_ce_total_sgp"), col("nbrclm_denied_inntwk_ce_catastrophic"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_ip"), col("nbrclm_denied_inntwk_ce_silver_ms_ip"), col("nbrclm_denied_inntwk_ce_gold_ms_ip"), col("nbrclm_denied_inntwk_ce_platinum_ms_ip"), col("nbrclm_denied_inntwk_ce_total_ms_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_sgp"), col("nbrclm_denied_inntwk_ce_silver_ms_sgp"), col("nbrclm_denied_inntwk_ce_gold_ms_sgp"), col("nbrclm_denied_inntwk_ce_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp", "nbrclm_denied_inntwk_ce_platinum_sgp", "nbrclm_denied_inntwk_ce_total_sgp", "nbrclm_denied_inntwk_ce_catastrophic",
        "nbrclm_denied_inntwk_ce_bronze_ms_ip", "nbrclm_denied_inntwk_ce_silver_ms_ip", "nbrclm_denied_inntwk_ce_gold_ms_ip", "nbrclm_denied_inntwk_ce_platinum_ms_ip", "nbrclm_denied_inntwk_ce_total_ms_ip",
        "nbrclm_denied_inntwk_ce_bronze_ms_sgp", "nbrclm_denied_inntwk_ce_silver_ms_sgp", "nbrclm_denied_inntwk_ce_gold_ms_sgp", "nbrclm_denied_inntwk_ce_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_inntwk_ce_bronze_ms_sgp.union(nbrclm_denied_inntwk_ce_silver_ms_sgp.union(nbrclm_denied_inntwk_ce_gold_ms_sgp.union(nbrclm_denied_inntwk_ce_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_ce_bronze_ms_sgp")

    val nbrclm_denied_inntwk_ce_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_ce_bronze_ms_sgp").alias("nbrclm_denied_inntwk_ce_total_ms_sgp"))

    val denied_inntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_inntwk_ce_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ce_bronze_ip"), col("nbrclm_denied_inntwk_ce_silver_ip"), col("nbrclm_denied_inntwk_ce_gold_ip"), col("nbrclm_denied_inntwk_ce_platinum_ip"), col("nbrclm_denied_inntwk_ce_total_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_sgp"), col("nbrclm_denied_inntwk_ce_silver_sgp"), col("nbrclm_denied_inntwk_ce_gold_sgp"), col("nbrclm_denied_inntwk_ce_platinum_sgp"), col("nbrclm_denied_inntwk_ce_total_sgp"), col("nbrclm_denied_inntwk_ce_catastrophic"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_ip"), col("nbrclm_denied_inntwk_ce_silver_ms_ip"), col("nbrclm_denied_inntwk_ce_gold_ms_ip"), col("nbrclm_denied_inntwk_ce_platinum_ms_ip"), col("nbrclm_denied_inntwk_ce_total_ms_ip"),
        col("nbrclm_denied_inntwk_ce_bronze_ms_sgp"), col("nbrclm_denied_inntwk_ce_silver_ms_sgp"), col("nbrclm_denied_inntwk_ce_gold_ms_sgp"), col("nbrclm_denied_inntwk_ce_platinum_ms_sgp"), col("nbrclm_denied_inntwk_ce_total_ms_sgp"))

    val denied_inntwk_Data_ce = denied_inntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ce_bronze_ip", "nbrclm_denied_inntwk_ce_silver_ip", "nbrclm_denied_inntwk_ce_gold_ip", "nbrclm_denied_inntwk_ce_platinum_ip", "nbrclm_denied_inntwk_ce_total_ip",
        "nbrclm_denied_inntwk_ce_bronze_sgp", "nbrclm_denied_inntwk_ce_silver_sgp", "nbrclm_denied_inntwk_ce_gold_sgp", "nbrclm_denied_inntwk_ce_platinum_sgp", "nbrclm_denied_inntwk_ce_total_sgp", "nbrclm_denied_inntwk_ce_catastrophic",
        "nbrclm_denied_inntwk_ce_bronze_ms_ip", "nbrclm_denied_inntwk_ce_silver_ms_ip", "nbrclm_denied_inntwk_ce_gold_ms_ip", "nbrclm_denied_inntwk_ce_platinum_ms_ip", "nbrclm_denied_inntwk_ce_total_ms_ip",
        "nbrclm_denied_inntwk_ce_bronze_ms_sgp", "nbrclm_denied_inntwk_ce_silver_ms_sgp", "nbrclm_denied_inntwk_ce_gold_ms_sgp", "nbrclm_denied_inntwk_ce_platinum_ms_sgp", "nbrclm_denied_inntwk_ce_total_ms_sgp")

    denied_inntwk_Data_ce

  }

  def getDeniedInntwkpa(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame, naic2018_mcas_pa_eob_cd_inbnd: DataFrame, naic2018_mcas_pa_src_eob_cd_inbnd: DataFrame, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_brz = joinedDf2018(received_brnz, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sil = joinedDf2018(received_silver, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_pa_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_pa_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip")

    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gld = joinedDf2018(received_gold, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_plt = joinedDf2018(received_platinum, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_pa_bronze_ip.union(nbrclm_denied_inntwk_pa_silver_ip.union(nbrclm_denied_inntwk_pa_gold_ip.union(nbrclm_denied_inntwk_pa_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_pa_bronze_ip")

    val nbrclm_denied_inntwk_pa_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_pa_bronze_ip").alias("nbrclm_denied_inntwk_pa_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_brz = joinedDf2018(received_sgp_bronze, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_sil = joinedDf2018(received_sgp_silver, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_gld = joinedDf2018(received_sgp_gold, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_plt = joinedDf2018(received_sgp_plt, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"), col("nbrclm_denied_inntwk_pa_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp", "nbrclm_denied_inntwk_pa_platinum_sgp")

    val tot_sgp = nbrclm_denied_inntwk_pa_bronze_sgp.union(nbrclm_denied_inntwk_pa_silver_sgp.union(nbrclm_denied_inntwk_pa_gold_sgp.union(nbrclm_denied_inntwk_pa_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_pa_bronze_sgp")

    val nbrclm_denied_inntwk_pa_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_pa_bronze_sgp").alias("nbrclm_denied_inntwk_pa_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"), col("nbrclm_denied_inntwk_pa_platinum_sgp"), col("nbrclm_denied_inntwk_pa_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp", "nbrclm_denied_inntwk_pa_platinum_sgp", "nbrclm_denied_inntwk_pa_total_sgp")

    val receivedCatFilters = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_cat = joinedDf2018(receivedCatFilters, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"), col("nbrclm_denied_inntwk_pa_platinum_sgp"), col("nbrclm_denied_inntwk_pa_total_sgp"), col("nbrclm_denied_inntwk_pa_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp", "nbrclm_denied_inntwk_pa_platinum_sgp", "nbrclm_denied_inntwk_pa_total_sgp", "nbrclm_denied_inntwk_pa_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_brz = joinedDf2018(received_msip_Brz, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_bronze_ms_ip = denied_in_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"), col("nbrclm_denied_inntwk_pa_platinum_sgp"), col("nbrclm_denied_inntwk_pa_total_sgp"), col("nbrclm_denied_inntwk_pa_catastrophic"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp", "nbrclm_denied_inntwk_pa_platinum_sgp", "nbrclm_denied_inntwk_pa_total_sgp", "nbrclm_denied_inntwk_pa_catastrophic",
        "nbrclm_denied_inntwk_pa_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_sil = joinedDf2018(received_msip_Sil, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_silver_ms_ip = denied_in_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"), col("nbrclm_denied_inntwk_pa_platinum_sgp"), col("nbrclm_denied_inntwk_pa_total_sgp"), col("nbrclm_denied_inntwk_pa_catastrophic"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_ip"), col("nbrclm_denied_inntwk_pa_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp", "nbrclm_denied_inntwk_pa_platinum_sgp", "nbrclm_denied_inntwk_pa_total_sgp", "nbrclm_denied_inntwk_pa_catastrophic",
        "nbrclm_denied_inntwk_pa_bronze_ms_ip", "nbrclm_denied_inntwk_pa_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_gld = joinedDf2018(received_msip_Gld, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_gold_ms_ip = denied_in_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"), col("nbrclm_denied_inntwk_pa_platinum_sgp"), col("nbrclm_denied_inntwk_pa_total_sgp"), col("nbrclm_denied_inntwk_pa_catastrophic"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_ip"), col("nbrclm_denied_inntwk_pa_silver_ms_ip"), col("nbrclm_denied_inntwk_pa_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp", "nbrclm_denied_inntwk_pa_platinum_sgp", "nbrclm_denied_inntwk_pa_total_sgp", "nbrclm_denied_inntwk_pa_catastrophic",
        "nbrclm_denied_inntwk_pa_bronze_ms_ip", "nbrclm_denied_inntwk_pa_silver_ms_ip", "nbrclm_denied_inntwk_pa_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_plt = joinedDf2018(received_msip_Plt, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_platinum_ms_ip = denied_in_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"), col("nbrclm_denied_inntwk_pa_platinum_sgp"), col("nbrclm_denied_inntwk_pa_total_sgp"), col("nbrclm_denied_inntwk_pa_catastrophic"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_ip"), col("nbrclm_denied_inntwk_pa_silver_ms_ip"), col("nbrclm_denied_inntwk_pa_gold_ms_ip"), col("nbrclm_denied_inntwk_pa_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp", "nbrclm_denied_inntwk_pa_platinum_sgp", "nbrclm_denied_inntwk_pa_total_sgp", "nbrclm_denied_inntwk_pa_catastrophic",
        "nbrclm_denied_inntwk_pa_bronze_ms_ip", "nbrclm_denied_inntwk_pa_silver_ms_ip", "nbrclm_denied_inntwk_pa_gold_ms_ip", "nbrclm_denied_inntwk_pa_platinum_ms_ip")

    val tot_msip = nbrclm_denied_inntwk_pa_bronze_ms_ip.union(nbrclm_denied_inntwk_pa_silver_ms_ip.union(nbrclm_denied_inntwk_pa_gold_ms_ip.union(nbrclm_denied_inntwk_pa_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_pa_bronze_ms_ip")

    val nbrclm_denied_inntwk_pa_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_pa_bronze_ms_ip").alias("nbrclm_denied_inntwk_pa_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"), col("nbrclm_denied_inntwk_pa_platinum_sgp"), col("nbrclm_denied_inntwk_pa_total_sgp"), col("nbrclm_denied_inntwk_pa_catastrophic"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_ip"), col("nbrclm_denied_inntwk_pa_silver_ms_ip"), col("nbrclm_denied_inntwk_pa_gold_ms_ip"), col("nbrclm_denied_inntwk_pa_platinum_ms_ip"), col("nbrclm_denied_inntwk_pa_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp", "nbrclm_denied_inntwk_pa_platinum_sgp", "nbrclm_denied_inntwk_pa_total_sgp", "nbrclm_denied_inntwk_pa_catastrophic",
        "nbrclm_denied_inntwk_pa_bronze_ms_ip", "nbrclm_denied_inntwk_pa_silver_ms_ip", "nbrclm_denied_inntwk_pa_gold_ms_ip", "nbrclm_denied_inntwk_pa_platinum_ms_ip", "nbrclm_denied_inntwk_pa_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_brz = joinedDf2018(received_mssgp_Brz, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_bronze_ms_sgp = denied_in_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"), col("nbrclm_denied_inntwk_pa_platinum_sgp"), col("nbrclm_denied_inntwk_pa_total_sgp"), col("nbrclm_denied_inntwk_pa_catastrophic"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_ip"), col("nbrclm_denied_inntwk_pa_silver_ms_ip"), col("nbrclm_denied_inntwk_pa_gold_ms_ip"), col("nbrclm_denied_inntwk_pa_platinum_ms_ip"), col("nbrclm_denied_inntwk_pa_total_ms_ip"), col("nbrclm_denied_inntwk_pa_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp", "nbrclm_denied_inntwk_pa_platinum_sgp", "nbrclm_denied_inntwk_pa_total_sgp", "nbrclm_denied_inntwk_pa_catastrophic",
        "nbrclm_denied_inntwk_pa_bronze_ms_ip", "nbrclm_denied_inntwk_pa_silver_ms_ip", "nbrclm_denied_inntwk_pa_gold_ms_ip", "nbrclm_denied_inntwk_pa_platinum_ms_ip", "nbrclm_denied_inntwk_pa_total_ms_ip",
        "nbrclm_denied_inntwk_pa_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_sil = joinedDf2018(received_mssgp_Sil, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_silver_ms_sgp = denied_in_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"), col("nbrclm_denied_inntwk_pa_platinum_sgp"), col("nbrclm_denied_inntwk_pa_total_sgp"), col("nbrclm_denied_inntwk_pa_catastrophic"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_ip"), col("nbrclm_denied_inntwk_pa_silver_ms_ip"), col("nbrclm_denied_inntwk_pa_gold_ms_ip"), col("nbrclm_denied_inntwk_pa_platinum_ms_ip"), col("nbrclm_denied_inntwk_pa_total_ms_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_sgp"), col("nbrclm_denied_inntwk_pa_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp", "nbrclm_denied_inntwk_pa_platinum_sgp", "nbrclm_denied_inntwk_pa_total_sgp", "nbrclm_denied_inntwk_pa_catastrophic",
        "nbrclm_denied_inntwk_pa_bronze_ms_ip", "nbrclm_denied_inntwk_pa_silver_ms_ip", "nbrclm_denied_inntwk_pa_gold_ms_ip", "nbrclm_denied_inntwk_pa_platinum_ms_ip", "nbrclm_denied_inntwk_pa_total_ms_ip",
        "nbrclm_denied_inntwk_pa_bronze_ms_sgp", "nbrclm_denied_inntwk_pa_silver_ms_sgp")

    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_gld = joinedDf2018(received_mssgp_Gld, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_gold_ms_sgp = denied_in_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"), col("nbrclm_denied_inntwk_pa_platinum_sgp"), col("nbrclm_denied_inntwk_pa_total_sgp"), col("nbrclm_denied_inntwk_pa_catastrophic"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_ip"), col("nbrclm_denied_inntwk_pa_silver_ms_ip"), col("nbrclm_denied_inntwk_pa_gold_ms_ip"), col("nbrclm_denied_inntwk_pa_platinum_ms_ip"), col("nbrclm_denied_inntwk_pa_total_ms_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_sgp"), col("nbrclm_denied_inntwk_pa_silver_ms_sgp"), col("nbrclm_denied_inntwk_pa_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp", "nbrclm_denied_inntwk_pa_platinum_sgp", "nbrclm_denied_inntwk_pa_total_sgp", "nbrclm_denied_inntwk_pa_catastrophic",
        "nbrclm_denied_inntwk_pa_bronze_ms_ip", "nbrclm_denied_inntwk_pa_silver_ms_ip", "nbrclm_denied_inntwk_pa_gold_ms_ip", "nbrclm_denied_inntwk_pa_platinum_ms_ip", "nbrclm_denied_inntwk_pa_total_ms_ip",
        "nbrclm_denied_inntwk_pa_bronze_ms_sgp", "nbrclm_denied_inntwk_pa_silver_ms_sgp", "nbrclm_denied_inntwk_pa_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_plt = joinedDf2018(received_mssgp_Plt, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_pa_platinum_ms_sgp = denied_in_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_pa_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"), col("nbrclm_denied_inntwk_pa_platinum_sgp"), col("nbrclm_denied_inntwk_pa_total_sgp"), col("nbrclm_denied_inntwk_pa_catastrophic"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_ip"), col("nbrclm_denied_inntwk_pa_silver_ms_ip"), col("nbrclm_denied_inntwk_pa_gold_ms_ip"), col("nbrclm_denied_inntwk_pa_platinum_ms_ip"), col("nbrclm_denied_inntwk_pa_total_ms_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_sgp"), col("nbrclm_denied_inntwk_pa_silver_ms_sgp"), col("nbrclm_denied_inntwk_pa_gold_ms_sgp"), col("nbrclm_denied_inntwk_pa_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp", "nbrclm_denied_inntwk_pa_platinum_sgp", "nbrclm_denied_inntwk_pa_total_sgp", "nbrclm_denied_inntwk_pa_catastrophic",
        "nbrclm_denied_inntwk_pa_bronze_ms_ip", "nbrclm_denied_inntwk_pa_silver_ms_ip", "nbrclm_denied_inntwk_pa_gold_ms_ip", "nbrclm_denied_inntwk_pa_platinum_ms_ip", "nbrclm_denied_inntwk_pa_total_ms_ip",
        "nbrclm_denied_inntwk_pa_bronze_ms_sgp", "nbrclm_denied_inntwk_pa_silver_ms_sgp", "nbrclm_denied_inntwk_pa_gold_ms_sgp", "nbrclm_denied_inntwk_pa_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_inntwk_pa_bronze_ms_sgp.union(nbrclm_denied_inntwk_pa_silver_ms_sgp.union(nbrclm_denied_inntwk_pa_gold_ms_sgp.union(nbrclm_denied_inntwk_pa_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_pa_bronze_ms_sgp")

    val nbrclm_denied_inntwk_pa_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_pa_bronze_ms_sgp").alias("nbrclm_denied_inntwk_pa_total_ms_sgp"))

    val denied_inntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_inntwk_pa_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_pa_bronze_ip"), col("nbrclm_denied_inntwk_pa_silver_ip"), col("nbrclm_denied_inntwk_pa_gold_ip"), col("nbrclm_denied_inntwk_pa_platinum_ip"), col("nbrclm_denied_inntwk_pa_total_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_sgp"), col("nbrclm_denied_inntwk_pa_silver_sgp"), col("nbrclm_denied_inntwk_pa_gold_sgp"), col("nbrclm_denied_inntwk_pa_platinum_sgp"), col("nbrclm_denied_inntwk_pa_total_sgp"), col("nbrclm_denied_inntwk_pa_catastrophic"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_ip"), col("nbrclm_denied_inntwk_pa_silver_ms_ip"), col("nbrclm_denied_inntwk_pa_gold_ms_ip"), col("nbrclm_denied_inntwk_pa_platinum_ms_ip"), col("nbrclm_denied_inntwk_pa_total_ms_ip"),
        col("nbrclm_denied_inntwk_pa_bronze_ms_sgp"), col("nbrclm_denied_inntwk_pa_silver_ms_sgp"), col("nbrclm_denied_inntwk_pa_gold_ms_sgp"), col("nbrclm_denied_inntwk_pa_platinum_ms_sgp"), col("nbrclm_denied_inntwk_pa_total_ms_sgp"))

    val denied_inntwk_Data_pa = denied_inntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_pa_bronze_ip", "nbrclm_denied_inntwk_pa_silver_ip", "nbrclm_denied_inntwk_pa_gold_ip", "nbrclm_denied_inntwk_pa_platinum_ip", "nbrclm_denied_inntwk_pa_total_ip",
        "nbrclm_denied_inntwk_pa_bronze_sgp", "nbrclm_denied_inntwk_pa_silver_sgp", "nbrclm_denied_inntwk_pa_gold_sgp", "nbrclm_denied_inntwk_pa_platinum_sgp", "nbrclm_denied_inntwk_pa_total_sgp", "nbrclm_denied_inntwk_pa_catastrophic",
        "nbrclm_denied_inntwk_pa_bronze_ms_ip", "nbrclm_denied_inntwk_pa_silver_ms_ip", "nbrclm_denied_inntwk_pa_gold_ms_ip", "nbrclm_denied_inntwk_pa_platinum_ms_ip", "nbrclm_denied_inntwk_pa_total_ms_ip",
        "nbrclm_denied_inntwk_pa_bronze_ms_sgp", "nbrclm_denied_inntwk_pa_silver_ms_sgp", "nbrclm_denied_inntwk_pa_gold_ms_sgp", "nbrclm_denied_inntwk_pa_platinum_ms_sgp", "nbrclm_denied_inntwk_pa_total_ms_sgp")

    denied_inntwk_Data_pa

  }

  def getDeniedInntwkncb(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame,
                         naic2018_mcas_ncb_src_eob_cd_inbnd: DataFrame, naic2018_mcas_ncb_eob_cd_inbnd: DataFrame, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_brz = joinedDf2018(received_brnz, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sil = joinedDf2018(received_silver, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_ncb_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_ncb_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip")

    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gld = joinedDf2018(received_gold, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_plt = joinedDf2018(received_platinum, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_ncb_bronze_ip.union(nbrclm_denied_inntwk_ncb_silver_ip.union(nbrclm_denied_inntwk_ncb_gold_ip.union(nbrclm_denied_inntwk_ncb_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_ncb_bronze_ip")

    val nbrclm_denied_inntwk_ncb_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_ncb_bronze_ip").alias("nbrclm_denied_inntwk_ncb_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_brz = joinedDf2018(received_sgp_bronze, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_sil = joinedDf2018(received_sgp_silver, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_gld = joinedDf2018(received_sgp_gold, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_plt = joinedDf2018(received_sgp_plt, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp", "nbrclm_denied_inntwk_ncb_platinum_sgp")

    val tot_sgp = nbrclm_denied_inntwk_ncb_bronze_sgp.union(nbrclm_denied_inntwk_ncb_silver_sgp.union(nbrclm_denied_inntwk_ncb_gold_sgp.union(nbrclm_denied_inntwk_ncb_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_ncb_bronze_sgp")

    val nbrclm_denied_inntwk_ncb_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_ncb_bronze_sgp").alias("nbrclm_denied_inntwk_ncb_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_sgp"), col("nbrclm_denied_inntwk_ncb_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp", "nbrclm_denied_inntwk_ncb_platinum_sgp", "nbrclm_denied_inntwk_ncb_total_sgp")

    val receivedCatFilters = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_cat = joinedDf2018(receivedCatFilters, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_sgp"), col("nbrclm_denied_inntwk_ncb_total_sgp"), col("nbrclm_denied_inntwk_ncb_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp", "nbrclm_denied_inntwk_ncb_platinum_sgp", "nbrclm_denied_inntwk_ncb_total_sgp", "nbrclm_denied_inntwk_ncb_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_brz = joinedDf2018(received_msip_Brz, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_bronze_ms_ip = denied_in_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_sgp"), col("nbrclm_denied_inntwk_ncb_total_sgp"), col("nbrclm_denied_inntwk_ncb_catastrophic"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp", "nbrclm_denied_inntwk_ncb_platinum_sgp", "nbrclm_denied_inntwk_ncb_total_sgp", "nbrclm_denied_inntwk_ncb_catastrophic",
        "nbrclm_denied_inntwk_ncb_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_sil = joinedDf2018(received_msip_Sil, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_silver_ms_ip = denied_in_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_sgp"), col("nbrclm_denied_inntwk_ncb_total_sgp"), col("nbrclm_denied_inntwk_ncb_catastrophic"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_inntwk_ncb_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp", "nbrclm_denied_inntwk_ncb_platinum_sgp", "nbrclm_denied_inntwk_ncb_total_sgp", "nbrclm_denied_inntwk_ncb_catastrophic",
        "nbrclm_denied_inntwk_ncb_bronze_ms_ip", "nbrclm_denied_inntwk_ncb_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_gld = joinedDf2018(received_msip_Gld, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_gold_ms_ip = denied_in_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_sgp"), col("nbrclm_denied_inntwk_ncb_total_sgp"), col("nbrclm_denied_inntwk_ncb_catastrophic"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_inntwk_ncb_silver_ms_ip"), col("nbrclm_denied_inntwk_ncb_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp", "nbrclm_denied_inntwk_ncb_platinum_sgp", "nbrclm_denied_inntwk_ncb_total_sgp", "nbrclm_denied_inntwk_ncb_catastrophic",
        "nbrclm_denied_inntwk_ncb_bronze_ms_ip", "nbrclm_denied_inntwk_ncb_silver_ms_ip", "nbrclm_denied_inntwk_ncb_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_plt = joinedDf2018(received_msip_Plt, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_platinum_ms_ip = denied_in_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_sgp"), col("nbrclm_denied_inntwk_ncb_total_sgp"), col("nbrclm_denied_inntwk_ncb_catastrophic"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_inntwk_ncb_silver_ms_ip"), col("nbrclm_denied_inntwk_ncb_gold_ms_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp", "nbrclm_denied_inntwk_ncb_platinum_sgp", "nbrclm_denied_inntwk_ncb_total_sgp", "nbrclm_denied_inntwk_ncb_catastrophic",
        "nbrclm_denied_inntwk_ncb_bronze_ms_ip", "nbrclm_denied_inntwk_ncb_silver_ms_ip", "nbrclm_denied_inntwk_ncb_gold_ms_ip", "nbrclm_denied_inntwk_ncb_platinum_ms_ip")

    val tot_msip = nbrclm_denied_inntwk_ncb_bronze_ms_ip.union(nbrclm_denied_inntwk_ncb_silver_ms_ip.union(nbrclm_denied_inntwk_ncb_gold_ms_ip.union(nbrclm_denied_inntwk_ncb_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_ncb_bronze_ms_ip")

    val nbrclm_denied_inntwk_ncb_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_ncb_bronze_ms_ip").alias("nbrclm_denied_inntwk_ncb_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_sgp"), col("nbrclm_denied_inntwk_ncb_total_sgp"), col("nbrclm_denied_inntwk_ncb_catastrophic"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_inntwk_ncb_silver_ms_ip"), col("nbrclm_denied_inntwk_ncb_gold_ms_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_inntwk_ncb_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp", "nbrclm_denied_inntwk_ncb_platinum_sgp", "nbrclm_denied_inntwk_ncb_total_sgp", "nbrclm_denied_inntwk_ncb_catastrophic",
        "nbrclm_denied_inntwk_ncb_bronze_ms_ip", "nbrclm_denied_inntwk_ncb_silver_ms_ip", "nbrclm_denied_inntwk_ncb_gold_ms_ip", "nbrclm_denied_inntwk_ncb_platinum_ms_ip", "nbrclm_denied_inntwk_ncb_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_brz = joinedDf2018(received_mssgp_Brz, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_bronze_ms_sgp = denied_in_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_sgp"), col("nbrclm_denied_inntwk_ncb_total_sgp"), col("nbrclm_denied_inntwk_ncb_catastrophic"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_inntwk_ncb_silver_ms_ip"), col("nbrclm_denied_inntwk_ncb_gold_ms_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_inntwk_ncb_total_ms_ip"), col("nbrclm_denied_inntwk_ncb_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp", "nbrclm_denied_inntwk_ncb_platinum_sgp", "nbrclm_denied_inntwk_ncb_total_sgp", "nbrclm_denied_inntwk_ncb_catastrophic",
        "nbrclm_denied_inntwk_ncb_bronze_ms_ip", "nbrclm_denied_inntwk_ncb_silver_ms_ip", "nbrclm_denied_inntwk_ncb_gold_ms_ip", "nbrclm_denied_inntwk_ncb_platinum_ms_ip", "nbrclm_denied_inntwk_ncb_total_ms_ip",
        "nbrclm_denied_inntwk_ncb_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_sil = joinedDf2018(received_mssgp_Sil, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_silver_ms_sgp = denied_in_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_sgp"), col("nbrclm_denied_inntwk_ncb_total_sgp"), col("nbrclm_denied_inntwk_ncb_catastrophic"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_inntwk_ncb_silver_ms_ip"), col("nbrclm_denied_inntwk_ncb_gold_ms_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_inntwk_ncb_total_ms_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_sgp"), col("nbrclm_denied_inntwk_ncb_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp", "nbrclm_denied_inntwk_ncb_platinum_sgp", "nbrclm_denied_inntwk_ncb_total_sgp", "nbrclm_denied_inntwk_ncb_catastrophic",
        "nbrclm_denied_inntwk_ncb_bronze_ms_ip", "nbrclm_denied_inntwk_ncb_silver_ms_ip", "nbrclm_denied_inntwk_ncb_gold_ms_ip", "nbrclm_denied_inntwk_ncb_platinum_ms_ip", "nbrclm_denied_inntwk_ncb_total_ms_ip",
        "nbrclm_denied_inntwk_ncb_bronze_ms_sgp", "nbrclm_denied_inntwk_ncb_silver_ms_sgp")

    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_gld = joinedDf2018(received_mssgp_Gld, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_gold_ms_sgp = denied_in_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_sgp"), col("nbrclm_denied_inntwk_ncb_total_sgp"), col("nbrclm_denied_inntwk_ncb_catastrophic"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_inntwk_ncb_silver_ms_ip"), col("nbrclm_denied_inntwk_ncb_gold_ms_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_inntwk_ncb_total_ms_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_sgp"), col("nbrclm_denied_inntwk_ncb_silver_ms_sgp"), col("nbrclm_denied_inntwk_ncb_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp", "nbrclm_denied_inntwk_ncb_platinum_sgp", "nbrclm_denied_inntwk_ncb_total_sgp", "nbrclm_denied_inntwk_ncb_catastrophic",
        "nbrclm_denied_inntwk_ncb_bronze_ms_ip", "nbrclm_denied_inntwk_ncb_silver_ms_ip", "nbrclm_denied_inntwk_ncb_gold_ms_ip", "nbrclm_denied_inntwk_ncb_platinum_ms_ip", "nbrclm_denied_inntwk_ncb_total_ms_ip",
        "nbrclm_denied_inntwk_ncb_bronze_ms_sgp", "nbrclm_denied_inntwk_ncb_silver_ms_sgp", "nbrclm_denied_inntwk_ncb_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_plt = joinedDf2018(received_mssgp_Plt, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_inntwk_ncb_platinum_ms_sgp = denied_in_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ncb_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_sgp"), col("nbrclm_denied_inntwk_ncb_total_sgp"), col("nbrclm_denied_inntwk_ncb_catastrophic"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_inntwk_ncb_silver_ms_ip"), col("nbrclm_denied_inntwk_ncb_gold_ms_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_inntwk_ncb_total_ms_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_sgp"), col("nbrclm_denied_inntwk_ncb_silver_ms_sgp"), col("nbrclm_denied_inntwk_ncb_gold_ms_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp", "nbrclm_denied_inntwk_ncb_platinum_sgp", "nbrclm_denied_inntwk_ncb_total_sgp", "nbrclm_denied_inntwk_ncb_catastrophic",
        "nbrclm_denied_inntwk_ncb_bronze_ms_ip", "nbrclm_denied_inntwk_ncb_silver_ms_ip", "nbrclm_denied_inntwk_ncb_gold_ms_ip", "nbrclm_denied_inntwk_ncb_platinum_ms_ip", "nbrclm_denied_inntwk_ncb_total_ms_ip",
        "nbrclm_denied_inntwk_ncb_bronze_ms_sgp", "nbrclm_denied_inntwk_ncb_silver_ms_sgp", "nbrclm_denied_inntwk_ncb_gold_ms_sgp", "nbrclm_denied_inntwk_ncb_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_inntwk_ncb_bronze_ms_sgp.union(nbrclm_denied_inntwk_ncb_silver_ms_sgp.union(nbrclm_denied_inntwk_ncb_gold_ms_sgp.union(nbrclm_denied_inntwk_ncb_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_ncb_bronze_ms_sgp")

    val nbrclm_denied_inntwk_ncb_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_ncb_bronze_ms_sgp").alias("nbrclm_denied_inntwk_ncb_total_ms_sgp"))

    val denied_inntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_inntwk_ncb_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ncb_bronze_ip"), col("nbrclm_denied_inntwk_ncb_silver_ip"), col("nbrclm_denied_inntwk_ncb_gold_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ip"), col("nbrclm_denied_inntwk_ncb_total_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_sgp"), col("nbrclm_denied_inntwk_ncb_silver_sgp"), col("nbrclm_denied_inntwk_ncb_gold_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_sgp"), col("nbrclm_denied_inntwk_ncb_total_sgp"), col("nbrclm_denied_inntwk_ncb_catastrophic"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_inntwk_ncb_silver_ms_ip"), col("nbrclm_denied_inntwk_ncb_gold_ms_ip"), col("nbrclm_denied_inntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_inntwk_ncb_total_ms_ip"),
        col("nbrclm_denied_inntwk_ncb_bronze_ms_sgp"), col("nbrclm_denied_inntwk_ncb_silver_ms_sgp"), col("nbrclm_denied_inntwk_ncb_gold_ms_sgp"), col("nbrclm_denied_inntwk_ncb_platinum_ms_sgp"), col("nbrclm_denied_inntwk_ncb_total_ms_sgp"))

    val denied_inntwk_Data_ncb = denied_inntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ncb_bronze_ip", "nbrclm_denied_inntwk_ncb_silver_ip", "nbrclm_denied_inntwk_ncb_gold_ip", "nbrclm_denied_inntwk_ncb_platinum_ip", "nbrclm_denied_inntwk_ncb_total_ip",
        "nbrclm_denied_inntwk_ncb_bronze_sgp", "nbrclm_denied_inntwk_ncb_silver_sgp", "nbrclm_denied_inntwk_ncb_gold_sgp", "nbrclm_denied_inntwk_ncb_platinum_sgp", "nbrclm_denied_inntwk_ncb_total_sgp", "nbrclm_denied_inntwk_ncb_catastrophic",
        "nbrclm_denied_inntwk_ncb_bronze_ms_ip", "nbrclm_denied_inntwk_ncb_silver_ms_ip", "nbrclm_denied_inntwk_ncb_gold_ms_ip", "nbrclm_denied_inntwk_ncb_platinum_ms_ip", "nbrclm_denied_inntwk_ncb_total_ms_ip",
        "nbrclm_denied_inntwk_ncb_bronze_ms_sgp", "nbrclm_denied_inntwk_ncb_silver_ms_sgp", "nbrclm_denied_inntwk_ncb_gold_ms_sgp", "nbrclm_denied_inntwk_ncb_platinum_ms_sgp", "nbrclm_denied_inntwk_ncb_total_ms_sgp")

    denied_inntwk_Data_ncb
  }

  def getDeniedInntwkebh(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame,
                         naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame, naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame
                         ): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_brz = joinedDfEbh(received_brnz, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sil = joinedDfEbh(received_silver, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_ebh_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_ebh_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip")

    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gld = joinedDfEbh(received_gold, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_plt = joinedDfEbh(received_platinum, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_ebh_bronze_ip.union(nbrclm_denied_inntwk_ebh_silver_ip.union(nbrclm_denied_inntwk_ebh_gold_ip.union(nbrclm_denied_inntwk_ebh_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_ebh_bronze_ip")

    val nbrclm_denied_inntwk_ebh_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_ebh_bronze_ip").alias("nbrclm_denied_inntwk_ebh_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_brz = joinedDfEbh(received_sgp_bronze, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_sil = joinedDfEbh(received_sgp_silver, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_gld = joinedDfEbh(received_sgp_gold, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_plt = joinedDfEbh(received_sgp_plt, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp", "nbrclm_denied_inntwk_ebh_platinum_sgp")

    val tot_sgp = nbrclm_denied_inntwk_ebh_bronze_sgp.union(nbrclm_denied_inntwk_ebh_silver_sgp.union(nbrclm_denied_inntwk_ebh_gold_sgp.union(nbrclm_denied_inntwk_ebh_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_ebh_bronze_sgp")

    val nbrclm_denied_inntwk_ebh_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_ebh_bronze_sgp").alias("nbrclm_denied_inntwk_ebh_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_sgp"), col("nbrclm_denied_inntwk_ebh_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp", "nbrclm_denied_inntwk_ebh_platinum_sgp", "nbrclm_denied_inntwk_ebh_total_sgp")

    val receivedCatFilters = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_cat = joinedDfEbh(receivedCatFilters, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_sgp"), col("nbrclm_denied_inntwk_ebh_total_sgp"), col("nbrclm_denied_inntwk_ebh_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp", "nbrclm_denied_inntwk_ebh_platinum_sgp", "nbrclm_denied_inntwk_ebh_total_sgp", "nbrclm_denied_inntwk_ebh_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_brz = joinedDfEbh(received_msip_Brz, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_bronze_ms_ip = denied_in_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_sgp"), col("nbrclm_denied_inntwk_ebh_total_sgp"), col("nbrclm_denied_inntwk_ebh_catastrophic"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp", "nbrclm_denied_inntwk_ebh_platinum_sgp", "nbrclm_denied_inntwk_ebh_total_sgp", "nbrclm_denied_inntwk_ebh_catastrophic",
        "nbrclm_denied_inntwk_ebh_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_sil = joinedDfEbh(received_msip_Sil, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_silver_ms_ip = denied_in_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_sgp"), col("nbrclm_denied_inntwk_ebh_total_sgp"), col("nbrclm_denied_inntwk_ebh_catastrophic"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_inntwk_ebh_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp", "nbrclm_denied_inntwk_ebh_platinum_sgp", "nbrclm_denied_inntwk_ebh_total_sgp", "nbrclm_denied_inntwk_ebh_catastrophic",
        "nbrclm_denied_inntwk_ebh_bronze_ms_ip", "nbrclm_denied_inntwk_ebh_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_gld = joinedDfEbh(received_msip_Gld, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_gold_ms_ip = denied_in_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_sgp"), col("nbrclm_denied_inntwk_ebh_total_sgp"), col("nbrclm_denied_inntwk_ebh_catastrophic"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_inntwk_ebh_silver_ms_ip"), col("nbrclm_denied_inntwk_ebh_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp", "nbrclm_denied_inntwk_ebh_platinum_sgp", "nbrclm_denied_inntwk_ebh_total_sgp", "nbrclm_denied_inntwk_ebh_catastrophic",
        "nbrclm_denied_inntwk_ebh_bronze_ms_ip", "nbrclm_denied_inntwk_ebh_silver_ms_ip", "nbrclm_denied_inntwk_ebh_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_plt = joinedDfEbh(received_msip_Plt, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_platinum_ms_ip = denied_in_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_sgp"), col("nbrclm_denied_inntwk_ebh_total_sgp"), col("nbrclm_denied_inntwk_ebh_catastrophic"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_inntwk_ebh_silver_ms_ip"), col("nbrclm_denied_inntwk_ebh_gold_ms_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp", "nbrclm_denied_inntwk_ebh_platinum_sgp", "nbrclm_denied_inntwk_ebh_total_sgp", "nbrclm_denied_inntwk_ebh_catastrophic",
        "nbrclm_denied_inntwk_ebh_bronze_ms_ip", "nbrclm_denied_inntwk_ebh_silver_ms_ip", "nbrclm_denied_inntwk_ebh_gold_ms_ip", "nbrclm_denied_inntwk_ebh_platinum_ms_ip")

    val tot_msip = nbrclm_denied_inntwk_ebh_bronze_ms_ip.union(nbrclm_denied_inntwk_ebh_silver_ms_ip.union(nbrclm_denied_inntwk_ebh_gold_ms_ip.union(nbrclm_denied_inntwk_ebh_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_ebh_bronze_ms_ip")

    val nbrclm_denied_inntwk_ebh_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_ebh_bronze_ms_ip").alias("nbrclm_denied_inntwk_ebh_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_sgp"), col("nbrclm_denied_inntwk_ebh_total_sgp"), col("nbrclm_denied_inntwk_ebh_catastrophic"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_inntwk_ebh_silver_ms_ip"), col("nbrclm_denied_inntwk_ebh_gold_ms_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_inntwk_ebh_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp", "nbrclm_denied_inntwk_ebh_platinum_sgp", "nbrclm_denied_inntwk_ebh_total_sgp", "nbrclm_denied_inntwk_ebh_catastrophic",
        "nbrclm_denied_inntwk_ebh_bronze_ms_ip", "nbrclm_denied_inntwk_ebh_silver_ms_ip", "nbrclm_denied_inntwk_ebh_gold_ms_ip", "nbrclm_denied_inntwk_ebh_platinum_ms_ip", "nbrclm_denied_inntwk_ebh_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_brz = joinedDfEbh(received_mssgp_Brz, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_bronze_ms_sgp = denied_in_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_sgp"), col("nbrclm_denied_inntwk_ebh_total_sgp"), col("nbrclm_denied_inntwk_ebh_catastrophic"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_inntwk_ebh_silver_ms_ip"), col("nbrclm_denied_inntwk_ebh_gold_ms_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_inntwk_ebh_total_ms_ip"), col("nbrclm_denied_inntwk_ebh_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp", "nbrclm_denied_inntwk_ebh_platinum_sgp", "nbrclm_denied_inntwk_ebh_total_sgp", "nbrclm_denied_inntwk_ebh_catastrophic",
        "nbrclm_denied_inntwk_ebh_bronze_ms_ip", "nbrclm_denied_inntwk_ebh_silver_ms_ip", "nbrclm_denied_inntwk_ebh_gold_ms_ip", "nbrclm_denied_inntwk_ebh_platinum_ms_ip", "nbrclm_denied_inntwk_ebh_total_ms_ip",
        "nbrclm_denied_inntwk_ebh_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_sil = joinedDfEbh(received_mssgp_Sil, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_silver_ms_sgp = denied_in_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_sgp"), col("nbrclm_denied_inntwk_ebh_total_sgp"), col("nbrclm_denied_inntwk_ebh_catastrophic"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_inntwk_ebh_silver_ms_ip"), col("nbrclm_denied_inntwk_ebh_gold_ms_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_inntwk_ebh_total_ms_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_sgp"), col("nbrclm_denied_inntwk_ebh_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp", "nbrclm_denied_inntwk_ebh_platinum_sgp", "nbrclm_denied_inntwk_ebh_total_sgp", "nbrclm_denied_inntwk_ebh_catastrophic",
        "nbrclm_denied_inntwk_ebh_bronze_ms_ip", "nbrclm_denied_inntwk_ebh_silver_ms_ip", "nbrclm_denied_inntwk_ebh_gold_ms_ip", "nbrclm_denied_inntwk_ebh_platinum_ms_ip", "nbrclm_denied_inntwk_ebh_total_ms_ip",
        "nbrclm_denied_inntwk_ebh_bronze_ms_sgp", "nbrclm_denied_inntwk_ebh_silver_ms_sgp")

    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_gld = joinedDfEbh(received_mssgp_Gld, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_gold_ms_sgp = denied_in_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_sgp"), col("nbrclm_denied_inntwk_ebh_total_sgp"), col("nbrclm_denied_inntwk_ebh_catastrophic"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_inntwk_ebh_silver_ms_ip"), col("nbrclm_denied_inntwk_ebh_gold_ms_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_inntwk_ebh_total_ms_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_sgp"), col("nbrclm_denied_inntwk_ebh_silver_ms_sgp"), col("nbrclm_denied_inntwk_ebh_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp", "nbrclm_denied_inntwk_ebh_platinum_sgp", "nbrclm_denied_inntwk_ebh_total_sgp", "nbrclm_denied_inntwk_ebh_catastrophic",
        "nbrclm_denied_inntwk_ebh_bronze_ms_ip", "nbrclm_denied_inntwk_ebh_silver_ms_ip", "nbrclm_denied_inntwk_ebh_gold_ms_ip", "nbrclm_denied_inntwk_ebh_platinum_ms_ip", "nbrclm_denied_inntwk_ebh_total_ms_ip",
        "nbrclm_denied_inntwk_ebh_bronze_ms_sgp", "nbrclm_denied_inntwk_ebh_silver_ms_sgp", "nbrclm_denied_inntwk_ebh_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_plt = joinedDfEbh(received_mssgp_Plt, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_ebh_platinum_ms_sgp = denied_in_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_ebh_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_sgp"), col("nbrclm_denied_inntwk_ebh_total_sgp"), col("nbrclm_denied_inntwk_ebh_catastrophic"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_inntwk_ebh_silver_ms_ip"), col("nbrclm_denied_inntwk_ebh_gold_ms_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_inntwk_ebh_total_ms_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_sgp"), col("nbrclm_denied_inntwk_ebh_silver_ms_sgp"), col("nbrclm_denied_inntwk_ebh_gold_ms_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp", "nbrclm_denied_inntwk_ebh_platinum_sgp", "nbrclm_denied_inntwk_ebh_total_sgp", "nbrclm_denied_inntwk_ebh_catastrophic",
        "nbrclm_denied_inntwk_ebh_bronze_ms_ip", "nbrclm_denied_inntwk_ebh_silver_ms_ip", "nbrclm_denied_inntwk_ebh_gold_ms_ip", "nbrclm_denied_inntwk_ebh_platinum_ms_ip", "nbrclm_denied_inntwk_ebh_total_ms_ip",
        "nbrclm_denied_inntwk_ebh_bronze_ms_sgp", "nbrclm_denied_inntwk_ebh_silver_ms_sgp", "nbrclm_denied_inntwk_ebh_gold_ms_sgp", "nbrclm_denied_inntwk_ebh_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_inntwk_ebh_bronze_ms_sgp.union(nbrclm_denied_inntwk_ebh_silver_ms_sgp.union(nbrclm_denied_inntwk_ebh_gold_ms_sgp.union(nbrclm_denied_inntwk_ebh_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_ebh_bronze_ms_sgp")

    val nbrclm_denied_inntwk_ebh_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_ebh_bronze_ms_sgp").alias("nbrclm_denied_inntwk_ebh_total_ms_sgp"))

    val denied_inntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_inntwk_ebh_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_ebh_bronze_ip"), col("nbrclm_denied_inntwk_ebh_silver_ip"), col("nbrclm_denied_inntwk_ebh_gold_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ip"), col("nbrclm_denied_inntwk_ebh_total_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_sgp"), col("nbrclm_denied_inntwk_ebh_silver_sgp"), col("nbrclm_denied_inntwk_ebh_gold_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_sgp"), col("nbrclm_denied_inntwk_ebh_total_sgp"), col("nbrclm_denied_inntwk_ebh_catastrophic"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_inntwk_ebh_silver_ms_ip"), col("nbrclm_denied_inntwk_ebh_gold_ms_ip"), col("nbrclm_denied_inntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_inntwk_ebh_total_ms_ip"),
        col("nbrclm_denied_inntwk_ebh_bronze_ms_sgp"), col("nbrclm_denied_inntwk_ebh_silver_ms_sgp"), col("nbrclm_denied_inntwk_ebh_gold_ms_sgp"), col("nbrclm_denied_inntwk_ebh_platinum_ms_sgp"), col("nbrclm_denied_inntwk_ebh_total_ms_sgp"))

    val denied_inntwk_Data_ebh = denied_inntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_ebh_bronze_ip", "nbrclm_denied_inntwk_ebh_silver_ip", "nbrclm_denied_inntwk_ebh_gold_ip", "nbrclm_denied_inntwk_ebh_platinum_ip", "nbrclm_denied_inntwk_ebh_total_ip",
        "nbrclm_denied_inntwk_ebh_bronze_sgp", "nbrclm_denied_inntwk_ebh_silver_sgp", "nbrclm_denied_inntwk_ebh_gold_sgp", "nbrclm_denied_inntwk_ebh_platinum_sgp", "nbrclm_denied_inntwk_ebh_total_sgp", "nbrclm_denied_inntwk_ebh_catastrophic",
        "nbrclm_denied_inntwk_ebh_bronze_ms_ip", "nbrclm_denied_inntwk_ebh_silver_ms_ip", "nbrclm_denied_inntwk_ebh_gold_ms_ip", "nbrclm_denied_inntwk_ebh_platinum_ms_ip", "nbrclm_denied_inntwk_ebh_total_ms_ip",
        "nbrclm_denied_inntwk_ebh_bronze_ms_sgp", "nbrclm_denied_inntwk_ebh_silver_ms_sgp", "nbrclm_denied_inntwk_ebh_gold_ms_sgp", "nbrclm_denied_inntwk_ebh_platinum_ms_sgp", "nbrclm_denied_inntwk_ebh_total_ms_sgp")

    denied_inntwk_Data_ebh
  }

  def getDeniedInntwkbh(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame,
                        naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame, 
                        naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame ): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_brz = joinedDfbh(received_brnz, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_bronze_ip = denied_in_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sil = joinedDfbh(received_silver, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_silver_ip = denied_in_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_silver_ip"))

    val BrzSilMaster = nbrclm_denied_inntwk_bh_bronze_ip.alias("parent").join(nbrclm_denied_inntwk_bh_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip")

    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_gld = joinedDfbh(received_gold, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_gold_ip = denied_in_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_plt = joinedDfbh(received_platinum, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_platinum_ip = denied_in_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip")

    val tot_ip = nbrclm_denied_inntwk_bh_bronze_ip.union(nbrclm_denied_inntwk_bh_silver_ip.union(nbrclm_denied_inntwk_bh_gold_ip.union(nbrclm_denied_inntwk_bh_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_bh_bronze_ip")

    val nbrclm_denied_inntwk_bh_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_bh_bronze_ip").alias("nbrclm_denied_inntwk_bh_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_brz = joinedDfbh(received_sgp_bronze, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_bronze_sgp = denied_in_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_sil = joinedDfbh(received_sgp_silver, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_silver_sgp = denied_in_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_gld = joinedDfbh(received_sgp_gold, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_gold_sgp = denied_in_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_sgp_plt = joinedDfbh(received_sgp_plt, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_platinum_sgp = denied_in_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"), col("nbrclm_denied_inntwk_bh_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp", "nbrclm_denied_inntwk_bh_platinum_sgp")

    val tot_sgp = nbrclm_denied_inntwk_bh_bronze_sgp.union(nbrclm_denied_inntwk_bh_silver_sgp.union(nbrclm_denied_inntwk_bh_gold_sgp.union(nbrclm_denied_inntwk_bh_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_bh_bronze_sgp")

    val nbrclm_denied_inntwk_bh_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_bh_bronze_sgp").alias("nbrclm_denied_inntwk_bh_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"), col("nbrclm_denied_inntwk_bh_platinum_sgp"), col("nbrclm_denied_inntwk_bh_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp", "nbrclm_denied_inntwk_bh_platinum_sgp", "nbrclm_denied_inntwk_bh_total_sgp")

    val receivedCatFilters = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_cat = joinedDfbh(receivedCatFilters, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_catastrophic = denied_in_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"), col("nbrclm_denied_inntwk_bh_platinum_sgp"), col("nbrclm_denied_inntwk_bh_total_sgp"), col("nbrclm_denied_inntwk_bh_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp", "nbrclm_denied_inntwk_bh_platinum_sgp", "nbrclm_denied_inntwk_bh_total_sgp", "nbrclm_denied_inntwk_bh_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_brz = joinedDfbh(received_msip_Brz, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_bronze_ms_ip = denied_in_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"), col("nbrclm_denied_inntwk_bh_platinum_sgp"), col("nbrclm_denied_inntwk_bh_total_sgp"), col("nbrclm_denied_inntwk_bh_catastrophic"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp", "nbrclm_denied_inntwk_bh_platinum_sgp", "nbrclm_denied_inntwk_bh_total_sgp", "nbrclm_denied_inntwk_bh_catastrophic",
        "nbrclm_denied_inntwk_bh_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_sil = joinedDfbh(received_msip_Sil, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_silver_ms_ip = denied_in_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"), col("nbrclm_denied_inntwk_bh_platinum_sgp"), col("nbrclm_denied_inntwk_bh_total_sgp"), col("nbrclm_denied_inntwk_bh_catastrophic"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_ip"), col("nbrclm_denied_inntwk_bh_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp", "nbrclm_denied_inntwk_bh_platinum_sgp", "nbrclm_denied_inntwk_bh_total_sgp", "nbrclm_denied_inntwk_bh_catastrophic",
        "nbrclm_denied_inntwk_bh_bronze_ms_ip", "nbrclm_denied_inntwk_bh_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_gld = joinedDfbh(received_msip_Gld, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_gold_ms_ip = denied_in_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"), col("nbrclm_denied_inntwk_bh_platinum_sgp"), col("nbrclm_denied_inntwk_bh_total_sgp"), col("nbrclm_denied_inntwk_bh_catastrophic"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_ip"), col("nbrclm_denied_inntwk_bh_silver_ms_ip"), col("nbrclm_denied_inntwk_bh_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp", "nbrclm_denied_inntwk_bh_platinum_sgp", "nbrclm_denied_inntwk_bh_total_sgp", "nbrclm_denied_inntwk_bh_catastrophic",
        "nbrclm_denied_inntwk_bh_bronze_ms_ip", "nbrclm_denied_inntwk_bh_silver_ms_ip", "nbrclm_denied_inntwk_bh_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_msip_plt = joinedDfbh(received_msip_Plt, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_platinum_ms_ip = denied_in_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"), col("nbrclm_denied_inntwk_bh_platinum_sgp"), col("nbrclm_denied_inntwk_bh_total_sgp"), col("nbrclm_denied_inntwk_bh_catastrophic"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_ip"), col("nbrclm_denied_inntwk_bh_silver_ms_ip"), col("nbrclm_denied_inntwk_bh_gold_ms_ip"), col("nbrclm_denied_inntwk_bh_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp", "nbrclm_denied_inntwk_bh_platinum_sgp", "nbrclm_denied_inntwk_bh_total_sgp", "nbrclm_denied_inntwk_bh_catastrophic",
        "nbrclm_denied_inntwk_bh_bronze_ms_ip", "nbrclm_denied_inntwk_bh_silver_ms_ip", "nbrclm_denied_inntwk_bh_gold_ms_ip", "nbrclm_denied_inntwk_bh_platinum_ms_ip")

    val tot_msip = nbrclm_denied_inntwk_bh_bronze_ms_ip.union(nbrclm_denied_inntwk_bh_silver_ms_ip.union(nbrclm_denied_inntwk_bh_gold_ms_ip.union(nbrclm_denied_inntwk_bh_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_bh_bronze_ms_ip")

    val nbrclm_denied_inntwk_bh_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_bh_bronze_ms_ip").alias("nbrclm_denied_inntwk_bh_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"), col("nbrclm_denied_inntwk_bh_platinum_sgp"), col("nbrclm_denied_inntwk_bh_total_sgp"), col("nbrclm_denied_inntwk_bh_catastrophic"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_ip"), col("nbrclm_denied_inntwk_bh_silver_ms_ip"), col("nbrclm_denied_inntwk_bh_gold_ms_ip"), col("nbrclm_denied_inntwk_bh_platinum_ms_ip"), col("nbrclm_denied_inntwk_bh_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp", "nbrclm_denied_inntwk_bh_platinum_sgp", "nbrclm_denied_inntwk_bh_total_sgp", "nbrclm_denied_inntwk_bh_catastrophic",
        "nbrclm_denied_inntwk_bh_bronze_ms_ip", "nbrclm_denied_inntwk_bh_silver_ms_ip", "nbrclm_denied_inntwk_bh_gold_ms_ip", "nbrclm_denied_inntwk_bh_platinum_ms_ip", "nbrclm_denied_inntwk_bh_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_brz = joinedDfbh(received_mssgp_Brz, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_bronze_ms_sgp = denied_in_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"), col("nbrclm_denied_inntwk_bh_platinum_sgp"), col("nbrclm_denied_inntwk_bh_total_sgp"), col("nbrclm_denied_inntwk_bh_catastrophic"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_ip"), col("nbrclm_denied_inntwk_bh_silver_ms_ip"), col("nbrclm_denied_inntwk_bh_gold_ms_ip"), col("nbrclm_denied_inntwk_bh_platinum_ms_ip"), col("nbrclm_denied_inntwk_bh_total_ms_ip"), col("nbrclm_denied_inntwk_bh_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp", "nbrclm_denied_inntwk_bh_platinum_sgp", "nbrclm_denied_inntwk_bh_total_sgp", "nbrclm_denied_inntwk_bh_catastrophic",
        "nbrclm_denied_inntwk_bh_bronze_ms_ip", "nbrclm_denied_inntwk_bh_silver_ms_ip", "nbrclm_denied_inntwk_bh_gold_ms_ip", "nbrclm_denied_inntwk_bh_platinum_ms_ip", "nbrclm_denied_inntwk_bh_total_ms_ip",
        "nbrclm_denied_inntwk_bh_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_sil = joinedDfbh(received_mssgp_Sil, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_silver_ms_sgp = denied_in_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"), col("nbrclm_denied_inntwk_bh_platinum_sgp"), col("nbrclm_denied_inntwk_bh_total_sgp"), col("nbrclm_denied_inntwk_bh_catastrophic"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_ip"), col("nbrclm_denied_inntwk_bh_silver_ms_ip"), col("nbrclm_denied_inntwk_bh_gold_ms_ip"), col("nbrclm_denied_inntwk_bh_platinum_ms_ip"), col("nbrclm_denied_inntwk_bh_total_ms_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_sgp"), col("nbrclm_denied_inntwk_bh_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp", "nbrclm_denied_inntwk_bh_platinum_sgp", "nbrclm_denied_inntwk_bh_total_sgp", "nbrclm_denied_inntwk_bh_catastrophic",
        "nbrclm_denied_inntwk_bh_bronze_ms_ip", "nbrclm_denied_inntwk_bh_silver_ms_ip", "nbrclm_denied_inntwk_bh_gold_ms_ip", "nbrclm_denied_inntwk_bh_platinum_ms_ip", "nbrclm_denied_inntwk_bh_total_ms_ip",
        "nbrclm_denied_inntwk_bh_bronze_ms_sgp", "nbrclm_denied_inntwk_bh_silver_ms_sgp")

    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_gld = joinedDfbh(received_mssgp_Gld, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_gold_ms_sgp = denied_in_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"), col("nbrclm_denied_inntwk_bh_platinum_sgp"), col("nbrclm_denied_inntwk_bh_total_sgp"), col("nbrclm_denied_inntwk_bh_catastrophic"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_ip"), col("nbrclm_denied_inntwk_bh_silver_ms_ip"), col("nbrclm_denied_inntwk_bh_gold_ms_ip"), col("nbrclm_denied_inntwk_bh_platinum_ms_ip"), col("nbrclm_denied_inntwk_bh_total_ms_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_sgp"), col("nbrclm_denied_inntwk_bh_silver_ms_sgp"), col("nbrclm_denied_inntwk_bh_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp", "nbrclm_denied_inntwk_bh_platinum_sgp", "nbrclm_denied_inntwk_bh_total_sgp", "nbrclm_denied_inntwk_bh_catastrophic",
        "nbrclm_denied_inntwk_bh_bronze_ms_ip", "nbrclm_denied_inntwk_bh_silver_ms_ip", "nbrclm_denied_inntwk_bh_gold_ms_ip", "nbrclm_denied_inntwk_bh_platinum_ms_ip", "nbrclm_denied_inntwk_bh_total_ms_ip",
        "nbrclm_denied_inntwk_bh_bronze_ms_sgp", "nbrclm_denied_inntwk_bh_silver_ms_sgp", "nbrclm_denied_inntwk_bh_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_in_mssgp_plt = joinedDfbh(received_mssgp_Plt, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd )

    val nbrclm_denied_inntwk_bh_platinum_ms_sgp = denied_in_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_bh_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"), col("nbrclm_denied_inntwk_bh_platinum_sgp"), col("nbrclm_denied_inntwk_bh_total_sgp"), col("nbrclm_denied_inntwk_bh_catastrophic"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_ip"), col("nbrclm_denied_inntwk_bh_silver_ms_ip"), col("nbrclm_denied_inntwk_bh_gold_ms_ip"), col("nbrclm_denied_inntwk_bh_platinum_ms_ip"), col("nbrclm_denied_inntwk_bh_total_ms_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_sgp"), col("nbrclm_denied_inntwk_bh_silver_ms_sgp"), col("nbrclm_denied_inntwk_bh_gold_ms_sgp"), col("nbrclm_denied_inntwk_bh_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp", "nbrclm_denied_inntwk_bh_platinum_sgp", "nbrclm_denied_inntwk_bh_total_sgp", "nbrclm_denied_inntwk_bh_catastrophic",
        "nbrclm_denied_inntwk_bh_bronze_ms_ip", "nbrclm_denied_inntwk_bh_silver_ms_ip", "nbrclm_denied_inntwk_bh_gold_ms_ip", "nbrclm_denied_inntwk_bh_platinum_ms_ip", "nbrclm_denied_inntwk_bh_total_ms_ip",
        "nbrclm_denied_inntwk_bh_bronze_ms_sgp", "nbrclm_denied_inntwk_bh_silver_ms_sgp", "nbrclm_denied_inntwk_bh_gold_ms_sgp", "nbrclm_denied_inntwk_bh_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_inntwk_bh_bronze_ms_sgp.union(nbrclm_denied_inntwk_bh_silver_ms_sgp.union(nbrclm_denied_inntwk_bh_gold_ms_sgp.union(nbrclm_denied_inntwk_bh_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_inntwk_bh_bronze_ms_sgp")

    val nbrclm_denied_inntwk_bh_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_inntwk_bh_bronze_ms_sgp").alias("nbrclm_denied_inntwk_bh_total_ms_sgp"))

    val denied_inntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_inntwk_bh_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_bh_bronze_ip"), col("nbrclm_denied_inntwk_bh_silver_ip"), col("nbrclm_denied_inntwk_bh_gold_ip"), col("nbrclm_denied_inntwk_bh_platinum_ip"), col("nbrclm_denied_inntwk_bh_total_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_sgp"), col("nbrclm_denied_inntwk_bh_silver_sgp"), col("nbrclm_denied_inntwk_bh_gold_sgp"), col("nbrclm_denied_inntwk_bh_platinum_sgp"), col("nbrclm_denied_inntwk_bh_total_sgp"), col("nbrclm_denied_inntwk_bh_catastrophic"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_ip"), col("nbrclm_denied_inntwk_bh_silver_ms_ip"), col("nbrclm_denied_inntwk_bh_gold_ms_ip"), col("nbrclm_denied_inntwk_bh_platinum_ms_ip"), col("nbrclm_denied_inntwk_bh_total_ms_ip"),
        col("nbrclm_denied_inntwk_bh_bronze_ms_sgp"), col("nbrclm_denied_inntwk_bh_silver_ms_sgp"), col("nbrclm_denied_inntwk_bh_gold_ms_sgp"), col("nbrclm_denied_inntwk_bh_platinum_ms_sgp"), col("nbrclm_denied_inntwk_bh_total_ms_sgp"))

    val denied_inntwk_Data_bh = denied_inntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_inntwk_bh_bronze_ip", "nbrclm_denied_inntwk_bh_silver_ip", "nbrclm_denied_inntwk_bh_gold_ip", "nbrclm_denied_inntwk_bh_platinum_ip", "nbrclm_denied_inntwk_bh_total_ip",
        "nbrclm_denied_inntwk_bh_bronze_sgp", "nbrclm_denied_inntwk_bh_silver_sgp", "nbrclm_denied_inntwk_bh_gold_sgp", "nbrclm_denied_inntwk_bh_platinum_sgp", "nbrclm_denied_inntwk_bh_total_sgp", "nbrclm_denied_inntwk_bh_catastrophic",
        "nbrclm_denied_inntwk_bh_bronze_ms_ip", "nbrclm_denied_inntwk_bh_silver_ms_ip", "nbrclm_denied_inntwk_bh_gold_ms_ip", "nbrclm_denied_inntwk_bh_platinum_ms_ip", "nbrclm_denied_inntwk_bh_total_ms_ip",
        "nbrclm_denied_inntwk_bh_bronze_ms_sgp", "nbrclm_denied_inntwk_bh_silver_ms_sgp", "nbrclm_denied_inntwk_bh_gold_ms_sgp", "nbrclm_denied_inntwk_bh_platinum_ms_sgp", "nbrclm_denied_inntwk_bh_total_ms_sgp")

    denied_inntwk_Data_bh

  }


  def getDeniedOutntwkce(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame,
                         naic2018_mcas_ce_src_eob_cd_inbnd: DataFrame, naic2018_mcas_ce_eob_cd_inbnd: DataFrame, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_brz = joinedDf2018(received_brnz, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_bronze_ip = denied_out_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sil = joinedDf2018(received_silver, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_silver_ip = denied_out_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_ce_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_ce_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip")

    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_gld = joinedDf2018(received_gold, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_gold_ip = denied_out_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_plt = joinedDf2018(received_platinum, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_platinum_ip = denied_out_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_ce_bronze_ip.union(nbrclm_denied_outntwk_ce_silver_ip.union(nbrclm_denied_outntwk_ce_gold_ip.union(nbrclm_denied_outntwk_ce_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_ce_bronze_ip")

    val nbrclm_denied_outntwk_ce_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_ce_bronze_ip").alias("nbrclm_denied_outntwk_ce_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_brz = joinedDf2018(received_sgp_bronze, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_bronze_sgp = denied_out_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_sil = joinedDf2018(received_sgp_silver, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_silver_sgp = denied_out_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_gld = joinedDf2018(received_sgp_gold, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_gold_sgp = denied_out_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_plt = joinedDf2018(received_sgp_plt, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_platinum_sgp = denied_out_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp")

    val tot_sgp = nbrclm_denied_outntwk_ce_bronze_sgp.union(nbrclm_denied_outntwk_ce_silver_sgp.union(nbrclm_denied_outntwk_ce_gold_sgp.union(nbrclm_denied_outntwk_ce_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_ce_bronze_sgp")

    val nbrclm_denied_outntwk_ce_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_ce_bronze_sgp").alias("nbrclm_denied_outntwk_ce_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp")

    val receivedCatFilters = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_cat = joinedDf2018(receivedCatFilters, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_catastrophic = denied_out_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_brz = joinedDf2018(received_msip_Brz, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_bronze_ms_ip = denied_out_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic",
        "nbrclm_denied_outntwk_ce_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_sil = joinedDf2018(received_msip_Sil, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_silver_ms_ip = denied_out_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_ip"), col("nbrclm_denied_outntwk_ce_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic",
        "nbrclm_denied_outntwk_ce_bronze_ms_ip", "nbrclm_denied_outntwk_ce_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_gld = joinedDf2018(received_msip_Gld, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_gold_ms_ip = denied_out_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_ip"), col("nbrclm_denied_outntwk_ce_silver_ms_ip"), col("nbrclm_denied_outntwk_ce_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic",
        "nbrclm_denied_outntwk_ce_bronze_ms_ip", "nbrclm_denied_outntwk_ce_silver_ms_ip", "nbrclm_denied_outntwk_ce_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_plt = joinedDf2018(received_msip_Plt, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_platinum_ms_ip = denied_out_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_ip"), col("nbrclm_denied_outntwk_ce_silver_ms_ip"), col("nbrclm_denied_outntwk_ce_gold_ms_ip"), col("nbrclm_denied_outntwk_ce_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic",
        "nbrclm_denied_outntwk_ce_bronze_ms_ip", "nbrclm_denied_outntwk_ce_silver_ms_ip", "nbrclm_denied_outntwk_ce_gold_ms_ip", "nbrclm_denied_outntwk_ce_platinum_ms_ip")

    val tot_msip = nbrclm_denied_outntwk_ce_bronze_ms_ip.union(nbrclm_denied_outntwk_ce_silver_ms_ip.union(nbrclm_denied_outntwk_ce_gold_ms_ip.union(nbrclm_denied_outntwk_ce_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_ce_bronze_ms_ip")

    val nbrclm_denied_outntwk_ce_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_ce_bronze_ms_ip").alias("nbrclm_denied_outntwk_ce_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_ip"), col("nbrclm_denied_outntwk_ce_silver_ms_ip"), col("nbrclm_denied_outntwk_ce_gold_ms_ip"), col("nbrclm_denied_outntwk_ce_platinum_ms_ip"), col("nbrclm_denied_outntwk_ce_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic",
        "nbrclm_denied_outntwk_ce_bronze_ms_ip", "nbrclm_denied_outntwk_ce_silver_ms_ip", "nbrclm_denied_outntwk_ce_gold_ms_ip", "nbrclm_denied_outntwk_ce_platinum_ms_ip", "nbrclm_denied_outntwk_ce_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_brz = joinedDf2018(received_mssgp_Brz, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_bronze_ms_sgp = denied_out_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_ip"), col("nbrclm_denied_outntwk_ce_silver_ms_ip"), col("nbrclm_denied_outntwk_ce_gold_ms_ip"), col("nbrclm_denied_outntwk_ce_platinum_ms_ip"), col("nbrclm_denied_outntwk_ce_total_ms_ip"), col("nbrclm_denied_outntwk_ce_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic",
        "nbrclm_denied_outntwk_ce_bronze_ms_ip", "nbrclm_denied_outntwk_ce_silver_ms_ip", "nbrclm_denied_outntwk_ce_gold_ms_ip", "nbrclm_denied_outntwk_ce_platinum_ms_ip", "nbrclm_denied_outntwk_ce_total_ms_ip",
        "nbrclm_denied_outntwk_ce_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_sil = joinedDf2018(received_mssgp_Sil, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_silver_ms_sgp = denied_out_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_ip"), col("nbrclm_denied_outntwk_ce_silver_ms_ip"), col("nbrclm_denied_outntwk_ce_gold_ms_ip"), col("nbrclm_denied_outntwk_ce_platinum_ms_ip"), col("nbrclm_denied_outntwk_ce_total_ms_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ce_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic",
        "nbrclm_denied_outntwk_ce_bronze_ms_ip", "nbrclm_denied_outntwk_ce_silver_ms_ip", "nbrclm_denied_outntwk_ce_gold_ms_ip", "nbrclm_denied_outntwk_ce_platinum_ms_ip", "nbrclm_denied_outntwk_ce_total_ms_ip",
        "nbrclm_denied_outntwk_ce_bronze_ms_sgp", "nbrclm_denied_outntwk_ce_silver_ms_sgp")

    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_gld = joinedDf2018(received_mssgp_Gld, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_gold_ms_sgp = denied_out_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_ip"), col("nbrclm_denied_outntwk_ce_silver_ms_ip"), col("nbrclm_denied_outntwk_ce_gold_ms_ip"), col("nbrclm_denied_outntwk_ce_platinum_ms_ip"), col("nbrclm_denied_outntwk_ce_total_ms_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ce_silver_ms_sgp"), col("nbrclm_denied_outntwk_ce_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic",
        "nbrclm_denied_outntwk_ce_bronze_ms_ip", "nbrclm_denied_outntwk_ce_silver_ms_ip", "nbrclm_denied_outntwk_ce_gold_ms_ip", "nbrclm_denied_outntwk_ce_platinum_ms_ip", "nbrclm_denied_outntwk_ce_total_ms_ip",
        "nbrclm_denied_outntwk_ce_bronze_ms_sgp", "nbrclm_denied_outntwk_ce_silver_ms_sgp", "nbrclm_denied_outntwk_ce_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_plt = joinedDf2018(received_mssgp_Plt, naic2018_mcas_ce_src_eob_cd_inbnd, naic2018_mcas_ce_eob_cd_inbnd, naic2018_mcas_ce_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ce_platinum_ms_sgp = denied_out_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ce_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_ip"), col("nbrclm_denied_outntwk_ce_silver_ms_ip"), col("nbrclm_denied_outntwk_ce_gold_ms_ip"), col("nbrclm_denied_outntwk_ce_platinum_ms_ip"), col("nbrclm_denied_outntwk_ce_total_ms_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ce_silver_ms_sgp"), col("nbrclm_denied_outntwk_ce_gold_ms_sgp"), col("nbrclm_denied_outntwk_ce_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic",
        "nbrclm_denied_outntwk_ce_bronze_ms_ip", "nbrclm_denied_outntwk_ce_silver_ms_ip", "nbrclm_denied_outntwk_ce_gold_ms_ip", "nbrclm_denied_outntwk_ce_platinum_ms_ip", "nbrclm_denied_outntwk_ce_total_ms_ip",
        "nbrclm_denied_outntwk_ce_bronze_ms_sgp", "nbrclm_denied_outntwk_ce_silver_ms_sgp", "nbrclm_denied_outntwk_ce_gold_ms_sgp", "nbrclm_denied_outntwk_ce_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_outntwk_ce_bronze_ms_sgp.union(nbrclm_denied_outntwk_ce_silver_ms_sgp.union(nbrclm_denied_outntwk_ce_gold_ms_sgp.union(nbrclm_denied_outntwk_ce_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_ce_bronze_ms_sgp")

    val nbrclm_denied_outntwk_ce_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_ce_bronze_ms_sgp").alias("nbrclm_denied_outntwk_ce_total_ms_sgp"))

    val denied_outntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_outntwk_ce_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ce_bronze_ip"), col("nbrclm_denied_outntwk_ce_silver_ip"), col("nbrclm_denied_outntwk_ce_gold_ip"), col("nbrclm_denied_outntwk_ce_platinum_ip"), col("nbrclm_denied_outntwk_ce_total_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_sgp"), col("nbrclm_denied_outntwk_ce_silver_sgp"), col("nbrclm_denied_outntwk_ce_gold_sgp"), col("nbrclm_denied_outntwk_ce_platinum_sgp"), col("nbrclm_denied_outntwk_ce_total_sgp"), col("nbrclm_denied_outntwk_ce_catastrophic"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_ip"), col("nbrclm_denied_outntwk_ce_silver_ms_ip"), col("nbrclm_denied_outntwk_ce_gold_ms_ip"), col("nbrclm_denied_outntwk_ce_platinum_ms_ip"), col("nbrclm_denied_outntwk_ce_total_ms_ip"),
        col("nbrclm_denied_outntwk_ce_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ce_silver_ms_sgp"), col("nbrclm_denied_outntwk_ce_gold_ms_sgp"), col("nbrclm_denied_outntwk_ce_platinum_ms_sgp"), col("nbrclm_denied_outntwk_ce_total_ms_sgp"))

    val denied_outntwk_Data_ce = denied_outntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ce_bronze_ip", "nbrclm_denied_outntwk_ce_silver_ip", "nbrclm_denied_outntwk_ce_gold_ip", "nbrclm_denied_outntwk_ce_platinum_ip", "nbrclm_denied_outntwk_ce_total_ip",
        "nbrclm_denied_outntwk_ce_bronze_sgp", "nbrclm_denied_outntwk_ce_silver_sgp", "nbrclm_denied_outntwk_ce_gold_sgp", "nbrclm_denied_outntwk_ce_platinum_sgp", "nbrclm_denied_outntwk_ce_total_sgp", "nbrclm_denied_outntwk_ce_catastrophic",
        "nbrclm_denied_outntwk_ce_bronze_ms_ip", "nbrclm_denied_outntwk_ce_silver_ms_ip", "nbrclm_denied_outntwk_ce_gold_ms_ip", "nbrclm_denied_outntwk_ce_platinum_ms_ip", "nbrclm_denied_outntwk_ce_total_ms_ip",
        "nbrclm_denied_outntwk_ce_bronze_ms_sgp", "nbrclm_denied_outntwk_ce_silver_ms_sgp", "nbrclm_denied_outntwk_ce_gold_ms_sgp", "nbrclm_denied_outntwk_ce_platinum_ms_sgp", "nbrclm_denied_outntwk_ce_total_ms_sgp")

    denied_outntwk_Data_ce
  }

  def getDeniedOutntwkpa(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame,
                         naic2018_mcas_pa_src_eob_cd_inbnd: DataFrame, naic2018_mcas_pa_eob_cd_inbnd: DataFrame, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_brz = joinedDf2018(received_brnz, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_bronze_ip = denied_out_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sil = joinedDf2018(received_silver, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_silver_ip = denied_out_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_pa_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_pa_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip")

    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_gld = joinedDf2018(received_gold, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_gold_ip = denied_out_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_plt = joinedDf2018(received_platinum, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_platinum_ip = denied_out_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_pa_bronze_ip.union(nbrclm_denied_outntwk_pa_silver_ip.union(nbrclm_denied_outntwk_pa_gold_ip.union(nbrclm_denied_outntwk_pa_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_pa_bronze_ip")

    val nbrclm_denied_outntwk_pa_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_pa_bronze_ip").alias("nbrclm_denied_outntwk_pa_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_brz = joinedDf2018(received_sgp_bronze, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_bronze_sgp = denied_out_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_sil = joinedDf2018(received_sgp_silver, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_silver_sgp = denied_out_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_gld = joinedDf2018(received_sgp_gold, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_gold_sgp = denied_out_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_plt = joinedDf2018(received_sgp_plt, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_platinum_sgp = denied_out_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp")

    val tot_sgp = nbrclm_denied_outntwk_pa_bronze_sgp.union(nbrclm_denied_outntwk_pa_silver_sgp.union(nbrclm_denied_outntwk_pa_gold_sgp.union(nbrclm_denied_outntwk_pa_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_pa_bronze_sgp")

    val nbrclm_denied_outntwk_pa_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_pa_bronze_sgp").alias("nbrclm_denied_outntwk_pa_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp")

    val receivedCatFilters = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_cat = joinedDf2018(receivedCatFilters, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_catastrophic = denied_out_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_brz = joinedDf2018(received_msip_Brz, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_bronze_ms_ip = denied_out_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic",
        "nbrclm_denied_outntwk_pa_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_sil = joinedDf2018(received_msip_Sil, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_silver_ms_ip = denied_out_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_ip"), col("nbrclm_denied_outntwk_pa_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic",
        "nbrclm_denied_outntwk_pa_bronze_ms_ip", "nbrclm_denied_outntwk_pa_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_gld = joinedDf2018(received_msip_Gld, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_gold_ms_ip = denied_out_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_ip"), col("nbrclm_denied_outntwk_pa_silver_ms_ip"), col("nbrclm_denied_outntwk_pa_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic",
        "nbrclm_denied_outntwk_pa_bronze_ms_ip", "nbrclm_denied_outntwk_pa_silver_ms_ip", "nbrclm_denied_outntwk_pa_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_plt = joinedDf2018(received_msip_Plt, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_platinum_ms_ip = denied_out_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_ip"), col("nbrclm_denied_outntwk_pa_silver_ms_ip"), col("nbrclm_denied_outntwk_pa_gold_ms_ip"), col("nbrclm_denied_outntwk_pa_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic",
        "nbrclm_denied_outntwk_pa_bronze_ms_ip", "nbrclm_denied_outntwk_pa_silver_ms_ip", "nbrclm_denied_outntwk_pa_gold_ms_ip", "nbrclm_denied_outntwk_pa_platinum_ms_ip")

    val tot_msip = nbrclm_denied_outntwk_pa_bronze_ms_ip.union(nbrclm_denied_outntwk_pa_silver_ms_ip.union(nbrclm_denied_outntwk_pa_gold_ms_ip.union(nbrclm_denied_outntwk_pa_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_pa_bronze_ms_ip")

    val nbrclm_denied_outntwk_pa_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_pa_bronze_ms_ip").alias("nbrclm_denied_outntwk_pa_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_ip"), col("nbrclm_denied_outntwk_pa_silver_ms_ip"), col("nbrclm_denied_outntwk_pa_gold_ms_ip"), col("nbrclm_denied_outntwk_pa_platinum_ms_ip"), col("nbrclm_denied_outntwk_pa_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic",
        "nbrclm_denied_outntwk_pa_bronze_ms_ip", "nbrclm_denied_outntwk_pa_silver_ms_ip", "nbrclm_denied_outntwk_pa_gold_ms_ip", "nbrclm_denied_outntwk_pa_platinum_ms_ip", "nbrclm_denied_outntwk_pa_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_brz = joinedDf2018(received_mssgp_Brz, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_bronze_ms_sgp = denied_out_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_ip"), col("nbrclm_denied_outntwk_pa_silver_ms_ip"), col("nbrclm_denied_outntwk_pa_gold_ms_ip"), col("nbrclm_denied_outntwk_pa_platinum_ms_ip"), col("nbrclm_denied_outntwk_pa_total_ms_ip"), col("nbrclm_denied_outntwk_pa_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic",
        "nbrclm_denied_outntwk_pa_bronze_ms_ip", "nbrclm_denied_outntwk_pa_silver_ms_ip", "nbrclm_denied_outntwk_pa_gold_ms_ip", "nbrclm_denied_outntwk_pa_platinum_ms_ip", "nbrclm_denied_outntwk_pa_total_ms_ip",
        "nbrclm_denied_outntwk_pa_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_sil = joinedDf2018(received_mssgp_Sil, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_silver_ms_sgp = denied_out_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_ip"), col("nbrclm_denied_outntwk_pa_silver_ms_ip"), col("nbrclm_denied_outntwk_pa_gold_ms_ip"), col("nbrclm_denied_outntwk_pa_platinum_ms_ip"), col("nbrclm_denied_outntwk_pa_total_ms_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_sgp"), col("nbrclm_denied_outntwk_pa_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic",
        "nbrclm_denied_outntwk_pa_bronze_ms_ip", "nbrclm_denied_outntwk_pa_silver_ms_ip", "nbrclm_denied_outntwk_pa_gold_ms_ip", "nbrclm_denied_outntwk_pa_platinum_ms_ip", "nbrclm_denied_outntwk_pa_total_ms_ip",
        "nbrclm_denied_outntwk_pa_bronze_ms_sgp", "nbrclm_denied_outntwk_pa_silver_ms_sgp")

    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_gld = joinedDf2018(received_mssgp_Gld, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_gold_ms_sgp = denied_out_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_ip"), col("nbrclm_denied_outntwk_pa_silver_ms_ip"), col("nbrclm_denied_outntwk_pa_gold_ms_ip"), col("nbrclm_denied_outntwk_pa_platinum_ms_ip"), col("nbrclm_denied_outntwk_pa_total_ms_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_sgp"), col("nbrclm_denied_outntwk_pa_silver_ms_sgp"), col("nbrclm_denied_outntwk_pa_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic",
        "nbrclm_denied_outntwk_pa_bronze_ms_ip", "nbrclm_denied_outntwk_pa_silver_ms_ip", "nbrclm_denied_outntwk_pa_gold_ms_ip", "nbrclm_denied_outntwk_pa_platinum_ms_ip", "nbrclm_denied_outntwk_pa_total_ms_ip",
        "nbrclm_denied_outntwk_pa_bronze_ms_sgp", "nbrclm_denied_outntwk_pa_silver_ms_sgp", "nbrclm_denied_outntwk_pa_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_plt = joinedDf2018(received_mssgp_Plt, naic2018_mcas_pa_src_eob_cd_inbnd, naic2018_mcas_pa_eob_cd_inbnd, naic2018_mcas_pa_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_pa_platinum_ms_sgp = denied_out_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_pa_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_ip"), col("nbrclm_denied_outntwk_pa_silver_ms_ip"), col("nbrclm_denied_outntwk_pa_gold_ms_ip"), col("nbrclm_denied_outntwk_pa_platinum_ms_ip"), col("nbrclm_denied_outntwk_pa_total_ms_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_sgp"), col("nbrclm_denied_outntwk_pa_silver_ms_sgp"), col("nbrclm_denied_outntwk_pa_gold_ms_sgp"), col("nbrclm_denied_outntwk_pa_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic",
        "nbrclm_denied_outntwk_pa_bronze_ms_ip", "nbrclm_denied_outntwk_pa_silver_ms_ip", "nbrclm_denied_outntwk_pa_gold_ms_ip", "nbrclm_denied_outntwk_pa_platinum_ms_ip", "nbrclm_denied_outntwk_pa_total_ms_ip",
        "nbrclm_denied_outntwk_pa_bronze_ms_sgp", "nbrclm_denied_outntwk_pa_silver_ms_sgp", "nbrclm_denied_outntwk_pa_gold_ms_sgp", "nbrclm_denied_outntwk_pa_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_outntwk_pa_bronze_ms_sgp.union(nbrclm_denied_outntwk_pa_silver_ms_sgp.union(nbrclm_denied_outntwk_pa_gold_ms_sgp.union(nbrclm_denied_outntwk_pa_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_pa_bronze_ms_sgp")

    val nbrclm_denied_outntwk_pa_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_pa_bronze_ms_sgp").alias("nbrclm_denied_outntwk_pa_total_ms_sgp"))

    val denied_outntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_outntwk_pa_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_pa_bronze_ip"), col("nbrclm_denied_outntwk_pa_silver_ip"), col("nbrclm_denied_outntwk_pa_gold_ip"), col("nbrclm_denied_outntwk_pa_platinum_ip"), col("nbrclm_denied_outntwk_pa_total_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_sgp"), col("nbrclm_denied_outntwk_pa_silver_sgp"), col("nbrclm_denied_outntwk_pa_gold_sgp"), col("nbrclm_denied_outntwk_pa_platinum_sgp"), col("nbrclm_denied_outntwk_pa_total_sgp"), col("nbrclm_denied_outntwk_pa_catastrophic"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_ip"), col("nbrclm_denied_outntwk_pa_silver_ms_ip"), col("nbrclm_denied_outntwk_pa_gold_ms_ip"), col("nbrclm_denied_outntwk_pa_platinum_ms_ip"), col("nbrclm_denied_outntwk_pa_total_ms_ip"),
        col("nbrclm_denied_outntwk_pa_bronze_ms_sgp"), col("nbrclm_denied_outntwk_pa_silver_ms_sgp"), col("nbrclm_denied_outntwk_pa_gold_ms_sgp"), col("nbrclm_denied_outntwk_pa_platinum_ms_sgp"), col("nbrclm_denied_outntwk_pa_total_ms_sgp"))

    val denied_outntwk_Data_pa = denied_outntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_pa_bronze_ip", "nbrclm_denied_outntwk_pa_silver_ip", "nbrclm_denied_outntwk_pa_gold_ip", "nbrclm_denied_outntwk_pa_platinum_ip", "nbrclm_denied_outntwk_pa_total_ip",
        "nbrclm_denied_outntwk_pa_bronze_sgp", "nbrclm_denied_outntwk_pa_silver_sgp", "nbrclm_denied_outntwk_pa_gold_sgp", "nbrclm_denied_outntwk_pa_platinum_sgp", "nbrclm_denied_outntwk_pa_total_sgp", "nbrclm_denied_outntwk_pa_catastrophic",
        "nbrclm_denied_outntwk_pa_bronze_ms_ip", "nbrclm_denied_outntwk_pa_silver_ms_ip", "nbrclm_denied_outntwk_pa_gold_ms_ip", "nbrclm_denied_outntwk_pa_platinum_ms_ip", "nbrclm_denied_outntwk_pa_total_ms_ip",
        "nbrclm_denied_outntwk_pa_bronze_ms_sgp", "nbrclm_denied_outntwk_pa_silver_ms_sgp", "nbrclm_denied_outntwk_pa_gold_ms_sgp", "nbrclm_denied_outntwk_pa_platinum_ms_sgp", "nbrclm_denied_outntwk_pa_total_ms_sgp")

    denied_outntwk_Data_pa
  }

  def getDeniedOutntwkncb(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame,
                          naic2018_mcas_ncb_src_eob_cd_inbnd: DataFrame, naic2018_mcas_ncb_eob_cd_inbnd: DataFrame, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_brz = joinedDf2018(received_brnz, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_bronze_ip = denied_out_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sil = joinedDf2018(received_silver, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_silver_ip = denied_out_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_ncb_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_ncb_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip")

    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_gld = joinedDf2018(received_gold, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_gold_ip = denied_out_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_plt = joinedDf2018(received_platinum, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_platinum_ip = denied_out_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_ncb_bronze_ip.union(nbrclm_denied_outntwk_ncb_silver_ip.union(nbrclm_denied_outntwk_ncb_gold_ip.union(nbrclm_denied_outntwk_ncb_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_ncb_bronze_ip")

    val nbrclm_denied_outntwk_ncb_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_ncb_bronze_ip").alias("nbrclm_denied_outntwk_ncb_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_brz = joinedDf2018(received_sgp_bronze, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_bronze_sgp = denied_out_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_sil = joinedDf2018(received_sgp_silver, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_silver_sgp = denied_out_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_gld = joinedDf2018(received_sgp_gold, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_gold_sgp = denied_out_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_plt = joinedDf2018(received_sgp_plt, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_platinum_sgp = denied_out_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp")

    val tot_sgp = nbrclm_denied_outntwk_ncb_bronze_sgp.union(nbrclm_denied_outntwk_ncb_silver_sgp.union(nbrclm_denied_outntwk_ncb_gold_sgp.union(nbrclm_denied_outntwk_ncb_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_ncb_bronze_sgp")

    val nbrclm_denied_outntwk_ncb_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_ncb_bronze_sgp").alias("nbrclm_denied_outntwk_ncb_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp")

    val receivedCatFilters = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      $"in_Exchange".equalTo("IN") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_cat = joinedDf2018(receivedCatFilters, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_catastrophic = denied_out_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp", "nbrclm_denied_outntwk_ncb_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_brz = joinedDf2018(received_msip_Brz, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_bronze_ms_ip = denied_out_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp", "nbrclm_denied_outntwk_ncb_catastrophic",
        "nbrclm_denied_outntwk_ncb_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_sil = joinedDf2018(received_msip_Sil, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_silver_ms_ip = denied_out_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_outntwk_ncb_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp", "nbrclm_denied_outntwk_ncb_catastrophic",
        "nbrclm_denied_outntwk_ncb_bronze_ms_ip", "nbrclm_denied_outntwk_ncb_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_gld = joinedDf2018(received_msip_Gld, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_gold_ms_ip = denied_out_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_outntwk_ncb_silver_ms_ip"), col("nbrclm_denied_outntwk_ncb_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp", "nbrclm_denied_outntwk_ncb_catastrophic",
        "nbrclm_denied_outntwk_ncb_bronze_ms_ip", "nbrclm_denied_outntwk_ncb_silver_ms_ip", "nbrclm_denied_outntwk_ncb_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_plt = joinedDf2018(received_msip_Plt, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_platinum_ms_ip = denied_out_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_outntwk_ncb_silver_ms_ip"), col("nbrclm_denied_outntwk_ncb_gold_ms_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp", "nbrclm_denied_outntwk_ncb_catastrophic",
        "nbrclm_denied_outntwk_ncb_bronze_ms_ip", "nbrclm_denied_outntwk_ncb_silver_ms_ip", "nbrclm_denied_outntwk_ncb_gold_ms_ip", "nbrclm_denied_outntwk_ncb_platinum_ms_ip")

    val tot_msip = nbrclm_denied_outntwk_ncb_bronze_ms_ip.union(nbrclm_denied_outntwk_ncb_silver_ms_ip.union(nbrclm_denied_outntwk_ncb_gold_ms_ip.union(nbrclm_denied_outntwk_ncb_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_ncb_bronze_ms_ip")

    val nbrclm_denied_outntwk_ncb_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_ncb_bronze_ms_ip").alias("nbrclm_denied_outntwk_ncb_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_outntwk_ncb_silver_ms_ip"), col("nbrclm_denied_outntwk_ncb_gold_ms_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_outntwk_ncb_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp", "nbrclm_denied_outntwk_ncb_catastrophic",
        "nbrclm_denied_outntwk_ncb_bronze_ms_ip", "nbrclm_denied_outntwk_ncb_silver_ms_ip", "nbrclm_denied_outntwk_ncb_gold_ms_ip", "nbrclm_denied_outntwk_ncb_platinum_ms_ip", "nbrclm_denied_outntwk_ncb_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_brz = joinedDf2018(received_mssgp_Brz, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_bronze_ms_sgp = denied_out_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_outntwk_ncb_silver_ms_ip"), col("nbrclm_denied_outntwk_ncb_gold_ms_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_outntwk_ncb_total_ms_ip"), col("nbrclm_denied_outntwk_ncb_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp", "nbrclm_denied_outntwk_ncb_catastrophic",
        "nbrclm_denied_outntwk_ncb_bronze_ms_ip", "nbrclm_denied_outntwk_ncb_silver_ms_ip", "nbrclm_denied_outntwk_ncb_gold_ms_ip", "nbrclm_denied_outntwk_ncb_platinum_ms_ip", "nbrclm_denied_outntwk_ncb_total_ms_ip",
        "nbrclm_denied_outntwk_ncb_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_sil = joinedDf2018(received_mssgp_Sil, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_silver_ms_sgp = denied_out_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_outntwk_ncb_silver_ms_ip"), col("nbrclm_denied_outntwk_ncb_gold_ms_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_outntwk_ncb_total_ms_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ncb_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp", "nbrclm_denied_outntwk_ncb_catastrophic",
        "nbrclm_denied_outntwk_ncb_bronze_ms_ip", "nbrclm_denied_outntwk_ncb_silver_ms_ip", "nbrclm_denied_outntwk_ncb_gold_ms_ip", "nbrclm_denied_outntwk_ncb_platinum_ms_ip", "nbrclm_denied_outntwk_ncb_total_ms_ip",
        "nbrclm_denied_outntwk_ncb_bronze_ms_sgp", "nbrclm_denied_outntwk_ncb_silver_ms_sgp")

    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_gld = joinedDf2018(received_mssgp_Gld, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_gold_ms_sgp = denied_out_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_outntwk_ncb_silver_ms_ip"), col("nbrclm_denied_outntwk_ncb_gold_ms_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_outntwk_ncb_total_ms_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ncb_silver_ms_sgp"), col("nbrclm_denied_outntwk_ncb_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp", "nbrclm_denied_outntwk_ncb_catastrophic",
        "nbrclm_denied_outntwk_ncb_bronze_ms_ip", "nbrclm_denied_outntwk_ncb_silver_ms_ip", "nbrclm_denied_outntwk_ncb_gold_ms_ip", "nbrclm_denied_outntwk_ncb_platinum_ms_ip", "nbrclm_denied_outntwk_ncb_total_ms_ip",
        "nbrclm_denied_outntwk_ncb_bronze_ms_sgp", "nbrclm_denied_outntwk_ncb_silver_ms_sgp", "nbrclm_denied_outntwk_ncb_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_plt = joinedDf2018(received_mssgp_Plt, naic2018_mcas_ncb_src_eob_cd_inbnd, naic2018_mcas_ncb_eob_cd_inbnd, naic2018_mcas_ncb_src_clm_line_disp_rsn_cd_inbnd)

    val nbrclm_denied_outntwk_ncb_platinum_ms_sgp = denied_out_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ncb_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_outntwk_ncb_silver_ms_ip"), col("nbrclm_denied_outntwk_ncb_gold_ms_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_outntwk_ncb_total_ms_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ncb_silver_ms_sgp"), col("nbrclm_denied_outntwk_ncb_gold_ms_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp", "nbrclm_denied_outntwk_ncb_catastrophic",
        "nbrclm_denied_outntwk_ncb_bronze_ms_ip", "nbrclm_denied_outntwk_ncb_silver_ms_ip", "nbrclm_denied_outntwk_ncb_gold_ms_ip", "nbrclm_denied_outntwk_ncb_platinum_ms_ip", "nbrclm_denied_outntwk_ncb_total_ms_ip",
        "nbrclm_denied_outntwk_ncb_bronze_ms_sgp", "nbrclm_denied_outntwk_ncb_silver_ms_sgp", "nbrclm_denied_outntwk_ncb_gold_ms_sgp", "nbrclm_denied_outntwk_ncb_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_outntwk_ncb_bronze_ms_sgp.union(nbrclm_denied_outntwk_ncb_silver_ms_sgp.union(nbrclm_denied_outntwk_ncb_gold_ms_sgp.union(nbrclm_denied_outntwk_ncb_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_ncb_bronze_ms_sgp")

    val nbrclm_denied_outntwk_ncb_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_ncb_bronze_ms_sgp").alias("nbrclm_denied_outntwk_ncb_total_ms_sgp"))

    val denied_outntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_outntwk_ncb_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ncb_bronze_ip"), col("nbrclm_denied_outntwk_ncb_silver_ip"), col("nbrclm_denied_outntwk_ncb_gold_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ip"), col("nbrclm_denied_outntwk_ncb_total_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_sgp"), col("nbrclm_denied_outntwk_ncb_silver_sgp"), col("nbrclm_denied_outntwk_ncb_gold_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_sgp"), col("nbrclm_denied_outntwk_ncb_total_sgp"), col("nbrclm_denied_outntwk_ncb_catastrophic"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_ip"), col("nbrclm_denied_outntwk_ncb_silver_ms_ip"), col("nbrclm_denied_outntwk_ncb_gold_ms_ip"), col("nbrclm_denied_outntwk_ncb_platinum_ms_ip"), col("nbrclm_denied_outntwk_ncb_total_ms_ip"),
        col("nbrclm_denied_outntwk_ncb_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ncb_silver_ms_sgp"), col("nbrclm_denied_outntwk_ncb_gold_ms_sgp"), col("nbrclm_denied_outntwk_ncb_platinum_ms_sgp"), col("nbrclm_denied_outntwk_ncb_total_ms_sgp"))

    val denied_outntwk_Data_ncb = denied_outntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ncb_bronze_ip", "nbrclm_denied_outntwk_ncb_silver_ip", "nbrclm_denied_outntwk_ncb_gold_ip", "nbrclm_denied_outntwk_ncb_platinum_ip", "nbrclm_denied_outntwk_ncb_total_ip",
        "nbrclm_denied_outntwk_ncb_bronze_sgp", "nbrclm_denied_outntwk_ncb_silver_sgp", "nbrclm_denied_outntwk_ncb_gold_sgp", "nbrclm_denied_outntwk_ncb_platinum_sgp", "nbrclm_denied_outntwk_ncb_total_sgp", "nbrclm_denied_outntwk_ncb_catastrophic",
        "nbrclm_denied_outntwk_ncb_bronze_ms_ip", "nbrclm_denied_outntwk_ncb_silver_ms_ip", "nbrclm_denied_outntwk_ncb_gold_ms_ip", "nbrclm_denied_outntwk_ncb_platinum_ms_ip", "nbrclm_denied_outntwk_ncb_total_ms_ip",
        "nbrclm_denied_outntwk_ncb_bronze_ms_sgp", "nbrclm_denied_outntwk_ncb_silver_ms_sgp", "nbrclm_denied_outntwk_ncb_gold_ms_sgp", "nbrclm_denied_outntwk_ncb_platinum_ms_sgp", "nbrclm_denied_outntwk_ncb_total_ms_sgp")

    denied_outntwk_Data_ncb
  }

  def getDeniedOutntwkebh(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame,
                          naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame, 
                          naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_brz = joinedDfEbh(received_brnz, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_bronze_ip = denied_out_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sil = joinedDfEbh(received_silver, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_silver_ip = denied_out_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_ebh_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_ebh_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip")

    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_gld = joinedDfEbh(received_gold, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_gold_ip = denied_out_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_plt = joinedDfEbh(received_platinum, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_platinum_ip = denied_out_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_ebh_bronze_ip.union(nbrclm_denied_outntwk_ebh_silver_ip.union(nbrclm_denied_outntwk_ebh_gold_ip.union(nbrclm_denied_outntwk_ebh_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_ebh_bronze_ip")

    val nbrclm_denied_outntwk_ebh_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_ebh_bronze_ip").alias("nbrclm_denied_outntwk_ebh_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_brz = joinedDfEbh(received_sgp_bronze, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_bronze_sgp = denied_out_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_sil = joinedDfEbh(received_sgp_silver, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_silver_sgp = denied_out_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_gld = joinedDfEbh(received_sgp_gold, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_gold_sgp = denied_out_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_plt = joinedDfEbh(received_sgp_plt, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_platinum_sgp = denied_out_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp")

    val tot_sgp = nbrclm_denied_outntwk_ebh_bronze_sgp.union(nbrclm_denied_outntwk_ebh_silver_sgp.union(nbrclm_denied_outntwk_ebh_gold_sgp.union(nbrclm_denied_outntwk_ebh_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_ebh_bronze_sgp")

    val nbrclm_denied_outntwk_ebh_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_ebh_bronze_sgp").alias("nbrclm_denied_outntwk_ebh_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp", "nbrclm_denied_outntwk_ebh_total_sgp")

    val receivedCatFilters = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_cat = joinedDfEbh(receivedCatFilters, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_catastrophic = denied_out_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"), col("nbrclm_denied_outntwk_ebh_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp", "nbrclm_denied_outntwk_ebh_total_sgp", "nbrclm_denied_outntwk_ebh_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_brz = joinedDfEbh(received_msip_Brz, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_bronze_ms_ip = denied_out_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"), col("nbrclm_denied_outntwk_ebh_catastrophic"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp", "nbrclm_denied_outntwk_ebh_total_sgp", "nbrclm_denied_outntwk_ebh_catastrophic",
        "nbrclm_denied_outntwk_ebh_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_sil = joinedDfEbh(received_msip_Sil, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_silver_ms_ip = denied_out_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"), col("nbrclm_denied_outntwk_ebh_catastrophic"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_outntwk_ebh_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp", "nbrclm_denied_outntwk_ebh_total_sgp", "nbrclm_denied_outntwk_ebh_catastrophic",
        "nbrclm_denied_outntwk_ebh_bronze_ms_ip", "nbrclm_denied_outntwk_ebh_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_gld = joinedDfEbh(received_msip_Gld, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_gold_ms_ip = denied_out_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"), col("nbrclm_denied_outntwk_ebh_catastrophic"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_outntwk_ebh_silver_ms_ip"), col("nbrclm_denied_outntwk_ebh_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp", "nbrclm_denied_outntwk_ebh_total_sgp", "nbrclm_denied_outntwk_ebh_catastrophic",
        "nbrclm_denied_outntwk_ebh_bronze_ms_ip", "nbrclm_denied_outntwk_ebh_silver_ms_ip", "nbrclm_denied_outntwk_ebh_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_plt = joinedDfEbh(received_msip_Plt, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_platinum_ms_ip = denied_out_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"), col("nbrclm_denied_outntwk_ebh_catastrophic"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_outntwk_ebh_silver_ms_ip"), col("nbrclm_denied_outntwk_ebh_gold_ms_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp", "nbrclm_denied_outntwk_ebh_total_sgp", "nbrclm_denied_outntwk_ebh_catastrophic",
        "nbrclm_denied_outntwk_ebh_bronze_ms_ip", "nbrclm_denied_outntwk_ebh_silver_ms_ip", "nbrclm_denied_outntwk_ebh_gold_ms_ip", "nbrclm_denied_outntwk_ebh_platinum_ms_ip")

    val tot_msip = nbrclm_denied_outntwk_ebh_bronze_ms_ip.union(nbrclm_denied_outntwk_ebh_silver_ms_ip.union(nbrclm_denied_outntwk_ebh_gold_ms_ip.union(nbrclm_denied_outntwk_ebh_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_ebh_bronze_ms_ip")

    val nbrclm_denied_outntwk_ebh_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_ebh_bronze_ms_ip").alias("nbrclm_denied_outntwk_ebh_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"), col("nbrclm_denied_outntwk_ebh_catastrophic"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_outntwk_ebh_silver_ms_ip"), col("nbrclm_denied_outntwk_ebh_gold_ms_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_outntwk_ebh_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp", "nbrclm_denied_outntwk_ebh_total_sgp", "nbrclm_denied_outntwk_ebh_catastrophic",
        "nbrclm_denied_outntwk_ebh_bronze_ms_ip", "nbrclm_denied_outntwk_ebh_silver_ms_ip", "nbrclm_denied_outntwk_ebh_gold_ms_ip", "nbrclm_denied_outntwk_ebh_platinum_ms_ip", "nbrclm_denied_outntwk_ebh_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_brz = joinedDfEbh(received_mssgp_Brz, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_bronze_ms_sgp = denied_out_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"), col("nbrclm_denied_outntwk_ebh_catastrophic"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_outntwk_ebh_silver_ms_ip"), col("nbrclm_denied_outntwk_ebh_gold_ms_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_outntwk_ebh_total_ms_ip"), col("nbrclm_denied_outntwk_ebh_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp", "nbrclm_denied_outntwk_ebh_total_sgp", "nbrclm_denied_outntwk_ebh_catastrophic",
        "nbrclm_denied_outntwk_ebh_bronze_ms_ip", "nbrclm_denied_outntwk_ebh_silver_ms_ip", "nbrclm_denied_outntwk_ebh_gold_ms_ip", "nbrclm_denied_outntwk_ebh_platinum_ms_ip", "nbrclm_denied_outntwk_ebh_total_ms_ip",
        "nbrclm_denied_outntwk_ebh_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_sil = joinedDfEbh(received_mssgp_Sil, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_silver_ms_sgp = denied_out_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"), col("nbrclm_denied_outntwk_ebh_catastrophic"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_outntwk_ebh_silver_ms_ip"), col("nbrclm_denied_outntwk_ebh_gold_ms_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_outntwk_ebh_total_ms_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ebh_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp", "nbrclm_denied_outntwk_ebh_total_sgp", "nbrclm_denied_outntwk_ebh_catastrophic",
        "nbrclm_denied_outntwk_ebh_bronze_ms_ip", "nbrclm_denied_outntwk_ebh_silver_ms_ip", "nbrclm_denied_outntwk_ebh_gold_ms_ip", "nbrclm_denied_outntwk_ebh_platinum_ms_ip", "nbrclm_denied_outntwk_ebh_total_ms_ip",
        "nbrclm_denied_outntwk_ebh_bronze_ms_sgp", "nbrclm_denied_outntwk_ebh_silver_ms_sgp")

    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_gld = joinedDfEbh(received_mssgp_Gld, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_gold_ms_sgp = denied_out_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"), col("nbrclm_denied_outntwk_ebh_catastrophic"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_outntwk_ebh_silver_ms_ip"), col("nbrclm_denied_outntwk_ebh_gold_ms_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_outntwk_ebh_total_ms_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ebh_silver_ms_sgp"), col("nbrclm_denied_outntwk_ebh_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp", "nbrclm_denied_outntwk_ebh_total_sgp", "nbrclm_denied_outntwk_ebh_catastrophic",
        "nbrclm_denied_outntwk_ebh_bronze_ms_ip", "nbrclm_denied_outntwk_ebh_silver_ms_ip", "nbrclm_denied_outntwk_ebh_gold_ms_ip", "nbrclm_denied_outntwk_ebh_platinum_ms_ip", "nbrclm_denied_outntwk_ebh_total_ms_ip",
        "nbrclm_denied_outntwk_ebh_bronze_ms_sgp", "nbrclm_denied_outntwk_ebh_silver_ms_sgp", "nbrclm_denied_outntwk_ebh_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_plt = joinedDfEbh(received_mssgp_Plt, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_ebh_platinum_ms_sgp = denied_out_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_ebh_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"), col("nbrclm_denied_outntwk_ebh_catastrophic"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_outntwk_ebh_silver_ms_ip"), col("nbrclm_denied_outntwk_ebh_gold_ms_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_outntwk_ebh_total_ms_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ebh_silver_ms_sgp"), col("nbrclm_denied_outntwk_ebh_gold_ms_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp", "nbrclm_denied_outntwk_ebh_total_sgp", "nbrclm_denied_outntwk_ebh_catastrophic",
        "nbrclm_denied_outntwk_ebh_bronze_ms_ip", "nbrclm_denied_outntwk_ebh_silver_ms_ip", "nbrclm_denied_outntwk_ebh_gold_ms_ip", "nbrclm_denied_outntwk_ebh_platinum_ms_ip", "nbrclm_denied_outntwk_ebh_total_ms_ip",
        "nbrclm_denied_outntwk_ebh_bronze_ms_sgp", "nbrclm_denied_outntwk_ebh_silver_ms_sgp", "nbrclm_denied_outntwk_ebh_gold_ms_sgp", "nbrclm_denied_outntwk_ebh_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_outntwk_ebh_bronze_ms_sgp.union(nbrclm_denied_outntwk_ebh_silver_ms_sgp.union(nbrclm_denied_outntwk_ebh_gold_ms_sgp.union(nbrclm_denied_outntwk_ebh_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_ebh_bronze_ms_sgp")

    val nbrclm_denied_outntwk_ebh_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_ebh_bronze_ms_sgp").alias("nbrclm_denied_outntwk_ebh_total_ms_sgp"))

    val denied_inntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_outntwk_ebh_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_ebh_bronze_ip"), col("nbrclm_denied_outntwk_ebh_silver_ip"), col("nbrclm_denied_outntwk_ebh_gold_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ip"), col("nbrclm_denied_outntwk_ebh_total_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_sgp"), col("nbrclm_denied_outntwk_ebh_silver_sgp"), col("nbrclm_denied_outntwk_ebh_gold_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_sgp"), col("nbrclm_denied_outntwk_ebh_total_sgp"), col("nbrclm_denied_outntwk_ebh_catastrophic"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_ip"), col("nbrclm_denied_outntwk_ebh_silver_ms_ip"), col("nbrclm_denied_outntwk_ebh_gold_ms_ip"), col("nbrclm_denied_outntwk_ebh_platinum_ms_ip"), col("nbrclm_denied_outntwk_ebh_total_ms_ip"),
        col("nbrclm_denied_outntwk_ebh_bronze_ms_sgp"), col("nbrclm_denied_outntwk_ebh_silver_ms_sgp"), col("nbrclm_denied_outntwk_ebh_gold_ms_sgp"), col("nbrclm_denied_outntwk_ebh_platinum_ms_sgp"), col("nbrclm_denied_outntwk_ebh_total_ms_sgp"))

    val denied_outntwk_Data_ebh = denied_inntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_ebh_bronze_ip", "nbrclm_denied_outntwk_ebh_silver_ip", "nbrclm_denied_outntwk_ebh_gold_ip", "nbrclm_denied_outntwk_ebh_platinum_ip", "nbrclm_denied_outntwk_ebh_total_ip",
        "nbrclm_denied_outntwk_ebh_bronze_sgp", "nbrclm_denied_outntwk_ebh_silver_sgp", "nbrclm_denied_outntwk_ebh_gold_sgp", "nbrclm_denied_outntwk_ebh_platinum_sgp", "nbrclm_denied_outntwk_ebh_total_sgp", "nbrclm_denied_outntwk_ebh_catastrophic",
        "nbrclm_denied_outntwk_ebh_bronze_ms_ip", "nbrclm_denied_outntwk_ebh_silver_ms_ip", "nbrclm_denied_outntwk_ebh_gold_ms_ip", "nbrclm_denied_outntwk_ebh_platinum_ms_ip", "nbrclm_denied_outntwk_ebh_total_ms_ip",
        "nbrclm_denied_outntwk_ebh_bronze_ms_sgp", "nbrclm_denied_outntwk_ebh_silver_ms_sgp", "nbrclm_denied_outntwk_ebh_gold_ms_sgp", "nbrclm_denied_outntwk_ebh_platinum_ms_sgp", "nbrclm_denied_outntwk_ebh_total_ms_sgp")

    denied_outntwk_Data_ebh

  }

  def getDeniedOutntwkbh(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk: DataFrame, naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk: DataFrame,
                         naic2018_mcas_nmn_src_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_eob_cd_inbnd: DataFrame, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd: DataFrame, 
                         naic2018_mcas_nmnbh_icd_diag_cd_inbnd: DataFrame): DataFrame = {

    var lob_type = "TOTAL INDIVIDUAL CBE"
    val clminn_cd = Seq("IN", "PAR")
    val clmLineAdjdctn = Seq("DND", "DNDZB")
    val ip_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_brnz = ip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_brz = joinedDfbh(received_brnz, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_bronze_ip = denied_out_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_bronze_ip"))

    val received_silver = ip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sil = joinedDfbh(received_silver, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_silver_ip = denied_out_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_silver_ip"))

    val BrzSilMaster = nbrclm_denied_outntwk_bh_bronze_ip.alias("parent").join(nbrclm_denied_outntwk_bh_silver_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"))

    val BrzSilMasterData = BrzSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip")

    val received_gold = ip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_gld = joinedDfbh(received_gold, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_gold_ip = denied_out_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_gold_ip"))

    val gldMaster = BrzSilMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_gold_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"))

    val gldMasterData = gldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip")

    val received_platinum = ip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_plt = joinedDfbh(received_platinum, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_platinum_ip = denied_out_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_platinum_ip"))

    val pltMaster = gldMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_platinum_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"))

    val pltMasterData = pltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip")

    val tot_ip = nbrclm_denied_outntwk_bh_bronze_ip.union(nbrclm_denied_outntwk_bh_silver_ip.union(nbrclm_denied_outntwk_bh_gold_ip.union(nbrclm_denied_outntwk_bh_platinum_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_bh_bronze_ip")

    val nbrclm_denied_outntwk_bh_total_ip = tot_ip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_bh_bronze_ip").alias("nbrclm_denied_outntwk_bh_total_ip"))

    val totipMaster = pltMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_total_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"), $"child.in_exchange".alias("s_inx"),
        col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"))

    val totipMasterData = totipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val sgp_df = getIpSgpPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_sgp_bronze = sgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_brz = joinedDfbh(received_sgp_bronze, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_bronze_sgp = denied_out_sgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_bronze_sgp"))

    val Brz_sgpMaster = totipMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_bronze_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"))

    val Brz_sgpMasterData = Brz_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp")

    val received_sgp_silver = sgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_sil = joinedDfbh(received_sgp_silver, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_silver_sgp = denied_out_sgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_silver_sgp"))

    val sil_sgpMaster = Brz_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_silver_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"))

    val sil_sgpMasterData = sil_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp")

    val received_sgp_gold = sgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_gld = joinedDfbh(received_sgp_gold, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_gold_sgp = denied_out_sgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_gold_sgp"))

    val gld_sgpMaster = sil_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_gold_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"))

    val gld_sgpMasterData = gld_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp")

    val received_sgp_plt = sgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_sgp_plt = joinedDfbh(received_sgp_plt, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_platinum_sgp = denied_out_sgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_platinum_sgp"))

    val plt_sgpMaster = gld_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_platinum_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"))

    val plt_sgpMasterData = plt_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp")

    val tot_sgp = nbrclm_denied_outntwk_bh_bronze_sgp.union(nbrclm_denied_outntwk_bh_silver_sgp.union(nbrclm_denied_outntwk_bh_gold_sgp.union(nbrclm_denied_outntwk_bh_platinum_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_bh_bronze_sgp")

    val nbrclm_denied_outntwk_bh_total_sgp = tot_sgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_bh_bronze_sgp").alias("nbrclm_denied_outntwk_bh_total_sgp"))

    val tot_sgpMaster = plt_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_total_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"), col("nbrclm_denied_outntwk_bh_total_sgp"))

    val tot_sgpMasterData = tot_sgpMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp", "nbrclm_denied_outntwk_bh_total_sgp")

    val receivedCatFilters = naic2018_mcas_hlthex_clmexphmcy_received_cat_wrk.filter($"naic_prod_desc".like("%CATASTROPHIC%") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"inn_cd".isin(clminn_cd: _*) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_cat = joinedDfbh(receivedCatFilters, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_catastrophic = denied_out_cat.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_catastrophic"))

    val catMaster = tot_sgpMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_catastrophic.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"), col("nbrclm_denied_outntwk_bh_total_sgp"), col("nbrclm_denied_outntwk_bh_catastrophic"))

    val catMasterData = catMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp", "nbrclm_denied_outntwk_bh_total_sgp", "nbrclm_denied_outntwk_bh_catastrophic")

    lob_type = "TOTAL INDIVIDUAL CBE"
    val msip_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_ip_wrk, lob_type)

    val received_msip_Brz = msip_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_brz = joinedDfbh(received_msip_Brz, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_bronze_ms_ip = denied_out_msip_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_bronze_ms_ip"))

    val msipBrzMaster = catMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_bronze_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"), col("nbrclm_denied_outntwk_bh_total_sgp"), col("nbrclm_denied_outntwk_bh_catastrophic"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_ip"))

    val msipBrzMasterData = msipBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp", "nbrclm_denied_outntwk_bh_total_sgp", "nbrclm_denied_outntwk_bh_catastrophic",
        "nbrclm_denied_outntwk_bh_bronze_ms_ip")

    val received_msip_Sil = msip_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_sil = joinedDfbh(received_msip_Sil, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_silver_ms_ip = denied_out_msip_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_silver_ms_ip"))

    val msipSilMaster = msipBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_silver_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"), col("nbrclm_denied_outntwk_bh_total_sgp"), col("nbrclm_denied_outntwk_bh_catastrophic"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_ip"), col("nbrclm_denied_outntwk_bh_silver_ms_ip"))

    val msipSilMasterData = msipSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp", "nbrclm_denied_outntwk_bh_total_sgp", "nbrclm_denied_outntwk_bh_catastrophic",
        "nbrclm_denied_outntwk_bh_bronze_ms_ip", "nbrclm_denied_outntwk_bh_silver_ms_ip")

    val received_msip_Gld = msip_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_gld = joinedDfbh(received_msip_Gld, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_gold_ms_ip = denied_out_msip_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_gold_ms_ip"))

    val msipGldMaster = msipSilMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_gold_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"), col("nbrclm_denied_outntwk_bh_total_sgp"), col("nbrclm_denied_outntwk_bh_catastrophic"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_ip"), col("nbrclm_denied_outntwk_bh_silver_ms_ip"), col("nbrclm_denied_outntwk_bh_gold_ms_ip"))

    val msipGldMasterData = msipGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp", "nbrclm_denied_outntwk_bh_total_sgp", "nbrclm_denied_outntwk_bh_catastrophic",
        "nbrclm_denied_outntwk_bh_bronze_ms_ip", "nbrclm_denied_outntwk_bh_silver_ms_ip", "nbrclm_denied_outntwk_bh_gold_ms_ip")

    val received_msip_Plt = msip_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_msip_plt = joinedDfbh(received_msip_Plt, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_platinum_ms_ip = denied_out_msip_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_platinum_ms_ip"))

    val msipPltMaster = msipGldMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_platinum_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"), col("nbrclm_denied_outntwk_bh_total_sgp"), col("nbrclm_denied_outntwk_bh_catastrophic"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_ip"), col("nbrclm_denied_outntwk_bh_silver_ms_ip"), col("nbrclm_denied_outntwk_bh_gold_ms_ip"), col("nbrclm_denied_outntwk_bh_platinum_ms_ip"))

    val msipPltMasterData = msipPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp", "nbrclm_denied_outntwk_bh_total_sgp", "nbrclm_denied_outntwk_bh_catastrophic",
        "nbrclm_denied_outntwk_bh_bronze_ms_ip", "nbrclm_denied_outntwk_bh_silver_ms_ip", "nbrclm_denied_outntwk_bh_gold_ms_ip", "nbrclm_denied_outntwk_bh_platinum_ms_ip")

    val tot_msip = nbrclm_denied_outntwk_bh_bronze_ms_ip.union(nbrclm_denied_outntwk_bh_silver_ms_ip.union(nbrclm_denied_outntwk_bh_gold_ms_ip.union(nbrclm_denied_outntwk_bh_platinum_ms_ip)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_bh_bronze_ms_ip")

    val nbrclm_denied_outntwk_bh_total_ms_ip = tot_msip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_bh_bronze_ms_ip").alias("nbrclm_denied_outntwk_bh_total_ms_ip"))

    val msipMaster = msipPltMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_total_ms_ip.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"), col("nbrclm_denied_outntwk_bh_total_sgp"), col("nbrclm_denied_outntwk_bh_catastrophic"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_ip"), col("nbrclm_denied_outntwk_bh_silver_ms_ip"), col("nbrclm_denied_outntwk_bh_gold_ms_ip"), col("nbrclm_denied_outntwk_bh_platinum_ms_ip"), col("nbrclm_denied_outntwk_bh_total_ms_ip"))

    val msipMasterData = msipMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp", "nbrclm_denied_outntwk_bh_total_sgp", "nbrclm_denied_outntwk_bh_catastrophic",
        "nbrclm_denied_outntwk_bh_bronze_ms_ip", "nbrclm_denied_outntwk_bh_silver_ms_ip", "nbrclm_denied_outntwk_bh_gold_ms_ip", "nbrclm_denied_outntwk_bh_platinum_ms_ip", "nbrclm_denied_outntwk_bh_total_ms_ip")

    lob_type = "TOTAL SMALL GROUP CBE"
    val mssgp_df = getMSPlan(naic2018_mcas_hlthex_clmexphmcy_received_sgp_wrk, lob_type)

    val received_mssgp_Brz = mssgp_df.filter($"exchng_metl_type_cd".equalTo("04") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_brz = joinedDfbh(received_mssgp_Brz, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_bronze_ms_sgp = denied_out_mssgp_brz.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_bronze_ms_sgp"))

    val mssgpBrzMaster = msipMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_bronze_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"), col("nbrclm_denied_outntwk_bh_total_sgp"), col("nbrclm_denied_outntwk_bh_catastrophic"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_ip"), col("nbrclm_denied_outntwk_bh_silver_ms_ip"), col("nbrclm_denied_outntwk_bh_gold_ms_ip"), col("nbrclm_denied_outntwk_bh_platinum_ms_ip"), col("nbrclm_denied_outntwk_bh_total_ms_ip"), col("nbrclm_denied_outntwk_bh_bronze_ms_sgp"))

    val mssgpBrzMasterData = mssgpBrzMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp", "nbrclm_denied_outntwk_bh_total_sgp", "nbrclm_denied_outntwk_bh_catastrophic",
        "nbrclm_denied_outntwk_bh_bronze_ms_ip", "nbrclm_denied_outntwk_bh_silver_ms_ip", "nbrclm_denied_outntwk_bh_gold_ms_ip", "nbrclm_denied_outntwk_bh_platinum_ms_ip", "nbrclm_denied_outntwk_bh_total_ms_ip",
        "nbrclm_denied_outntwk_bh_bronze_ms_sgp")

    val received_mssgp_Sil = mssgp_df.filter($"exchng_metl_type_cd".equalTo("03") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_sil = joinedDfbh(received_mssgp_Sil, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_silver_ms_sgp = denied_out_mssgp_sil.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_silver_ms_sgp"))

    val mssgpSilMaster = mssgpBrzMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_silver_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"), col("nbrclm_denied_outntwk_bh_total_sgp"), col("nbrclm_denied_outntwk_bh_catastrophic"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_ip"), col("nbrclm_denied_outntwk_bh_silver_ms_ip"), col("nbrclm_denied_outntwk_bh_gold_ms_ip"), col("nbrclm_denied_outntwk_bh_platinum_ms_ip"), col("nbrclm_denied_outntwk_bh_total_ms_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_sgp"), col("nbrclm_denied_outntwk_bh_silver_ms_sgp"))

    val mssgpSilMasterData = mssgpSilMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp", "nbrclm_denied_outntwk_bh_total_sgp", "nbrclm_denied_outntwk_bh_catastrophic",
        "nbrclm_denied_outntwk_bh_bronze_ms_ip", "nbrclm_denied_outntwk_bh_silver_ms_ip", "nbrclm_denied_outntwk_bh_gold_ms_ip", "nbrclm_denied_outntwk_bh_platinum_ms_ip", "nbrclm_denied_outntwk_bh_total_ms_ip",
        "nbrclm_denied_outntwk_bh_bronze_ms_sgp", "nbrclm_denied_outntwk_bh_silver_ms_sgp")

    val received_mssgp_Gld = mssgp_df.filter($"exchng_metl_type_cd".equalTo("02") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_gld = joinedDfbh(received_mssgp_Gld, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_gold_ms_sgp = denied_out_mssgp_gld.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_gold_ms_sgp"))

    val mssgpGldMaster = mssgpSilMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_gold_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"), col("nbrclm_denied_outntwk_bh_total_sgp"), col("nbrclm_denied_outntwk_bh_catastrophic"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_ip"), col("nbrclm_denied_outntwk_bh_silver_ms_ip"), col("nbrclm_denied_outntwk_bh_gold_ms_ip"), col("nbrclm_denied_outntwk_bh_platinum_ms_ip"), col("nbrclm_denied_outntwk_bh_total_ms_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_sgp"), col("nbrclm_denied_outntwk_bh_silver_ms_sgp"), col("nbrclm_denied_outntwk_bh_gold_ms_sgp"))

    val mssgpGldMasterData = mssgpGldMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp", "nbrclm_denied_outntwk_bh_total_sgp", "nbrclm_denied_outntwk_bh_catastrophic",
        "nbrclm_denied_outntwk_bh_bronze_ms_ip", "nbrclm_denied_outntwk_bh_silver_ms_ip", "nbrclm_denied_outntwk_bh_gold_ms_ip", "nbrclm_denied_outntwk_bh_platinum_ms_ip", "nbrclm_denied_outntwk_bh_total_ms_ip",
        "nbrclm_denied_outntwk_bh_bronze_ms_sgp", "nbrclm_denied_outntwk_bh_silver_ms_sgp", "nbrclm_denied_outntwk_bh_gold_ms_sgp")

    val received_mssgp_Plt = mssgp_df.filter($"exchng_metl_type_cd".equalTo("01") &&
      (!$"inn_cd".isin(clminn_cd: _*)) &&
      $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn: _*) &&
      $"ADJDCTN_DT".between(strt_year, end_year))

    val denied_out_mssgp_plt = joinedDfbh(received_mssgp_Plt, naic2018_mcas_nmn_src_eob_cd_inbnd, naic2018_mcas_nmn_eob_cd_inbnd, naic2018_mcas_nmn_src_clm_line_disp_rsn_cd_inbnd, naic2018_mcas_nmnbh_icd_diag_cd_inbnd  )

    val nbrclm_denied_outntwk_bh_platinum_ms_sgp = denied_out_mssgp_plt.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_bh_platinum_ms_sgp"))

    val mssgpPltMaster = mssgpGldMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_platinum_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"), col("nbrclm_denied_outntwk_bh_total_sgp"), col("nbrclm_denied_outntwk_bh_catastrophic"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_ip"), col("nbrclm_denied_outntwk_bh_silver_ms_ip"), col("nbrclm_denied_outntwk_bh_gold_ms_ip"), col("nbrclm_denied_outntwk_bh_platinum_ms_ip"), col("nbrclm_denied_outntwk_bh_total_ms_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_sgp"), col("nbrclm_denied_outntwk_bh_silver_ms_sgp"), col("nbrclm_denied_outntwk_bh_gold_ms_sgp"), col("nbrclm_denied_outntwk_bh_platinum_ms_sgp"))

    val mssgpPltMasterData = mssgpPltMaster.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp", "nbrclm_denied_outntwk_bh_total_sgp", "nbrclm_denied_outntwk_bh_catastrophic",
        "nbrclm_denied_outntwk_bh_bronze_ms_ip", "nbrclm_denied_outntwk_bh_silver_ms_ip", "nbrclm_denied_outntwk_bh_gold_ms_ip", "nbrclm_denied_outntwk_bh_platinum_ms_ip", "nbrclm_denied_outntwk_bh_total_ms_ip",
        "nbrclm_denied_outntwk_bh_bronze_ms_sgp", "nbrclm_denied_outntwk_bh_silver_ms_sgp", "nbrclm_denied_outntwk_bh_gold_ms_sgp", "nbrclm_denied_outntwk_bh_platinum_ms_sgp")

    val tot_mssgp = nbrclm_denied_outntwk_bh_bronze_ms_sgp.union(nbrclm_denied_outntwk_bh_silver_ms_sgp.union(nbrclm_denied_outntwk_bh_gold_ms_sgp.union(nbrclm_denied_outntwk_bh_platinum_ms_sgp)))
      .select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"nbrclm_denied_outntwk_bh_bronze_ms_sgp")

    val nbrclm_denied_outntwk_bh_total_ms_sgp = tot_mssgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum("nbrclm_denied_outntwk_bh_bronze_ms_sgp").alias("nbrclm_denied_outntwk_bh_total_ms_sgp"))

    val denied_inntwk = mssgpPltMasterData.alias("parent").join(nbrclm_denied_outntwk_bh_total_ms_sgp.alias("child"), $"parent.health_year" === $"child.health_year"
      && $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
      .select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
        $"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
        $"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
        $"child.in_exchange".alias("s_inx"), col("nbrclm_denied_outntwk_bh_bronze_ip"), col("nbrclm_denied_outntwk_bh_silver_ip"), col("nbrclm_denied_outntwk_bh_gold_ip"), col("nbrclm_denied_outntwk_bh_platinum_ip"), col("nbrclm_denied_outntwk_bh_total_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_sgp"), col("nbrclm_denied_outntwk_bh_silver_sgp"), col("nbrclm_denied_outntwk_bh_gold_sgp"), col("nbrclm_denied_outntwk_bh_platinum_sgp"), col("nbrclm_denied_outntwk_bh_total_sgp"), col("nbrclm_denied_outntwk_bh_catastrophic"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_ip"), col("nbrclm_denied_outntwk_bh_silver_ms_ip"), col("nbrclm_denied_outntwk_bh_gold_ms_ip"), col("nbrclm_denied_outntwk_bh_platinum_ms_ip"), col("nbrclm_denied_outntwk_bh_total_ms_ip"),
        col("nbrclm_denied_outntwk_bh_bronze_ms_sgp"), col("nbrclm_denied_outntwk_bh_silver_ms_sgp"), col("nbrclm_denied_outntwk_bh_gold_ms_sgp"), col("nbrclm_denied_outntwk_bh_platinum_ms_sgp"), col("nbrclm_denied_outntwk_bh_total_ms_sgp"))

    val denied_outntwk_Data_bh = denied_inntwk.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
      .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
      .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
      .withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
      .select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrclm_denied_outntwk_bh_bronze_ip", "nbrclm_denied_outntwk_bh_silver_ip", "nbrclm_denied_outntwk_bh_gold_ip", "nbrclm_denied_outntwk_bh_platinum_ip", "nbrclm_denied_outntwk_bh_total_ip",
        "nbrclm_denied_outntwk_bh_bronze_sgp", "nbrclm_denied_outntwk_bh_silver_sgp", "nbrclm_denied_outntwk_bh_gold_sgp", "nbrclm_denied_outntwk_bh_platinum_sgp", "nbrclm_denied_outntwk_bh_total_sgp", "nbrclm_denied_outntwk_bh_catastrophic",
        "nbrclm_denied_outntwk_bh_bronze_ms_ip", "nbrclm_denied_outntwk_bh_silver_ms_ip", "nbrclm_denied_outntwk_bh_gold_ms_ip", "nbrclm_denied_outntwk_bh_platinum_ms_ip", "nbrclm_denied_outntwk_bh_total_ms_ip",
        "nbrclm_denied_outntwk_bh_bronze_ms_sgp", "nbrclm_denied_outntwk_bh_silver_ms_sgp", "nbrclm_denied_outntwk_bh_gold_ms_sgp", "nbrclm_denied_outntwk_bh_platinum_ms_sgp", "nbrclm_denied_outntwk_bh_total_ms_sgp")

    denied_outntwk_Data_bh

  }
}

object PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_2018 {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    // new PCADX_SCL_NAIC2018_IEXStgTransformationclmexphmcy_2018().sparkInIt()
  }
}