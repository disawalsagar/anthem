package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit
//import gen.PCADX_SCL_NAIC_OEXStgTransformationclmPhmcy
class PCADX_SCL_NAIC2018_UnicareStgTransformationclmPhmcy {
  var year =""
  val dbProperties = new Properties
  
  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()

  import spark.implicits._
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_UnicareStgTransformationclmPhmcy])
  val dbsg = dbProperties.getProperty("stage.db")
  val dbwrk = dbProperties.getProperty("work.db")
  val dbin = dbProperties.getProperty("inbound.db")
  val tblreceived_ip = dbProperties.getProperty("received_ip")
  val tblreceived_sgp = dbProperties.getProperty("received_sgp")
  val tblreceived_lgp = dbProperties.getProperty("received_lgp")
  val tblreceived_cat = dbProperties.getProperty("received_cat")
  val tblpclm_denied = dbProperties.getProperty("pclm_denied")
  
  
  val tblpclm_paid = dbProperties.getProperty("pclm_paid")  
  val tblpaid_ip = dbProperties.getProperty("paid_ip")
  val tblpaid_sgp = dbProperties.getProperty("paid_sgp")
  val tblpaid_cat = dbProperties.getProperty("paid_cat")
  val tblpaid_lgp =  dbProperties.getProperty("paid_lgp")
  println("***********************"+tblreceived_cat+"*********************************")
  val tblsrvc_dnl = dbProperties.getProperty("srvc_dnl")
  
  var naic2018_mcas_hlthex_clmphmcy_unicare_received_ip_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmphmcy_unicare_received_lgp_wrk :DataFrame = null
  var naic2018_mcas_hlthex_clmphmcy_unicare_paid_ip_wrk:DataFrame = null
  var naic2018_mcas_hlthex_clmphmcy_unicare_paid_lgp_wrk:DataFrame= null
  
  var naic2018_mcas_hlthex_clmPhmcy_denied_wrk:DataFrame = null
  var naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd:DataFrame = null

  val uri: String = dbProperties.getProperty("uri")
  val strt_year = dbProperties.getProperty("strt_year_clm")
  val end_year =dbProperties.getProperty("end_year_clm")
 
  def sparkInIt(){
    println("dbwrk.tblreceived_ip : "+dbwrk+"."+tblreceived_ip)
     naic2018_mcas_hlthex_clmphmcy_unicare_received_ip_wrk = readDataFromHive(dbwrk+"."+"naic2018_mcas_hlthex_clmphmcy_unicare_received_ip_wrk")
     
     naic2018_mcas_hlthex_clmphmcy_unicare_received_lgp_wrk = readDataFromHive(dbwrk+"."+"naic2018_mcas_hlthex_clmphmcy_unicare_received_lgp_wrk")
     naic2018_mcas_hlthex_clmphmcy_unicare_paid_ip_wrk = readDataFromHive(dbwrk+"."+"naic2018_mcas_hlthex_clmphmcy_unicare_paid_ip_wrk")
     println(dbwrk+"."+tblreceived_cat)
     naic2018_mcas_hlthex_clmphmcy_unicare_paid_lgp_wrk = readDataFromHive(dbwrk+"."+"naic2018_mcas_hlthex_clmphmcy_unicare_paid_lgp_wrk")
   naic2018_mcas_hlthex_clmPhmcy_denied_wrk = readDataFromHive(dbwrk+".naic2018_mcas_pclm_denied_wrk") 
     println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
     println(dbin+"."+tblsrvc_dnl)
     naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd = readDataFromHive(dbin+"."+tblsrvc_dnl)
     val finalReceivedData = getClmReceivedData()
    val finalDeniedInntwk = getDeniedInntwkData()
    val finalDeniedOutntwk = getDeniedOutntwkData()
     println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
    val finalPaidInntwk = getPaidInntwkData()
    val finalPaidOutntwk=getPaidOutntwkData()
   val finalPay = getTotalPaidCpaid("PAID_AMT","paid")
   //finalPay.show(1)
    val finalCPay = getTotalPaidCpaid("CPAY_AMT","copay")
    val finalCoinSrcPay = getTotalPaidCpaid("COINSRN_AMT","coinsrn")
    val finalddctblPay = getTotalPaidCpaid("DDCTBL_AMT","ddctbl")
    val oex = new PCADX_SCL_NAIC2018_OEXStgTransformationclmPhmcy()
    //oex.ge
   val stagData = oex.getStgdata(finalReceivedData,finalDeniedInntwk,finalDeniedOutntwk,finalPaidInntwk,finalPaidOutntwk,finalPay,
        finalCPay,finalCoinSrcPay,finalddctblPay)
        	var load_log_key = ""
    if(!naic2018_mcas_hlthex_clmphmcy_unicare_received_ip_wrk.take(1).isEmpty){
     load_log_key = naic2018_mcas_hlthex_clmphmcy_unicare_received_ip_wrk.select($"load_log_key").first.getString(0)
    }else if(!naic2018_mcas_hlthex_clmphmcy_unicare_paid_ip_wrk.take(1).isEmpty){
      load_log_key = naic2018_mcas_hlthex_clmphmcy_unicare_paid_ip_wrk.select($"load_log_key").first.getString(0)
    }
   val finalStgData = stagData.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
     
    writeDataToHive(dbsg+".naic2018_mcas_hlthoex_clmphmcy_stg",finalStgData) 
    spark.close()
  }
  def truncateTbl(tblName:String){
			  spark.sql("TRUNCATE TABLE "+tblName)
	}
  def writeDataToHive(tblName: String, finalDf: DataFrame) {
    //finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
    finalDf.write.mode(SaveMode.Append).insertInto(tblName)
    println("Data added in stage table")
  }
 def readDataFromHive(tble: String): DataFrame = {
    val queryOutputTable="""SELECT * FROM """ +  tble
    val tbl_data_df = spark.sql(queryOutputTable)//.na.fill("")
    logger.info("Read data from hive")
    tbl_data_df
 } 
 
 def getClmReceivedData():DataFrame={
 
                          
      println("************************ GTLGP *********************************************")                         
      val nbrclm_received_gtlgp  = naic2018_mcas_hlthex_clmphmcy_unicare_received_lgp_wrk.filter(
                              $"naic_lob".equalTo("LARGE GROUP GRAND"))//IL state
                            .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                            .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_received_gtlgp")).withColumn("nbrclm_received_gtlgp",$"nbrclm_received_gtlgp".cast(IntegerType))
    
          
     val nbrclm_received_gtip  = naic2018_mcas_hlthex_clmphmcy_unicare_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND"))// state DC
                            .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                              .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_received_gtip")).withColumn("nbrclm_received_gtip",$"nbrclm_received_gtip".cast(IntegerType))
                         
          
      val ipSgplgpgtSgpgtip=  nbrclm_received_gtlgp.alias("parent").join(nbrclm_received_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtip"))
                                            
     val ipSgplgpgtSgpgtipData = ipSgplgpgtSgpgtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
                            .withColumn("nbrclm_received_total_ip", lit(0))
                           .withColumn("nbrclm_received_total_sgp", lit(0))
                           .withColumn("nbrclm_received_gtsgp", lit(0))
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip")
    
          
      val totalgtIp=  nbrclm_received_gtip.union(nbrclm_received_gtlgp)
                      .select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"nbrclm_received_gtip")
      val nbrclm_received_total_gtip = totalgtIp.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum($"nbrclm_received_gtip").alias("nbrclm_received_total_gtip")).withColumn("nbrclm_received_total_gtip",$"nbrclm_received_total_gtip".cast(IntegerType))
      
      
       val ipSgplgpgtSgpgtipTot=  nbrclm_received_total_gtip.alias("parent").join(ipSgplgpgtSgpgtipData.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"),
           col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"))
                                            
     val ipsgpTotipData = ipSgplgpgtSgpgtipTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip")
    
      
      val nbrclm_received_lgp_mmcare = naic2018_mcas_hlthex_clmphmcy_unicare_received_lgp_wrk.filter($"naic_lob".equalTo("LARGE GROUP CBE"))// MA state
                                           .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                            .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_received_lgp_mmcare")).withColumn("nbrclm_received_lgp_mmcare",$"nbrclm_received_lgp_mmcare".cast(IntegerType))
                                            
                                            
       val ipsgpTotipCatmmCar=  ipsgpTotipData.alias("parent").join(nbrclm_received_lgp_mmcare.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"),col("nbrclm_received_total_ip"), col("nbrclm_received_total_sgp"), col("nbrclm_received_gtlgp"), col("nbrclm_received_gtsgp"),
           col("nbrclm_received_gtip"), col("nbrclm_received_total_gtip"),  col("nbrclm_received_lgp_mmcare"))
                                            
     val receivedData = ipsgpTotipCatmmCar.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .withColumn("nbrclm_received_catastrophic", lit(0))
                           .withColumn("nbrclm_received_stucvg", lit(0))
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_received_total_ip" ,"nbrclm_received_total_sgp" , "nbrclm_received_gtlgp", "nbrclm_received_gtsgp",
                               "nbrclm_received_gtip", "nbrclm_received_total_gtip","nbrclm_received_catastrophic", "nbrclm_received_lgp_mmcare", "nbrclm_received_stucvg")
                               
       receivedData 
 
 }
 def getDeniedJoindataFrame(naic2018_mcas_pclm_denied_wrk:DataFrame, naic2018_mcas_hlthex_clmphmcy_received_wrk:DataFrame,  
     naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd:DataFrame) :DataFrame = {
   
   val joinedDf = naic2018_mcas_hlthex_clmphmcy_received_wrk.alias("received_wrk").join(naic2018_mcas_pclm_denied_wrk.alias("denied_wrk"), 
                                                                   $"received_wrk.CLM_NBR" === $"denied_wrk.CLM_NBR" &&
                                                                   $"received_wrk.MBR_KEY" === $"denied_wrk.MBR_KEY" &&
                                                                   $"received_wrk.RX_FILLED_DT" === $"denied_wrk.RX_FILLED_DT" &&
                                                                   $"received_wrk.ADJDCTN_DT" === $"denied_wrk.ADJDCTN_DT" &&
                                                                   $"received_wrk.NDC" === $"denied_wrk.NDC" &&
                                                                   $"received_wrk.RX_NBR" === $"denied_wrk.RX_NBR" , "inner")
                                                                   .join(naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd.alias("sec"),
                                                                        $"received_wrk.src_srvc_dnl_rsn_cd" === $"sec.src_srvc_dnl_rsn_cd" &&
                                                                        $"received_wrk.clm_sor_cd" === $"sec.clm_sor_cd", "left_outer")
                                                                    .filter( $"sec.src_srvc_dnl_rsn_cd".isNull && 
                                                                     $"sec.clm_sor_cd".isNull)
                                                                     .groupBy($"received_wrk.health_year".alias("health_year"), $"received_wrk.cmpny_cf_cd".alias("cmpny_cf_cd"), $"received_wrk.state".alias("state"),$"received_wrk.outoff_exchange".alias("outoff_exchange"), 
                                                                      $"received_wrk.CLM_NBR", $"received_wrk.CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                                                        
    joinedDf                                                                
 }
 def getDeniedInntwkData(): DataFrame = {
     val clminn_cd = Seq("IN", "PAR")
    
   val clmLineAdjdctn = Seq("DND","DNDZB")
   
   val receivedgtlgpFilters = naic2018_mcas_hlthex_clmphmcy_unicare_received_lgp_wrk.filter(
                               $"naic_lob".equalTo("LARGE GROUP GRAND") &&
                               $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_gtlgp =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedgtlgpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_inntwk_gtlgp   = denied_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gtlgp"))

   
   val receivedgtipFilters = naic2018_mcas_hlthex_clmphmcy_unicare_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
                             $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_gtip =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedgtipFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_inntwk_gtip  = denied_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_gtip"))
    
    
    val ipSgpgtlgpgtsgpgtipData=  nbrclm_denied_inntwk_gtlgp.alias("parent").join(nbrclm_denied_inntwk_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"), col("nbrclm_denied_inntwk_gtlgp"),  col("nbrclm_denied_inntwk_gtip"))
                                            
     val ipSgpgtData = ipSgpgtlgpgtsgpgtipData.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .withColumn("nbrclm_denied_inntwk_total_ip", lit(0))
                           .withColumn("nbrclm_denied_inntwk_total_sgp",lit(0))
                            .withColumn("nbrclm_denied_inntwk_gtsgp",lit(0))
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip")
                               
     
    val tot_gtip = nbrclm_denied_inntwk_gtip.union(nbrclm_denied_inntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"nbrclm_denied_inntwk_gtip")
    
    val nbrclm_denied_inntwk_total_gtip = tot_gtip.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum($"nbrclm_denied_inntwk_gtip").alias("nbrclm_denied_inntwk_total_gtip"))
    
    
    val ipSgptotgt=  ipSgpgtData.alias("parent").join(nbrclm_denied_inntwk_total_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"),col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"),
           col("nbrclm_denied_inntwk_gtip"), col("nbrclm_denied_inntwk_total_gtip"))
                                            
     val ipSgptotgtData = ipSgptotgt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip")
    
    
    
    val receivedmmcareFilters = naic2018_mcas_hlthex_clmphmcy_unicare_received_lgp_wrk.filter(
                              $"naic_lob".equalTo("LARGE GROUP CBE") &&
                               $"inn_cd".isin(clminn_cd:_*) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
    val denied_mmcare =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedmmcareFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
    
    val nbrclm_denied_inntwk_lgp_mmcare   = denied_mmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_denied_inntwk_lgp_mmcare"))
    
     val ipSgptotgtCatmmcare=  ipSgptotgtData.alias("parent").join(nbrclm_denied_inntwk_lgp_mmcare.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"),col("nbrclm_denied_inntwk_total_ip"), col("nbrclm_denied_inntwk_total_sgp"), col("nbrclm_denied_inntwk_gtlgp"), col("nbrclm_denied_inntwk_gtsgp"),
           col("nbrclm_denied_inntwk_gtip"), col("nbrclm_denied_inntwk_total_gtip"), col("nbrclm_denied_inntwk_lgp_mmcare"))
                                            
     val deniedInntwkData = ipSgptotgtCatmmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .withColumn("nbrclm_denied_inntwk_catastrophic", lit(0))
                           .withColumn("nbrclm_denied_inntwk_stucvg", lit(0))
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_denied_inntwk_total_ip" ,"nbrclm_denied_inntwk_total_sgp", "nbrclm_denied_inntwk_gtlgp", "nbrclm_denied_inntwk_gtsgp",
                               "nbrclm_denied_inntwk_gtip", "nbrclm_denied_inntwk_total_gtip", "nbrclm_denied_inntwk_catastrophic", "nbrclm_denied_inntwk_lgp_mmcare", "nbrclm_denied_inntwk_stucvg")
     
    
   
    deniedInntwkData
    
    
  }
 
 def getDeniedOutntwkData(): DataFrame = {
     val clminn_cd = Seq("IN", "PAR")
    
   val clmLineAdjdctn = Seq("DND","DNDZB")
   
   val receivedgtlgpFilters = naic2018_mcas_hlthex_clmphmcy_unicare_received_lgp_wrk.filter(
                              $"naic_lob".equalTo("LARGE GROUP GRAND") &&
                               (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_gtlgp =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedgtlgpFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_outntwk_gtlgp   = denied_gtlgp.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gtlgp"))

                 
   val receivedgtipFilters = naic2018_mcas_hlthex_clmphmcy_unicare_received_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
                             
                               (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
                              
                              
   val denied_gtip =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedgtipFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
   
  
    val nbrclm_denied_outntwk_gtip  = denied_gtip.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_gtip"))
    
    
    val ipSgpgtlgpgtsgpgtipData=  nbrclm_denied_outntwk_gtlgp.alias("parent").join(nbrclm_denied_outntwk_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"),col("nbrclm_denied_outntwk_gtlgp"),  col("nbrclm_denied_outntwk_gtip"))
                                            
     val ipSgpgtData = ipSgpgtlgpgtsgpgtipData.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .withColumn("nbrclm_denied_outntwk_total_ip", lit(0))
                           .withColumn("nbrclm_denied_outntwk_total_sgp", lit(0))
                           .withColumn("nbrclm_denied_outntwk_gtsgp", lit(0))
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip")
                               
     
    val tot_gtip = nbrclm_denied_outntwk_gtip.union(nbrclm_denied_outntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"nbrclm_denied_outntwk_gtip")
    
    val nbrclm_denied_outntwk_total_gtip = tot_gtip.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum($"nbrclm_denied_outntwk_gtip").alias("nbrclm_denied_outntwk_total_gtip"))//.withColumn("mbrmpoa_renewed_total_ip",$"mbrmpoa_renewed_total_ip".cast(IntegerType))
    
    
    val ipSgptotgt=  ipSgpgtData.alias("parent").join(nbrclm_denied_outntwk_total_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"),col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"),
           col("nbrclm_denied_outntwk_gtip"), col("nbrclm_denied_outntwk_total_gtip"))
                                            
     val ipSgptotgtData = ipSgptotgt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip")
    
    
    
    val receivedmmcareFilters = naic2018_mcas_hlthex_clmphmcy_unicare_received_lgp_wrk.filter(
                              $"naic_lob".equalTo("LARGE GROUP CBE") &&
                               (!$"inn_cd".isin(clminn_cd:_*)) &&
                              $"RPTG_CLM_LINE_ADJDCTN_STTS_CD".isin(clmLineAdjdctn:_*) &&
                              $"ADJDCTN_DT".between(strt_year,end_year))
    val denied_mmcare =  getDeniedJoindataFrame(naic2018_mcas_hlthex_clmPhmcy_denied_wrk, receivedmmcareFilters, naic2018_mcas_src_srvc_dnl_rsn_cd_inbnd)
    
    val nbrclm_denied_outntwk_lgp_mmcare   = denied_mmcare.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_denied_outntwk_lgp_mmcare"))
    
     val ipSgptotgtCatmmcare=  ipSgptotgtData.alias("parent").join(nbrclm_denied_outntwk_lgp_mmcare.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"),col("nbrclm_denied_outntwk_total_ip"), col("nbrclm_denied_outntwk_total_sgp"), col("nbrclm_denied_outntwk_gtlgp"), col("nbrclm_denied_outntwk_gtsgp"),
           col("nbrclm_denied_outntwk_gtip"), col("nbrclm_denied_outntwk_total_gtip"),  col("nbrclm_denied_outntwk_lgp_mmcare"))
                                            
     val deniedOutntwkData = ipSgptotgtCatmmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .withColumn("nbrclm_denied_outntwk_catastrophic", lit(0))
                           .withColumn("nbrclm_denied_outntwk_stucvg", lit(0))
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_denied_outntwk_total_ip" ,"nbrclm_denied_outntwk_total_sgp", "nbrclm_denied_outntwk_gtlgp", "nbrclm_denied_outntwk_gtsgp",
                               "nbrclm_denied_outntwk_gtip", "nbrclm_denied_outntwk_total_gtip", "nbrclm_denied_outntwk_catastrophic", "nbrclm_denied_outntwk_lgp_mmcare", "nbrclm_denied_outntwk_stucvg")
     
    
    deniedOutntwkData
    
    
  }
 def getPaidInntwkData():DataFrame = {
   val clminn_cd = Seq("IN", "PAR")
                           
    val nbrclm_paid_inntwk_gtlgp = naic2018_mcas_hlthex_clmphmcy_unicare_paid_lgp_wrk.filter(
                                    $"naic_lob".equalTo("LARGE GROUP GRAND") &&
                                    $"inn_cd".isin(clminn_cd:_*)) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gtlgp"))                          
   
                                
      val nbrclm_paid_inntwk_gtip = naic2018_mcas_hlthex_clmphmcy_unicare_paid_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND")  &&
                                    $"inn_cd".isin(clminn_cd:_*)) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_gtip"))                          
   
                           
        val gtip=  nbrclm_paid_inntwk_gtlgp.alias("parent").join(nbrclm_paid_inntwk_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"), col("nbrclm_paid_inntwk_gtlgp"),col("nbrclm_paid_inntwk_gtip"))
                                            
         val gtipMasterData = gtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
                          .withColumn("nbrclm_paid_inntwk_total_ip", lit(0))
                            .withColumn("nbrclm_paid_inntwk_total_sgp", lit(0))
                           .withColumn("nbrclm_paid_inntwk_gtsgp", lit(0))
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip")
          
      val totalgtip = nbrclm_paid_inntwk_gtip.union(nbrclm_paid_inntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"nbrclm_paid_inntwk_gtip")
      
      val nbrclm_paid_inntwk_total_gtip = totalgtip.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum($"nbrclm_paid_inntwk_gtip").alias("nbrclm_paid_inntwk_total_gtip"))
      
       val totgtip=  gtipMasterData.alias("parent").join(nbrclm_paid_inntwk_total_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"),col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"),
           col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"))
                                            
         val totgtipMasterData = totgtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip")
                           
                     
           val nbrclm_paid_inntwk_lgp_mmcare = naic2018_mcas_hlthex_clmphmcy_unicare_paid_lgp_wrk.filter(
                                    $"naic_lob".equalTo("LARGE GROUP CBE") &&
                                    $"inn_cd".isin(clminn_cd:_*)) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_paid_inntwk_lgp_mmcare"))                          
   
                           
             val mmcare=  totgtipMasterData.alias("parent").join(nbrclm_paid_inntwk_lgp_mmcare.alias("child") , $"parent.health_year"===$"child.health_year" 
                      && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
                      .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                       $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                       $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
                       $"child.outoff_exchange".alias("s_inx"),col("nbrclm_paid_inntwk_total_ip"), col("nbrclm_paid_inntwk_total_sgp"), col("nbrclm_paid_inntwk_gtlgp"), col("nbrclm_paid_inntwk_gtsgp"),
                       col("nbrclm_paid_inntwk_gtip"), col("nbrclm_paid_inntwk_total_gtip"), col("nbrclm_paid_inntwk_lgp_mmcare"))
                                            
         val paidInntwkData = mmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .withColumn("nbrclm_paid_inntwk_catastrophic", lit(0))
                           .withColumn("nbrclm_paid_inntwk_stucvg", lit(0))
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_paid_inntwk_total_ip" ,"nbrclm_paid_inntwk_total_sgp","nbrclm_paid_inntwk_gtlgp", "nbrclm_paid_inntwk_gtsgp",
                               "nbrclm_paid_inntwk_gtip", "nbrclm_paid_inntwk_total_gtip", "nbrclm_paid_inntwk_catastrophic", "nbrclm_paid_inntwk_lgp_mmcare", "nbrclm_paid_inntwk_stucvg")               
                           
                 
                           
                           
 paidInntwkData
 }
 def getPaidOutntwkData():DataFrame = {
   val clminn_cd = Seq("IN", "PAR")
                  
    val nbrclm_paid_outntwk_gtlgp = naic2018_mcas_hlthex_clmphmcy_unicare_paid_lgp_wrk.filter(
                                    $"naic_lob".equalTo("LARGE GROUP GRAND") &&
                                        (!$"inn_cd".isin(clminn_cd:_*))) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gtlgp"))                          
   
                                 
      val nbrclm_paid_outntwk_gtip = naic2018_mcas_hlthex_clmphmcy_unicare_paid_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND") &&
                                    (!$"inn_cd".isin(clminn_cd:_*))) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_gtip"))                          
   
                           
        val gtip=  nbrclm_paid_outntwk_gtlgp.alias("parent").join(nbrclm_paid_outntwk_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtip"))
                                            
         val gtipMasterData = gtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .withColumn("nbrclm_paid_outntwk_total_ip", lit(0))
                           .withColumn("nbrclm_paid_outntwk_total_sgp", lit(0))
                           .withColumn("nbrclm_paid_outntwk_gtsgp", lit(0))
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp",
                               "nbrclm_paid_outntwk_gtip")
          
      val totalgtip = nbrclm_paid_outntwk_gtip.union(nbrclm_paid_outntwk_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"nbrclm_paid_outntwk_gtip")
      
      val nbrclm_paid_outntwk_total_gtip = totalgtip.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum($"nbrclm_paid_outntwk_gtip").alias("nbrclm_paid_outntwk_total_gtip"))
      
       val totgtip=  gtipMasterData.alias("parent").join(nbrclm_paid_outntwk_total_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"),col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"),
           col("nbrclm_paid_outntwk_gtip"), col("nbrclm_paid_outntwk_total_gtip"))
                                            
         val totgtipMasterData = totgtip.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp",
                               "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip")
                           
                       
           val nbrclm_paid_outntwk_lgp_mmcare = naic2018_mcas_hlthex_clmphmcy_unicare_paid_lgp_wrk.filter(
                                    $"naic_lob".equalTo("LARGE GROUP CBE") && (!$"inn_cd".isin(clminn_cd:_*))) 
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR").agg((lit(1)).alias("count_Val"))
                                    .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum("count_Val").alias("nbrclm_paid_outntwk_lgp_mmcare"))                          
   
                           
             val mmcare=  totgtipMasterData.alias("parent").join(nbrclm_paid_outntwk_lgp_mmcare.alias("child") , $"parent.health_year"===$"child.health_year" 
                      && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
                      .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
                       $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
                       $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
                       $"child.outoff_exchange".alias("s_inx"),col("nbrclm_paid_outntwk_total_ip"), col("nbrclm_paid_outntwk_total_sgp"), col("nbrclm_paid_outntwk_gtlgp"), col("nbrclm_paid_outntwk_gtsgp"),
                       col("nbrclm_paid_outntwk_gtip"), col("nbrclm_paid_outntwk_total_gtip"), col("nbrclm_paid_outntwk_lgp_mmcare"))
                                            
         val paidoutntwkData = mmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
                           .withColumn("nbrclm_paid_outntwk_catastrophic", lit(0))
                           .withColumn("nbrclm_paid_outntwk_stucvg", lit(0))
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", "nbrclm_paid_outntwk_total_ip" ,"nbrclm_paid_outntwk_total_sgp","nbrclm_paid_outntwk_gtlgp", "nbrclm_paid_outntwk_gtsgp",
                               "nbrclm_paid_outntwk_gtip", "nbrclm_paid_outntwk_total_gtip", "nbrclm_paid_outntwk_catastrophic", "nbrclm_paid_outntwk_lgp_mmcare","nbrclm_paid_outntwk_stucvg")               
                           
                             
                                    
                           
 paidoutntwkData
 }
 def getTotalPaidCpaid(paid_col:String, typeOfPay:String):DataFrame={
   val total_ip = "clm_total_"+typeOfPay+"_amt_total_ip"//clm_total_paid_amt_total_ip   clm_total_paid_amt_total_ip
       val total_sgp ="clm_total_"+typeOfPay+"_amt_total_sgp"
       val total_gtsgp = "clm_total_"+typeOfPay+"_amt_gtsgp"
       val total_lgp = "clm_total_"+typeOfPay+"_amt_gtlgp"                    
      val clm_total_paid_amt_gtlgp = naic2018_mcas_hlthex_clmphmcy_unicare_paid_lgp_wrk.filter(
                                  $"naic_lob".equalTo("LARGE GROUP GRAND"))
                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR",  col(paid_col)).agg((lit(1)).alias("count_Val"))
                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum(col(paid_col)).alias(total_lgp)).withColumn(total_lgp,col(total_lgp).cast(IntegerType))
   
        
      val total_gtip = "clm_total_"+typeOfPay+"_amt_gtip"
   val clm_total_paid_amt_total_gtip = naic2018_mcas_hlthex_clmphmcy_unicare_paid_ip_wrk.filter($"naic_lob".equalTo("INDIVIDUAL GRAND"))
                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR",  col(paid_col)).agg((lit(1)).alias("count_Val"))
                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum(col(paid_col)).alias(total_gtip)).withColumn(total_gtip,col(total_gtip).cast(IntegerType))
   
                           
         val gtIp=  clm_total_paid_amt_gtlgp.alias("parent").join(clm_total_paid_amt_total_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"), col(total_lgp), col(total_gtip))
                                            
     val gtIpMasterData = gtIp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .withColumn(total_ip, lit(0))
                           .withColumn(total_sgp, lit(0))
                           .withColumn(total_gtsgp, lit(0))
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", total_ip ,total_sgp, total_lgp, total_gtsgp, total_gtip)
      val total_sum_gtip =   "clm_total_"+typeOfPay+"_amt_total_gtip"                   
      val totalgtip = clm_total_paid_amt_total_gtip.union(clm_total_paid_amt_gtlgp).select($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", col(total_gtip))
      
      val nbrclm_paid_outntwk_total_gtip = totalgtip.groupBy("health_year","cmpny_cf_cd", "state", "outoff_exchange").agg(sum(col(total_gtip)).alias(total_sum_gtip)).withColumn(total_sum_gtip,col(total_sum_gtip).cast(IntegerType))
      
       val totgtIp=  gtIpMasterData.alias("parent").join(nbrclm_paid_outntwk_total_gtip.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"),col(total_ip), col(total_sgp), col(total_lgp), col(total_gtsgp), col(total_gtip), col(total_sum_gtip))
                                            
     val totgtIpMasterData = totgtIp.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", total_ip ,total_sgp, total_lgp, total_gtsgp, total_gtip, total_sum_gtip)
       
                           
      val total_cat =   "clm_total_"+typeOfPay+"_amt_catastrophic"
      
         
                          
                           
      val total_lgpmmcare =   "clm_total_"+typeOfPay+"_amt_lgp_mmcare"
      
      val clm_total_paid_amt_lgp_mmcare = naic2018_mcas_hlthex_clmphmcy_unicare_paid_lgp_wrk.filter(
                                      $"naic_lob".equalTo("LARGE GROUP CBE"))
                                      .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange", $"CLM_ADJSTMNT_KEY", $"CLM_LINE_NBR",  col(paid_col)).agg((lit(1)).alias("count_Val"))
                                   .groupBy($"health_year", $"cmpny_cf_cd", $"state", $"outoff_exchange").agg(sum(col(paid_col)).alias(total_lgpmmcare)).withColumn(total_lgpmmcare,col(total_lgpmmcare).cast(IntegerType))
     
        val mmcare=  totgtIpMasterData.alias("parent").join(clm_total_paid_amt_lgp_mmcare.alias("child") , $"parent.health_year"===$"child.health_year" 
          && $"parent.cmpny_cf_cd"===$"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.outoff_exchange"===$"child.outoff_exchange", "outer")
          .select($"parent.health_year".alias("b_year"),$"child.health_year".alias("s_year"), 
           $"parent.cmpny_cf_cd".alias("b_cmpny"),$"child.cmpny_cf_cd".alias("s_cmpny") , $"parent.state".alias("b_state"), 
           $"child.state".alias("s_state") , $"parent.outoff_exchange".alias("b_inx"),
           $"child.outoff_exchange".alias("s_inx"),col(total_ip), col(total_sgp), col(total_lgp), col(total_gtsgp), col(total_gtip), col(total_sum_gtip),
           col(total_lgpmmcare))
      val total_lgpstuvg =   "clm_total_"+typeOfPay+"_amt_stucvg"                                      
     val clmPaidData = mmcare.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
                           .withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
                           .withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
                           .withColumn("outoff_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx")) 
                           .withColumn(total_cat, lit(0))
                           .withColumn(total_lgpstuvg, lit(0))
                           .select("health_year","cmpny_cf_cd", "state", "outoff_exchange", total_ip ,total_sgp, total_lgp, total_gtsgp, total_gtip, total_sum_gtip, total_cat,
                               total_lgpmmcare, total_lgpstuvg)
       
                 
 
    clmPaidData                       
  }
 
}
object PCADX_SCL_NAIC2018_UnicareStgTransformationclmPhmcy{
  def main(args: Array[String]) {
  PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
  val unicare =  new PCADX_SCL_NAIC2018_UnicareStgTransformationclmPhmcy()
  unicare.sparkInIt()
  }
}