package gen

import java.util.Properties
import org.apache.log4j.PropertyConfigurator
import org.apache.spark.sql.SparkSession
import org.apache.spark
import org.apache.spark.SparkConf
import org.apache.spark.SparkContext._

import org.apache.spark.SparkContext
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.SaveMode

import org.apache.spark.sql.functions.udf
import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row

import org.apache.hadoop.fs._;
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.temporal.ChronoUnit


class PCADX_SCL_NAIC2018_IEXStg_Transformation_POA_SG {

	val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
			config("hive.exec.dynamic.partition.mode", "nonstrict").
			config("spark.sql.parquet.compression.codec", "snappy").
			config("hive.warehouse.data.skipTrash", "true").
			config("spark.sql.parquet.writeLegacyFormat", "true").
			enableHiveSupport().getOrCreate()

			import org.apache.spark.sql.types._
			import spark.implicits._

			var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_IEXStg_Transformation_POA_SG])

			val dbProperties = new Properties
			dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))

			val dbsg = dbProperties.getProperty("stage.db")
			val dbwrk = dbProperties.getProperty("work.db")
		
			val tbl_poag_Mmissued = dbProperties.getProperty("mmissued_poag")
			val tbl_poag_Mmrenewed = dbProperties.getProperty("mmrenewed_poag")
			val tbl_poag_Termed_lives = dbProperties.getProperty("termed_lives_poag")
			val tbl_poag_Termed_nonpay_lives = dbProperties.getProperty("termed_nonpay_lives_poag")


			def sparkInIt() {

				val naic2018_mcas_hlthex_poag_mmissued_wrk = readDataFromHive(dbwrk + "." + tbl_poag_Mmissued)
				val naic2018_mcas_hlthex_poag_mmrenewed_wrk = readDataFromHive(dbwrk + "." + tbl_poag_Mmrenewed)
				val naic2018_mcas_hlthex_poag_termed_lives_wrk = readDataFromHive(dbwrk + "." + tbl_poag_Termed_lives)
				val naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk = readDataFromHive(dbwrk + "." + tbl_poag_Termed_nonpay_lives)

				//truncateTbl(dbsg+"."+"naic_mcas_hlthiex_poa_stg")
				val sg_stgData = populateStageTbl(naic2018_mcas_hlthex_poag_mmissued_wrk, naic2018_mcas_hlthex_poag_mmrenewed_wrk, naic2018_mcas_hlthex_poag_termed_lives_wrk, naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk )
				sg_stgData.repartition(50)
				writeDataToHive(dbsg + "." + "naic2018_mcas_hlthiex_poa_sg_stg", sg_stgData)
				spark.close()
			}

			def truncateTbl(tblName: String) {
				spark.sql("TRUNCATE TABLE " + tblName)
			}

			def writeDataToHive(tblName: String, finalDf: DataFrame) {
				finalDf.write.mode(SaveMode.Overwrite).insertInto(tblName)
				println("Data added in POA Small Group Stage Table")
			}

			def readDataFromHive(tble: String): DataFrame = {
					val queryOutputTable = """SELECT * FROM """ + tble
							println(queryOutputTable)
							val tbl_data_df = spark.sql(queryOutputTable) //.na.fill("")
							logger.info("Read data from hive")
							tbl_data_df
			}
			
			def populateStageTbl(naic2018_mcas_hlthex_poag_mmissued_wrk: DataFrame, naic2018_mcas_hlthex_poag_mmrenewed_wrk: DataFrame, 
					naic2018_mcas_hlthex_poag_termed_lives_wrk: DataFrame, naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk: DataFrame): DataFrame = {
			  
							val final_df = null
							val issueFinalDf = getIssuedData(naic2018_mcas_hlthex_poag_mmissued_wrk, "issued")
							val rennewedFinalDf = getIssuedData(naic2018_mcas_hlthex_poag_mmrenewed_wrk, "renewed")
						  val termedFinalDf = getIssuedData(naic2018_mcas_hlthex_poag_termed_lives_wrk, "termed")
						  val termed_nonpayFinalDf = getIssuedData(naic2018_mcas_hlthex_poag_termed_nonpay_lives_wrk, "termed_nonpay")						  
						  
						  val IexStgData = getStageData(issueFinalDf, rennewedFinalDf, termedFinalDf, termed_nonpayFinalDf)
						  var load_log_key = ""

						  if (!naic2018_mcas_hlthex_poag_mmissued_wrk.take(1).isEmpty) {
							  load_log_key = naic2018_mcas_hlthex_poag_mmissued_wrk.select($"load_log_key").first.getString(0)
						  }

							val finalStgdata = IexStgData.withColumn("load_log_key", lit(load_log_key)).withColumn("load_dt", current_timestamp());
							//finalStgdata.filter($"state".equalTo("OH")).show()
							finalStgdata			  
			}
			
			def getIssuedData(naic2018_mcas_hlthex_poag_wrk: DataFrame, typeOfData: String): DataFrame = {
					// val finalIssuedDataDf;

					    val nbrpoa_bronze_sgp = "nbrpoa_" + typeOfData + "_bronze_sgp"
							val nbrpoa_issued_bronze_sgp = naic2018_mcas_hlthex_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
									naic2018_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
									naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("04") &&
									naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias(nbrpoa_bronze_sgp))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_bronze_sgp).alias(nbrpoa_bronze_sgp))


							val nbrpoa_silver_sgp = "nbrpoa_" + typeOfData + "_silver_sgp"
							val nbrpoa_issued_silver_sgp = naic2018_mcas_hlthex_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
									naic2018_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
									naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("03") &&
									naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias(nbrpoa_silver_sgp))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_silver_sgp).alias(nbrpoa_silver_sgp))


							val brSil = nbrpoa_issued_bronze_sgp.alias("bronze").join(nbrpoa_issued_silver_sgp.alias("silver"), $"bronze.health_year" === $"silver.health_year"
							&& $"bronze.cmpny_cf_cd" === $"silver.cmpny_cf_cd" && $"bronze.state" === $"silver.state" && $"bronze.in_exchange" === $"silver.in_exchange", "outer")
							.select($"bronze.health_year".alias("b_year"), $"silver.health_year".alias("s_year"),
									$"bronze.cmpny_cf_cd".alias("b_cmpny"), $"silver.cmpny_cf_cd".alias("s_cmpny"), $"bronze.state".alias("b_state"),
									$"silver.state".alias("s_state"), $"bronze.in_exchange".alias("b_inx"),
									$"silver.in_exchange".alias("s_inx"), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp))

							val brSilData = brSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_sgp, nbrpoa_silver_sgp)

							val nbrpoa_gold_sgp = "nbrpoa_" + typeOfData + "_gold_sgp"
							val nbrpoa_issued_gold_sgp = naic2018_mcas_hlthex_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
									naic2018_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
									naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("02") &&
									naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias(nbrpoa_gold_sgp))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_gold_sgp).alias(nbrpoa_gold_sgp))
							

							val bsGold = brSilData.alias("brsil").join(nbrpoa_issued_gold_sgp.alias("gold"), $"brsil.health_year" === $"gold.health_year"
							&& $"brsil.cmpny_cf_cd" === $"gold.cmpny_cf_cd" && $"brsil.state" === $"gold.state" && $"brsil.in_exchange" === $"gold.in_exchange", "outer")
							.select($"brsil.health_year".alias("b_year"), $"gold.health_year".alias("s_year"),
									$"brsil.cmpny_cf_cd".alias("b_cmpny"), $"gold.cmpny_cf_cd".alias("s_cmpny"), $"brsil.state".alias("b_state"),
									$"gold.state".alias("s_state"), $"brsil.in_exchange".alias("b_inx"),
									$"gold.in_exchange".alias("s_inx"), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp))

							val bsGoldData = bsGold.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp)

							val nbrpoa_platinum_sgp = "nbrpoa_" + typeOfData + "_platinum_sgp"
							val nbrpoa_issued_platinum_sgp = naic2018_mcas_hlthex_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									(naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").notEqual("YES") || naic2018_mcas_hlthex_poag_wrk("grndfthr_ind_cd").isNull) &&
									naic2018_mcas_hlthex_poag_wrk("hcr_cmplynt_cd").equalTo("Y") &&
									(naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").notEqual("M") || naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").isNull) &&
									naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("01") &&
									naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias(nbrpoa_platinum_sgp))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_platinum_sgp).alias(nbrpoa_platinum_sgp))
							

							val bsgPlt = bsGoldData.alias("bsg").join(nbrpoa_issued_platinum_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
									$"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp))

							val bsgPltinumData = bsgPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp)

							val nbrpoa_total_sgp = "nbrpoa_" + typeOfData + "_total_sgp"
							val getTotal_ip = nbrpoa_issued_bronze_sgp.union(nbrpoa_issued_silver_sgp.union(nbrpoa_issued_gold_sgp.union(nbrpoa_issued_platinum_sgp)))
							.select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col(nbrpoa_bronze_sgp)).withColumn(nbrpoa_bronze_sgp, col(nbrpoa_bronze_sgp).cast(IntegerType))

							val nbrpoa_issued_total_ip = getTotal_ip.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum(col(nbrpoa_bronze_sgp)).alias(nbrpoa_total_sgp))

							val bsgpTot = bsgPltinumData.alias("bsg").join(nbrpoa_issued_total_ip.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
									$"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp),
									col(nbrpoa_total_sgp))

							val bsgPTotData = bsgpTot.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,
									nbrpoa_total_sgp)

									
							val nbrpoa_bronze_ms_sgp = "nbrpoa_" + typeOfData + "_bronze_ms_sgp"
							val nbrpoa_issued_bronze_ms_sgp = naic2018_mcas_hlthex_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").equalTo("M") &&
									naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("04") &&
									naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias(nbrpoa_bronze_ms_sgp))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_bronze_ms_sgp).alias(nbrpoa_bronze_ms_sgp))

							val bsgptcBrz = bsgPTotData.alias("bsg").join(nbrpoa_issued_bronze_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
									$"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp),
									col(nbrpoa_total_sgp), col(nbrpoa_bronze_ms_sgp))

							val bsgptcBrzData = bsgptcBrz.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,
									nbrpoa_total_sgp, nbrpoa_bronze_ms_sgp)

							val nbrpoa_silver_ms_sgp = "nbrpoa_" + typeOfData + "_silver_ms_sgp"
							val nbrpoa_issued_silver_ms_sgp = naic2018_mcas_hlthex_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").equalTo("M") &&
									naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("03") &&
									naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias(nbrpoa_silver_ms_sgp))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_silver_ms_sgp).alias(nbrpoa_silver_ms_sgp))


							val bsgptcbSil = bsgptcBrzData.alias("bsg").join(nbrpoa_issued_silver_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
									$"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp),
									col(nbrpoa_total_sgp), col(nbrpoa_bronze_ms_sgp), col(nbrpoa_silver_ms_sgp))

							val bsgptcbSilData = bsgptcbSil.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,
									nbrpoa_total_sgp, nbrpoa_bronze_ms_sgp, nbrpoa_silver_ms_sgp)

							val nbrpoa_gold_ms_sgp = "nbrpoa_" + typeOfData + "_gold_ms_sgp"
							val nbrpoa_issued_gold_ms_sgp = naic2018_mcas_hlthex_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").equalTo("M") &&
									naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("02") &&
									naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias(nbrpoa_gold_ms_sgp))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_gold_ms_sgp).alias(nbrpoa_gold_ms_sgp))

							val bsgptcbsGold = bsgptcbSilData.alias("bsg").join(nbrpoa_issued_gold_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
									$"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp),
									col(nbrpoa_total_sgp), col(nbrpoa_bronze_ms_sgp), col(nbrpoa_silver_ms_sgp), col(nbrpoa_gold_ms_sgp))

							val bsgptcbsGoldData = bsgptcbsGold.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,
									nbrpoa_total_sgp, nbrpoa_bronze_ms_sgp, nbrpoa_silver_ms_sgp, nbrpoa_gold_ms_sgp)

							val nbrpoa_platinum_ms_sgp = "nbrpoa_" + typeOfData + "_platinum_ms_sgp"
							val nbrpoa_issued_platinum_ms_sgp = naic2018_mcas_hlthex_poag_wrk.filter(naic2018_mcas_hlthex_poag_wrk("naic_lob").equalTo("TOTAL SMALL GROUP CBE") &&
									naic2018_mcas_hlthex_poag_wrk("src_exchng_certfn_cd").equalTo("M") &&
									naic2018_mcas_hlthex_poag_wrk("exchng_metl_type_cd").equalTo("01") &&
									naic2018_mcas_hlthex_poag_wrk("in_exchange").equalTo("IN"))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", $"mbrshp_sor_cd", $"src_grp_nbr").agg((lit(1)).alias(nbrpoa_platinum_ms_sgp))
							.groupBy($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange").agg(sum(nbrpoa_platinum_ms_sgp).alias(nbrpoa_platinum_ms_sgp))

							val bsgptcbsfPlt = bsgptcbsGoldData.alias("bsg").join(nbrpoa_issued_platinum_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
									$"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp),
									col(nbrpoa_total_sgp), col(nbrpoa_bronze_ms_sgp), col(nbrpoa_silver_ms_sgp), col(nbrpoa_gold_ms_sgp),
									col(nbrpoa_platinum_ms_sgp))

							val bsgptcbsfPltData = bsgptcbsfPlt.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,
									nbrpoa_total_sgp, nbrpoa_bronze_ms_sgp, nbrpoa_silver_ms_sgp, nbrpoa_gold_ms_sgp, nbrpoa_platinum_ms_sgp)
							//bsgptcbsfPltData.show()
							
							val nbrpoa_total_ms_sgp = "nbrpoa_" + typeOfData + "_total_ms_sgp"
							val getTotal_ms_sgp = nbrpoa_issued_bronze_ms_sgp.union(nbrpoa_issued_silver_ms_sgp.union(nbrpoa_issued_gold_ms_sgp.union(nbrpoa_issued_platinum_ms_sgp)))
							.select($"health_year", $"cmpny_cf_cd", $"state", $"in_exchange", col(nbrpoa_bronze_ms_sgp)).withColumn(nbrpoa_bronze_ms_sgp, col(nbrpoa_bronze_ms_sgp).cast(IntegerType))

							val nbrpoa_issued_total_ms_sgp = getTotal_ms_sgp.groupBy("health_year", "cmpny_cf_cd", "state", "in_exchange").agg(sum(nbrpoa_bronze_ms_sgp).alias(nbrpoa_total_ms_sgp))

							val finalDat = bsgptcbsfPltData.alias("bsg").join(nbrpoa_issued_total_ms_sgp.alias("plt"), $"bsg.health_year" === $"plt.health_year"
							&& $"bsg.cmpny_cf_cd" === $"plt.cmpny_cf_cd" && $"bsg.state" === $"plt.state" && $"bsg.in_exchange" === $"plt.in_exchange", "outer")
							.select($"bsg.health_year".alias("b_year"), $"plt.health_year".alias("s_year"),
									$"bsg.cmpny_cf_cd".alias("b_cmpny"), $"plt.cmpny_cf_cd".alias("s_cmpny"), $"bsg.state".alias("b_state"),
									$"plt.state".alias("s_state"), $"bsg.in_exchange".alias("b_inx"),
									$"plt.in_exchange".alias("s_inx"), col(nbrpoa_bronze_sgp), col(nbrpoa_silver_sgp), col(nbrpoa_gold_sgp), col(nbrpoa_platinum_sgp),
									col(nbrpoa_total_sgp), col(nbrpoa_bronze_ms_sgp), col(nbrpoa_silver_ms_sgp), col(nbrpoa_gold_ms_sgp),
									col(nbrpoa_platinum_ms_sgp), col(nbrpoa_total_ms_sgp))

							val FinalData = finalDat.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", "in_exchange", nbrpoa_bronze_sgp, nbrpoa_silver_sgp, nbrpoa_gold_sgp, nbrpoa_platinum_sgp,
									nbrpoa_total_sgp, nbrpoa_bronze_ms_sgp, nbrpoa_silver_ms_sgp, nbrpoa_gold_ms_sgp, nbrpoa_platinum_ms_sgp,	nbrpoa_total_ms_sgp)

							FinalData
			}
			
			def getStageData(issueFinalDf: DataFrame, rennewedFinalDf: DataFrame,termedFinalDf: DataFrame, termed_nonpayFinalDf: DataFrame ): DataFrame = {

					val issued_renewed = issueFinalDf.alias("parent").join(rennewedFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
									$"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
									$"child.in_exchange".alias("s_inx"), $"nbrpoa_issued_bronze_sgp", $"nbrpoa_issued_silver_sgp", $"nbrpoa_issued_gold_sgp", $"nbrpoa_issued_platinum_sgp",
									$"nbrpoa_issued_total_sgp", $"nbrpoa_issued_bronze_ms_sgp", $"nbrpoa_issued_silver_ms_sgp",
									$"nbrpoa_issued_gold_ms_sgp", $"nbrpoa_issued_platinum_ms_sgp",
									$"nbrpoa_issued_total_ms_sgp", $"nbrpoa_renewed_bronze_sgp", $"nbrpoa_renewed_silver_sgp", $"nbrpoa_renewed_gold_sgp", $"nbrpoa_renewed_platinum_sgp",
									$"nbrpoa_renewed_total_sgp", $"nbrpoa_renewed_bronze_ms_sgp", $"nbrpoa_renewed_silver_ms_sgp", $"nbrpoa_renewed_gold_ms_sgp",
									$"nbrpoa_renewed_platinum_ms_sgp", $"nbrpoa_renewed_total_ms_sgp")

					val issued_renewedData = issued_renewed.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrpoa_issued_bronze_sgp", "nbrpoa_issued_silver_sgp", "nbrpoa_issued_gold_sgp", 
									"nbrpoa_issued_platinum_sgp", "nbrpoa_issued_total_sgp", "nbrpoa_issued_bronze_ms_sgp", "nbrpoa_issued_silver_ms_sgp", "nbrpoa_issued_gold_ms_sgp", 									
									"nbrpoa_issued_platinum_ms_sgp", "nbrpoa_issued_total_ms_sgp", "nbrpoa_renewed_bronze_sgp", "nbrpoa_renewed_silver_sgp", "nbrpoa_renewed_gold_sgp", 
									"nbrpoa_renewed_platinum_sgp", "nbrpoa_renewed_total_sgp", "nbrpoa_renewed_bronze_ms_sgp", "nbrpoa_renewed_silver_ms_sgp", "nbrpoa_renewed_gold_ms_sgp",
									"nbrpoa_renewed_platinum_ms_sgp", "nbrpoa_renewed_total_ms_sgp") 
									
			  
					val ir_termed = issued_renewedData.alias("parent").join(termedFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
									$"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
									$"child.in_exchange".alias("s_inx"), $"nbrpoa_issued_bronze_sgp", $"nbrpoa_issued_silver_sgp", $"nbrpoa_issued_gold_sgp", $"nbrpoa_issued_platinum_sgp",
									$"nbrpoa_issued_total_sgp", $"nbrpoa_issued_bronze_ms_sgp", $"nbrpoa_issued_silver_ms_sgp", $"nbrpoa_issued_gold_ms_sgp", $"nbrpoa_issued_platinum_ms_sgp",									
									$"nbrpoa_issued_total_ms_sgp", $"nbrpoa_renewed_bronze_sgp", $"nbrpoa_renewed_silver_sgp", $"nbrpoa_renewed_gold_sgp", $"nbrpoa_renewed_platinum_sgp",
									$"nbrpoa_renewed_total_sgp", $"nbrpoa_renewed_bronze_ms_sgp", $"nbrpoa_renewed_silver_ms_sgp", $"nbrpoa_renewed_gold_ms_sgp",
									$"nbrpoa_renewed_platinum_ms_sgp", $"nbrpoa_renewed_total_ms_sgp", $"nbrpoa_termed_bronze_sgp", $"nbrpoa_termed_silver_sgp", $"nbrpoa_termed_gold_sgp", 
									$"nbrpoa_termed_platinum_sgp", $"nbrpoa_termed_total_sgp", $"nbrpoa_termed_bronze_ms_sgp", $"nbrpoa_termed_silver_ms_sgp", $"nbrpoa_termed_gold_ms_sgp", 
									$"nbrpoa_termed_platinum_ms_sgp", $"nbrpoa_termed_total_ms_sgp")

					val ir_termedData = ir_termed.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("health_year", "cmpny_cf_cd", "state", "in_exchange", "nbrpoa_issued_bronze_sgp", "nbrpoa_issued_silver_sgp", "nbrpoa_issued_gold_sgp",
									"nbrpoa_issued_platinum_sgp", "nbrpoa_issued_total_sgp", "nbrpoa_issued_bronze_ms_sgp", "nbrpoa_issued_silver_ms_sgp", "nbrpoa_issued_gold_ms_sgp", 									
									"nbrpoa_issued_platinum_ms_sgp", "nbrpoa_issued_total_ms_sgp", "nbrpoa_renewed_bronze_sgp", "nbrpoa_renewed_silver_sgp", "nbrpoa_renewed_gold_sgp", 
									"nbrpoa_renewed_platinum_sgp", "nbrpoa_renewed_total_sgp", "nbrpoa_renewed_bronze_ms_sgp", "nbrpoa_renewed_silver_ms_sgp", "nbrpoa_renewed_gold_ms_sgp",
									"nbrpoa_renewed_platinum_ms_sgp", "nbrpoa_renewed_total_ms_sgp", "nbrpoa_termed_bronze_sgp", "nbrpoa_termed_silver_sgp", "nbrpoa_termed_gold_sgp", 
									"nbrpoa_termed_platinum_sgp", "nbrpoa_termed_total_sgp", "nbrpoa_termed_bronze_ms_sgp", "nbrpoa_termed_silver_ms_sgp", "nbrpoa_termed_gold_ms_sgp", 
									"nbrpoa_termed_platinum_ms_sgp", "nbrpoa_termed_total_ms_sgp") 		
				
				 val irtermedNonPay = ir_termedData.alias("parent").join(termed_nonpayFinalDf.alias("child"), $"parent.health_year" === $"child.health_year"
							&& $"parent.cmpny_cf_cd" === $"child.cmpny_cf_cd" && $"parent.state" === $"child.state" && $"parent.in_exchange" === $"child.in_exchange", "outer")
							.select($"parent.health_year".alias("b_year"), $"child.health_year".alias("s_year"),
									$"parent.cmpny_cf_cd".alias("b_cmpny"), $"child.cmpny_cf_cd".alias("s_cmpny"), $"parent.state".alias("b_state"),
									$"child.state".alias("s_state"), $"parent.in_exchange".alias("b_inx"),
									$"child.in_exchange".alias("s_inx"), $"nbrpoa_issued_bronze_sgp", $"nbrpoa_issued_silver_sgp", $"nbrpoa_issued_gold_sgp", $"nbrpoa_issued_platinum_sgp",
									$"nbrpoa_issued_total_sgp", $"nbrpoa_issued_bronze_ms_sgp", $"nbrpoa_issued_silver_ms_sgp", $"nbrpoa_issued_gold_ms_sgp", $"nbrpoa_issued_platinum_ms_sgp",									
									$"nbrpoa_issued_total_ms_sgp", $"nbrpoa_renewed_bronze_sgp", $"nbrpoa_renewed_silver_sgp", $"nbrpoa_renewed_gold_sgp", $"nbrpoa_renewed_platinum_sgp",
									$"nbrpoa_renewed_total_sgp", $"nbrpoa_renewed_bronze_ms_sgp", $"nbrpoa_renewed_silver_ms_sgp", $"nbrpoa_renewed_gold_ms_sgp",
									$"nbrpoa_renewed_platinum_ms_sgp", $"nbrpoa_renewed_total_ms_sgp", $"nbrpoa_termed_bronze_sgp", $"nbrpoa_termed_silver_sgp", $"nbrpoa_termed_gold_sgp", 
									$"nbrpoa_termed_platinum_sgp", $"nbrpoa_termed_total_sgp", $"nbrpoa_termed_bronze_ms_sgp", $"nbrpoa_termed_silver_ms_sgp", $"nbrpoa_termed_gold_ms_sgp", 
									$"nbrpoa_termed_platinum_ms_sgp", $"nbrpoa_termed_total_ms_sgp", $"nbrpoa_termed_nonpay_bronze_sgp", $"nbrpoa_termed_nonpay_silver_sgp", 
									$"nbrpoa_termed_nonpay_gold_sgp", $"nbrpoa_termed_nonpay_platinum_sgp", $"nbrpoa_termed_nonpay_total_sgp", $"nbrpoa_termed_nonpay_bronze_ms_sgp", 
									$"nbrpoa_termed_nonpay_silver_ms_sgp", $"nbrpoa_termed_nonpay_gold_ms_sgp", $"nbrpoa_termed_nonpay_platinum_ms_sgp", $"nbrpoa_termed_nonpay_total_ms_sgp")
			  
					val finalData = irtermedNonPay.withColumn("health_year", when(($"b_year").isNull, $"s_year").otherwise($"b_year"))
							.withColumn("cmpny_cf_cd", when(($"b_cmpny").isNull, $"s_cmpny").otherwise($"b_cmpny"))
							.withColumn("state", when(($"b_state").isNull, $"s_state").otherwise($"b_state"))
							.withColumn("in_exchange", when(($"b_inx").isNull, $"s_inx").otherwise($"b_inx"))
							.select("in_exchange", "health_year", "cmpny_cf_cd", "state", "nbrpoa_issued_bronze_sgp", "nbrpoa_issued_silver_sgp", "nbrpoa_issued_gold_sgp",
									"nbrpoa_issued_platinum_sgp", "nbrpoa_issued_total_sgp", "nbrpoa_issued_bronze_ms_sgp", "nbrpoa_issued_silver_ms_sgp", "nbrpoa_issued_gold_ms_sgp", 									
									"nbrpoa_issued_platinum_ms_sgp", "nbrpoa_issued_total_ms_sgp", "nbrpoa_renewed_bronze_sgp", "nbrpoa_renewed_silver_sgp", "nbrpoa_renewed_gold_sgp", 
									"nbrpoa_renewed_platinum_sgp", "nbrpoa_renewed_total_sgp", "nbrpoa_renewed_bronze_ms_sgp", "nbrpoa_renewed_silver_ms_sgp", "nbrpoa_renewed_gold_ms_sgp",
									"nbrpoa_renewed_platinum_ms_sgp", "nbrpoa_renewed_total_ms_sgp", "nbrpoa_termed_bronze_sgp", "nbrpoa_termed_silver_sgp", "nbrpoa_termed_gold_sgp", 
									"nbrpoa_termed_platinum_sgp", "nbrpoa_termed_total_sgp", "nbrpoa_termed_bronze_ms_sgp", "nbrpoa_termed_silver_ms_sgp", "nbrpoa_termed_gold_ms_sgp", 
									"nbrpoa_termed_platinum_ms_sgp", "nbrpoa_termed_total_ms_sgp", "nbrpoa_termed_nonpay_bronze_sgp", "nbrpoa_termed_nonpay_silver_sgp", 
									"nbrpoa_termed_nonpay_gold_sgp", "nbrpoa_termed_nonpay_platinum_sgp", "nbrpoa_termed_nonpay_total_sgp", "nbrpoa_termed_nonpay_bronze_ms_sgp", 
									"nbrpoa_termed_nonpay_silver_ms_sgp", "nbrpoa_termed_nonpay_gold_ms_sgp", "nbrpoa_termed_nonpay_platinum_ms_sgp", "nbrpoa_termed_nonpay_total_ms_sgp") 	
									
			  finalData

			}
			
}

object PCADX_SCL_NAIC2018_IEXStg_Transformation_POA_SG {
	def main(args: Array[String]) {
		PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
		val iex = new PCADX_SCL_NAIC2018_IEXStg_Transformation_POA_SG()
		iex.sparkInIt()
	}
}