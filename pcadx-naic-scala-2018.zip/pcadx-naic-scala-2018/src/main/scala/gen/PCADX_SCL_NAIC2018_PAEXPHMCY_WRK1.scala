package gen
import java.util.Properties
import org.apache.log4j.PropertyConfigurator

import java.sql.Timestamp
import org.slf4j.{ Logger, LoggerFactory }
import scala.io.Source
import java.io._
import java.util.Properties
import java.io.FileInputStream
import java.io.IOException;
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit

import org.apache.hadoop.fs._;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
class PCADX_SCL_NAIC2018_PAEXPHMCY_WRK1 {

  val spark = SparkSession.builder().config("hive.exec.dynamic.partition", "true").
    config("hive.exec.dynamic.partition.mode", "nonstrict").
    config("spark.sql.parquet.compression.codec", "snappy").
    config("hive.warehouse.data.skipTrash", "true").
    config("spark.sql.parquet.writeLegacyFormat", "true").
    enableHiveSupport().getOrCreate()
  spark.conf.set("spark.sql.crossJoin.enabled", "true")

  import spark.implicits._

  var logger: Logger = LoggerFactory.getLogger(classOf[PCADX_SCL_NAIC2018_PAEXPHMCY_WRK1])

  val dbProperties = new Properties
  dbProperties.load(getClass().getResourceAsStream(PCADX_SCL_NAIC2018_EnvironValues.fileName))
  val dbWrk = dbProperties.getProperty("work.db")
  val dbInbnd = dbProperties.getProperty("inbound.db")
  val apprvd_strtdt = dbProperties.getProperty("apprvd_pa_temp_strtDt")
  val apprvd_enddt = dbProperties.getProperty("apprvd_pa_temp_endDt")
  val reportYear = dbProperties.getProperty("report.year")
  val wrhDb = dbProperties.getProperty("warehouse.db")
  val prcp_cd = dbProperties.getProperty("PRCP_TYPE_CD")
  val audit_log_df = spark.sql("select * from " + wrhDb + ".audt_load_log")
  val load_log_key = audit_log_df.filter($"subj_area_nm" === "NAIC2018_MCAS" && $"prcs_nm" === "NAIC2018_MCAS_RPT" && $"load_stts_cd" === "S")
    .orderBy($"LOAD_END_DTM".desc).limit(1).select($"load_log_key").head().getLong(0).toString()
  val umRqstCreatFrmDt=dbProperties.getProperty("um_rqst_creat_frmDt")
  val umRqstCreatToDt=dbProperties.getProperty("um_rqst_creat_toDt")

    def TrnctTbl = """Truncate table """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_wrk1"""


  def pa_query1() = """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_wrk1""" +
    """ 
      select 
        ur.MBR_KEY as MBR_KEY,
        ur.UM_RQST_INITD_DT as UM_RQST_INITD_DT ,
        ur.UM_RQST_CREAT_DT as UM_RQST_CREAT_DT ,
        ur.CASE_TYPE_CD as CASE_TYPE_CD ,
        ur.AUTHRZN_STTS_CD as AUTHRZN_STTS_CD ,
        ur.RCRD_STTS_CD as RCRD_STTS_CD ,
        us.CLNCL_SOR_CD as  CLNCL_SOR_CD ,
        us.RFRNC_NBR as RFRNC_NBR , 
        us.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
        us.UM_SRVC_STTS_CD as UM_SRVC_STTS_CD , 
        us.SRC_UM_SRVC_STTS_CD as SRC_UM_SRVC_STTS_CD , 
        us.STTS_DT as  STTS_DT , 
        ux.SRVC_RVW_TYPE_CD as SRVC_RVW_TYPE_CD ,
        ux.AUTHRZD_PLACE_OF_SRVC_CD as  AUTHRZD_PLACE_OF_SRVC_CD ,
        ux.INPAT_RQSTD_CD  as INPAT_RQSTD_CD ,
        ux.INPAT_AUTHRZD_CD  as INPAT_AUTHRZD_CD ,
        ux.RQSTD_PLACE_OF_SRVC_CD as RQSTD_PLACE_OF_SRVC_CD ,
        ux.RQSTD_PROC_SRVC_TYPE_CD as RQSTD_PROC_SRVC_TYPE_CD,
        """+load_log_key+""" as load_log_key,
				current_timestamp
      from 
        """ + dbInbnd + """.UM_RQST ur
        inner join """ + dbInbnd + """.UM_SRVC_STTS us
        on us.RFRNC_NBR = ur.RFRNC_NBR
        and us.CLNCL_SOR_CD = ur.CLNCL_SOR_CD
        inner join """ + dbInbnd + """.UM_SRVC ux
        on ux.RFRNC_NBR = us.RFRNC_NBR
        and ux.SRVC_LINE_NBR = us.SRVC_LINE_NBR
        and ux.CLNCL_SOR_CD= us.CLNCL_SOR_CD
      where 
        us.CLNCL_SOR_CD in ( '870' , '872' , '873' , '948' , '1103' , '1035' , '1036'  )
        and ur.UM_RQST_CREAT_DT BETWEEN  """+umRqstCreatFrmDt+ """  AND """+umRqstCreatToDt+ """ 
        and ur.CASE_TYPE_CD NOT IN ( 'PHARMACY' , 'DENTAL')
        and ux.SRVC_RVW_TYPE_CD in ('P','PU','PNU')
        and ur.RCRD_STTS_CD not in ( 'DEL', 'DUP' )
        and us.UM_SRVC_STTS_CD not in ( 'NA' , 'UNK'   )
      group by 
        ur.MBR_KEY ,
        ur.UM_RQST_INITD_DT  ,
        ur.UM_RQST_CREAT_DT  ,
        ur.CASE_TYPE_CD  ,
        ur.AUTHRZN_STTS_CD  ,
        ur.RCRD_STTS_CD  ,
        us.CLNCL_SOR_CD  ,
        us.RFRNC_NBR  , 
        us.SRVC_LINE_NBR  ,
        us.UM_SRVC_STTS_CD  , 
        us.SRC_UM_SRVC_STTS_CD  , 
        us.STTS_DT  , 
        ux.SRVC_RVW_TYPE_CD  ,
        ux.AUTHRZD_PLACE_OF_SRVC_CD  ,
        ux.INPAT_RQSTD_CD   ,
        ux.INPAT_AUTHRZD_CD  ,
        ux.RQSTD_PLACE_OF_SRVC_CD ,
        ux.RQSTD_PROC_SRVC_TYPE_CD

     """
        
    def pa_query2() =  """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_wrk1""" + 
     """
 
      select 
        ur.MBR_KEY as MBR_KEY,
        ur.UM_RQST_INITD_DT as UM_RQST_INITD_DT ,
        ur.UM_RQST_CREAT_DT as UM_RQST_CREAT_DT ,
        ur.CASE_TYPE_CD as CASE_TYPE_CD ,
        ur.AUTHRZN_STTS_CD as AUTHRZN_STTS_CD ,
        ur.RCRD_STTS_CD as RCRD_STTS_CD ,
        us.CLNCL_SOR_CD as  CLNCL_SOR_CD ,
        us.RFRNC_NBR as RFRNC_NBR , 
        us.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
        us.UM_SRVC_STTS_CD as UM_SRVC_STTS_CD , 
        us.SRC_UM_SRVC_STTS_CD as SRC_UM_SRVC_STTS_CD , 
        us.STTS_DT as  STTS_DT , 
        ux.SRVC_RVW_TYPE_CD as SRVC_RVW_TYPE_CD ,
        ux.AUTHRZD_PLACE_OF_SRVC_CD as  AUTHRZD_PLACE_OF_SRVC_CD ,
        ux.INPAT_RQSTD_CD  as INPAT_RQSTD_CD ,
        ux.INPAT_AUTHRZD_CD  as INPAT_AUTHRZD_CD ,
        ux.RQSTD_PLACE_OF_SRVC_CD as RQSTD_PLACE_OF_SRVC_CD ,
        ux.RQSTD_PROC_SRVC_TYPE_CD as RQSTD_PROC_SRVC_TYPE_CD,
        """+load_log_key+""" as load_log_key,
				current_timestamp
      from 
        """ + dbInbnd + """.UM_RQST ur
        inner join """ + dbInbnd + """.UM_SRVC_STTS us
        on us.RFRNC_NBR = ur.RFRNC_NBR
        and us.CLNCL_SOR_CD = ur.CLNCL_SOR_CD
        inner join """ + dbInbnd + """.UM_SRVC ux
        on ux.RFRNC_NBR = us.RFRNC_NBR
        and ux.SRVC_LINE_NBR = us.SRVC_LINE_NBR
        and ux.CLNCL_SOR_CD= us.CLNCL_SOR_CD
      where 
        us.CLNCL_SOR_CD in ( '870' , '872' , '873' , '948' , '1103' , '1035' , '1036'  )
        and ur.UM_RQST_CREAT_DT BETWEEN  """+umRqstCreatFrmDt+ """  AND """+umRqstCreatToDt+ """ 
        and ur.CASE_TYPE_CD  IN ( 'PHARMACY' )
        and ux.SRVC_RVW_TYPE_CD in ('P','PU','PNU')
        and ur.RCRD_STTS_CD not in ( 'DEL', 'DUP' )
        and us.UM_SRVC_STTS_CD not in ( 'NA' , 'UNK'   )
        and ux.RQSTD_PLACE_OF_SRVC_CD <> '99'
      group by 
        ur.MBR_KEY ,
        ur.UM_RQST_INITD_DT  ,
        ur.UM_RQST_CREAT_DT  ,
        ur.CASE_TYPE_CD  ,
        ur.AUTHRZN_STTS_CD  ,
        ur.RCRD_STTS_CD  ,
        us.CLNCL_SOR_CD  ,
        us.RFRNC_NBR  , 
        us.SRVC_LINE_NBR  ,
        us.UM_SRVC_STTS_CD  , 
        us.SRC_UM_SRVC_STTS_CD  , 
        us.STTS_DT  , 
        ux.SRVC_RVW_TYPE_CD  ,
        ux.AUTHRZD_PLACE_OF_SRVC_CD  ,
        ux.INPAT_RQSTD_CD   ,
        ux.INPAT_AUTHRZD_CD ,
        ux.RQSTD_PLACE_OF_SRVC_CD ,
        ux.RQSTD_PROC_SRVC_TYPE_CD

    """    
        def pa_query3() = """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_wrk1""" + 
    """
      
      select 
        ur.MBR_KEY as MBR_KEY,
        ur.UM_RQST_INITD_DT as UM_RQST_INITD_DT ,
        ur.UM_RQST_CREAT_DT as UM_RQST_CREAT_DT ,
        ur.CASE_TYPE_CD as CASE_TYPE_CD ,
        ur.AUTHRZN_STTS_CD as AUTHRZN_STTS_CD ,
        ur.RCRD_STTS_CD as RCRD_STTS_CD ,
        us.CLNCL_SOR_CD as  CLNCL_SOR_CD ,
        us.RFRNC_NBR as RFRNC_NBR , 
        us.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
        us.UM_SRVC_STTS_CD as UM_SRVC_STTS_CD , 
        us.SRC_UM_SRVC_STTS_CD as SRC_UM_SRVC_STTS_CD , 
        us.STTS_DT as  STTS_DT , 
        ux.SRVC_RVW_TYPE_CD as SRVC_RVW_TYPE_CD ,
        ux.AUTHRZD_PLACE_OF_SRVC_CD as  AUTHRZD_PLACE_OF_SRVC_CD ,
        ux.INPAT_RQSTD_CD  as INPAT_RQSTD_CD ,
        ux.INPAT_AUTHRZD_CD  as INPAT_AUTHRZD_CD ,
        ux.RQSTD_PLACE_OF_SRVC_CD as RQSTD_PLACE_OF_SRVC_CD ,
        ux.RQSTD_PROC_SRVC_TYPE_CD as RQSTD_PROC_SRVC_TYPE_CD,
        """+load_log_key+""" as load_log_key,
				current_timestamp
      from 
        """ + dbInbnd + """.UM_RQST ur
        inner join """ + dbInbnd + """.UM_SRVC_STTS us
        on us.RFRNC_NBR = ur.RFRNC_NBR
        and us.CLNCL_SOR_CD = ur.CLNCL_SOR_CD
        inner join """ + dbInbnd + """.UM_SRVC ux
        on ux.RFRNC_NBR = us.RFRNC_NBR
        and ux.SRVC_LINE_NBR = us.SRVC_LINE_NBR
        and ux.CLNCL_SOR_CD= us.CLNCL_SOR_CD
      where 
        us.CLNCL_SOR_CD in (  '948' , '1103'  )
        and ur.UM_RQST_CREAT_DT BETWEEN  """+umRqstCreatFrmDt+ """  AND """+umRqstCreatToDt+ """  
        and ur.CASE_TYPE_CD  IN ( '~01' )
        and ux.SRVC_RVW_TYPE_CD in ('P','PU','PNU')
        and ur.RCRD_STTS_CD not in ( 'DEL', 'DUP' )
        and us.UM_SRVC_STTS_CD not in ( 'NA' , 'UNK'   )
      group by 
        ur.MBR_KEY ,
        ur.UM_RQST_INITD_DT  ,
        ur.UM_RQST_CREAT_DT  ,
        ur.CASE_TYPE_CD  ,
        ur.AUTHRZN_STTS_CD ,
        ur.RCRD_STTS_CD  ,
        us.CLNCL_SOR_CD  ,
        us.RFRNC_NBR  , 
        us.SRVC_LINE_NBR  ,
        us.UM_SRVC_STTS_CD  , 
        us.SRC_UM_SRVC_STTS_CD  , 
        us.STTS_DT  , 
        ux.SRVC_RVW_TYPE_CD  ,
        ux.AUTHRZD_PLACE_OF_SRVC_CD  ,
        ux.INPAT_RQSTD_CD   ,
        ux.INPAT_AUTHRZD_CD ,
        ux.RQSTD_PLACE_OF_SRVC_CD ,
        ux.RQSTD_PROC_SRVC_TYPE_CD

   """

        def pa_query4() = """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_wrk1""" + 
   """
       select 
        ur.MBR_KEY as MBR_KEY,
        ur.UM_RQST_INITD_DT as UM_RQST_INITD_DT ,
        ur.UM_RQST_CREAT_DT as UM_RQST_CREAT_DT ,
        ur.CASE_TYPE_CD as CASE_TYPE_CD ,
        ur.AUTHRZN_STTS_CD as AUTHRZN_STTS_CD ,
        ur.RCRD_STTS_CD as RCRD_STTS_CD ,
        us.CLNCL_SOR_CD as  CLNCL_SOR_CD ,
        us.RFRNC_NBR as RFRNC_NBR , 
        us.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
        us.UM_SRVC_STTS_CD as UM_SRVC_STTS_CD , 
        us.SRC_UM_SRVC_STTS_CD as SRC_UM_SRVC_STTS_CD , 
        us.STTS_DT as  STTS_DT , 
        ux.SRVC_RVW_TYPE_CD as SRVC_RVW_TYPE_CD ,
        ux.AUTHRZD_PLACE_OF_SRVC_CD as  AUTHRZD_PLACE_OF_SRVC_CD ,
        ux.INPAT_RQSTD_CD  as INPAT_RQSTD_CD ,
        ux.INPAT_AUTHRZD_CD  as INPAT_AUTHRZD_CD ,
        ux.RQSTD_PLACE_OF_SRVC_CD as RQSTD_PLACE_OF_SRVC_CD ,
        ux.RQSTD_PROC_SRVC_TYPE_CD as RQSTD_PROC_SRVC_TYPE_CD,
        """+load_log_key+""" as load_log_key,
				current_timestamp
       from 
        """ + dbInbnd + """.UM_RQST ur
        inner join """ + dbInbnd + """.UM_SRVC_STTS us
        on us.RFRNC_NBR = ur.RFRNC_NBR
        and us.CLNCL_SOR_CD = ur.CLNCL_SOR_CD
        inner join """ + dbInbnd + """.UM_SRVC ux
        on ux.RFRNC_NBR = us.RFRNC_NBR
        and ux.SRVC_LINE_NBR = us.SRVC_LINE_NBR
        and ux.CLNCL_SOR_CD= us.CLNCL_SOR_CD
       where 
        us.CLNCL_SOR_CD in (  '1036'  )
        and ur.UM_RQST_CREAT_DT BETWEEN  """+umRqstCreatFrmDt+ """  AND """+umRqstCreatToDt+ """ 
        and ur.CASE_TYPE_CD  IN  ( 'PHARMACY' )
        and ux.SRVC_RVW_TYPE_CD in ('P','PU','PNU')
        and ur.RCRD_STTS_CD not in ( 'DEL', 'DUP' )
        and us.UM_SRVC_STTS_CD not in ( 'NA' , 'UNK'   )
       group by 
        ur.MBR_KEY ,
        ur.UM_RQST_INITD_DT  ,
        ur.UM_RQST_CREAT_DT  ,
        ur.CASE_TYPE_CD  ,
        ur.AUTHRZN_STTS_CD  ,
        ur.RCRD_STTS_CD  ,
        us.CLNCL_SOR_CD  ,
        us.RFRNC_NBR  , 
        us.SRVC_LINE_NBR  ,
        us.UM_SRVC_STTS_CD  , 
        us.SRC_UM_SRVC_STTS_CD  , 
        us.STTS_DT  , 
        ux.SRVC_RVW_TYPE_CD  ,
        ux.AUTHRZD_PLACE_OF_SRVC_CD  ,
        ux.INPAT_RQSTD_CD   ,
        ux.INPAT_AUTHRZD_CD ,
        ux.RQSTD_PLACE_OF_SRVC_CD ,
        ux.RQSTD_PROC_SRVC_TYPE_CD
    """
  
        def pa_query5() = """Insert into table """ + dbWrk + """.naic2018_mcas_hlthex_paexphmcy_wrk1""" + 
    """
       select 
        ur.MBR_KEY as MBR_KEY,
        ur.UM_RQST_INITD_DT as UM_RQST_INITD_DT ,
        ur.UM_RQST_CREAT_DT as UM_RQST_CREAT_DT ,
        ur.CASE_TYPE_CD as CASE_TYPE_CD ,
        ur.AUTHRZN_STTS_CD as AUTHRZN_STTS_CD ,
        ur.RCRD_STTS_CD as RCRD_STTS_CD ,
        us.CLNCL_SOR_CD as  CLNCL_SOR_CD ,
        us.RFRNC_NBR as RFRNC_NBR , 
        us.SRVC_LINE_NBR as  SRVC_LINE_NBR ,
        us.UM_SRVC_STTS_CD as UM_SRVC_STTS_CD , 
        us.SRC_UM_SRVC_STTS_CD as SRC_UM_SRVC_STTS_CD , 
        us.STTS_DT as  STTS_DT , 
        ux.SRVC_RVW_TYPE_CD as SRVC_RVW_TYPE_CD ,
        ux.AUTHRZD_PLACE_OF_SRVC_CD as  AUTHRZD_PLACE_OF_SRVC_CD ,
        ux.INPAT_RQSTD_CD  as INPAT_RQSTD_CD ,
        ux.INPAT_AUTHRZD_CD  as INPAT_AUTHRZD_CD ,
        ux.RQSTD_PLACE_OF_SRVC_CD as RQSTD_PLACE_OF_SRVC_CD ,
        ux.RQSTD_PROC_SRVC_TYPE_CD as RQSTD_PROC_SRVC_TYPE_CD,
        """+load_log_key+""" as load_log_key,
				current_timestamp
       from 
        """ + dbInbnd + """.UM_RQST ur
        inner join """ + dbInbnd + """.UM_SRVC_STTS us
        on us.RFRNC_NBR = ur.RFRNC_NBR
        and us.CLNCL_SOR_CD = ur.CLNCL_SOR_CD
        inner join """ + dbInbnd + """.UM_SRVC ux
        on ux.RFRNC_NBR = us.RFRNC_NBR
        and ux.SRVC_LINE_NBR = us.SRVC_LINE_NBR
        and ux.CLNCL_SOR_CD= us.CLNCL_SOR_CD
       where 
        us.CLNCL_SOR_CD in (  '873'  )
        and ur.UM_RQST_CREAT_DT BETWEEN  """+umRqstCreatFrmDt+ """  AND """+umRqstCreatToDt+ """ 
        and ur.CASE_TYPE_CD  IN  ( 'PHARMACY' )
        and ux.SRVC_RVW_TYPE_CD in ('P','PU','PNU')
        and ur.RCRD_STTS_CD not in ( 'DEL', 'DUP' )
        and us.UM_SRVC_STTS_CD not in ( 'NA' , 'UNK'   )
        and ux.RQSTD_PLACE_OF_SRVC_CD <> '99'
        and ux.RQSTD_PROC_SRVC_TYPE_CD not in (  'NDC' , 'UNK' )
       group by 
        ur.MBR_KEY ,
        ur.UM_RQST_INITD_DT  ,
        ur.UM_RQST_CREAT_DT  ,
        ur.CASE_TYPE_CD  ,
        ur.AUTHRZN_STTS_CD  ,
        ur.RCRD_STTS_CD  ,
        us.CLNCL_SOR_CD  ,
        us.RFRNC_NBR  , 
        us.SRVC_LINE_NBR  ,
        us.UM_SRVC_STTS_CD  , 
        us.SRC_UM_SRVC_STTS_CD  , 
        us.STTS_DT  , 
        ux.SRVC_RVW_TYPE_CD  ,
        ux.AUTHRZD_PLACE_OF_SRVC_CD  ,
        ux.INPAT_RQSTD_CD   ,
        ux.INPAT_AUTHRZD_CD ,
        ux.RQSTD_PLACE_OF_SRVC_CD ,
        ux.RQSTD_PROC_SRVC_TYPE_CD
    """

  def sparkInIt() {
spark.sql(TrnctTbl)
    spark.sql(pa_query1())
   spark.sql(pa_query2())
    spark.sql(pa_query3())
    spark.sql(pa_query4())
    spark.sql(pa_query5())
  }

}

object PCADX_SCL_NAIC2018_PAEXPHMCY_WRK1 {
  def main(args: Array[String]) {
    PCADX_SCL_NAIC2018_EnvironValues.setFileName(args(0))
    new PCADX_SCL_NAIC2018_PAEXPHMCY_WRK1().sparkInIt()
    println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$")
  }
}